"""Recompute map-paired outcomes and apply the recorded development filters."""
import argparse, json, hashlib
from pathlib import Path
from compare import load_rows, comparison

p=argparse.ArgumentParser()
p.add_argument('paths',nargs='+',type=Path)
p.add_argument('--names',nargs='+',required=True)
p.add_argument('--out',required=True,type=Path)
p.add_argument('--screen',action='store_true')
a=p.parse_args()
root=Path(__file__).resolve().parent
folders=['maps','maps_gen']+([] if a.screen else ['maps_dev200'])
expected={hashlib.sha256(f.read_bytes()).hexdigest() for d in folders for f in (root/'arena'/d).glob('*.map26a')}
assert len(expected)==(53 if a.screen else 253), 'Unexpected development cohort'
rows=load_rows(a.paths)
results={n:comparison(rows,n) for n in a.names}
qualified=[]
for n,x in results.items():
    d,panel=x['original'],x['panel']
    for opponent in ('original','spar11','spar12','spar16'):
        actual={r['map_sha256'] for k,r in rows.items() if k[0]==n and k[1]==opponent}
        assert actual==expected, 'Incomplete/wrong candidate cohort: '+n+'/'+opponent
        if opponent!='original':
            base_actual={r['map_sha256'] for k,r in rows.items() if k[0]=='original' and k[1]==opponent and r['map_sha256'] in expected}
            assert base_actual==expected, 'Incomplete matched baseline cohort: '+opponent
    assert d['maps']==len(expected) and panel['maps']==len(expected)
    observed={r['key']:r for k,r in rows.items() if k[0]==n}
    for r in list(observed.values()):
        if r['opponent'] in ('spar11','spar12','spar16'):
            base=rows[('original',r['opponent'],r['map_sha256'],r['side'])]
            observed[base['key']]=base
    faults=sum(any(r['faults']) for r in observed.values())
    reinit=sum(any(v['reinitializations_observed'] for v in r['stdout'].values()) for r in observed.values())
    x['quality']={'physical_games':len(observed),'fault_games':faults,'reinitialization_games':reinit}
    direct=d['wins']+0.5*d['draws']
    passes_direct=direct>=d['games']/2 if a.screen else direct>d['games']/2
    passes=passes_direct and panel['score_delta']>0 and all(v['percentage_point_delta']>=-2 for v in x['spar'].values()) and faults==0 and reinit==0
    x['development_eligible']=passes
    if passes:qualified.append(n)
    print(f"{n:30} direct {d['wins']:4}-{d['losses']:<4} panel {panel['candidate_win_score']:5g}/{panel['original_win_score']:<5g} delta {panel['score_delta']:+5g} maps {panel['positive_maps']}/{panel['negative_maps']} spar {[v['score_delta'] for v in x['spar'].values()]} faults/reinit={faults}/{reinit} eligible={passes}")
qualified.sort(key=lambda n:(-results[n]['panel']['score_delta'],n))
out={'comparisons':results,'eligible_ranked':qualified,'screen':a.screen,
     'limits':'Development selection only; p-values are descriptive after multiple/adaptive comparisons.'}
a.out.parent.mkdir(parents=True,exist_ok=True)
a.out.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print('Eligible ranked:',qualified)
