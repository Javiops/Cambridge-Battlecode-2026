"""Independent pre-freeze combination/ablation audit; writes combo-audit.json.

Does not call the production comparator/analyzer or run games. Integer
half-point scores are clustered by map; the pre-run8-win rule is kept exact.
"""
from collections import Counter
from pathlib import Path
import json, math, sys
from datetime import datetime, timezone
sys.dont_write_bytecode=True
import audit_export as evidence

ROOT=Path(__file__).resolve().parent
SPARS=('spar11','spar12','spar16')

def require(ok,message):
    if not ok:raise RuntimeError(message)
def sign(positive,negative):
    n=positive+negative
    return min(1.,2*sum(math.comb(n,k) for k in range(min(positive,negative)+1))/2**n) if n else 1.
def points(row):
    return 1 if row['outcome']=='draw' else 2*int((row['outcome']=='teamA')==(row['side']==0))
def main():
    expected={evidence.sha(p) for folder in ('maps','maps_gen','maps_dev200') for p in (ROOT/'arena'/folder).glob('*.map26a')}
    require(len(expected)==253,'Full-development cohort differs')
    observed={};sources={};stage_proofs={}
    for stage in ('combat-baseline','combat-full','combat-combo'):
        path=ROOT/'results'/f'{stage}.json';plan_path=ROOT/'stages'/f'{stage}-plan.json'
        plan=evidence.read(plan_path)['plan'];meta={};expected_slots=Counter((s['candidate'],s['opponent'],s['map_sha256'],s['side'],s['key']) for s in plan['slots'])
        keys=set();fresh=set();rows=0
        for name,source in plan['sources'].items():
            if name in sources:require(sources[name]==source,'Source manifest changed')
            sources[name]=source
        for row in evidence.stage_rows(path,meta):
            slot=(row['candidate'],row['opponent'],row['map_sha256'],row['side'],row['key'])
            require(expected_slots[slot]>0,'Duplicate or unplanned screen slot');expected_slots[slot]-=1
            evidence.verify_row(row)
            raw=row['statistics']
            for metric in ('deaths','kills'):
                require(row[metric]==[sum(c[metric] for c in raw['champions'] if c['team']==t) for t in (0,1)],'Derived champion metric differs')
            for metric in ('championDamageDone','championDamageTaken'):
                require(row[metric]==[sum(c.get(metric,0) for c in raw['champions'] if c['team']==t) for t in (0,1)],'Derived damage metric differs')
            require(row['identity']['runtime']==plan['runtime'],'Runtime differs from stage plan')
            a,b=(row['candidate'],row['opponent']) if row['side']==0 else (row['opponent'],row['candidate'])
            require(row['identity']['wasm_a_sha256']==plan['sources'][a]['wasm_sha256'] and row['identity']['wasm_b_sha256']==plan['sources'][b]['wasm_sha256'],'WASM order differs from plan')
            keys.add(row['key']);rows+=1
            if not row['cached']:fresh.add(row['key'])
            value={k:row[k] for k in ('candidate','opponent','map_sha256','side','key','outcome','identity','faults','stdout','gems','deaths','kills','championDamageDone','championDamageTaken')}
            view=slot[:4]
            if view in observed:require(observed[view]==value,'Conflicting repeated semantic view')
            observed[view]=value
        require(all(v==0 for v in expected_slots.values()),'Stage coverage incomplete')
        require(meta['plan_sha256']==evidence.sha(plan_path),'Result plan SHA differs')
        require(len(keys)==meta['unique_physical_games'] and len(fresh)==meta['new_unique_games'],'Physical/new count differs')
        stage_proofs[stage]={'semantic_rows':rows,'physical_inputs':len(keys),'new_inputs':len(fresh),'cached_inputs':len(keys)-len(fresh),'result_sha256':meta['_file_sha256'],'plan_sha256':meta['plan_sha256']}
    for name,source in sources.items():
        current={p.name:evidence.sha(p) for p in (ROOT/'arena/bots'/name/'src').iterdir() if p.is_file()}
        require(current==source['source_sha256'],'Current source differs: '+name)
        require(evidence.sha(ROOT/'arena/bots'/name/'.cambc/build/bot-injected.wasm')==source['wasm_sha256'],'Current compiled WASM differs: '+name)
        for module,h in source.get('patch_modules_sha256',{}).items():require(evidence.sha(ROOT/module)==h,'Frozen module changed')
    single_report=evidence.read(ROOT/'full-comparison.json');combo_report=evidence.read(ROOT/'combo-comparison.json')
    reported={'comparisons':{**single_report['comparisons'],**combo_report['comparisons']}}
    names=sorted(reported['comparisons']);computed={};eligible=[];metrics={}
    for name in names:
        direct=[observed[(name,'original',m,s)] for m in expected for s in (0,1)]
        wins=sum(points(r)==2 for r in direct);losses=sum(points(r)==0 for r in direct);draws=sum(points(r)==1 for r in direct)
        both_won=sum(all(points(observed[(name,'original',m,s)])==2 for s in (0,1)) for m in expected)
        both_lost=sum(all(points(observed[(name,'original',m,s)])==0 for s in (0,1)) for m in expected)
        spar={};map_deltas={m:0 for m in expected};quality={r['key']:r for r in direct};candidate_total=baseline_total=0
        for opponent in SPARS:
            cs=bs=0;delta={m:0 for m in expected}
            for m in expected:
                for side in (0,1):
                    c=observed[(name,opponent,m,side)];b=observed[('original',opponent,m,side)]
                    team='b' if side==0 else 'a'
                    require(c['identity']['wasm_'+team+'_sha256']==b['identity']['wasm_'+team+'_sha256'] and c['identity']['runtime']==b['identity']['runtime'],'Matched spar source/runtime differs')
                    x,y=points(c),points(b);cs+=x;bs+=y;delta[m]+=x-y;map_deltas[m]+=x-y
                    quality[c['key']]=c;quality[b['key']]=b
            candidate_total+=cs;baseline_total+=bs
            positive=sum(v>0 for v in delta.values());negative=sum(v<0 for v in delta.values())
            spar[opponent]={'candidate_win_score':cs/2,'original_win_score':bs/2,'score_delta':(cs-bs)/2,'percentage_point_delta':100*(cs-bs)/(2*506),'positive_maps':positive,'negative_maps':negative,'p_two_sided':sign(positive,negative)}
        # The combo stage also contains both component-ablation opponents;
        # every candidate game belongs in the same all-side quality gate.
        for view,row in observed.items():
            if view[0]==name:quality[row['key']]=row
        faults=sum(any(r['faults']) for r in quality.values());reinit=sum(any(s['reinitializations_observed'] for s in r['stdout'].values()) for r in quality.values())
        positive=sum(v>0 for v in map_deltas.values());negative=sum(v<0 for v in map_deltas.values())
        passes=2*wins+draws>506 and candidate_total>baseline_total and all(v['percentage_point_delta']>=-2 for v in spar.values()) and faults==0 and reinit==0
        actual={'original':{'wins':wins,'losses':losses,'draws':draws,'both_won':both_won,'both_lost':both_lost,'p_two_sided':sign(both_won,both_lost)},
            'spar':spar,'panel':{'candidate_win_score':candidate_total/2,'original_win_score':baseline_total/2,'score_delta':(candidate_total-baseline_total)/2,'positive_maps':positive,'negative_maps':negative,'neutral_maps':253-positive-negative,'p_two_sided':sign(positive,negative)},
            'quality':{'physical_games':len(quality),'fault_games':faults,'reinitialization_games':reinit},'development_eligible':passes}
        r=reported['comparisons'][name]
        for section in ('original','panel','quality'):
            require(all(r[section][key]==value for key,value in actual[section].items()),'Reported comparator differs: '+name+'/'+section)
        for opponent in SPARS:require(all(r['spar'][opponent][key]==value for key,value in spar[opponent].items()),'Reported spar comparator differs')
        require(r['development_eligible']==passes,'Reported promotion gate differs')
        if passes:eligible.append(name)
        computed[name]=actual
        direct_metrics={};panel_metrics={}
        for metric in ('gems','deaths','kills','championDamageDone','championDamageTaken'):
            direct_metrics[metric+'_candidate_minus_opponent_mean']=sum(r[metric][r['side']]-r[metric][1-r['side']] for r in direct)/len(direct)
            diffs=[]
            for opponent in SPARS:
                for m in expected:
                    for side in (0,1):
                        c=observed[(name,opponent,m,side)];b=observed[('original',opponent,m,side)]
                        diffs.append(c[metric][side]-b[metric][side])
            panel_metrics[metric+'_candidate_own_minus_baseline_own_mean']=sum(diffs)/len(diffs)
        metrics[name]={'direct':direct_metrics,'matched_spar_panel':panel_metrics,'limits':'Descriptive final-game totals on the same pinned opponent/map/side panel; these are not causal per-turn mechanism estimates or selection criteria.'}
    eligible.sort(key=lambda n:(-computed[n]['panel']['score_delta'],n))
    require(eligible==['cm_combo_aoe_dash','cm_sweep_aoe_edge','cm_dash_cd_reach'],'Full-development rank differs')
    combo='cm_combo_aoe_dash';components=('cm_sweep_aoe_edge','cm_dash_cd_reach');ablations={}
    published_ablations=evidence.read(ROOT/'combo-ablations.json');all_combo_quality={}
    for opponent in components:
        rs=[observed[(combo,opponent,m,side)] for m in expected for side in (0,1)]
        bw=sum(all(points(observed[(combo,opponent,m,s)])==2 for s in (0,1)) for m in expected)
        bl=sum(all(points(observed[(combo,opponent,m,s)])==0 for s in (0,1)) for m in expected)
        val={'wins':sum(points(r)==2 for r in rs),'losses':sum(points(r)==0 for r in rs),'both_won':bw,'both_lost':bl,'p':sign(bw,bl)}
        require(val==published_ablations[opponent],'Reported component ablation differs')
        ablations[opponent]=val
        for row in rs:all_combo_quality[row['key']]=row
    for view,row in observed.items():
        if view[0]==combo or (view[0]=='original' and view[1] in SPARS):all_combo_quality[row['key']]=row
    all_faults=sum(any(r['faults']) for r in all_combo_quality.values())
    all_reinit=sum(any(s['reinitializations_observed'] for s in r['stdout'].values()) for r in all_combo_quality.values())
    plan_path=ROOT/'combination-plan.txt';text=plan_path.read_text(encoding='utf-8')
    require('at least8 wins' in text,'Recorded simplicity threshold differs')
    plan_written=datetime.fromtimestamp(plan_path.stat().st_mtime,timezone.utc)
    combo_stage_created=evidence.timestamp(evidence.read(ROOT/'stages/combat-combo-plan.json')['created_utc'])
    require(plan_written<=combo_stage_created,'Combination criterion file changed after combo stage plan')
    panel=computed[combo]['panel']['candidate_win_score']
    component_scores={c:computed[c]['panel']['candidate_win_score'] for c in components}
    increment=panel-max(component_scores.values())
    gates={'standard_full_development':computed[combo]['development_eligible'],
        'panel_improves_on_both_components':all(panel>value for value in component_scores.values()),
        'at_least8_panel_wins_over_stronger_single':increment>=8,
        'nonlosing_both_direct_component_ablations':all(v['wins']>=v['losses'] for v in ablations.values()),
        'all_side_quality_including_component_ablations_and_baseline':all_faults==0 and all_reinit==0,
        'criterion_recorded_before_combo_plan':True}
    chosen=combo if all(gates.values()) else max(components,key=lambda c:component_scores[c])
    decision={'candidate':chosen,'gates':gates,'combo_panel_score':panel,'component_panel_scores':component_scores,
        'panel_win_increment_over_stronger_single':increment,'minimum_increment':8,
        'ablations':ablations,'fault_games':all_faults,'reinitialization_games':all_reinit,
        'criterion_file_sha256':evidence.sha(plan_path),'criterion_last_modified_utc':plan_written.isoformat(),
        'combo_stage_plan_created_utc':combo_stage_created.isoformat(),
        'limits':'Development selection only. AoE incremental head-to-head is weak; no component is independently fresh-confirmed. Only one frozen full candidate may advance to the pre-recorded confirmation.'}
    output={'passed':True,'created_utc':evidence.now(),'method':'Independent integer half-point recomputation from raw stage rows; production compare.py/analyze_stage.py not imported. Exact253map cohort and all original/spar sides; clustered per-map sign tests; source/WASM/runtime identity and quality includes baseline.',
        'maps':253,'stage_proofs':stage_proofs,'eligible_ranked':eligible,'comparisons':computed,'metrics':metrics,'decision':decision,'new_games_from_audit':0,'scope':'Combined development and direct component ablations only. Development p-values are descriptive.'}
    (ROOT/'combo-audit.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'passed':True,'decision':decision,'stage_proofs':stage_proofs},indent=2))

if __name__=='__main__':main()
