"""Independent streaming audit of the complete, frozen confirmation.

Read-only except for exclusive creation of confirmation-audit.json. No games,
builds, maps, candidate changes, selection or remote actions are performed.
Historical orchestration-source provenance remains explicitly qualified.
"""
from __future__ import annotations
from collections import Counter
from datetime import datetime, timezone
import ast
import hashlib
import json
import math
from pathlib import Path
import sys
import zipfile

sys.dont_write_bytecode=True
from audit_export import stage_rows
from generate_confirmation import validate_freeze, guard
from confirm import verify_generation
from test_matches import audit_stdout

ROOT=Path(__file__).resolve().parent
SPARS=('spar11','spar12','spar16')


def require(ok,message):
    if not ok:raise RuntimeError(message)


def sha(path):
    value=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):value.update(block)
    return value.hexdigest()


def read(path):return json.loads(Path(path).read_text(encoding='utf8'))
def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def stamp(value):
    result=datetime.fromisoformat(value.replace('Z','+00:00'))
    require(result.tzinfo is not None,'Naive evidence timestamp')
    return result.astimezone(timezone.utc)


def sign_p(positive,negative):
    n=positive+negative
    return min(1.,2*sum(math.comb(n,k) for k in range(min(positive,negative)+1))/2**n) if n else 1.


def main():
    started=datetime.now(timezone.utc).isoformat();self_pin=sha(Path(__file__))
    freeze,plan=validate_freeze();generation,manifest=verify_generation(freeze,plan)
    name=freeze['candidate'];maps={m['sha256'] for m in manifest['maps']}
    require(len(maps)==plan['confirmation']['maps']==1024,'Wrong fixed cohort size')
    require(sha(ROOT/'selection.json')==freeze['selection_sha256'],'Development selection changed after freeze')
    for module,pin in freeze['patch_modules_sha256'].items():require(sha(guard(ROOT/module))==pin,'Frozen patch module changed')
    recovery=read(ROOT/'orchestration-recovery.json');addendum=read(ROOT/'recovery-provenance-addendum.json')
    review=read(ROOT/'recovery-provenance-review.json');verdict=read(ROOT/'confirmation-verdict.json')
    pins={p:sha(guard(ROOT/p)) for p in ('freeze.json','generation.json','selection-plan.json','selection.json',
        'orchestration-recovery.json','recovery-provenance-addendum.json','recovery-provenance-review.json',
        'test_matches.pre-recovery.py','test_matches.py','confirm.py','generate_confirmation.py','compare.py','audit_export.py',
        'confirmation-verdict.json')}
    require(addendum['recovery_manifest_sha256']==pins['orchestration-recovery.json'],'Recovery addendum binds different manifest')
    require(addendum['current_harness_sha256']==recovery['harness_after']['sha256']==pins['test_matches.py'],'Current repair hash differs')
    require(addendum['archived_pre_repair_harness']['sha256']==recovery['harness_before']['sha256']==pins['test_matches.pre-recovery.py'],'Archived repair hash differs')
    require(review['historical_probe_hash']==addendum['conflicting_independent_probe']['reported_sha256'],'Hash caveat record differs')
    require(addendum['conflicting_independent_probe']['source_bytes_available'] is False,'Historical caveat unexpectedly changed')
    require(recovery['freeze_sha256']==pins['freeze.json'] and recovery['generation_record_sha256']==pins['generation.json'],'Recovery freeze/generation differs')
    functions=lambda p:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef)}
    before,after=functions(ROOT/'test_matches.pre-recovery.py'),functions(ROOT/'test_matches.py')
    require(all(before[n]==after[n] for n in recovery['unchanged_function_ast']),'Identity/statistics/cache functions changed in repair')
    recovered={r['key']:r for r in recovery['recovered_current_experiment_inputs']}
    require(len(recovered)==recovery['recovered_count']==6143,'Unexpected recovered inventory')
    require(sha(ROOT/'recovery-contracts.json')==recovery['pure_contracts_sha256'],'Pure repair contracts changed')
    for artifact in recovery['failure_artifacts']:
        path=guard(ROOT/artifact['path']);require(sha(path)==artifact['sha256'],'Failed-launch artifact changed')
        failure=read(path)
        require(failure['returncode']!=0 and 'failed to persist temporary file: Access is denied' in failure['log'],'Failure is not the specific launch error')
        require(not(path.parent/'statistics.json').exists() and not list(path.parent.glob('*.repl26a')),'Failed attempt contains possible game output')

    wasm={name:freeze['wasm_sha256'],**freeze['reference_wasm_sha256']}
    observed={};scores={};cache_pins={};stage_pins={};stage_summary={};replays={};recovered_seen=set()
    faults=reinit=caught=low_fuel=0
    configs=(('confirmation-baseline',['original'],list(SPARS),6144),
             ('confirmation-candidate',[name],['original',*SPARS],8192))
    for stage,names,opponents,count in configs:
        result_path=guard(ROOT/'results'/f'{stage}.json');plan_path=guard(ROOT/'stages'/f'{stage}-plan.json')
        envelope=read(plan_path);stage_plan=envelope['plan'];plan_pin=sha(plan_path)
        require(stage_plan['stage']==stage and stage_plan['names']==names and stage_plan['opponents']==opponents,'Wrong stage scope')
        require(stage_plan['runtime']==freeze['runtime'],'Stage runtime differs from freeze')
        require(stamp(envelope['created_utc'])>=stamp(generation['finished_utc']),'Stage plan predates generated cohort')
        require(set(stage_plan['maps'].values())==maps and len(stage_plan['maps'])==1024,'Wrong stage maps')
        require(stage_plan['semantic_games']==stage_plan['unique_physical_games']==count,'Wrong planned stage size')
        for alias,record in stage_plan['sources'].items():
            require(record['wasm_sha256']==wasm[alias],'Stage source/WASM differs from freeze')
            current=read(ROOT/'candidates'/f'{alias}.json')
            require(record==current,'Stage registration differs from current pinned registration')
        expected={(n,o,h,side) for n in names for o in opponents for h in maps for side in (0,1)}
        slot_keys={(s['candidate'],s['opponent'],s['map_sha256'],s['side']):s['key'] for s in stage_plan['slots']}
        require(len(expected)==len(stage_plan['slots'])==len(slot_keys)==count and set(slot_keys)==expected,'Incomplete/duplicate planned slots')
        if stage=='confirmation-baseline':
            require(plan_pin==recovery['original_stage_plan_sha256'],'Resumed stage plan differs')
            require(set(slot_keys.values())-set(recovered)==set(recovery['missing_keys_before_resume']),'Recovery partition differs from stage')
        seen=set();meta={};cached_count=0;last_created=stamp(generation['finished_utc'])
        stage_pin=sha(result_path)
        for row in stage_rows(result_path,meta):
            slot=(row['candidate'],row['opponent'],row['map_sha256'],row['side'])
            require(type(row['side']) is int and slot in expected and slot not in seen,'Missing/extra/duplicate semantic slot')
            seen.add(slot);candidate,opponent,h,side=slot
            a,b=(candidate,opponent) if side==0 else (opponent,candidate)
            identity={'wasm_a_sha256':wasm[a],'wasm_b_sha256':wasm[b],'map_sha256':h,'runtime':freeze['runtime']}
            key=hashlib.sha256(json.dumps(identity,sort_keys=True,separators=(',',':')).encode()).hexdigest()
            require(row['identity']==identity and row['key']==key==slot_keys[slot],'Ordered physical input identity differs')
            require(key not in observed,'Unexpected duplicate physical confirmation input')
            require(row['valid'] is True and row['schema_version']==2,'Invalid completed row')
            created=stamp(row['created_utc']);require(stamp(generation['finished_utc'])<=created<=datetime.now(timezone.utc),'Invalid game timestamp')
            last_created=max(last_created,created)
            data=row['statistics'];require(hashlib.sha256(canonical(data)).hexdigest()==row['statistics_content_sha256'],'Statistics content hash differs')
            require(isinstance(data['teams'],list) and len(data['teams'])==2,'Invalid native team count')
            require(data['schemaVersion']==2 and str(data['engineVersion'])=='0.0.1','Unexpected native statistics version')
            require(type(data['round']) is int and 1<=data['round']<=2000,'Invalid round')
            require(data['outcome'] in ('teamA','teamB','draw'),'Invalid outcome')
            require(isinstance(data['botFaults'],list) and len(data['botFaults'])==2 and all(type(v) is int and v>=0 for v in data['botFaults']),'Invalid faults')
            derived={'outcome':data['outcome'],'rounds':data['round'],'gems':[t['submittedGems'] for t in data['teams']],
                     'faults':data['botFaults'],'engine_version':data['engineVersion'],'statistics_schema':data['schemaVersion']}
            for field in ('deaths','kills','collectedGems','championDamageDone','championDamageTaken','monsterDamageDone','monsterDamageTaken'):
                if field in row:derived[field]=[sum(c.get(field,0) for c in data['champions'] if c['team']==t) for t in (0,1)]
            require(all(row[k]==v for k,v in derived.items()),'Statistics-derived game field differs')
            require(set(row['stdout'])=={'a','b'},'Missing team diagnostics')
            repeated=False
            for diagnostic in row['stdout'].values():
                counts=diagnostic['initializations'];require(isinstance(counts,dict) and all(type(v) is int and v>=1 for v in counts.values()),'Invalid initialization count')
                computed=sum(v-1 for v in counts.values())
                require(type(diagnostic['reinitializations_observed']) is int and computed==diagnostic['reinitializations_observed'],'Repeated-initialization marker mismatch')
                repeated|=computed>0;caught+=sum(diagnostic['caught_errors'].values());low_fuel+=diagnostic['low_fuel_logged']
            faults+=any(data['botFaults']);reinit+=repeated
            cache_path=guard(ROOT/'game-cache'/(key+'.json'));cache_bytes=cache_path.read_bytes();cache_pin=hashlib.sha256(cache_bytes).hexdigest()
            cache=json.loads(cache_bytes);require(all(row.get(k)==v for k,v in cache.items()),'Result differs from its exact-key cache')
            require(not cache.get('imported_cache'),'Unexpected historical cache import for new confirmation maps')
            cache_pins[key]=cache_pin;require(type(row['cached']) is bool,'Invalid cache status')
            cached_count+=row['cached']
            if key in recovered:
                old=recovered[key];require(stage=='confirmation-baseline' and row['cached'] is True,'Recovered game not reused in baseline')
                require(cache_pin==old['cache_file_sha256'] and row['created_utc']==old['created_utc'],'Recovered cache bytes or creation timestamp changed')
                require(stamp(envelope['created_utc'])<=created<stamp(recovery['created_utc']),'Recovered game outside original pre-resume window')
                recovered_seen.add(key)
            else:require(row['cached'] is False,'Unexpected cached nonrecovered confirmation input')
            if row.get('retained_replay'):
                replay=guard(ROOT/row['retained_replay']);require(sha(replay)==row['replay_sha256'],'Retained replay differs')
                with zipfile.ZipFile(replay) as archive:
                    require(archive.testzip() is None,'Retained replay CRC failure')
                    for team in ('a','b'):
                        parsed=audit_stdout(archive.read('team-'+team+'.stdout').decode('utf8',errors='replace'))
                        require(parsed==row['stdout'][team],'Retained stdout differs from recorded quality diagnostics')
                replays[key]=row['replay_sha256']
            winner={'teamA':0,'teamB':1,'draw':-1}[row['outcome']]
            scores[slot]=1 if winner==-1 else 2 if winner==side else 0
            observed[key]=slot
        require(seen==expected,'Incomplete completed stage')
        require(meta['stage']==stage and meta['plan_sha256']==plan_pin,'Stage metadata/plan differs')
        require(meta['semantic_games']==meta['unique_physical_games']==count,'Completed stage size differs')
        require(meta['cached_unique_games']==cached_count and meta['new_unique_games']==count-cached_count,'Stage cache counts differ')
        require(meta['prior_experiment_cache_origin_games']==0,'Incorrect historical confirmation cache imports')
        require(stamp(meta['completed_utc'])>=last_created,'Stage marked complete before a game')
        require(sha(result_path)==stage_pin==meta['_file_sha256'] and sha(plan_path)==plan_pin,'Stage changed during audit')
        stage_pins[str(result_path.resolve())]=stage_pin
        stage_summary[stage]={'semantic_slots':len(seen),'unique_physical_inputs':count,'recovered_local_cache_games':cached_count,
                              'executed_on_resumed_invocation':count-cached_count,'stage_completed_utc':meta['completed_utc']}
        print(f'Audited {stage}: {len(seen)} complete slots and cache records',flush=True)
    require(len(scores)==len(observed)==len(cache_pins)==14336 and recovered_seen==set(recovered),'Global confirmation/recovery coverage differs')

    direct=[scores[(name,'original',h,side)] for h in maps for side in (0,1)]
    both_won=sum(all(scores[(name,'original',h,side)]==2 for side in (0,1)) for h in maps)
    both_lost=sum(all(scores[(name,'original',h,side)]==0 for side in (0,1)) for h in maps)
    comparison={'candidate':name,'spar':{},'original':{'games':2048,'maps':1024,'wins':direct.count(2),'losses':direct.count(0),
        'draws':direct.count(1),'both_won':both_won,'both_lost':both_lost,'p_two_sided':sign_p(both_won,both_lost)}}
    panel_map=Counter();panel_candidate=panel_original=0
    for spar in SPARS:
        per_map={h:sum(scores[(name,spar,h,side)]-scores[('original',spar,h,side)] for side in (0,1)) for h in maps}
        positive=sum(v>0 for v in per_map.values());negative=sum(v<0 for v in per_map.values())
        candidate=sum(scores[(name,spar,h,side)] for h in maps for side in (0,1))/2
        original=sum(scores[('original',spar,h,side)] for h in maps for side in (0,1))/2
        comparison['spar'][spar]={'games':2048,'maps':1024,'candidate_win_score':candidate,'original_win_score':original,
            'score_delta':candidate-original,'percentage_point_delta':100*(candidate-original)/2048,
            'positive_maps':positive,'negative_maps':negative,'p_two_sided':sign_p(positive,negative)}
        panel_map.update(per_map);panel_candidate+=candidate;panel_original+=original
    positive=sum(v>0 for v in panel_map.values());negative=sum(v<0 for v in panel_map.values())
    comparison['panel']={'games':6144,'maps':1024,'candidate_win_score':panel_candidate,'original_win_score':panel_original,
        'score_delta':panel_candidate-panel_original,'percentage_point_delta':100*(panel_candidate-panel_original)/6144,
        'positive_maps':positive,'negative_maps':negative,'neutral_maps':sum(v==0 for v in panel_map.values()),'p_two_sided':sign_p(positive,negative)}
    direct_result=comparison['original'];panel=comparison['panel']
    gates={'positive_original':direct_result['wins']>direct_result['losses'],'original_p':direct_result['p_two_sided']<0.05,
        'positive_panel_mean':panel['score_delta']>0,'positive_panel_map_direction':positive>negative,'panel_p':panel['p_two_sided']<0.05,
        'per_spar_tolerance':all(v['percentage_point_delta']>=-1 for v in comparison['spar'].values()),'faults_and_reinitializations':faults==0 and reinit==0}
    require(verdict['comparison']==comparison and verdict['gates']==gates and verdict['passes']==all(gates.values()),'Independent outcomes/gates disagree with frozen verifier')
    require(verdict['semantic_confirmation_slots']==verdict['unique_physical_games']==14336 and verdict['fault_games']==faults and verdict['reinitialization_games']==reinit,'Verifier quality/coverage differs')
    require(verdict['result_files_sha256']==stage_pins and verdict['freeze_sha256']==pins['freeze.json'] and verdict['generation_record_sha256']==pins['generation.json'],'Verifier evidence pins differ')
    validate_freeze();verify_generation(freeze,plan)
    require(all(sha(guard(ROOT/p))==pin for p,pin in pins.items()) and sha(Path(__file__))==self_pin,'Pinned evidence/tool changed during audit')
    out={'audit_completed':True,'started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),'audit_script_sha256':self_pin,
        'candidate':name,'independently_recomputed_gates_pass':all(gates.values()),'agrees_with_frozen_verifier':True,'comparison':comparison,'gates':gates,
        'semantic_confirmation_slots':len(scores),'unique_physical_games':len(observed),'maps':len(maps),'fault_games_both_teams':faults,
        'observed_reinitialization_games_both_teams':reinit,'caught_error_samples_both_teams':caught,'sampled_low_fuel_log_entries_both_teams':low_fuel,
        'recovered_current_experiment_cache_bytes_verified_unchanged':len(recovered_seen),'historical_cache_imports_in_confirmation':0,
        'executed_on_resumed_invocations':sum(s['executed_on_resumed_invocation'] for s in stage_summary.values()),
        'retained_replay_sha_and_crc_checks':len(replays),'cache_inventory_sha256':hashlib.sha256(canonical(cache_pins)).hexdigest(),
        'stages':stage_summary,'result_files_sha256':stage_pins,'evidence_and_tool_sha256':pins,
        'historical_harness_provenance_status':'QUALIFIED: isolated raw70e90d probe conflicts with older+archived141fded and cannot be reconstructed. No continuous historical orchestration-byte identity claim. Current frozen bot/WASM/runtime/map and all final row/cache integrity checks passed separately.',
        'limits':'One frozen candidate and fixed procedural1024-map distribution versus pinned original and three fixed older spars. Team size is coupled to symmetry; all generated fingerprints are Unknown, dimensions24..72, actual roster/branch activity is not inferred from geometry. Caught SDK errors and sampled low-fuel logs are diagnostics, not automatic fault gates or exact native exhaustion. No games, maps, tuning, source changes or remote actions performed by this audit.'}
    with guard(ROOT/'confirmation-audit.json').open('x',encoding='utf8') as stream:stream.write(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2));return 0


if __name__=='__main__':
    try:raise SystemExit(main())
    except (RuntimeError,OSError,ValueError,KeyError) as error:
        print('INDEPENDENT CONFIRMATION AUDIT FAILED: '+str(error),file=sys.stderr);raise SystemExit(1)
