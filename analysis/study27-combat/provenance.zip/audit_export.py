#!/usr/bin/env python3
"""Read-only unique-input audit; optionally export compact experiment evidence.

Default: print an audit snapshot, without changing experiment files. --export
DIR writes only new deliverables in a task-local directory. It never starts a
CLI/game/build, creates maps, edits source, or contacts a remote service.
Large pretty-printed result stages are decoded one row at a time using stdlib.
"""
from __future__ import annotations
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
import codecs
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import re
import stat
import sys
import time
import zipfile

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
ARENA=ROOT/'arena'
PRIOR_ROOT=ROOT.parent/'study27-micro'
LIMIT=25_000_000
SCRIPT_SHA256=None

def require(ok,message):
    if not ok:raise RuntimeError(message)
def now():return datetime.now(timezone.utc).isoformat()
def digest(data):return hashlib.sha256(data).hexdigest()
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def canonical(value):return json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
def timestamp(value):return datetime.fromisoformat(value.replace('Z','+00:00'))
def relative(path):return Path(path).relative_to(ROOT).as_posix()
def sanitize(value):
    if isinstance(value,dict):return {k:sanitize(v) for k,v in value.items()}
    if isinstance(value,list):return [sanitize(v) for v in value]
    if isinstance(value,str):
        for prefix,label in ((str(ROOT),'TASK'),(str(ROOT.parent),'WORK'),(str(Path.home()),'USER')):
            value=value.replace(prefix,label).replace(prefix.replace('\\','/'),label)
    return value
def plain_path(path,boundary):
    path=Path(path).absolute();boundary=Path(boundary).absolute();require(path.is_relative_to(boundary),'Path escapes its declared boundary')
    cursor=path
    while True:
        try:info=cursor.lstat()
        except FileNotFoundError:info=None
        if info is not None:
            require(not stat.S_ISLNK(info.st_mode) and not(getattr(info,'st_file_attributes',0)&0x400),'Refusing output redirect '+str(cursor))
        if cursor==boundary:break
        cursor=cursor.parent
    require(path.resolve()==path,'Export path redirects');return path
def output_guard(path):return plain_path(path,ROOT)

class JSONStream:
    """Incremental root-object reader; keeps only one game object in memory."""
    def __init__(self,path):
        self.stream=Path(path).open('rb');self.buffer='';self.pos=0;self.eof=False
        self.decoder=json.JSONDecoder();self.utf8=codecs.getincrementaldecoder('utf8')();self.hash=hashlib.sha256()
    def close(self):self.stream.close()
    def more(self):
        if self.eof:return False
        if self.pos:self.buffer=self.buffer[self.pos:];self.pos=0
        block=self.stream.read(1024*1024)
        self.hash.update(block)
        if not block:self.eof=True
        self.buffer+=self.utf8.decode(block,final=self.eof)
        return bool(block)
    def peek(self):
        while True:
            while self.pos<len(self.buffer) and self.buffer[self.pos].isspace():self.pos+=1
            if self.pos<len(self.buffer):return self.buffer[self.pos]
            if not self.more():return ''
    def token(self,wanted):
        require(self.peek()==wanted,'Malformed JSON token, expected '+wanted);self.pos+=1
    def value(self):
        self.peek()
        while True:
            try:value,end=self.decoder.raw_decode(self.buffer,self.pos)
            except json.JSONDecodeError:
                require(self.more(),'Malformed/incomplete JSON value');continue
            # A scalar may end at a chunk boundary midway through its token.
            if end==len(self.buffer) and not self.eof:
                self.more();continue
            if end<len(self.buffer) and not (self.buffer[end].isspace() or self.buffer[end] in ',:]}'):
                require(self.more(),'Malformed JSON token continuation');continue
            self.pos=end;return value

def stage_rows(path,metadata):
    stream=JSONStream(path);seen=False
    try:
        stream.token('{')
        while stream.peek()!='}':
            key=stream.value();require(isinstance(key,str),'Invalid root key');stream.token(':')
            if key=='games':
                require(not seen,'Duplicate root games key');seen=True;stream.token('[')
                while stream.peek()!=']':
                    row=stream.value();require(isinstance(row,dict),'Invalid game row');yield row
                    if stream.peek()!=']':
                        stream.token(',');require(stream.peek()!=']','Trailing comma in games array')
                stream.token(']')
            else:
                require(key not in metadata,'Duplicate result metadata key');metadata[key]=stream.value()
            if stream.peek()!='}':
                stream.token(',');require(stream.peek()!='}','Trailing comma in root object')
        stream.token('}');require(stream.peek()=='','Trailing result data');require(seen,'Missing games array')
        metadata['_file_sha256']=stream.hash.hexdigest()
    finally:stream.close()

def physical_key(identity):
    # Must match test_matches.py: default ensure_ascii=True in the identity hash.
    return digest(json.dumps(identity,sort_keys=True,separators=(',',':')).encode())
def compact(row):
    fields=('key','created_utc','outcome','rounds','gems','deaths','kills','faults','engine_version','statistics_schema',
            'statistics_sha256','statistics_content_sha256','replay_sha256','stdout',
            'collectedGems','championDamageDone','championDamageTaken','monsterDamageDone','monsterDamageTaken')
    result={k:row[k] for k in fields if k in row}
    result['identity']=row['identity']
    if row.get('imported_cache'):result['imported_cache']=row['imported_cache']
    result['execution_attempts']=len(row.get('execution_attempts',[]))
    result['pre_game_access_denied_retries']=sum(a.get('pre_game_access_denied_retry',False) for a in row.get('execution_attempts',[]))
    return result
def verify_row(row):
    require(row.get('valid') and row.get('schema_version')==2,'Unexpected cache schema')
    require(physical_key(row['identity'])==row['key'],'Physical key mismatch')
    require(row['engine_version']=='0.0.1' and row['statistics_schema']==2,'Unexpected engine/stats version')
    data=row['statistics'];require(digest(canonical(data))==row['statistics_content_sha256'],'Canonical statistics hash mismatch')
    for field,source in (('outcome','outcome'),('rounds','round'),('faults','botFaults'),('engine_version','engineVersion'),('statistics_schema','schemaVersion')):
        require(row[field]==data[source],'Derived field mismatch: '+field)
    require(row['gems']==[t['submittedGems'] for t in data['teams']],'Gem totals mismatch')
    require(isinstance(row['faults'],list) and len(row['faults'])==2 and all(type(n)is int and n>=0 for n in row['faults']),'Invalid faults')
    require(row['outcome'] in ('teamA','teamB','draw') and 1<=row['rounds']<=2000,'Invalid outcome/round')
    for metric in ('deaths','kills','championDamageDone','championDamageTaken','monsterDamageDone','monsterDamageTaken','collectedGems'):
        if metric in row:
            require(row[metric]==[sum(c.get(metric,0) for c in data['champions'] if c['team']==team) for team in (0,1)],'Derived champion metric mismatch: '+metric)
    require(set(row['stdout'])=={'a','b'},'Missing team diagnostics')
    for stream in row['stdout'].values():
        counts=stream['initializations']
        require(isinstance(counts,dict) and all(type(n)is int and n>=1 for n in counts.values()),'Invalid initialization marker count')
        require(type(stream['reinitializations_observed'])is int and stream['reinitializations_observed']==sum(n-1 for n in counts.values()),'Reinitialization count differs from markers')

def audit(allow_incomplete=False,verify_cache=True):
    started=now();paths=sorted((ROOT/'results').glob('*.json'));cache_inventory={p.stem for p in (ROOT/'game-cache').glob('*.json')}
    recovery_path=ROOT/'orchestration-recovery.json';recovery=read(recovery_path) if recovery_path.is_file() else None
    recovered={r['key']:r for r in recovery['recovered_current_experiment_inputs']} if recovery else {}
    if recovery:
        require(recovery['recovered_count']==len(recovered),'Duplicate/missing recovery input')
        require(sha(ROOT/recovery['harness_before']['path'])==recovery['harness_before']['sha256'],'Before-recovery harness changed')
        require(sha(ROOT/recovery['harness_after']['path'])==recovery['harness_after']['sha256'],'After-recovery harness changed')
        require(sha(ROOT/'freeze.json')==recovery['freeze_sha256'] and sha(ROOT/'generation.json')==recovery['generation_record_sha256'],'Recovery freeze/generation changed')
        require(sha(ROOT/'recovery-contracts.json')==recovery['pure_contracts_sha256'],'Recovery contracts changed')
        for artifact in recovery['failure_artifacts']:
            p=plain_path(ROOT/artifact['path'],ROOT);require(sha(p)==artifact['sha256'],'Interrupted pre-game failure evidence changed')
            data=read(p)
            require(data['returncode']!=0 and 'failed to persist temporary file: Access is denied'in data['log'],'Interrupted failure is not the proven pre-game error')
            require(not(p.parent/'statistics.json').exists() and not list(p.parent.glob('*.repl26a')),'Interrupted attempt has game artifacts')
    physical={};views={};stages={};plans={};sources={};map_paths={};runtime={};fresh_claims={};candidate_stages={}
    for path in paths:
        stage=path.stem;plan_path=ROOT/'stages'/f'{stage}-plan.json'
        require(plan_path.is_file(),'Missing plan for '+stage)
        envelope=read(plan_path);plan=envelope['plan'];require(plan['stage']==stage,'Stage plan name mismatch')
        plans[stage]={'created_utc':envelope['created_utc'],'sha256':sha(plan_path),'plan':plan}
        require(timestamp(envelope['created_utc'])<=timestamp(now()),'Future stage plan timestamp')
        expected=Counter((s['candidate'],s['opponent'],s['map_sha256'],s['side'],s['key']) for s in plan['slots'])
        require(all(n==1 for n in expected.values()),'Duplicate semantic slot in plan '+stage)
        for name,record in plan['sources'].items():
            if name in sources:require(sources[name]==record,'Candidate provenance changed between stages: '+name)
            sources[name]=record;candidate_stages.setdefault(name,set()).add(stage)
            require(timestamp(record['created_utc'])<=timestamp(envelope['created_utc']),'Candidate registered after its stage plan')
        for name,h in plan['maps'].items():
            p=ARENA/Path(name);require(p.is_file() and sha(p)==h,'Map changed: '+name)
            map_paths.setdefault(h,set()).add(p)
        rt=plan['runtime'];runtime.setdefault(digest(canonical(rt)),rt)
        metadata={};count=0;stage_keys=set();new_keys=set();cache_keys=set()
        for row in stage_rows(path,metadata):
            key=row['key'];slot=(row['candidate'],row['opponent'],row['map_sha256'],row['side'],key)
            require(expected[slot]>0,'Unplanned/duplicate game slot in '+stage);expected[slot]-=1;count+=1
            side=row['side'];a,b=(row['candidate'],row['opponent']) if side==0 else (row['opponent'],row['candidate'])
            require(row['identity']['runtime']==rt,'Game runtime differs from plan')
            require(row['identity']['map_sha256']==row['map_sha256'],'Map identity differs')
            require(row['identity']['wasm_a_sha256']==plan['sources'][a]['wasm_sha256'] and row['identity']['wasm_b_sha256']==plan['sources'][b]['wasm_sha256'],'Ordered source-pair differs from plan')
            if key not in physical:
                verify_row(row);value=compact(row)
                value['stages']=[];physical[key]=value
            else:
                old=physical[key];require(all(old[k]==v for k,v in compact(row).items()),'Physical input produced conflicting recorded outcome')
            if stage not in physical[key]['stages']:physical[key]['stages'].append(stage)
            stage_keys.add(key)
            if row['cached']:cache_keys.add(key)
            else:
                new_keys.add(key)
                require(timestamp(row['created_utc'])>=timestamp(envelope['created_utc']),'New physical game predates its stage plan')
            require(not row.get('imported_cache') or row['cached'],'Imported historical input counted as a new game')
            if key in recovered and stage==recovery['stage']:
                require(row['cached'] and not row.get('imported_cache'),'Recovered local input incorrectly classified on resume')
                require(timestamp(envelope['created_utc'])<=timestamp(row['created_utc'])<=timestamp(recovery['created_utc']),'Recovered game chronology differs')
            view=slot[:4]
            if view in views:require(views[view]['key']==key,'Semantic slot changed physical identity across stages')
            val=views.setdefault(view,{'candidate':row['candidate'],'opponent':row['opponent'],'map_sha256':row['map_sha256'],'side':side,'key':key,'stages':[]})
            val['stages'].append(stage)
        require(all(n==0 for n in expected.values()),'Incomplete stage coverage: '+stage)
        require(metadata['stage']==stage and metadata['plan_sha256']==plans[stage]['sha256'],'Result plan pin changed')
        require(count==metadata['semantic_games']==plan['semantic_games'],'Wrong semantic game count')
        require(len(stage_keys)==metadata['unique_physical_games']==plan['unique_physical_games'],'Wrong physical game count')
        require(len(new_keys)==metadata['new_unique_games'] and len(cache_keys)==metadata['cached_unique_games'],'Wrong cache/new annotation counts')
        require(not new_keys.intersection(cache_keys),'Same stage classified one physical game both new and cached')
        for key in new_keys:fresh_claims.setdefault(key,[]).append(stage)
        completed=timestamp(metadata['completed_utc']);require(timestamp(envelope['created_utc'])<=completed,'Stage completed before plan')
        require(all(timestamp(physical[k]['created_utc'])<=completed for k in stage_keys),'Stage references a later physical game')
        stages[stage]={'plan_created_utc':envelope['created_utc'],'completed_utc':metadata['completed_utc'],
            'result_sha256':metadata['_file_sha256'],'plan_sha256':plans[stage]['sha256'],
            'semantic_games':count,'unique_physical_games':len(stage_keys),'new_unique_games':len(new_keys),'cached_unique_games':len(cache_keys),
            'maps':len(plan['maps']),'names':plan['names'],'opponents':plan['opponents'],'sets':plan['sets'],
            'summary':metadata.get('summary',{})}
        print(f'Audited {stage}: {count} slots, {len(stage_keys)} physical inputs ({len(new_keys)} new / {len(cache_keys)} reused)',file=sys.stderr,flush=True)
    if verify_cache:
        def check_cache(key):
            cp=ROOT/'game-cache'/(key+'.json');require(cp.is_file(),'Completed stage missing cache entry')
            content=cp.read_bytes();row=json.loads(content);verify_row(row)
            require(all(physical[key][k]==v for k,v in compact(row).items()),'Stage row differs from physical cache entry')
            if key in recovered:require(digest(content)==recovered[key]['cache_file_sha256'] and row['created_utc']==recovered[key]['created_utc'],'Recovered cache changed after pre-resume snapshot')
            if row.get('retained_replay'):
                replay=plain_path(ROOT/row['retained_replay'],ROOT)
                require(sha(replay)==row['replay_sha256'],'Current retained replay changed')
            imported=row.get('imported_cache')
            if imported:
                require(imported['source_experiment']=='study27-micro' and imported['source_key']==key,'Unknown imported-cache origin')
                prior=plain_path(PRIOR_ROOT/'game-cache'/(key+'.json'),PRIOR_ROOT)
                old_bytes=prior.read_bytes();require(digest(old_bytes)==imported['source_cache_file_sha256'],'Imported source cache hash changed')
                old=json.loads(old_bytes);verify_row(old)
                base={k:v for k,v in compact(row).items() if k!='imported_cache'}
                require(compact(old)==base,'Imported physical outcome/statistics differs from its old source')
                require(timestamp(old['created_utc'])<=timestamp(imported['imported_utc']),'Import predates source game')
                if old.get('retained_replay'):
                    old_replay=plain_path(PRIOR_ROOT/old['retained_replay'],PRIOR_ROOT)
                    require(sha(old_replay)==old['replay_sha256'],'Imported source retained replay changed')
            return key,digest(content)
        with ThreadPoolExecutor(max_workers=8) as pool:
            futures=[pool.submit(check_cache,key) for key in physical]
            for index,future in enumerate(as_completed(futures),1):
                key,file_sha=future.result();physical[key]['cache_file_sha256']=file_sha
                if index%5000==0 or index==len(futures):print(f'Independently verified {index}/{len(futures)} cache files',file=sys.stderr,flush=True)
    pending=sorted(p.name.removesuffix('-plan.json') for p in (ROOT/'stages').glob('*-plan.json') if p.name.removesuffix('-plan.json') not in stages)
    if not allow_incomplete:require(not pending,'Planned stages still incomplete: '+', '.join(pending))
    require(all(len(v)==1 for v in fresh_claims.values()),'Physical input claimed new in more than one stage')
    if recovery and recovery['stage']in stages:
        require(plans[recovery['stage']]['sha256']==recovery['original_stage_plan_sha256'],'Recovery original plan changed')
        require(set(recovered)<=set(physical) and not set(recovered).intersection(fresh_claims),'Recovered input missing or claimed newly executed on resume')
        require(all(recovery['stage']in physical[k]['stages']for k in recovered),'Recovery input not used by its resumed stage')
        for key in recovered:physical[key]['recovery_provenance']={'stage':recovery['stage'],'manifest_sha256':sha(recovery_path),'classification':'Same-experiment completed physical input, cached on resumed invocation; counted once.'}
    elif recovered and not allow_incomplete:raise RuntimeError('Recovery stage is not complete')
    eligible_recovered=set(recovered)&set(physical)
    require(set(fresh_claims)|eligible_recovered=={key for key,row in physical.items() if 'imported_cache'not in row},'Fresh/recovered claims do not exactly separate local games from historical imports')
    for name,record in sources.items():
        src=ARENA/'bots'/name/'src'
        observed={p.name:sha(p) for p in src.iterdir() if p.is_file()};require(observed==record['source_sha256'],'Current candidate source differs: '+name)
        require(sha(ARENA/'bots'/name/'.cambc/build/bot-injected.wasm')==record['wasm_sha256'],'Current candidate WASM differs: '+name)
        for module,h in record.get('patch_modules_sha256',{}).items():require(sha(ROOT/module)==h,'Frozen patch module changed: '+module)
    for rt in runtime.values():
        require(sha(ROOT.parent/'battlecode-bot-v1/runtime/cambc.exe')==rt['cli_sha256'],'Current CLI differs from recorded runtime')
        require(sha(ARENA/'cambc.toml')==rt['project_config_sha256'],'Current project configuration changed')
        require(sha(ARENA/'sdk/cpp/cambc.h')==rt['sdk_header_sha256'],'Current SDK changed')
        require(sha(ROOT.parent/'battlecode-bot-v1/r2-research/v0_0_1-ctH8uuEb.wasm')==rt['reference_engine_wasm_sha256'],'Reference generator engine changed')
    # Registration without any result-stage participation is not played evidence.
    registered={p.stem:read(p) for p in (ROOT/'candidates').glob('*.json')}
    played={name for val in views.values() for name in (val['candidate'],val['opponent'])}
    registered_unplayed=sorted(set(registered)-played)
    for name in registered_unplayed:
        record=registered[name];src=ARENA/'bots'/name/'src'
        require({p.name:sha(p) for p in src.iterdir() if p.is_file()}==record['source_sha256'],'Unplayed registered source changed: '+name)
        if record.get('wasm_sha256'):require(sha(ARENA/'bots'/name/'.cambc/build/bot-injected.wasm')==record['wasm_sha256'],'Unplayed compiled control changed: '+name)
        for module,h in record.get('patch_modules_sha256',{}).items():require(sha(ROOT/module)==h,'Unplayed registered module pin changed: '+name)
    faults={key:r['faults'] for key,r in physical.items() if any(r['faults'])}
    reinit={key:{t:s['reinitializations_observed'] for t,s in r['stdout'].items()} for key,r in physical.items() if any(s['reinitializations_observed'] for s in r['stdout'].values())}
    runtime_pins=[sanitize(r) for r in runtime.values()]
    summary={'audit_started_utc':started,'audit_completed_utc':now(),'snapshot_is_final':not pending,'pending_stages':pending,
        'independent_cache_reread':verify_cache,
        'independent_imported_source_cache_reread':verify_cache,
        'publication_gate_evaluated':False,
        'completed_stages':len(stages),'semantic_stage_rows':sum(s['semantic_games'] for s in stages.values()),
        'unique_semantic_slots':len(views),'unique_completed_physical_inputs':len(physical),
        'repeated_physical_stage_memberships':sum(s['unique_physical_games'] for s in stages.values())-len(physical),
        'annotated_new_unique_sum':sum(s['new_unique_games'] for s in stages.values()),
        'annotated_cached_unique_sum':sum(s['cached_unique_games'] for s in stages.values()),
        'duplicate_new_claims':{k:v for k,v in fresh_claims.items() if len(v)>1},
        'unique_maps':len(map_paths),'played_bot_names':sorted(played),'registered_unplayed':registered_unplayed,
        'registered_unplayed_notes':{name:note for name,note in {
            'exact_control':'Exact source/WASM equivalence control; no game was run.',
            'patch_combat_moves':'Accidental candidate-name shadowing registration before games; preserved unbuilt/unplayed, excluded from tested candidates.'}.items() if name in registered_unplayed},
        'imported_historical_physical_inputs':sum('imported_cache' in r for r in physical.values()),
        'new_experiment_physical_inputs':sum('imported_cache' not in r for r in physical.values()),
        'recovered_current_experiment_physical_inputs':len(eligible_recovered),
        'recovery_manifest_sha256':sha(recovery_path) if recovery else None,
        'recovery_historical_harness_provenance':'Qualified: one isolated contrary raw hash could not be reconstructed; archived before bytes agree with two earlier contemporaneous records. See immutable addendum/review; no continuously-identical historical harness-byte claim.' if recovery else None,
        'failed_pre_game_attempts_in_interrupted_invocation':recovery['failed_pre_game_attempt_count'] if recovery else 0,
        'cache_files_at_snapshot_start':len(cache_inventory),'cache_inputs_not_referenced_by_completed_stages_at_snapshot_start':len(cache_inventory-set(physical)),
        'fault_games':len(faults),'faults':faults,'reinitialization_games':len(reinit),'reinitializations':reinit,
        'caught_error_log_samples':sum(sum(s.get('caught_errors',{}).values()) for r in physical.values() for s in r['stdout'].values()),
        'pre_game_access_denied_retry_attempts_new_experiment':sum(r['pre_game_access_denied_retries'] for r in physical.values() if 'imported_cache' not in r),
        'pre_game_access_denied_retry_attempts_imported_history':sum(r['pre_game_access_denied_retries'] for r in physical.values() if 'imported_cache' in r),
        'first_physical_game_created_utc':min((r['created_utc'] for r in physical.values()),default=None),
        'last_physical_game_created_utc':max((r['created_utc'] for r in physical.values()),default=None),
        'runtime_pins':runtime_pins,'stages':stages,
        'limits':['Unique physical inputs are exact ordered WASM/map/runtime/config/settings identities, not statistically independent games.',
                  'Cache reuse, duplicate smoke slots and panel reuse never add new evidence.',
                  'Imported old games may predate this experiment; their exact source cache hash, physical identity, statistics and retained replays are independently verified.',
                  'Quality counts include every physical input, including original-vs-spar baseline rows and either side.',
                  'Identity/quality audit success is not evidence of improvement. Publication still requires the separately recorded frozen confirmation gates.',
                  'SDK errors and low-fuel status are sampled logs, not exact native fuel-exhaustion counts.',
                  'Compact exports omit full raw statistics and native replay bulk; raw SHA256 pins remain, and full local evidence is retained.',
                  'Completed-stage snapshot can exclude concurrently running/newly published stages; snapshot_is_final is false when a planned stage is pending.']}
    return summary,physical,views,plans,sources,map_paths,registered

def export(dest,payload):
    summary,physical,views,plans,sources,map_paths,registered=payload
    require(summary['snapshot_is_final'],'Do not export an incomplete experiment snapshot')
    require(SCRIPT_SHA256 is None or sha(Path(__file__))==SCRIPT_SHA256,'Audit script changed during execution')
    dest=output_guard(dest);require(dest!=ROOT,'Export directory cannot be task root')
    try:dest.lstat()
    except FileNotFoundError:pass
    else:raise RuntimeError('Export directory must be new and absent: '+str(dest))
    dest.mkdir(parents=True,exist_ok=False)
    required=['audit.json','outcomes.jsonl.gz','views.jsonl.gz','maps.zip','provenance.zip','export-manifest.json']
    require(not any((dest/name).exists() for name in required),'Export targets already exist; use a new directory')
    with output_guard(dest/'audit.json').open('xb') as stream:stream.write(json.dumps(sanitize(summary),indent=2,ensure_ascii=False).encode()+b'\n')
    with gzip.open(output_guard(dest/'outcomes.jsonl.gz'),'xb',compresslevel=9) as stream:
        for key in sorted(physical):stream.write(canonical(sanitize(physical[key]))+b'\n')
    with gzip.open(output_guard(dest/'views.jsonl.gz'),'xb',compresslevel=9) as stream:
        for key in sorted(views):stream.write(canonical(views[key])+b'\n')
    with zipfile.ZipFile(output_guard(dest/'maps.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        manifest={}
        for h,paths in sorted(map_paths.items()):
            path=sorted(paths,key=str)[0];name=path.relative_to(ARENA).as_posix()
            archive.write(path,name);manifest[h]={'archive_path':name,'aliases':[p.relative_to(ARENA).as_posix() for p in sorted(paths,key=str)]}
        archive.writestr('audit-map-manifest.json',json.dumps(manifest,indent=2))
    with zipfile.ZipFile(output_guard(dest/'provenance.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for stage,plan in plans.items():archive.writestr('stages/'+stage+'-plan.json',json.dumps(sanitize(plan),indent=2))
        for name,record in registered.items():
            archive.writestr('candidates/'+name+'.json',json.dumps(sanitize(record),indent=2))
            for file in sorted((ARENA/'bots'/name/'src').iterdir()):
                if file.is_file():archive.write(file,'sources/'+name+'/src/'+file.name)
        explicit=('harness-plan.json','selection-plan.json','candidate-rationale.txt','control-equivalence.json','cache-import-smoke.json','harness-audit.txt','registration-fix-audit.json','module-composition-audit.json',
            'combat-moves-builds.json','combat-moves-fixtures.json','targets-helper-fixtures.json','targets-source-checks.json',
            'test_combat_moves.py','test_combat_moves_build.py','test_targets_helpers.py','check_targets_sources.py',
            'patch_combat_targets.py','patch_combat_moves.py','compare.py','lab.py','test_matches.py','audit_export.py',
            'audit_screen.py','screen-audit.json','audit_full.py','full-audit.json','audit_combo.py','combo-audit.json',
            'screen-comparison.json','full-comparison.json','combination-plan.txt','combo-comparison.json','combo-ablations.json',
            'combat_metrics.py','test_combat_metrics.py','combat-metrics-selfcheck.json','screen-selected-metrics.json','full-selected-metrics.json',
            'analyze_stage.py','confirm.py','generate_confirmation.py','test_confirmation.py','confirmation-tests.json',
            'freeze_candidate.py','selection.json','run_confirmation.py','generation.json','audit_generation.py','generation-audit.json',
            'record_recovery.py','test_recovery.py','recovery-contracts.json','orchestration-recovery.json','test_matches.pre-recovery.py',
            'record_recovery_addendum.py','recovery-provenance-addendum.json','recovery-provenance-review.json','orchestration-repair.diff',
            'confirmation-verdict.json','audit_confirmation.py','confirmation-audit.json','generate-fresh.mjs')
        extras={ROOT/name for name in explicit if (ROOT/name).is_file()}
        extras.update(ROOT.glob('*freeze*.json'))
        if (ROOT/'orchestration-recovery.json').is_file():
            extras.update(ROOT/a['path']for a in read(ROOT/'orchestration-recovery.json')['failure_artifacts'])
        extras.update((ROOT/'stage-failures').glob('*.json'))
        for folder in ('baseline',):
            if (ROOT/folder/'manifest.json').is_file():extras.add(ROOT/folder/'manifest.json')
        for folder in {p.parent for paths in map_paths.values() for p in paths}:
            if (folder/'manifest.json').is_file():extras.add(folder/'manifest.json')
        extras.update(p for p in (ROOT/'publish-tools').glob('*') if p.is_file())
        for path in sorted(extras,key=str):
            if path.suffix=='.json':archive.writestr(relative(path),json.dumps(sanitize(read(path)),indent=2))
            else:archive.write(path,relative(path))
    artifacts={name:{'bytes':(dest/name).stat().st_size,'sha256':sha(dest/name)} for name in required if (dest/name).exists()}
    require(all(v['bytes']<LIMIT for v in artifacts.values()),'An evidence artifact exceeds the GitHub 25MB limit')
    manifest={'created_utc':now(),'audit_script_sha256':sha(Path(__file__)),'artifacts':artifacts,
        'unique_completed_physical_inputs':summary['unique_completed_physical_inputs'],
        'path_policy':'Published plan copies replace task/work/user-home prefixes with TASK/WORK/USER; original local plan/result/cache SHA256 values pin original evidence.',
        'limits':summary['limits']}
    with output_guard(dest/'export-manifest.json').open('xb') as stream:stream.write(json.dumps(manifest,indent=2).encode()+b'\n')
    return manifest

def wait_for_confirmation_audit(timeout=900):
    path=ROOT/'confirmation-audit.json';start=time.monotonic();last=start
    while True:
        if path.is_file():
            try:value=read(path)
            except json.JSONDecodeError:value=None
            if isinstance(value,dict):return
        require(time.monotonic()-start<timeout,'Independent confirmation audit did not finish before export timeout')
        if time.monotonic()-last>=30:
            print('Full physical audit ready; waiting for independent confirmation-audit.json before export.',file=sys.stderr,flush=True);last=time.monotonic()
        time.sleep(1)

def main():
    global SCRIPT_SHA256
    SCRIPT_SHA256=sha(Path(__file__))
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--allow-incomplete',action='store_true',help='Read-only snapshot while stages run; exports remain disabled');p.add_argument('--no-verify-cache',action='store_true',help='Skip independent cache-file reread (stage statistics still self-checked)');p.add_argument('--export',type=Path);p.add_argument('--wait-for-confirmation-audit',action='store_true',help='After the full audit, wait for the independent confirmation audit before export')
    a=p.parse_args();payload=audit(a.allow_incomplete,not a.no_verify_cache)
    if a.export:
        print(json.dumps({k:v for k,v in payload[0].items() if k!='stages'},indent=2),flush=True)
        if a.wait_for_confirmation_audit:wait_for_confirmation_audit()
        print(json.dumps(export(a.export,payload),indent=2))
    else:
        report=payload[0];print(json.dumps({k:v for k,v in report.items() if k!='stages'},indent=2))
    return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except (RuntimeError,OSError,ValueError,KeyError) as exc:
        print('AUDIT FAILED: '+str(exc),file=sys.stderr);raise SystemExit(1)
