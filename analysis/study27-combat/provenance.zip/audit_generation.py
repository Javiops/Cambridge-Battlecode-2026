"""Independent read-only freeze/cohort audit; never reads confirmation outcomes."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,stat,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
ARENA=ROOT/'arena'
def require(ok,message):
    if not ok:raise RuntimeError(message)
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stamp(x):
    y=datetime.fromisoformat(x.replace('Z','+00:00'));require(y.tzinfo is not None,'Naive timestamp');return y.astimezone(timezone.utc)
def plain(p):
    p=p.absolute();require(p.is_relative_to(ROOT),'Path escape')
    for a in (p,*p.parents):
        s=a.lstat();require(not stat.S_ISLNK(s.st_mode) and not(getattr(s,'st_file_attributes',0)&0x400),'Redirected evidence path')
        if a==ROOT:break
    require(p.resolve()==p,'Redirected absolute path');return p
def main():
    freeze_path=ROOT/'freeze.json';generation_path=ROOT/'generation.json'
    f=read(freeze_path);g=read(generation_path);plan=read(ROOT/'selection-plan.json');selection=read(ROOT/'selection.json')
    require(sha(ROOT/'selection-plan.json')==f['selection_plan_sha256'],'Selection plan hash changed')
    require(sha(ROOT/'selection.json')==f['selection_sha256'],'Selection record hash changed')
    require(selection['candidate']==f['candidate']=='cm_combo_aoe_dash','Frozen candidate differs from audited selection')
    require(stamp(selection['created_utc'])<=stamp(f['created_utc']),'Selection follows freeze')
    require(g['status']=='complete' and g['freeze_sha256']==sha(freeze_path),'Generation does not bind exact freeze')
    require(g['selection_plan_sha256']==f['selection_plan_sha256'] and g['generation_inputs']==f['generation_inputs'],'Generation pins changed')
    require(stamp(f['created_utc'])<stamp(g['started_utc'])<=stamp(g['finished_utc'])<=datetime.now(timezone.utc),'Invalid freeze/generation chronology')
    require(g['seed']==plan['confirmation']['seed']==2154873391 and g['count']==plan['confirmation']['maps']==1024,'Cohort differs from recorded plan')
    refs={'original','spar11','spar12','spar16'};require(set(f['reference_wasm_sha256'])==refs,'Incomplete references')
    for name in sorted(refs|{f['candidate']}):
        rec=read(ROOT/'candidates'/f'{name}.json');folder=plain(ARENA/'bots'/name/'src')
        current={p.name:sha(plain(p)) for p in folder.iterdir() if p.is_file()}
        require(current==rec['source_sha256'],'Source registration changed: '+name)
        binary=sha(plain(ARENA/'bots'/name/'.cambc/build/bot-injected.wasm'))
        expected=f['wasm_sha256'] if name==f['candidate'] else f['reference_wasm_sha256'][name]
        require(binary==expected==rec['wasm_sha256'],'Binary pin changed: '+name)
        require(rec['base_commit']==(plan['spar_commit'] if name.startswith('spar') else plan['baseline_commit']),'Base commit differs: '+name)
        for field in ('cli_sha256','project_config_sha256','sdk_header_sha256'):require(rec[field]==f['runtime'][field],'Build runtime differs: '+name)
        if name==f['candidate']:
            require(current==f['source_sha256'] and rec['patch_modules_sha256']==f['patch_modules_sha256'],'Frozen source/module metadata differs')
    for module,h in f['patch_modules_sha256'].items():require(sha(plain(ROOT/module))==h,'Patch module changed')
    rt=f['runtime'];require(rt['engine_version']=='0.0.1','Unexpected native engine version')
    require(sha(ROOT.parent/'battlecode-bot-v1/runtime/cambc.exe')==rt['cli_sha256'],'CLI changed')
    require(sha(ARENA/'cambc.toml')==rt['project_config_sha256'] and sha(ARENA/'sdk/cpp/cambc.h')==rt['sdk_header_sha256'],'Config/SDK changed')
    files={'generator_sha256':ROOT.parent/'study28-fixes/generate-fresh.mjs','helper_sha256':ROOT.parent/'battlecode-bot-v1/r2-ward/map-variants.mjs','engine_sha256':ROOT.parent/'battlecode-bot-v1/r2-research/v0_0_1-ctH8uuEb.wasm','wrapper_sha256':ROOT/'generate_confirmation.py'}
    require({k:sha(p) for k,p in files.items()}==f['generation_inputs'],'Generator support pins changed')
    require(sha(ROOT/'confirm.py')==f['confirmation_tool_sha256'],'Confirmation verifier changed')
    require(f['generation_inputs']['engine_sha256']==rt['reference_engine_wasm_sha256'],'Reference engine pin differs')
    dev={p.relative_to(ARENA).as_posix():sha(plain(p)) for d in ('maps','maps_gen','maps_dev200') for p in (ARENA/d).glob('*.map26a')}
    require(dev==f['development_maps_sha256'] and len(dev)==len(set(dev.values()))==253,'Development cohort changed')
    folder=plain(ARENA/'confirmation1024');manifest_path=folder/'manifest.json';m=read(manifest_path)
    require(sha(manifest_path)==g['manifest_sha256'],'Manifest changed after generation')
    require(m['seed']==g['seed'] and m['count']==1024 and m['source_maps_read']==0 and m['candidate_results_read']is False,'Unexpected manifest provenance')
    require(all(m[k]==f['generation_inputs'][k] for k in ('generator_sha256','helper_sha256','engine_sha256')),'Manifest tooling pins differ')
    require(stamp(g['started_utc'])<=stamp(m['created_at_utc'])<=stamp(g['finished_utc']),'Manifest generation time out of bounds')
    rows=m['maps'];require(len(rows)==1024,'Incomplete manifest')
    expected_names={f'fresh-{i:04d}.map26a' for i in range(1024)}
    require({r['file'] for r in rows}==expected_names and {p.name for p in folder.iterdir()}==expected_names|{'manifest.json'},'Cohort filenames differ')
    require(len({r['sha256'] for r in rows})==len({r['topology_d4_sha256'] for r in rows})==1024,'Repeated map byte or recorded nonbush D4 geometry')
    require(not set(dev.values()).intersection(r['sha256'] for r in rows),'Development map byte reuse')
    checks=('official_integrity','official_verify_game','official_runtime_expansion_equal','all_camps_reachable_from_both_teams','all_altars_reachable_from_both_teams','mirrored_camp_distance_equal')
    times=[]
    for r in rows:
        p=plain(folder/r['file']);require(sha(p)==r['sha256'],'Map bytes differ: '+r['file'])
        require(all(r['validation'].get(k)is True for k in checks),'Missing generator-native validation claim')
        t=datetime.fromtimestamp(p.stat().st_mtime,timezone.utc)
        require(stamp(g['started_utc'])<=t<=stamp(g['finished_utc']),'Map modified outside generation window');times.append(t)
    require(min(times)==stamp(g['first_map_file_utc']) and max(times)==stamp(g['last_map_file_utc']),'Recorded map chronology differs')
    out={'passed':True,'created_utc':datetime.now(timezone.utc).isoformat(),'candidate':f['candidate'],'wasm_sha256':f['wasm_sha256'],
         'freeze_sha256':sha(freeze_path),'generation_record_sha256':sha(generation_path),'manifest_sha256':sha(manifest_path),
         'freeze_utc':f['created_utc'],'generation_started_utc':g['started_utc'],'generation_finished_utc':g['finished_utc'],
         'confirmation_maps':1024,'unique_map_bytes':1024,'unique_recorded_nonbush_d4_geometries':1024,'development_maps':253,'byte_overlap_with_development':0,
         'confirmation_outcomes_read':False,'new_games':0,'new_maps':0,
         'limits':'Independent byte/pin/chronology checks only. Native integrity, reachability and D4 topology claims were verified by the pinned generator and not rerun here. CLI verifies native engine version, not injection of the reference generator WASM.'}
    target=ROOT/'generation-audit.json'
    with target.open('x',encoding='utf8') as stream:stream.write(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
