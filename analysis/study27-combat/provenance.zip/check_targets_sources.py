"""Pinned source/composition contracts and scratch full-SDK compilation; no games."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import itertools
import json
from pathlib import Path
import subprocess
import patch_combat_targets as patch
from lab import ARENA,CLI,ENV

ROOT=Path(__file__).resolve().parent


def cut(text,start,end):return text.split(start,1)[1].split(end,1)[0]


def main():
    base={p.name:p.read_text()for p in(ROOT/'baseline/src').iterdir()if p.is_file()}
    before=dict(base)
    outputs={}
    for size in range(1,len(patch.FEATURES)+1):
        for features in itertools.combinations(patch.FEATURES,size):
            a=patch.apply_many(base,features)
            assert a==patch.apply_many(base,reversed(features))
            assert base==before
            assert {k for k in base if a[k]!=base[k]}=={'main.cpp'}
            for start,end in (('void farm(', '// ---------------------------------------------------------------------------\n// One turn'),
                ('bool other_captures(', 'void drop_target('),
                ('    // 4. Recall to heal', '    // 5. Bank gems.'),
                ('void shop(', 'bool step_towards('),
                ('template <class U>\nbool cast_offense(', 'template <class U>\nbool basic_attack(')):
                # A forward declaration/retarget helper is inserted at the next
                # basic template boundary, after the unchanged cast function.
                if start.startswith('template'):
                    old=base['main.cpp'].split(start,1)[1].split('    return false;\n}',1)[0]
                    new=a['main.cpp'].split(start,1)[1].split('    return false;\n}',1)[0]
                    assert old==new
                else:assert cut(a['main.cpp'],start,end)==cut(base['main.cpp'],start,end),(features,start)
            assert a['main.cpp'].split('enum class Slot',1)[0]==base['main.cpp'].split('enum class Slot',1)[0]
            outputs[features]=a
    assert patch.apply_many(base,['cm_fresh_basic','cm_spellkill_retarget'])==patch.apply(base,'cm_spellkill_retarget')
    try:patch.apply(patch.apply(base,patch.FEATURES[0]),patch.FEATURES[1])
    except ValueError:pass
    else:raise AssertionError('Unbatched changed main.cpp accepted')
    variants={n:patch.apply(base,n)for n in patch.FEATURES}
    variants['all_targets']=patch.apply_many(base,patch.FEATURES)
    def build(item):
        name,source=item
        bot=ARENA/'bots'/('targetcheck-'+name)
        folder=bot/'src'
        folder.mkdir(parents=True,exist_ok=True)
        for filename,text in source.items():
            p=folder/filename
            if p.exists()and p.read_text()!=text:raise RuntimeError('Scratch source drift: '+str(p))
            p.write_text(text,newline='\n')
        proc=subprocess.run([str(CLI),'build','bots/'+bot.name],cwd=ARENA,env=ENV,capture_output=True,text=True,timeout=600)
        log=ROOT/('check-'+name+'.log');log.write_text(proc.stdout+proc.stderr)
        if proc.returncode:raise RuntimeError(proc.stdout+proc.stderr)
        wasm=bot/'.cambc/build/bot-injected.wasm'
        assert wasm.exists()
        return {'feature':name,'full_sdk_compile':True,'wasm_sha256':hashlib.sha256(wasm.read_bytes()).hexdigest()}
    with ThreadPoolExecutor(max_workers=2)as pool:builds=list(pool.map(build,variants.items()))
    output={'passed':True,'canonical_feature_subsets':len(outputs),'base_unchanged':base==before,
            'no_games':True,'method':'Pinned source contracts, canonical reverse-order composition and seven unregistered scratch full-SDK builds.',
            'builds':builds,'patch_sha256':hashlib.sha256((ROOT/'patch_combat_targets.py').read_bytes()).hexdigest()}
    (ROOT/'targets-source-checks.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output,indent=2))


if __name__=='__main__':main()
