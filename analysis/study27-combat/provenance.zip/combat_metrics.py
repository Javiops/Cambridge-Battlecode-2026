"""Read-only matched combat/farming counter summaries, with map as the unit.

Compare candidate and original against identical spar WASM, map and side. These
descriptive counters do not identify causal actions, camp captures, stolen camps
or farming deaths. Caught errors are sampled diagnostic lines, not true totals.
No game runner, candidate source, or remote service is accessed by this module.
"""
from __future__ import annotations
import argparse
from collections import Counter,defaultdict
import json
from pathlib import Path
import re
from statistics import fmean,median

SPARS=('spar11','spar12','spar16')
METRICS=('submittedGems','collectedGems','kills','deaths','championDamageDone',
         'championDamageTaken','monsterDamageDone','monsterDamageTaken','earnedGold','spentGold')
LIMITS=[
    'Map is the descriptive unit: aggregate both sides and all specified opponents within each map before summarising maps.',
    'Raw and per-100-round deltas remain correlated with match duration and outcome; neither establishes the cause of an improvement.',
    'Collected gems can include champion loot. Damage to monsters does not establish captures, conceded camps or deaths during farming.',
    'Caught-error diagnostics contain only the first 8 errors per body and each 500th thereafter; log samples are not true error totals or unbiased frequencies.',
    'Low-fuel periodic samples omit intervening turns. Zero sampled errors or low-fuel lines does not mean API-error-free or fuel-independent operation.',
    'This helper does not select a winner or compute confirmatory significance; outcome gates and independent confirmation are separate.',
]


def load(paths):
    result={}
    for path in paths:
        data=json.loads(Path(path).read_text(encoding='utf-8'))
        if not data.get('completed_utc'):raise ValueError('Expected a completed result stage: '+str(path))
        for row in data['games']:
            key=(row['candidate'],row['opponent'],row['map_sha256'],row['side'])
            if key in result:
                assert result[key]['key']==row['key']and result[key]['outcome']==row['outcome'],key
            result[key]=row
    return result


def score(row):
    if row['outcome']=='draw':return 0.5
    assert row['outcome']in('teamA','teamB')
    return float(row['outcome']==('teamA'if row['side']==0 else'teamB'))


def team_metrics(row,enemy=False):
    team=1-row['side']if enemy else row['side']
    champions=[c for c in row['statistics']['champions']if c['team']==team]
    metrics={k:sum(c[k]for c in champions)for k in METRICS}
    actual=next(t for t in row['statistics']['teams']if t['team']==team)
    assert metrics['submittedGems']==actual['submittedGems']
    return metrics


def quality(row):
    side=row['side'];stdout=row['stdout']['a'if side==0 else'b']
    by_code=Counter()
    for text,count in stdout['caught_errors'].items():
        code=re.search(r'engine error (\d+):',text)
        by_code[code[1]if code else'non_engine_exception']+=count
    return {'bot_faults':row['faults'][side],
            'reinitializations_observed':stdout['reinitializations_observed'],
            'caught_error_log_samples':sum(stdout['caught_errors'].values()),
            'low_fuel_periodic_samples':stdout['low_fuel_logged'],
            'caught_error_log_samples_by_code':dict(by_code)}


def matched_pairs(rows,baseline,name,opponents=SPARS,map_set='all'):
    found=[]
    prefix={'official':'maps','gen':'maps_gen','dev':'maps_dev200','legacy':'maps_hold60'}
    for row in rows.values():
        if row['candidate']!=name or row['opponent']not in opponents:continue
        if map_set!='all'and row['map_path'].replace('\\','/').split('/',1)[0]!=prefix[map_set]:continue
        key=('original',row['opponent'],row['map_sha256'],row['side'])
        old=baseline[key]
        assert row['identity']['runtime']==old['identity']['runtime'],'Runtime/configuration differ'
        enemy='b'if row['side']==0 else'a'
        assert row['identity']['wasm_'+enemy+'_sha256']==old['identity']['wasm_'+enemy+'_sha256'],'Spar WASM differs'
        assert row['map_sha256']==old['map_sha256']
        found.append((row,old))
    expected={(o,s)for o in opponents for s in(0,1)}
    per_map=defaultdict(set)
    for row,_ in found:per_map[row['map_sha256']].add((row['opponent'],row['side']))
    assert per_map,'No matched completed games for '+name
    assert all(slots==expected for slots in per_map.values()),'Incomplete opponent/side panel on a map'
    return found


def describe(values):
    return {'mean':fmean(values),'median':median(values),
            'positive_maps':sum(v>1e-9 for v in values),
            'negative_maps':sum(v<-1e-9 for v in values),
            'neutral_maps':sum(abs(v)<=1e-9 for v in values)}


def summarize(pairs):
    maps=defaultdict(list)
    diagnostics=[defaultdict(int),defaultdict(int)]
    error_codes=[Counter(),Counter()]
    own_totals=[Counter(),Counter()]
    drafts_differ=0
    for row,old in pairs:
        ours,base=team_metrics(row),team_metrics(old)
        theirs,base_enemy=team_metrics(row,True),team_metrics(old,True)
        assert row['rounds']>0 and old['rounds']>0
        raw={k:ours[k]-base[k]for k in METRICS}
        margin={k:(ours[k]-theirs[k])-(base[k]-base_enemy[k])for k in METRICS}
        rate={k:100*(ours[k]/row['rounds']-base[k]/old['rounds'])for k in METRICS}
        maps[row['map_sha256']].append({'map':row['map'],'score_delta':score(row)-score(old),
             'round_delta':row['rounds']-old['rounds'],'raw':raw,'margin':margin,'per100round':rate})
        for i,r in enumerate((row,old)):
            q=quality(r)
            for k,v in q.items():
                if k!='caught_error_log_samples_by_code':diagnostics[i][k]+=v
            error_codes[i].update(q['caught_error_log_samples_by_code'])
            own_totals[i].update(ours if i==0 else base)
        drafts_differ+=row['statistics']['teams']!=old['statistics']['teams']and any(
            next(t for t in row['statistics']['teams']if t['team']==side)['draftPicks']!=
            next(t for t in old['statistics']['teams']if t['team']==side)['draftPicks']for side in(0,1))
    by_map={}
    for sha,items in maps.items():
        by_map[sha]={'map':items[0]['map'],'paired_games':len(items),
            'score_delta_sum':sum(x['score_delta']for x in items),
            'mean_round_delta':fmean(x['round_delta']for x in items),
            **{kind:{k:fmean(x[kind][k]for x in items)for k in METRICS}for kind in('raw','margin','per100round')}}
    diag_keys=set(diagnostics[0])|set(diagnostics[1])
    result={'games':len(pairs),'maps':len(maps),
            'candidate_win_score':sum(score(r)for r,b in pairs),
            'baseline_win_score':sum(score(b)for r,b in pairs),
            'candidate_totals':dict(own_totals[0]),'baseline_totals':dict(own_totals[1]),
            'mean_map_round_delta':fmean(v['mean_round_delta']for v in by_map.values()),
            'map_descriptive_deltas':{kind:{k:describe([m[kind][k]for m in by_map.values()])for k in METRICS}for kind in('raw','margin','per100round')},
            'quality':{'candidate':dict(diagnostics[0]),'baseline':dict(diagnostics[1]),
                'delta':{k:diagnostics[0][k]-diagnostics[1][k]for k in diag_keys},
                'candidate_caught_error_log_samples_by_code':dict(error_codes[0]),
                'baseline_caught_error_log_samples_by_code':dict(error_codes[1]),
                'caught_error_log_samples_by_code_delta':{k:error_codes[0][k]-error_codes[1][k]for k in set(error_codes[0])|set(error_codes[1])},
                'paired_draft_mismatch_games':drafts_differ},
            'by_map':by_map}
    return result


def analyze(paths,baseline_paths,names,opponents=SPARS,map_set='all'):
    rows=load(paths);baseline=load(baseline_paths)
    output={'limits':LIMITS,'map_set':map_set,'opponents':list(opponents),'candidates':{}}
    for name in names:
        pairs=matched_pairs(rows,baseline,name,opponents,map_set)
        output['candidates'][name]={'panel':summarize(pairs),
            'by_opponent':{o:summarize([p for p in pairs if p[0]['opponent']==o])for o in opponents}}
    return output


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('results',nargs='+');p.add_argument('--baseline',nargs='+',required=True)
    p.add_argument('--names',nargs='+',required=True);p.add_argument('--opponents',nargs='+',default=SPARS)
    p.add_argument('--map-set',choices=('all','official','gen','dev','legacy'),default='all')
    p.add_argument('--out',required=True)
    a=p.parse_args()
    output=analyze(a.results,a.baseline,a.names,tuple(a.opponents),a.map_set)
    dest=Path(a.out);dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    compact={}
    for name,item in output['candidates'].items():
        panel=item['panel'];ds=panel['map_descriptive_deltas']
        compact[name]={'games':panel['games'],'maps':panel['maps'],
            'score_delta':panel['candidate_win_score']-panel['baseline_win_score'],
            'mean_map_raw_delta':{k:round(ds['raw'][k]['mean'],3)for k in METRICS},
            'mean_map_per100round_delta':{k:round(ds['per100round'][k]['mean'],3)for k in METRICS},
            'quality':panel['quality']}
    print(json.dumps(compact,indent=2))


if __name__=='__main__':main()
