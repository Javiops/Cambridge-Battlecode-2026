"""Verify one frozen candidate's complete confirmation inputs and gates.

This never generates maps, builds, runs games or selects another candidate.
Freeze support fields come from generate_confirmation.confirmation_support_pins.
Run only after both complete candidate and original spar-panel stages exist.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sys
from compare import comparison
from generate_confirmation import (ROOT,DEST,REFERENCES,require,read,sha,stamp,
                                   validate_freeze,validate_maps,guard,write_new)


def confirmation_gates(comparison_result,faults,reinit):
    direct,panel=comparison_result['original'],comparison_result['panel']
    return {
        'positive_original':direct['wins']>direct['losses'],
        'original_p':direct['p_two_sided']<0.05,
        'positive_panel_mean':panel['score_delta']>0,
        'positive_panel_map_direction':panel['positive_maps']>panel['negative_maps'],
        'panel_p':panel['p_two_sided']<0.05,
        'per_spar_tolerance':all(v['percentage_point_delta']>=-1 for v in comparison_result['spar'].values()),
        'faults_and_reinitializations':faults==0 and reinit==0,
    }


def load_confirmation_rows(paths):
    rows={}
    for path in paths:
        for row in read(path)['games']:
            slot=(row['candidate'],row['opponent'],row['map_sha256'],row['side'])
            require(type(row['side'])is int and row['side']in (0,1),'Invalid semantic side')
            if slot in rows:
                previous={k:v for k,v in rows[slot].items() if k!='cached'}
                current={k:v for k,v in row.items() if k!='cached'}
                require(previous==current,'Conflicting repeated semantic confirmation slot')
            rows[slot]=row
    return rows


def verify_generation(freeze,plan):
    record=read(ROOT/'generation.json')
    require(record['status']=='complete','Confirmation generation is incomplete/failed')
    require(record['freeze_sha256']==sha(ROOT/'freeze.json'),'Freeze differs from pre-generation record')
    require(record['selection_plan_sha256']==freeze['selection_plan_sha256'],'Generation plan differs from freeze')
    require(record['generation_inputs']==freeze['generation_inputs'],'Generation inputs differ from freeze')
    require(record['seed']==plan['confirmation']['seed'] and record['count']==plan['confirmation']['maps'],'Generation cohort differs from plan')
    require(record['destination']=='arena/confirmation1024','Unexpected generation destination')
    from generate_confirmation import now
    require(stamp(freeze['created_utc'])<stamp(record['started_utc'])<=stamp(record['finished_utc'])<=stamp(now()),'Invalid freeze/generation chronology')
    require(record['manifest_sha256']==sha(DEST/'manifest.json'),'Generated manifest changed after completion')
    manifest,times=validate_maps(freeze,plan,record['started_utc'])
    require(stamp(record['started_utc'])<=stamp(manifest['created_at_utc'])<=stamp(record['finished_utc']),'Manifest outside generation window')
    require(times=={k:record[k] for k in times},'Map file times differ from completed generation record')
    require(stamp(times['last_map_file_utc'])<=stamp(record['finished_utc']),'Map file modified after completed generation')
    return record,manifest


def verify_rows(rows,freeze,plan,generation,manifest):
    from test_matches import stats_fields
    name=freeze['candidate'];maps={m['sha256'] for m in manifest['maps']}
    pairings=[(name,reference) for reference in REFERENCES]+[('original',spar) for spar in REFERENCES if spar!='original']
    expected={(candidate,opponent,h,side) for candidate,opponent in pairings for h in maps for side in (0,1)}
    require(set(rows)==expected,'Missing, extra or mismatched semantic confirmation slots')
    require(len(expected)==14*plan['confirmation']['maps'],'Wrong confirmation panel size')
    wasm={name:freeze['wasm_sha256'],**freeze['reference_wasm_sha256']}
    physical={}
    for slot,row in rows.items():
        candidate,opponent,map_hash,side=slot
        a,b=(candidate,opponent) if side==0 else (opponent,candidate)
        identity=row['identity']
        require(identity['wasm_a_sha256']==wasm[a] and identity['wasm_b_sha256']==wasm[b],'Result source/WASM differs from frozen ordered pair')
        require(identity['runtime']==freeze['runtime'],'Result runtime differs from freeze')
        require(identity['map_sha256']==map_hash==row['map_sha256'],'Result map identity differs')
        key=hashlib.sha256(json.dumps(identity,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        require(key==row['key'],'Result physical key differs from identity')
        require(row.get('valid')is True and row.get('schema_version')==2,'Invalid completed-game record')
        require(stamp(row['created_utc'])>=stamp(generation['finished_utc']),'Result predates completed frozen map generation')
        require(all(row.get(k)==v for k,v in stats_fields(row['statistics']).items()),'Result derived fields differ from statistics')
        serialized=json.dumps(row['statistics'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
        require(hashlib.sha256(serialized).hexdigest()==row['statistics_content_sha256'],'Result statistics content hash differs')
        require(set(row['stdout'])=={'a','b'},'Missing team diagnostics')
        for stream in row['stdout'].values():
            require(isinstance(stream['initializations'],dict) and all(type(n)is int and n>=1 for n in stream['initializations'].values()),'Invalid initialization marker counts')
            computed=sum(max(0,n-1) for n in stream['initializations'].values())
            require(type(stream['reinitializations_observed'])is int and stream['reinitializations_observed']==computed,'Initialization diagnostic differs from markers')
        if key in physical:
            previous=physical[key]
            require(previous['statistics_content_sha256']==row['statistics_content_sha256'] and previous['outcome']==row['outcome'] and previous['stdout']==row['stdout'],'Conflicting physical game reuse')
        else:physical[key]=row
    faults=sum(any(r['faults']) for r in physical.values())
    reinit=sum(any(v['reinitializations_observed'] for v in r['stdout'].values()) for r in physical.values())
    return physical,faults,reinit


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('paths',nargs='+',type=Path);args=parser.parse_args()
    freeze,plan=validate_freeze();generation,manifest=verify_generation(freeze,plan)
    file_pins={str(p.resolve()):sha(p) for p in args.paths}
    rows=load_confirmation_rows(args.paths)
    physical,faults,reinit=verify_rows(rows,freeze,plan,generation,manifest)
    result=comparison(rows,freeze['candidate']);count=plan['confirmation']['maps']
    require(result['original']['maps']==result['panel']['maps']==count,'Wrong paired-map counts')
    require(result['original']['games']==2*count and result['panel']['games']==6*count,'Wrong direct/panel game counts')
    require(all(sha(p)==file_pins[str(p.resolve())] for p in args.paths),'Result files changed during verification')
    validate_freeze();verify_generation(freeze,plan)
    gates=confirmation_gates(result,faults,reinit)
    out={'candidate':freeze['candidate'],'comparison':result,'gates':gates,'passes':all(gates.values()),
         'semantic_confirmation_slots':len(rows),'unique_physical_games':len(physical),
         'fault_games':faults,'reinitialization_games':reinit,
         'freeze_sha256':sha(ROOT/'freeze.json'),'generation_record_sha256':sha(ROOT/'generation.json'),
         'result_files_sha256':file_pins,
         'scope':'One frozen candidate and fixed generated-map cohort against pinned study27 and three older spars; not an online ladder guarantee. Caught SDK errors are separate diagnostics.'}
    verdict=guard(ROOT/'confirmation-verdict.json')
    if verdict.exists():require(read(verdict)==out,'A different confirmation verdict already exists')
    else:write_new(verdict,out)
    print(json.dumps(out,indent=2));return 0


if __name__=='__main__':
    try:raise SystemExit(main())
    except (RuntimeError,OSError,ValueError,KeyError) as error:
        print('CONFIRMATION REFUSED/FAILED: '+str(error),file=sys.stderr);raise SystemExit(1)
