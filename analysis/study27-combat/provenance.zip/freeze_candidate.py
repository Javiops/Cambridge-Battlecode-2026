"""Freeze the pre-recorded development winner once, before any fresh maps."""
from lab import ROOT,read,sha,now
from test_matches import runtime_identity
from generate_confirmation import confirmation_support_pins,write_new,validate_freeze

name='cm_combo_aoe_dash'
single=read(ROOT/'full-comparison.json')['comparisons']
combo=read(ROOT/'combo-comparison.json')['comparisons'][name]
ablations=read(ROOT/'combo-ablations.json')
assert combo['development_eligible']
assert all(v['development_eligible'] for v in single.values())
assert combo['panel']['candidate_win_score']-max(v['panel']['candidate_win_score'] for v in single.values())>=8
assert all(v['wins']>=v['losses'] for v in ablations.values())
assert (ROOT/'combo-audit.json').is_file()
decision={'candidate':name,'created_utc':now(),'features':['cm_sweep_aoe_edge','cm_dash_cd_reach'],
 'selection':'Recorded >=8 panel-win incremental threshold plus nonlosing direct component ablations and ordinary development gates.',
 'comparison':combo,'single_comparisons':single,'direct_ablations':ablations,
 'independent_combo_audit_sha256':sha(ROOT/'combo-audit.json'),
 'limits':'Adaptive development winner; not yet independently confirmed. AoE-vs-combo direct ablation is weak (p=.603). No per-component fresh-confirmation claim.'}
write_new(ROOT/'selection.json',decision)
record=read(ROOT/'candidates'/f'{name}.json')
freeze={'candidate':name,'created_utc':now(),'selection_plan_sha256':sha(ROOT/'selection-plan.json'),
 'selection_sha256':sha(ROOT/'selection.json'),'source_sha256':record['source_sha256'],
 'wasm_sha256':record['wasm_sha256'],'features':record['features'],
 'patch_modules_sha256':record['patch_modules_sha256'],
 'reference_wasm_sha256':{n:read(ROOT/'candidates'/f'{n}.json')['wasm_sha256'] for n in ('original','spar11','spar12','spar16')},
 'runtime':runtime_identity(),**confirmation_support_pins()}
write_new(ROOT/'freeze.json',freeze)
validate_freeze()
print('Frozen',name,'WASM',record['wasm_sha256'])
