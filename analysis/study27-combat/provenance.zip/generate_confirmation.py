"""Generate the single fixed confirmation cohort only after a verified freeze.

No work runs on import. Root must call this script after writing freeze.json.
Merge **confirmation_support_pins() into the proposed freeze fields. Required:
candidate, created_utc, selection_plan_sha256, source_sha256, wasm_sha256,
reference_wasm_sha256 (original/spar11/spar12/spar16), runtime, and the support
pins returned here. --check-only validates that freeze without creating files.
The generator creates maps and native integrity checks; it never runs bot games.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import uuid

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
ARENA=ROOT/'arena'
GENERATOR=ROOT.parent/'study28-fixes/generate-fresh.mjs'
GENERATOR_HELPER=ROOT.parent/'battlecode-bot-v1/r2-ward/map-variants.mjs'
GENERATOR_ENGINE=ROOT.parent/'battlecode-bot-v1/r2-research/v0_0_1-ctH8uuEb.wasm'
DEST=ARENA/'confirmation1024'
REFERENCES=('original','spar11','spar12','spar16')


def require(ok,message):
    if not ok:raise RuntimeError(message)


def now():return datetime.now(timezone.utc).isoformat()
def read(path):return json.loads(Path(path).read_text(encoding='utf8'))


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()


def stamp(value):
    result=datetime.fromisoformat(value.replace('Z','+00:00'))
    require(result.tzinfo is not None and result.utcoffset() is not None,'Timestamp must include UTC offset')
    return result.astimezone(timezone.utc)


def guard(path):
    path=Path(path).absolute();require(path.is_relative_to(ROOT),'Output escapes combat task')
    cursor=path
    while True:
        try:observed=cursor.lstat()
        except FileNotFoundError:observed=None
        if observed is not None:
            require(not stat.S_ISLNK(observed.st_mode) and not(getattr(observed,'st_file_attributes',0)&0x400),'Refusing output redirect: '+str(cursor))
        if cursor==ROOT:break
        cursor=cursor.parent
    require(path.resolve()==path,'Output redirects from intended location')
    return path


def absent(path):
    guard(path)
    try:path.lstat()
    except FileNotFoundError:return
    raise RuntimeError('Refusing existing confirmation output: '+str(path))


def write_new(path,value):
    path=guard(path)
    with path.open('x',encoding='utf8',newline='\n') as stream:stream.write(json.dumps(value,indent=2)+'\n')


def development_map_pins():
    result={}
    for folder,count in (('maps',9),('maps_gen',44),('maps_dev200',200)):
        files=sorted((ARENA/folder).glob('*.map26a'))
        require(len(files)==count,'Development map cohort changed: '+folder)
        for file in files:result[file.relative_to(ARENA).as_posix()]=sha(file)
    require(len(result)==253 and len(set(result.values()))==253,'Development cohort must contain253 unique map byte hashes')
    return result


def confirmation_support_pins():
    return {'generation_inputs':{'generator_sha256':sha(GENERATOR),
            'helper_sha256':sha(GENERATOR_HELPER),'engine_sha256':sha(GENERATOR_ENGINE),
            'wrapper_sha256':sha(Path(__file__))},
            'confirmation_tool_sha256':sha(ROOT/'confirm.py'),
            'development_maps_sha256':development_map_pins()}


def source_hashes(name):
    require(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,63}',name),'Invalid candidate/reference name')
    folder=guard(ARENA/'bots'/name/'src')
    files=list(folder.iterdir());require(files and all(guard(p).is_file() for p in files),'Unexpected source directory')
    return {p.name:sha(p) for p in sorted(files)}


def validate_freeze():
    from test_matches import verify_runtime,EXPECTED_ENGINE
    freeze=read(ROOT/'freeze.json');plan=read(ROOT/'selection-plan.json')
    require(sha(ROOT/'selection-plan.json')==freeze['selection_plan_sha256'],'Selection plan changed after freeze')
    require(stamp(freeze['created_utc'])<=stamp(now()),'Freeze is future-dated')
    name=freeze['candidate'];require(isinstance(name,str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,63}',name),'Invalid frozen candidate name')
    require(name not in REFERENCES,'Candidate cannot be a reference alias')
    record=read(ROOT/'candidates'/f'{name}.json')
    require(record['source_sha256']==freeze['source_sha256'] and record['wasm_sha256']==freeze['wasm_sha256'],'Candidate registration differs from freeze')
    require(source_hashes(name)==freeze['source_sha256'],'Candidate source files differ from freeze')
    require(sha(ARENA/'bots'/name/'.cambc/build/bot-injected.wasm')==freeze['wasm_sha256'],'Candidate WASM differs from freeze')
    require(record['base_commit']==plan['baseline_commit'],'Candidate is not based on the pinned study27 commit')
    require(freeze['runtime']['engine_version']==EXPECTED_ENGINE,'Frozen engine version differs from harness')
    for field in ('cli_sha256','project_config_sha256','sdk_header_sha256'):
        require(record[field]==freeze['runtime'][field],'Candidate build differs from frozen runtime: '+field)
    require(set(freeze['reference_wasm_sha256'])==set(REFERENCES),'Incomplete reference WASM pins')
    for reference in REFERENCES:
        ref=read(ROOT/'candidates'/f'{reference}.json')
        expected_commit=plan['baseline_commit'] if reference=='original' else plan['spar_commit']
        require(ref['base_commit']==expected_commit,'Reference commit changed: '+reference)
        for field in ('cli_sha256','project_config_sha256','sdk_header_sha256'):
            require(ref[field]==freeze['runtime'][field],'Reference build differs from frozen runtime: '+reference+'/'+field)
        require(source_hashes(reference)==ref['source_sha256'],'Reference source changed: '+reference)
        require(ref['wasm_sha256']==freeze['reference_wasm_sha256'][reference],'Reference registration differs from freeze')
        require(sha(ARENA/'bots'/reference/'.cambc/build/bot-injected.wasm')==freeze['reference_wasm_sha256'][reference],'Reference WASM differs from freeze')
    verify_runtime(freeze['runtime'])
    require(confirmation_support_pins()=={k:freeze[k] for k in ('generation_inputs','confirmation_tool_sha256','development_maps_sha256')},'Generator, validation tool or development map pins changed after freeze')
    return freeze,plan


def manifest_structure(manifest,count,seed):
    require(type(manifest.get('count'))is int and manifest['count']==count,'Wrong confirmation map count')
    require(type(manifest.get('seed'))is int and manifest['seed']==seed,'Wrong confirmation seed')
    require(manifest.get('source_maps_read')==0 and manifest.get('candidate_results_read')is False,'Generator must not read old maps or candidate outcomes')
    maps=manifest.get('maps');require(isinstance(maps,list) and len(maps)==count,'Incomplete manifest rows')
    names=[];hashes=[];geometries=[]
    for row in maps:
        name=row['file'];require(Path(name).name==name and re.fullmatch(r'fresh-\d{4}\.map26a',name),'Unsafe/unexpected map filename')
        for field in ('sha256','topology_d4_sha256'):require(re.fullmatch(r'[0-9a-f]{64}',row[field]),'Invalid map/topology hash')
        names.append(name);hashes.append(row['sha256']);geometries.append(row['topology_d4_sha256'])
        validation=row['validation']
        require(all(validation.get(k)is True for k in ('official_integrity','official_verify_game','official_runtime_expansion_equal','all_camps_reachable_from_both_teams','all_altars_reachable_from_both_teams','mirrored_camp_distance_equal')),'Missing native/reachability validation')
    require(len(set(names))==len(set(hashes))==len(set(geometries))==count,'Duplicate map file, bytes or nonbush D4 topology')
    return maps


def validate_maps(freeze,plan,started_utc):
    guard(DEST)
    manifest=read(guard(DEST/'manifest.json'))
    maps=manifest_structure(manifest,plan['confirmation']['maps'],plan['confirmation']['seed'])
    require({k:manifest[k] for k in ('generator_sha256','helper_sha256','engine_sha256')}==
            {k:freeze['generation_inputs'][k] for k in ('generator_sha256','helper_sha256','engine_sha256')},'Manifest generator/engine pins differ from freeze')
    require(stamp(manifest['created_at_utc'])>=stamp(started_utc),'Manifest predates recorded generation start')
    expected={m['file'] for m in maps}|{'manifest.json'}
    require({p.name for p in DEST.iterdir()}==expected,'Unexpected/missing confirmation output files')
    old=set(freeze['development_maps_sha256'].values());times=[]
    for row in maps:
        file=guard(DEST/row['file'])
        require(file.is_file() and sha(file)==row['sha256'],'Actual map bytes differ from manifest: '+row['file'])
        require(row['sha256']not in old,'Confirmation repeats a development map')
        modified=datetime.fromtimestamp(file.stat().st_mtime,timezone.utc)
        require(modified>=stamp(started_utc),'Map file predates generation start: '+row['file'])
        times.append(modified)
    return manifest,{'first_map_file_utc':min(times).isoformat(),'last_map_file_utc':max(times).isoformat()}


def find_node():
    value=os.environ.get('CAMBC_NODE') or shutil.which('node')
    fallback=Path('C:/Users/frans/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
    result=Path(value) if value else fallback
    require(result.is_file(),'Set CAMBC_NODE to the Node executable')
    return result.resolve()


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--check-only',action='store_true');args=parser.parse_args()
    freeze,plan=validate_freeze()
    if args.check_only:
        print('Freeze, sources, references, runtime, generation tools and253 development map pins verified. No files created.');return 0
    record_path=ROOT/'generation.json';log_path=ROOT/'generation.log'
    for output in (DEST,record_path,log_path):absent(output)
    node=find_node();started=now();require(stamp(started)>stamp(freeze['created_utc']),'Generation must start after freeze')
    command=[str(node),str(GENERATOR),'--seed',str(plan['confirmation']['seed']),'--count',str(plan['confirmation']['maps']),'--out',str(DEST)]
    record={'status':'running','run_id':str(uuid.uuid4()),'started_utc':started,'freeze_sha256':sha(ROOT/'freeze.json'),
            'selection_plan_sha256':freeze['selection_plan_sha256'],'generation_inputs':freeze['generation_inputs'],
            'seed':plan['confirmation']['seed'],'count':plan['confirmation']['maps'],'destination':'arena/confirmation1024',
            'node_sha256':sha(node),'command':command}
    write_new(record_path,record)
    try:
        with guard(log_path).open('x',encoding='utf8') as log:
            proc=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,text=True,timeout=1800)
        require(proc.returncode==0,'Official map generation failed; see generation.log')
        validate_freeze();require(sha(ROOT/'freeze.json')==record['freeze_sha256'],'Freeze changed during generation')
        require(sha(node)==record['node_sha256'],'Node changed during generation')
        manifest,times=validate_maps(freeze,plan,started)
        record.update(status='complete',finished_utc=now(),manifest_sha256=sha(DEST/'manifest.json'),
                      generator_manifest_created_utc=manifest['created_at_utc'],**times)
    except Exception as error:
        record.update(status='failed',finished_utc=now(),error=str(error));raise
    finally:
        require(read(record_path)['run_id']==record['run_id'],'Generation record changed during execution')
        temporary=guard(record_path.with_name('generation.json.'+str(os.getpid())+'.tmp'))
        write_new(temporary,record);os.replace(temporary,guard(record_path))
    print(json.dumps(record,indent=2));return 0


if __name__=='__main__':
    try:raise SystemExit(main())
    except (RuntimeError,OSError,ValueError,KeyError) as error:
        print('GENERATION REFUSED/FAILED: '+str(error),file=sys.stderr);raise SystemExit(1)
