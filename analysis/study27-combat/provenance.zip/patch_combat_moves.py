"""Small, independent fight.h-only experiments on exact stable study27.

Input source comes from the pinned Git baseline. apply_many checks the original
fight.h hash once, then applies unique requested features in canonical order.
Other source files are preserved byte-for-byte as supplied, allowing composition
with the separate main.cpp targeting module. No local files are read by apply.
These are candidate heuristics; only paired engine experiments decide retention.
"""
from __future__ import annotations

import hashlib

BASE_FIGHT_SHA256 = "2e5bb46e20258e7eebc8ca3e2a62fbbdd3e1fd216813c15270569f419a2a022b"
FEATURES = (
    "cm_dash_cd_reach",
    "cm_kite_spell_reach",
    "cm_kite_volley_tie",
    "cm_retreat_available_allies",
    "cm_kite_available_allies",
)

DASH_HELPER = r'''
// Combat-moves experiment: cooldown uses owner turn-end ticks. Treat <=1 as
// potentially ready at the next opportunity rather than asserting an exact
// initiative forecast. Missing/unreadable metadata keeps the original reach.
inline bool combat_moves_dash_soon(const bc::champion& c) {
    try {
        bool found = false;
        for (const auto& ab : c.abilities()) {
            if (!ab.is_dash()) continue;
            found = true;
            if (ab.cooldown() <= 1) return true;
        }
        return !found;
    } catch (...) {
        return true;
    }
}

'''

SPELL_REACH = r'''    // Combat-moves experiment: existing fresh volley metadata also includes
    // stationary spell range, move-compatible spells and free crowd control.
    // Reuse that snapshot; no additional vision scan or live SDK queries.
    std::vector<int> reaches;
    bool ready_contact = false;
    for (auto* f : near) {
        int r = reach(*f);
        if (s.thr_r == round)
            for (const auto& th : s.thr) {
                if (!(th.p == f->p)) continue;
                if (th.xd > 0 && th.xr >= 0) r = std::max(r, th.xr);
                if (th.fd > 0 && th.fr >= 0) r = std::max(r, th.fr + 1);
                if (th.sr >= 0) r = std::max(r, th.sr + 1);
            }
        reaches.push_back(r);
        if (f->d <= r) ready_contact = true;
    }
'''


def _replace_once(text: str, old: str, new: str) -> str:
    count = text.count(old)
    if count != 1:
        raise ValueError(f"Expected one pinned fight.h anchor, found {count}: {old[:100]!r}")
    return text.replace(old, new, 1)


def function_block(text: str, signature: str) -> tuple[int, int]:
    """Return this fixed source's complete function, including nested lambdas."""
    if text.count(signature) != 1:
        raise ValueError("Function anchor differs: " + signature)
    start = text.index(signature)
    brace = text.index("{", start)
    depth, end = 1, brace + 1
    while depth:
        depth += (text[end] == "{") - (text[end] == "}")
        end += 1
    return start, end


def _within(text: str, signature: str, old: str, new: str) -> str:
    start, end = function_block(text, signature)
    return text[:start] + _replace_once(text[start:end], old, new) + text[end:]


def _one(fight: str, feature: str) -> str:
    if feature == "cm_dash_cd_reach":
        fight = _replace_once(fight, "inline int reach(const Foe& f) {",
                              DASH_HELPER + "inline int reach(const Foe& f) {")
        return _within(fight, "inline int reach(", "        return dash ? 3 : 2;",
                       "        if (!dash) return 2;\n"
                       "        return combat_moves_dash_soon(f.c) ? 3 : 2;")

    if feature == "cm_kite_spell_reach":
        signature = "inline bool kite("
        fight = _within(fight, signature,
            "    // P_KITE_ZONE: nobody within this many tiles and we were not hit: keep farming (two caster balls\n",
            SPELL_REACH + "    // P_KITE_ZONE: nobody within this many tiles and we were not hit: keep farming (two caster balls\n")
        fight = _within(fight, signature,
            "    if (P_KITE_ZONE && closest > P_KITE_ZONE && round - s.hit_round > 2) return false;",
            "    if (P_KITE_ZONE && closest > P_KITE_ZONE && round - s.hit_round > 2 && !ready_contact) return false;")
        fight = _within(fight, signature, "        if (!live) return false;",
            "        if (!live && !ready_contact) return false;")
        return _within(fight, signature,
            "    std::vector<int> reaches;\n    for (auto* f : near) reaches.push_back(reach(*f));\n",
            "    // Ready reaches were sampled before the contact gates above.\n")

    if feature == "cm_kite_volley_tie":
        signature = "inline bool kite("
        fight = _within(fight, signature,
            "        double bs = score(pos);\n        std::optional<vec2> bt;",
            "        double bs = score(pos);\n"
            "        // Combat-moves experiment: preserve the original movement objective;\n"
            "        // prefer lower ready damage only among equally scoring positions.\n"
            "        const bool fresh_volley = s.thr_r == round;\n"
            "        double bd = fresh_volley ? danger_at(s.thr, pos) : 0.0;\n"
            "        std::optional<vec2> bt;")
        return _within(fight, signature,
            "                if (sc > bs + 0.5) { bs = sc; bt = t; }",
            "                const double dg = fresh_volley ? danger_at(s.thr, t) : 0.0;\n"
            "                if (sc > bs + 0.5 || (std::abs(sc - bs) <= 0.5 && dg + 1.0 < bd)) {\n"
            "                    bs = sc; bd = dg; bt = t;\n"
            "                }")

    if feature == "cm_retreat_available_allies":
        return _within(fight, "inline bool safe_step(",
            "            if (!(a == me) && a.is_alive() && a.health() > 0.4f * a.max_health()) allies.push_back(a.position());",
            "            // Combat-moves experiment: a channeling body is not immediate retreat support.\n"
            "            if (!(a == me) && a.is_alive() && a.health() > 0.4f * a.max_health() &&\n"
            "                !a.is_recalling() && !a.is_teleporting() && !a.is_submitting_gems())\n"
            "                allies.push_back(a.position());")

    if feature == "cm_kite_available_allies":
        return _within(fight, "inline bool kite(",
            "                if (a == me || !a.is_alive()) continue;",
            "                // Combat-moves experiment: omit unavailable channeling support.\n"
            "                if (a == me || !a.is_alive() || a.is_recalling() ||\n"
            "                    a.is_teleporting() || a.is_submitting_gems()) continue;")
    raise ValueError("Unknown combat movement feature: " + str(feature))


def apply_many(source: dict[str, str], features) -> dict[str, str]:
    requested = tuple(features)
    if len(set(requested)) != len(requested) or any(f not in FEATURES for f in requested):
        raise ValueError("Unknown or duplicate combat movement feature")
    out = dict(source)
    original = out["fight.h"].replace("\r\n", "\n").replace("\r", "\n")
    if hashlib.sha256(original.encode("utf8")).hexdigest() != BASE_FIGHT_SHA256:
        raise ValueError("Expected exact c462346d stable study27 fight.h before movement transforms")
    fight = original
    for feature in FEATURES:
        if feature in requested:
            fight = _one(fight, feature)
    if requested:
        out["fight.h"] = fight
    return out


def apply(source: dict[str, str], feature: str) -> dict[str, str]:
    return apply_many(source, (feature,))
