"""Isolated main.cpp combat policies for source-pinned stable study27.

No transform changes draft, shop, recall, camp-targeted casting/attacking, farming,
or shared memory. Availability/geometry estimates are policies, not path proofs.
apply_many applies a canonical feature set once; fresh-basic is subsumed by the
spell-kill retarget policy. No local source/patch files are read by transforms.
"""
from __future__ import annotations
import hashlib

BASE_MAIN = "0650eda916f8f2fe16ae69923d239d15e916e738205e90060113fac65a85453f"
FEATURES = ("cm_fresh_basic", "cm_spellkill_retarget", "cm_sweep_execute",
            "cm_sweep_cc_focus", "cm_sweep_aoe_edge", "cm_killable_ready")

RETARGET = r'''
template <class U>
bool basic_attack(State& s, bc::champion& me, const U& tgt, vec2 tpos);

// Recover a still-available basic after our spell removed the chosen champion.
// This helper is never called for camp targets, and never starts another spell.
bool cm_retarget_basic(State& s, bc::champion& me) {
    if (!me.can_attack()) return false;
    const vec2 pos = me.position();
    const int range = static_cast<int>(me.attack_range());
    std::optional<bc::champion> best;
    vec2 best_pos;
    float best_hp = 1e30f;
    for (auto& c : bc::vision::champions(*s.en)) {
        try {
            if (!c.is_visible() || !c.is_alive()) continue;
            const vec2 p = c.position();
            const float hp = c.health();
            if (hp <= 0 || dist(pos, p) > range || s.en_spawn.is_set(p)) continue;
            if (hp < best_hp) { best = c; best_pos = p; best_hp = hp; }
        } catch (...) {
        }
    }
    return best && basic_attack(s, me, *best, best_pos);
}

'''

SPELL_HELPERS = r'''
// The SDK predicts health lost after mitigation/shields, capped at target HP.
// Readiness and geometric range are checked separately; one spell per turn.
bool cm_spell_can_finish(State& s, bc::champion& me, int k, const bc::champion& target,
                         bool free_only = false) {
    return attempt([&] {
        if (!me.can_cast() || !target.is_visible() || target.health() <= 0) return false;
        if (s.slots[k] != Slot::Targeted && s.slots[k] != Slot::Ground) return false;
        auto ab = me.abilities()[k];
        if (!ab.is_ready() || (!ab.is_damage() && !ab.is_aoe_damage() && !ab.is_cc())) return false;
        if (s.slots[k] == Slot::Targeted && !ab.can_target_enemies()) return false;
        auto info = ab.info();
        if (!info) return false;
        double range = 0;
        bool exclusive = false;
        std::visit([&](const auto& x) {
            exclusive = x.exclusive_with_movement;
            if constexpr (requires { x.range; }) range = x.range;
            if constexpr (requires { x.radius; }) range += x.radius;
        }, *info);
        if ((free_only && exclusive) || dist(me.position(), target.position()) > range) return false;
        return ab.damage_amount(target) >= target.health();
    });
}

'''

STUN_HELPER = r'''
// An active stun or stun immunity removes the control value of another stun;
// damaging CC may still be used if there is no other useful control target.
bool cm_stun_useful(const bc::champion& target) {
    return attempt([&] {
        return target.is_visible() && target.health() > 0 &&
               target.passive() != bc::passive_type::stun_immunity && !target.buffs().has_stun();
    });
}

'''

EDGE_HELPER = r'''
// An AoE with cast range four and radius one can hit a visible champion five
// tiles away by aiming at a legal nearer centre. Ordinary targeted casts keep
// their existing scan/range; this is only a fallback when they did not cast.
bool cm_edge_aoe(State& s, bc::champion& me, bool allow_exclusive, bool track_root,
                 bool free_only = false, bool escape = false) {
    if (s.sweep < 3 || !me.can_cast() || !fuel_ok(16000)) return false;
    const vec2 pos = me.position();
    auto abs = me.abilities();
    for (int k = 0; k < 2; ++k) {
        if (s.slots[k] != Slot::Ground || !abs[k].is_ready()) continue;
        const AoeSlot a = aoe_slot(me, k);
        if (a.radius <= 0) continue;
        const bool exclusive = slot_exclusive(s, me, k);
        if (exclusive && (!allow_exclusive || free_only || escape)) continue;
        std::optional<vec2> best;
        double best_score = -1e30;
        for (auto& c : bc::vision::champions(*s.en)) {
            if (!fuel_ok(8000)) return false;
            attempt([&] {
                if (!c.is_visible() || !c.is_alive() || c.health() <= 0) return false;
                const vec2 p = c.position();
                const int d = dist(pos, p);
                if (s.en_spawn.is_set(p) || d <= SPELL_RANGE || d > a.range + a.radius) return false;
                int hits = 0;
                vec2 centre = aoe_centre(s, me, k, p, &hits);
                if (hits <= 0 || dist(pos, centre) > a.range || dist(centre, p) > a.radius) return false;
                const double score = hits * 1000.0 - c.health();
                if (score > best_score) { best = centre; best_score = score; }
                return true;
            });
        }
        if (best && attempt([&] { return abs[k].use(*best); })) {
            if (track_root && exclusive) s.rooted_r = static_cast<int>(bc::round_number());
            return true;
        }
    }
    return false;
}

'''

KILL_HELPER = r'''
// Estimate an available finishing route, taking the best of mutually exclusive
// casts instead of assuming every champion has two basic attacks. Basic damage
// still uses raw Strength and range is geometric; this is not a path proof.
double cm_available_finish_damage(State& s, bc::champion& me, const bc::champion& target) {
    double best = 0;
    attempt([&] {
        if (!target.is_visible() || target.health() <= 0) return false;
        const int d = dist(me.position(), target.position());
        const int ar = static_cast<int>(me.attack_range());
        const double basic = me.strength();
        const bool attack = me.can_attack(), move = me.can_move();
        const bool walk_basic = attack && (d <= ar || (ar <= 1 && move && d <= ar + 1));
        if (walk_basic) best = basic;
        if (!me.can_cast()) return true;
        auto abs = me.abilities();
        for (int k = 0; k < 2; ++k) {
            auto& ab = abs[k];
            if (!ab.is_ready()) continue;
            auto info = ab.info();
            if (!info) continue;
            int range = 0;
            bool exclusive = false;
            std::visit([&](const auto& x) {
                exclusive = x.exclusive_with_movement;
                if constexpr (requires { x.range; }) range = static_cast<int>(x.range);
                if constexpr (requires { x.radius; }) range += static_cast<int>(x.radius);
            }, *info);
            if (ab.is_attack_reset()) {
                if (d <= ar || (ar <= 1 && move && d <= ar + 1))
                    best = std::max(best, basic * (attack ? 2.0 : 1.0));
            } else if (ab.is_dash()) {
                if (attack && d <= ar + range + ((ar <= 1 && move) ? 1 : 0)) best = std::max(best, basic);
            } else if (s.slots[k] == Slot::Targeted || s.slots[k] == Slot::Ground) {
                if (!ab.is_damage() && !ab.is_aoe_damage() && !ab.is_cc()) continue;
                if (s.slots[k] == Slot::Targeted && !ab.can_target_enemies()) continue;
                if (d > range) continue;
                const double damage = ab.damage_amount(target);
                const bool add_basic = attack && (d <= ar || (!exclusive && ar <= 1 && move && d <= ar + 1));
                best = std::max(best, damage + (add_basic ? basic : 0.0));
            }
        }
        return true;
    });
    return best;
}

'''


def _once(text, old, new):
    if text.count(old) != 1:
        raise ValueError(f"Expected one pinned study27 anchor: {old[:110]!r}")
    return text.replace(old,new,1)


def apply(source:dict[str,str], feature:str)->dict[str,str]:
    return apply_many(source,[feature])


def apply_many(source:dict[str,str], features)->dict[str,str]:
    requested=tuple(features)
    if not requested or len(set(requested))!=len(requested) or any(n not in FEATURES for n in requested):
        raise ValueError(requested)
    out=dict(source)
    main=out['main.cpp']
    if hashlib.sha256(main.encode()).hexdigest()!=BASE_MAIN:
        raise ValueError('Expected unchanged stable study27 main.cpp before target transforms')
    chosen=set(requested)
    helpers=[]
    if chosen & {'cm_fresh_basic','cm_spellkill_retarget'}:
        retarget='cm_spellkill_retarget'in chosen
        if retarget:
            main=_once(main,'template <class U>\nbool basic_attack(State& s, bc::champion& me, const U& tgt, vec2 tpos) {',
                       RETARGET+'template <class U>\nbool basic_attack(State& s, bc::champion& me, const U& tgt, vec2 tpos) {')
        prefix=('    // Champion handles can die or move after a preceding spell.\n'
                '    if constexpr (std::is_same_v<std::remove_cvref_t<U>, bc::champion>) {\n'
                '        if (!me.can_attack()) return false;\n'
                '        if (!u34_target_visible(tgt)) '+('return cm_retarget_basic(s, me);'if retarget else'return false;')+'\n'
                '        tpos = tgt.position();\n'
                '    }\n')
        main=_once(main,'bool basic_attack(State& s, bc::champion& me, const U& tgt, vec2 tpos) {\n',
                   'bool basic_attack(State& s, bc::champion& me, const U& tgt, vec2 tpos) {\n'+prefix)
        if retarget:
            main=_once(main,'    if (basic_attack(s, me, tgt, tpos)) return true;\n    if (dist(me.position(), tpos) > range) {',
                '    if (basic_attack(s, me, tgt, tpos)) return true;\n'
                '    if constexpr (std::is_same_v<std::remove_cvref_t<U>, bc::champion>) {\n'
                '        if (acted && !u34_target_visible(tgt)) return acted;\n'
                '    }\n'
                '    if (dist(me.position(), tpos) > range) {')
    if 'cm_killable_ready'in chosen:
        helpers.append(KILL_HELPER)
        main=_once(main,'bool killable = tgt && tgt->hp <= me.strength() * 2.0f;',
                   'bool killable = tgt && tgt->hp <= cm_available_finish_damage(s, me, tgt->c);')
    if 'cm_sweep_execute'in chosen:
        helpers.append(SPELL_HELPERS)
        main=_once(main,'auto try_use = [&](bool want_cc, Foe* t) {',
                   'auto try_use = [&](bool want_cc, Foe* t, bool lethal_only = false) {')
        main=_once(main,'            if (cc != want_cc || !ab.is_ready()) continue;\n',
                   '            if (cc != want_cc || !ab.is_ready()) continue;\n'
                   '            if (lethal_only && !cm_spell_can_finish(s, me, k, t->c, free_only)) continue;\n')
        execute=r'''    // Take a legal one-spell finish before spending the cast on control or a large bag.
    Foe* cm_finish = nullptr;
    double cm_finish_score = 1e30;
    if (fuel_ok(16000)) {
        for (auto& f : foes) {
            if (!fuel_ok(10000)) break;
            bool lethal = cm_spell_can_finish(s, me, 0, f.c, free_only) || cm_spell_can_finish(s, me, 1, f.c, free_only);
            const double score = f.hp - (f.channeling ? 300.0 : 0.0) - 5.0 * f.gems;
            if (lethal && score < cm_finish_score) { cm_finish = &f; cm_finish_score = score; }
        }
    }
    if (cm_finish) {
        try_use(false, cm_finish, true);
        if (!cast) try_use(true, cm_finish, true);
    }
'''
        main=_once(main,'    if (threat) try_use(true, threat);\n',execute+'    if (!cast && threat) try_use(true, threat);\n')
    if 'cm_sweep_cc_focus'in chosen:
        helpers.append(STUN_HELPER)
        anchor='            if (cc != want_cc || !ab.is_ready()) continue;\n'
        smart=r'''            if (want_cc && @LETHAL_GUARD@!cm_stun_useful(t->c)) {
                Foe* alternative = nullptr;
                for (auto& f : foes)
                    if (f.d <= fight::reach(f) && cm_stun_useful(f.c) && (!alternative || f.d < alternative->d)) alternative = &f;
                if (alternative) t = alternative;
                // Damage remains useful even when the control component is redundant.
                if (!cm_stun_useful(t->c) && attempt([&] { return ab.damage_amount(t->c) <= 0; })) continue;
            }
'''.replace('@LETHAL_GUARD@','!lethal_only && 'if'cm_sweep_execute'in chosen else'')
        main=_once(main,anchor,anchor+smart)
    if 'cm_sweep_aoe_edge'in chosen:
        helpers.append(EDGE_HELPER)
        # The no-nearby-foe path has not computed old stand/escape guards. Do not
        # introduce a rooting cast when any of those optional modes is enabled.
        begin=main.index('void spell_sweep(State& s, bool pre = false, bool free_only = false) {')
        old='    if (foes.empty()) return;\n'
        tail=main[begin:]
        tail=_once(tail,old,
            '    if (foes.empty()) {\n'
            '        const bool roots_allowed = !P_CASTSAFE && !P_UNI_STAND && P_SWEEP != 5;\n'
            '        if (cm_edge_aoe(s, me, roots_allowed, false, free_only)) g_mode = "sweep";\n'
            '        return;\n'
            '    }\n')
        main=main[:begin]+tail
        main=_once(main,'    if (!cast) try_use(true, weak);\n',
            '    if (!cast) try_use(true, weak);\n'
            '    if (!cast) cast = cm_edge_aoe(s, me, !guard || stand_ok, guard && pre, free_only, escape);\n')
    if helpers:
        main=_once(main,'void play_turn(State& s) {\n',''.join(helpers)+'void play_turn(State& s) {\n')
    out['main.cpp']=main
    return out
