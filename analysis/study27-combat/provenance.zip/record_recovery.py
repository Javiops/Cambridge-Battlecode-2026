"""Pin pre-resume metadata and failed-launch evidence; never examines outcomes."""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def require(ok,msg):
    if not ok:raise RuntimeError(msg)
def stamp(v):return datetime.fromisoformat(v.replace('Z','+00:00'))
def main():
    stage='confirmation-baseline';pp=ROOT/'stages'/f'{stage}-plan.json';plan=read(pp)
    target=ROOT/'orchestration-recovery.json';require(not target.exists(),'Recovery record already exists')
    require(not(ROOT/'results'/f'{stage}.json').exists(),'Recovery requires incomplete original stage')
    require(not any((ROOT/'locks').glob('*.lock')),'Active game lock prevents recovery snapshot')
    before=ROOT/'test_matches.pre-recovery.py';after=ROOT/'test_matches.py'
    def funcs(p):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    old,new=funcs(before),funcs(after)
    preserved=('runtime_identity','physical_identity','verify_runtime','stats_fields','audit_stdout','validate_cache','load_cache','summarize_pair','summarize')
    require(all(old[n]==new[n]for n in preserved),'Frozen identity/statistics/cache behavior changed')
    keys={s['key']for s in plan['plan']['slots']};cache={p.stem:p for p in(ROOT/'game-cache').glob('*.json')}
    recovered=[]
    for key in sorted(keys&cache.keys()):
        path=cache[key];raw=path.read_bytes();metadata=json.loads(raw)
        require(metadata['key']==key and metadata['valid']is True and not metadata.get('imported_cache'),'Recovered input is not a completed local game')
        identity=metadata['identity'];require(hashlib.sha256(json.dumps(identity,sort_keys=True,separators=(',',':')).encode()).hexdigest()==key,'Recovered physical identity changed')
        require(identity['runtime']==plan['plan']['runtime'] and stamp(metadata['created_utc'])>=stamp(plan['created_utc']),'Recovered input predates/differs from original plan')
        recovered.append({'key':key,'cache_file_sha256':hashlib.sha256(raw).hexdigest(),'created_utc':metadata['created_utc']})
    missing=sorted(keys-cache.keys())
    require(len(recovered)==6143 and missing==['5706479e62e4b7eb5171853b71ec01235d5fb184174051d43f24bbc2febae6ac'],'Unexpected recovery inventory')
    failure_root=ROOT/'game-output'/missing[0];attempts=[]
    for p in sorted(failure_root.glob('*/pre-game-failure.json')):
        v=read(p);require(v['returncode']!=0 and 'failed to persist temporary file: Access is denied'in v['log'],'Nonrecoverable launch failure')
        require(not(p.parent/'statistics.json').exists() and not list(p.parent.glob('*.repl26a')),'Failure may contain a completed game')
        attempts.append({'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p),'classification':'Proven temporary-file AccessDenied before statistics/replay creation'})
    finals=list(failure_root.glob('*/failure.json'));require(len(attempts)==4 and len(finals)==1,'Original launch failure evidence differs')
    artifacts=attempts+[{'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p),'classification':'Original exhausted pre-game launch failure'}for p in finals]
    out={'schema_version':1,'created_utc':datetime.now(timezone.utc).isoformat(),'stage':stage,'original_stage_plan_sha256':sha(pp),'original_stage_plan_created_utc':plan['created_utc'],
         'freeze_sha256':sha(ROOT/'freeze.json'),'generation_record_sha256':sha(ROOT/'generation.json'),
         'reason':'Original executor raised after one proven pre-game temporary-file AccessDenied exhaustion; context-manager shutdown drained remaining queued work. Root confirmed process exited1 before this snapshot.',
         'harness_before':{'path':before.name,'sha256':sha(before)},'harness_after':{'path':after.name,'sha256':sha(after)},'unchanged_function_ast':list(preserved),
         'recovered_current_experiment_inputs':recovered,'recovered_count':len(recovered),'missing_keys_before_resume':missing,
         'failed_pre_game_attempt_count':4,'failure_artifacts':artifacts,'pure_contracts_sha256':sha(ROOT/'recovery-contracts.json'),
         'policy':'Resume the same immutable stage plan and exact orderedWASM/map/runtime keys. Existing rows stay cached=true in resumed invocation; count recovered6143 once as current-experiment physical inputs, separately from historical imports and newly executed-on-resume games.',
         'confirmation_outcomes_examined':False,'new_games_created_by_recording':0}
    with target.open('x',encoding='utf8')as stream:stream.write(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items()if k!='recovered_current_experiment_inputs'},indent=2))
if __name__=='__main__':main()
