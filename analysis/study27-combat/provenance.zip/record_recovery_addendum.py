"""Preserve conflicting historical harness hash evidence without rewriting it."""
from pathlib import Path
from datetime import datetime,timezone
import difflib,hashlib,json
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    old=ROOT/'test_matches.pre-recovery.py';new=ROOT/'test_matches.py';audit=ROOT/'harness-audit.txt'
    expected='141fded402339f230c5205f3eae7706b197bee3295163cdf433751d2656c9097'
    assert sha(old)==expected and audit.read_text().count(expected)==2
    diff=ROOT/'orchestration-repair.diff'
    with diff.open('x',encoding='utf8')as stream:stream.writelines(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile=old.name,tofile=new.name))
    out={'created_utc':datetime.now(timezone.utc).isoformat(),'recovery_manifest_sha256':sha(ROOT/'orchestration-recovery.json'),
         'archived_pre_repair_harness':{'path':old.name,'sha256':sha(old),'bytes':old.stat().st_size,'copy_created_utc':datetime.fromtimestamp(old.stat().st_ctime,timezone.utc).isoformat(),'preserved_last_modified_utc':datetime.fromtimestamp(old.stat().st_mtime,timezone.utc).isoformat()},
         'earlier_contemporaneous_record':{'path':audit.name,'sha256':sha(audit),'reported_sha256':expected,'recorded_twice':True,'audit_heading_utc':'2026-10-15T18:07:56.443386+00:00','last_modified_utc':datetime.fromtimestamp(audit.stat().st_mtime,timezone.utc).isoformat()},
         'conflicting_independent_probe':{'reported_sha256':'70e90d187bf7e1c5a956a612d6b73dfacb668d402de1439863be958f6d5b18a6','tool_chunk_id':'7ddb10','method':'Auditor reports Python-B hashlib.sha256(Path(...).read_bytes()).hexdigest() during pre-repair checklist. No raw source snapshot was retained. Other four harness/tool hashes agree with current evidence.','source_bytes_available':False},
         'current_harness_sha256':sha(new),'repair_diff':{'path':diff.name,'sha256':sha(diff)},
         'status':'Conflicting historical hash observation is not reconciled to source bytes. The archived before-repair bytes agree with two earlier recorded hashes, but the single contrary probe cannot be reconstructed or silently discarded.',
         'scope':'Uncertainty concerns historical orchestration-source provenance. Frozen bot source/WASM, map bytes, CLI/config/SDK/reference-engine identity, generator and confirmation-verifier pins remain separately exact and are checked against every final game. The original immutable recovery manifest is unchanged.',
         'confirmation_outcomes_examined':False,'new_games_or_maps':0}
    target=ROOT/'recovery-provenance-addendum.json'
    with target.open('x',encoding='utf8')as stream:stream.write(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
