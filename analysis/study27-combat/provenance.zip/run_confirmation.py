"""Run the complete fixed confirmation, without inspecting interim outcomes."""
from contextlib import redirect_stdout
import sys
from lab import ROOT,read
from test_matches import run
from generate_confirmation import validate_freeze

class Tee:
    def __init__(self,stream):self.stream=stream
    def write(self,value):
        self.stream.write(value);self.stream.flush()
        if 'unique games resolved' in value:sys.__stdout__.write(value+'\n');sys.__stdout__.flush()
    def flush(self):self.stream.flush()

freeze,_=validate_freeze()
assert read(ROOT/'generation.json')['status']=='complete'
with (ROOT/'confirmation-console.log').open('a',encoding='utf-8') as log:
    with redirect_stdout(Tee(log)):
        run('confirmation-baseline',['original'],['spar11','spar12','spar16'],['confirmation1024'],jobs=24)
        run('confirmation-candidate',[freeze['candidate']],['original','spar11','spar12','spar16'],['confirmation1024'],jobs=24)
print('Both fixed confirmation stages completed.',flush=True)
