"""Known perturbations and pairing failures for the read-only metrics helper."""
from copy import deepcopy
import json
from pathlib import Path
import combat_metrics as metrics


def main():
    path=Path(__file__).resolve().parent/'results/combat-baseline.json'
    original=metrics.load([path])
    first=next(iter(original.values()))['map_sha256']
    small={k:r for k,r in original.items()if r['map_sha256']==first}
    assert len(small)==6
    before=deepcopy(small)
    result=metrics.summarize(metrics.matched_pairs(small,small,'original'))
    assert result['maps']==1 and result['games']==6
    assert all(v['mean']==0 for kind in result['map_descriptive_deltas'].values()for v in kind.values())
    probe={}
    for _,row in small.items():
        copy=deepcopy(row);copy['candidate']='probe'
        key=('probe',copy['opponent'],copy['map_sha256'],copy['side'])
        probe[key]=copy
    key=next(iter(probe));row=probe[key]
    champion=next(c for c in row['statistics']['champions']if c['team']==row['side'])
    champion['collectedGems']+=6
    result=metrics.summarize(metrics.matched_pairs(probe,small,'probe'))
    assert result['map_descriptive_deltas']['raw']['collectedGems']['mean']==1
    assert result['map_descriptive_deltas']['raw']['collectedGems']['positive_maps']==1
    assert abs(result['map_descriptive_deltas']['per100round']['collectedGems']['mean']-100/row['rounds'])<1e-9
    incomplete=dict(probe);incomplete.pop(key)
    try:metrics.matched_pairs(incomplete,small,'probe')
    except AssertionError:pass
    else:raise AssertionError('Incomplete opponent/side map panel accepted')
    wrong=deepcopy(probe)
    enemy='b'if row['side']==0 else'a'
    wrong[key]['identity']['wasm_'+enemy+'_sha256']='different'
    try:metrics.matched_pairs(wrong,small,'probe')
    except AssertionError:pass
    else:raise AssertionError('Different spar WASM accepted')
    wrong=deepcopy(probe);wrong[key]['identity']['runtime']['engine_version']='different'
    try:metrics.matched_pairs(wrong,small,'probe')
    except AssertionError:pass
    else:raise AssertionError('Different runtime accepted')
    assert small==before,'Input baseline was mutated'
    print(json.dumps({'passed':True,'method':'Completed baseline self-control; synthetic +6 collected-gem perturbation gives one-map mean +1, and incomplete/opponent/runtime mismatches reject. No games or candidate-stage analysis.'}))


if __name__=='__main__':main()
