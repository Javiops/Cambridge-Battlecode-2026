"""Execute actual patched reach/safe_step/kite functions with narrow SDK fakes.

These contracts check availability, stale snapshots, conservative cooldowns and
movement ordering. They do not measure tactical strength or replace engine games.
All generated fixtures stay in this new combat experiment directory.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess
import patch_combat_moves as patch

ROOT = Path(__file__).resolve().parent
COMPILER = Path('C:/Users/frans/AppData/Local/cambc/wasi-sdk-33/bin/clang++.exe')
NODE = Path('C:/Users/frans/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')

PREFIX = r'''
#include <algorithm>
#include <array>
#include <cassert>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <stdexcept>
#include <string>
#include <vector>
struct vec2 {
    int x=0,y=0;
    vec2()=default;
    vec2(int xx,int yy):x(xx),y(yy){}
    vec2 operator+(vec2 b) const {return {x+b.x,y+b.y};}
    bool operator==(vec2 b) const {return x==b.x && y==b.y;}
};
int dist(vec2 a,vec2 b){return std::max(std::abs(a.x-b.x),std::abs(a.y-b.y));}
int X(vec2 p){return p.x;}
int Y(vec2 p){return p.y;}
namespace bc {
struct ability {
    bool dash=false,bad=false;
    int cd=99;
    bool is_dash() const {return dash;}
    int cooldown() const {if(bad)throw std::runtime_error("unreadable");return cd;}
    bool is_ready() const {return false;}
    bool is_cc() const {return false;}
    bool can_target_enemies() const {return true;}
    template<class T> bool use(T){return false;}
};
struct champion {
    int id=0,ar=3;
    vec2 p{10,10};
    double hp=1000,mhp=1000;
    bool alive=true,recall=false,teleport=false,submit=false,movable=true;
    std::string name="cassi";
    std::array<ability,2> abs;
    bool operator==(const champion& c)const{return id==c.id;}
    bool is_alive()const{return alive;}
    bool is_recalling()const{return recall;}
    bool is_teleporting()const{return teleport;}
    bool is_submitting_gems()const{return submit;}
    int attack_range()const{return ar;}
    double health()const{return hp;}
    double max_health()const{return mhp;}
    vec2 position()const{return p;}
    bool can_move()const{return movable;}
    bool can_cast()const{return false;}
    bool can_attack()const{return false;}
    bool move_absolute(vec2 t){if(!movable)return false;p=t;movable=false;return true;}
    std::string champion_name()const{return name;}
    const std::array<ability,2>& abilities()const{return abs;}
    std::array<ability,2>& abilities(){return abs;}
};
std::string to_string(const std::string& s){return s;}
namespace map {bool is_in_bounds(vec2 p){return p.x>=0&&p.y>=0&&p.x<32&&p.y<32;}}
namespace vision {std::vector<champion> allies;const std::vector<champion>& champions(int){return allies;}}
}
std::string norm(std::string s){for(char& c:s)c=static_cast<char>(std::tolower(c));return s;}
bool starts_with(const std::string& s,const char* p){return s.rfind(p,0)==0;}
template<class F> bool attempt(F f){try{return f();}catch(...){return false;}}
struct Mask {std::vector<vec2> tiles;bool is_set(vec2 p)const{return std::find(tiles.begin(),tiles.end(),p)!=tiles.end();}};
enum class Slot {Other,Targeted,Ground};
constexpr int SPELL_RANGE=4;
#define P_DASHFIX 1
#define P_NOCHASE 1
#define P_CHASE_GEMS 150
#define P_KITE_ZONE 4
#define P_KITE_OUT 2
#define P_KITEFRONT 0
#define P_SQUISHY 0
#define P_AOE 2
'''

MIDDLE = r'''
struct State {
    Mask blocked,en_spawn;
    int dash_slot=-1,hit_round=-1000,thr_r=-1000;
    vec2 spawn_center{0,0};
    const int team=0;const int* my=&team;
    std::array<Slot,2> slots{Slot::Other,Slot::Other};
    std::vector<Threat> thr;
};
template<class T>bool cast_offense(State&,bc::champion&,const T&,vec2,bool){return false;}
template<class T>bool basic_attack(State&,bc::champion&,const T&,vec2){return false;}
struct Aoe {int radius=0;};
Aoe aoe_slot(bc::champion&,int){return {};}
vec2 aoe_centre(State&,bc::champion&,int,vec2 p,int* hits=nullptr){if(hits)*hits=0;return p;}
Foe foe(int id,int x,int y,int ar=3,double hp=1000,const char* name="cassi"){
    bc::champion c;c.id=id;c.p={x,y};c.ar=ar;c.hp=hp;c.name=name;
    return Foe{c,c.p,static_cast<float>(hp),dist(c.p,{10,10}),0,false};
}
void legal_steps(State& s,std::vector<vec2> allowed){
    for(int dx=-1;dx<=1;++dx)for(int dy=-1;dy<=1;++dy){
        if(!dx&&!dy)continue;vec2 p{10+dx,10+dy};
        if(std::find(allowed.begin(),allowed.end(),p)==allowed.end())s.blocked.tiles.push_back(p);
    }
}
'''

CASES = r'''
int main(){
    int checks=0;
    auto test=[&](bool pass,const char* label){if(!pass)std::printf("FAIL: %s\n",label);assert(pass);++checks;};
    // The actual reach() body must retain conservative uncertainty handling.
    auto melee=foe(1,12,10,1,1000,"vendetta");melee.c.abs[0].dash=true;
    for(int cd:{0,1,2,8}){
        melee.c.abs[0].cd=cd;
        test(control::reach(melee)==3,"original assumes dash");
        test(candidate::reach(melee)==(@DASH@&&cd>1?2:3),"conservative cooldown horizon");
    }
    melee.c.abs[0].bad=true;test(candidate::reach(melee)==3,"unreadable dash retains original reach");
    melee.c.abs[0].bad=false;melee.c.abs[0].dash=false;
    test(candidate::reach(melee)==3,"missing dash metadata retains original reach");
    auto ordinary=foe(2,12,10,1,1000,"ryth");test(candidate::reach(ordinary)==2,"ordinary melee unchanged");
    auto ranged=foe(3,12,10,3);test(candidate::reach(ranged)==4,"ranged reach unchanged");

    // Actual kite(): a ready five-tile spell may threaten beyond P_KITE_ZONE.
    for(int kind=0;kind<5;++kind){
        State a,b;bc::champion ca,cb;ca.movable=cb.movable=false;
        auto fs=std::vector<Foe>{foe(1,15,10)};Threat t;t.p={15,10};
        a.thr_r=b.thr_r=10;
        if(kind==0){t.xd=400;t.xr=5;}
        if(kind==1){t.fd=300;t.fr=4;}
        if(kind==2)t.sr=4;
        if(kind==3){t.xd=400;t.xr=4;}
        if(kind==4){t.xd=400;t.xr=5;a.thr_r=b.thr_r=9;}
        a.thr=b.thr={t};bc::vision::allies.clear();
        test(!control::kite(a,ca,fs,10),"original distant contact gate");
        test(candidate::kite(b,cb,fs,10)==(@SPELL@&&kind<3),"ready/stale spell contact gate");
    }

    // Equal original scores: one side is inside a separate caster's ready spell.
    for(bool fresh:{true,false}){
        State a,b;bc::champion ca,cb;
        legal_steps(a,{{11,9},{11,11}});legal_steps(b,{{11,9},{11,11}});
        a.thr_r=b.thr_r=fresh?10:9;
        Threat x;x.p={14,10};x.atk=100;x.ar=4;
        Threat y;y.p={10,6};y.xd=400;y.xr=4;y.ar=2;
        a.thr=b.thr={x,y};bc::vision::allies.clear();
        auto fs=std::vector<Foe>{foe(1,14,10),foe(2,10,6,1,10000,"ryth")};
        test(control::kite(a,ca,fs,10),"original movement turn");
        test(ca.p==vec2(11,9),"original deterministic first tie");
        test(candidate::kite(b,cb,fs,10),"candidate movement turn");
        test(cb.p==(fresh&&(@TIE@||@SPELL@)?vec2(11,11):vec2(11,9)),"lower ready-damage tie or unchanged stale snapshot");
    }

    // Actual safe_step(): recalling/teleporting/tributing allies cannot anchor escape.
    for(int channel=0;channel<3;++channel){
        State a,b;bc::champion ca,cb;
        legal_steps(a,{{11,9},{11,11}});legal_steps(b,{{11,9},{11,11}});
        bc::champion unavailable,healthy;unavailable.id=2;healthy.id=3;
        unavailable.p={12,8};healthy.p={12,12};
        unavailable.recall=channel==0;unavailable.teleport=channel==1;unavailable.submit=channel==2;
        bc::vision::allies={unavailable,healthy};
        auto fs=std::vector<Foe>{foe(1,8,9,1,1000,"ryth")};
        test(control::safe_step(a,ca,fs),"original escape exists");
        test(candidate::safe_step(b,cb,fs),"candidate escape exists");
        test(ca.p==vec2(11,9),"original retreat chooses unavailable anchor tie");
        test(cb.p==(@RETREAT@?vec2(11,11):vec2(11,9)),"available retreat anchor");
    }

    // Actual kite(): channeling ally must not make a four-body enemy pack look supported.
    for(int channel=0;channel<4;++channel){
        State a,b;bc::champion ca,cb;ca.movable=cb.movable=false;
        bc::champion mate;mate.id=8;mate.p={11,10};
        mate.recall=channel==0;mate.teleport=channel==1;mate.submit=channel==2;
        bc::vision::allies={mate};
        auto fs=std::vector<Foe>{foe(1,14,9),foe(2,14,10),foe(3,14,11),foe(4,13,12)};
        test(control::kite(a,ca,fs,10),"original pack power counts channeling ally");
        test(candidate::kite(b,cb,fs,10)==(!@KITEALLY@||channel==3),"available ally local-power estimate");
    }
    std::printf("actual reach/safe_step/kite: %d checks passed\n",checks);
}
'''


def block(text, signature):
    start,end=patch.function_block(text,signature)
    return text[start:end]


def namespace_functions(text,name):
    signatures=['inline bool gone(', 'inline int reach(', 'inline int threats_at(', 'inline bool safe_step(',
                'inline bool hit_any(', 'inline bool kite(']
    parts=[block(text,s) for s in signatures]
    if 'inline bool combat_moves_dash_soon(' in text:
        parts.insert(0,block(text,'inline bool combat_moves_dash_soon('))
    return 'namespace '+name+' {\n'+'\n'.join(parts)+'\n}\n'


def main():
    source={p.name:p.read_text() for p in (ROOT/'baseline/src').iterdir() if p.is_file()}
    before=dict(source)
    variants={name:patch.apply(source,name) for name in patch.FEATURES}
    variants['all_moves']=patch.apply_many(source,patch.FEATURES)
    assert source==before
    assert patch.apply_many(source,[])==source
    assert patch.apply_many(source,reversed(patch.FEATURES))==variants['all_moves']
    for name,out in variants.items():
        assert {k for k in source if out[k]!=source[k]}=={'fight.h'},name
        try:patch.apply(out,patch.FEATURES[0])
        except ValueError:pass
        else:raise AssertionError('Repeated/foreign fighter source accepted')
    for features in [('unknown',), (patch.FEATURES[0],patch.FEATURES[0])]:
        try:patch.apply_many(source,features)
        except ValueError:pass
        else:raise AssertionError('Invalid feature accepted')
    main_source=source['main.cpp'];fighter=source['fight.h']
    common=PREFIX+block(main_source,'struct Threat {')+';\n'+block(main_source,'struct Foe {')+';\n'+MIDDLE+block(main_source,'inline double danger_at(')+'\n'
    fixture_dir=ROOT/'moves-fixtures';fixture_dir.mkdir(exist_ok=True)
    records=[]
    for name,out in variants.items():
        enabled=set(patch.FEATURES if name=='all_moves' else [name])
        cases=CASES
        for marker,feature in [('@DASH@','cm_dash_cd_reach'),('@SPELL@','cm_kite_spell_reach'),('@TIE@','cm_kite_volley_tie'),('@RETREAT@','cm_retreat_available_allies'),('@KITEALLY@','cm_kite_available_allies')]:
            cases=cases.replace(marker,str(int(feature in enabled)))
        code=common+namespace_functions(fighter,'control')+namespace_functions(out['fight.h'],'candidate')+cases
        cpp=fixture_dir/(name+'.cpp');wasm=fixture_dir/(name+'.wasm');runner=fixture_dir/(name+'.mjs')
        cpp.write_text(code,newline='\n')
        proc=subprocess.run([str(COMPILER),'-std=c++20','-fwasm-exceptions','-O2',str(cpp),'-lunwind','-o',str(wasm)],capture_output=True,text=True)
        if proc.returncode:raise RuntimeError(proc.stderr)
        runner.write_text("import fs from 'node:fs';\nimport {WASI} from 'node:wasi';\nconst wasi=new WASI({version:'preview1',args:[],env:{},preopens:{}});\nconst {instance}=await WebAssembly.instantiate(fs.readFileSync(new URL('./"+wasm.name+"',import.meta.url)),{wasi_snapshot_preview1:wasi.wasiImport});\nwasi.start(instance);\n",newline='\n')
        proc=subprocess.run([str(NODE),str(runner)],capture_output=True,text=True)
        if proc.returncode:raise RuntimeError(proc.stdout+proc.stderr)
        records.append({'feature':name,'stdout':proc.stdout.strip(),'fixture_sha256':hashlib.sha256(cpp.read_bytes()).hexdigest()})
    report={'passed':True,'features':patch.FEATURES,'fixture_runs':records,'source_only_fight_h':True,
            'canonical_combination':True,'method':'Actual reach/safe_step/kite plus actual baseline danger_at extracted from transformed source, WASI compiled and run with narrow SDK stand-ins. These are contracts, not bot games.',
            'dash_horizon':'Cooldown<=1 conservatively counts as potentially ready; failures preserve old reach. Actual next-action readiness is not claimed.',
            'patch_sha256':hashlib.sha256((ROOT/'patch_combat_moves.py').read_bytes()).hexdigest()}
    (ROOT/'combat-moves-fixtures.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
