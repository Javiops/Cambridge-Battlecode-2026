"""Compile movement isolates in an unregistered scratch arena; no games."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import patch_combat_moves as patch

ROOT=Path(__file__).resolve().parent
SCRATCH=ROOT/'moves-build-checks'
CLI=ROOT.parent/'battlecode-bot-v1/runtime/cambc.exe'


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    SCRATCH.mkdir(exist_ok=True)
    for folder in ('sdk','cmake'):
        if not (SCRATCH/folder).exists():shutil.copytree(ROOT/'arena'/folder,SCRATCH/folder)
    if not (SCRATCH/'cambc.toml').exists():shutil.copyfile(ROOT/'arena/cambc.toml',SCRATCH/'cambc.toml')
    assert sha(SCRATCH/'sdk/cpp/cambc.h')==sha(ROOT/'arena/sdk/cpp/cambc.h')
    source={p.name:p.read_text() for p in (ROOT/'baseline/src').iterdir() if p.is_file()}
    before=dict(source)
    variants={f:patch.apply(source,f) for f in patch.FEATURES}
    variants['all_moves']=patch.apply_many(source,patch.FEATURES)
    env={**os.environ,'CAMBC_NO_UPDATE_CHECK':'1','CAMBC_WASMTIME_CACHE':str(SCRATCH/'wasmtime-cache')}
    records=[]
    for name,payload in variants.items():
        bot=SCRATCH/'bots'/name;target=bot/'src';target.mkdir(parents=True,exist_ok=True)
        for filename,value in payload.items():
            path=target/filename;expected=value.encode('utf8')
            if path.exists():assert path.read_bytes()==expected,'Scratch source changed: '+str(path)
            else:path.write_bytes(expected)
        process=subprocess.run([str(CLI),'build',str(bot)],cwd=SCRATCH,env=env,capture_output=True,text=True,errors='replace',timeout=600)
        (bot/'build.log').write_text(process.stdout+process.stderr,encoding='utf8')
        if process.returncode:raise RuntimeError(name+': '+(process.stdout+process.stderr)[-3500:])
        records.append({'feature':name,'source_sha256':{f:sha(target/f) for f in sorted(payload)},
                        'wasm_sha256':sha(bot/'.cambc/build/bot-injected.wasm')})
        print('Full SDK build PASS:',name,flush=True)
    assert source==before
    report={'passed':True,'no_games':True,'unregistered_scratch_arena':str(SCRATCH),
            'sdk_header_sha256':sha(SCRATCH/'sdk/cpp/cambc.h'),'cli_sha256':sha(CLI),
            'patch_sha256':sha(ROOT/'patch_combat_moves.py'),'builds':records}
    (ROOT/'combat-moves-builds.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    print('Six complete source variants compiled; no matches or candidate registrations.')


if __name__=='__main__':main()
