"""Pure confirmation-contract fixtures. No files, maps, builds or games are made."""
from __future__ import annotations
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

sys.dont_write_bytecode=True
import generate_confirmation as generation
import confirm
import test_matches
from test_matches import stats_fields

CHECKS=0


def accepted(call):
    global CHECKS
    call();CHECKS+=1


def refused(call):
    global CHECKS
    try:call()
    except (RuntimeError,ValueError,KeyError,TypeError):CHECKS+=1;return
    raise AssertionError('Invalid fixture was accepted')


def digest(value):return hashlib.sha256(value.encode()).hexdigest()


def fixture_manifest(count=2):
    flags={k:True for k in ('official_integrity','official_verify_game','official_runtime_expansion_equal',
        'all_camps_reachable_from_both_teams','all_altars_reachable_from_both_teams','mirrored_camp_distance_equal')}
    return {'count':count,'seed':2154873391,'source_maps_read':0,'candidate_results_read':False,
        'maps':[{'file':f'fresh-{i:04}.map26a','sha256':digest('map'+str(i)),
                 'topology_d4_sha256':digest('geometry'+str(i)),'validation':flags.copy()} for i in range(count)]}


def fixture_rows():
    name='fixture';references=generation.REFERENCES
    freeze={'candidate':name,'wasm_sha256':digest(name),
        'reference_wasm_sha256':{r:digest(r) for r in references},'runtime':{'fixture_runtime':'pinned'}}
    wasm={name:freeze['wasm_sha256'],**freeze['reference_wasm_sha256']}
    manifest=fixture_manifest();plan={'confirmation':{'maps':2,'seed':manifest['seed']}}
    record={'finished_utc':'2026-10-15T12:00:00+00:00'}
    rows={}
    pairs=[(name,r) for r in references]+[('original',r) for r in references if r!='original']
    for candidate,opponent in pairs:
        for m in manifest['maps']:
            for side in (0,1):
                a,b=(candidate,opponent) if side==0 else (opponent,candidate)
                identity={'wasm_a_sha256':wasm[a],'wasm_b_sha256':wasm[b],'map_sha256':m['sha256'],'runtime':freeze['runtime']}
                key=digest(json.dumps(identity,sort_keys=True,separators=(',',':')))
                statistics={'outcome':'teamA','round':100,'engineVersion':'0.0.1','schemaVersion':2,
                    'teams':[{'submittedGems':1002},{'submittedGems':100}],
                    'botFaults':[0,0],'champions':[{'team':t,'deaths':0,'kills':0} for t in (0,1)]}
                row={'schema_version':2,'valid':True,'candidate':candidate,'opponent':opponent,'map_sha256':m['sha256'],'side':side,
                    'key':key,'identity':identity,'created_utc':'2026-10-15T12:00:01+00:00',
                    'statistics':statistics,'statistics_content_sha256':digest(json.dumps(statistics,ensure_ascii=False,sort_keys=True,separators=(',',':'))),
                    'stdout':{t:{'initializations':{'body':1},'reinitializations_observed':0} for t in ('a','b')},**stats_fields(statistics)}
                rows[(candidate,opponent,m['sha256'],side)]=row
    return rows,freeze,plan,record,manifest


def main():
    accepted(lambda:generation.manifest_structure(fixture_manifest(),2,2154873391))
    mutations=[lambda m:m.update(count=1),lambda m:m.update(count=True),lambda m:m.update(seed=1),
        lambda m:m.update(candidate_results_read=True),lambda m:m.update(source_maps_read=1),
        lambda m:m['maps'].pop(),lambda m:m['maps'][1].update(file=m['maps'][0]['file']),
        lambda m:m['maps'][1].update(sha256=m['maps'][0]['sha256']),
        lambda m:m['maps'][1].update(topology_d4_sha256=m['maps'][0]['topology_d4_sha256']),
        lambda m:m['maps'][0].update(file='../escape.map26a'),
        lambda m:m['maps'][0].update(sha256='bad'),lambda m:m['maps'][0]['validation'].update(official_integrity=False),
        lambda m:m['maps'][0]['validation'].pop('all_camps_reachable_from_both_teams')]
    for mutate in mutations:
        value=fixture_manifest();mutate(value)
        refused(lambda:generation.manifest_structure(value,2,2154873391))
    refused(lambda:generation.stamp('2026-10-15T12:00:00'))
    accepted(lambda:generation.stamp('2026-10-15T12:00:00Z'))
    refused(lambda:generation.guard(generation.ROOT/'../outside-confirmation'))
    accepted(lambda:generation.guard(generation.ROOT/'not-created-confirmation-test-file'))

    # Freeze construction and rejection are mocked end-to-end, including all
    # references. No freeze.json or confirmation directory is ever written.
    fields={k:digest(k) for k in ('cli_sha256','project_config_sha256','sdk_header_sha256')}
    plan={'baseline_commit':'baseline','spar_commit':'spars'}
    support={'generation_inputs':{'generator_sha256':digest('generator')},
        'confirmation_tool_sha256':digest('confirm'),'development_maps_sha256':{'fixture':digest('map')}}
    freeze={'candidate':'fixture','created_utc':'2020-01-01T00:00:00Z',
        'selection_plan_sha256':digest('selection-plan.json'),'source_sha256':{'main.cpp':digest('source')},
        'wasm_sha256':digest('fixture'),'reference_wasm_sha256':{r:digest(r) for r in generation.REFERENCES},
        'runtime':{'engine_version':'0.0.1',**fields},**support}
    records={r:{'base_commit':'baseline' if r in ('fixture','original') else 'spars',
        'wasm_sha256':digest(r),'source_sha256':{'main.cpp':digest('source')},**fields} for r in ('fixture',*generation.REFERENCES)}
    state={'freeze.json':deepcopy(freeze),'selection-plan.json':deepcopy(plan),**{k+'.json':deepcopy(v) for k,v in records.items()}}
    def freeze_read(path):return state[Path(path).name]
    def freeze_sha(path):
        path=Path(path)
        return digest(path.parts[-4]) if path.name=='bot-injected.wasm' else digest(path.name)
    with patch.object(generation,'read',side_effect=freeze_read),patch.object(generation,'sha',side_effect=freeze_sha),\
         patch.object(generation,'source_hashes',return_value={'main.cpp':digest('source')}),\
         patch.object(generation,'confirmation_support_pins',return_value=support),\
         patch.object(test_matches,'verify_runtime') as runtime_check:
        accepted(generation.validate_freeze);runtime_check.assert_called_once_with(freeze['runtime'])
        for mode in ('candidate_path','candidate_source','candidate_wasm','reference_wasm','reference_commit','runtime_build','support'):
            state['freeze.json']=deepcopy(freeze);state['spar12.json']=deepcopy(records['spar12'])
            if mode=='candidate_path':state['freeze.json']['candidate']='../outside'
            elif mode=='candidate_source':state['freeze.json']['source_sha256']['main.cpp']=digest('changed')
            elif mode=='candidate_wasm':state['freeze.json']['wasm_sha256']=digest('changed')
            elif mode=='reference_wasm':state['freeze.json']['reference_wasm_sha256']['spar12']=digest('changed')
            elif mode=='reference_commit':state['spar12.json']['base_commit']='changed'
            elif mode=='runtime_build':state['freeze.json']['runtime']['cli_sha256']=digest('changed')
            elif mode=='support':state['freeze.json']['generation_inputs']={'changed':True}
            refused(generation.validate_freeze)
    with patch.object(sys,'argv',['generate_confirmation.py','--check-only']),\
         patch.object(generation,'validate_freeze',return_value=(freeze,plan)),\
         patch.object(generation,'write_new') as write,patch.object(generation.subprocess,'run') as process:
        accepted(generation.main);write.assert_not_called();process.assert_not_called()
    with patch.object(sys,'argv',['generate_confirmation.py']),\
         patch.object(generation,'validate_freeze',return_value=(freeze,plan)),\
         patch.object(generation,'absent',side_effect=RuntimeError('existing cohort')) as absent,\
         patch.object(generation,'write_new') as write,patch.object(generation.subprocess,'run') as process:
        refused(generation.main);absent.assert_called_once();write.assert_not_called();process.assert_not_called()

    # Completed-generation provenance must be after freeze and before maps are
    # consumed. Map byte/native validation itself is mocked here, not generated.
    plan={'confirmation':{'maps':2,'seed':2154873391}}
    generated={'status':'complete','freeze_sha256':digest('freeze.json'),
        'selection_plan_sha256':freeze['selection_plan_sha256'],'generation_inputs':freeze['generation_inputs'],
        'seed':2154873391,'count':2,'destination':'arena/confirmation1024',
        'started_utc':'2020-01-01T00:00:01Z','finished_utc':'2020-01-01T00:00:03Z',
        'manifest_sha256':digest('manifest.json'),'first_map_file_utc':'2020-01-01T00:00:01.5Z',
        'last_map_file_utc':'2020-01-01T00:00:02Z'}
    times={k:generated[k] for k in ('first_map_file_utc','last_map_file_utc')}
    manifest={'created_at_utc':'2020-01-01T00:00:02.5Z'}
    for mode in ('valid','status','freeze','plan','count','destination','early_start','future_finish','manifest','file_time'):
        bad=deepcopy(generated)
        if mode=='status':bad['status']='running'
        elif mode=='freeze':bad['freeze_sha256']=digest('changed')
        elif mode=='plan':bad['selection_plan_sha256']=digest('changed')
        elif mode=='count':bad['count']=1
        elif mode=='destination':bad['destination']='somewhere/else'
        elif mode=='early_start':bad['started_utc']=freeze['created_utc']
        elif mode=='future_finish':bad['finished_utc']='2099-01-01T00:00:00Z'
        elif mode=='manifest':bad['manifest_sha256']=digest('changed')
        elif mode=='file_time':bad['last_map_file_utc']='2020-01-01T00:00:04Z'
        with patch.object(confirm,'read',return_value=bad),patch.object(confirm,'sha',side_effect=lambda p:digest(Path(p).name)),\
             patch.object(confirm,'validate_maps',return_value=(manifest,times)):
            (accepted if mode=='valid' else refused)(lambda:confirm.verify_generation(freeze,plan))

    rows,freeze,plan,record,manifest=fixture_rows()
    physical,faults,reinit=confirm.verify_rows(rows,freeze,plan,record,manifest)
    assert (len(rows),len(physical),faults,reinit)==(28,28,0,0)
    accepted(lambda:confirm.verify_rows(rows,freeze,plan,record,manifest))
    for mode in ('missing','extra','frozen_wasm','reference_wasm','runtime','map','physical_key','schema','valid',
                 'before_generation','derived','statistics_hash','missing_stdout','negative_init','float_init','reinit_total'):
        bad=deepcopy(rows);slot=next(iter(bad));row=bad[slot]
        if mode=='missing':bad.pop(slot)
        elif mode=='extra':bad[('other',*slot[1:])]=row
        elif mode=='frozen_wasm':row['identity']['wasm_a_sha256']=digest('changed')
        elif mode=='reference_wasm':row['identity']['wasm_b_sha256']=digest('changed')
        elif mode=='runtime':row['identity']['runtime']={'changed':True}
        elif mode=='map':row['identity']['map_sha256']=digest('changed')
        elif mode=='physical_key':row['key']=digest('changed')
        elif mode=='schema':row['schema_version']=1
        elif mode=='valid':row['valid']=False
        elif mode=='before_generation':row['created_utc']='2026-10-15T11:59:59+00:00'
        elif mode=='derived':row['gems'][0]+=1
        elif mode=='statistics_hash':row['statistics_content_sha256']=digest('changed')
        elif mode=='missing_stdout':row['stdout'].pop('b')
        elif mode=='negative_init':row['stdout']['a']['initializations']['body']=-1
        elif mode=='float_init':row['stdout']['a']['initializations']['body']=1.0
        elif mode=='reinit_total':row['stdout']['a']['reinitializations_observed']=1
        refused(lambda:confirm.verify_rows(bad,freeze,plan,record,manifest))
    for baseline in (False,True):
        bad=deepcopy(rows);slot=next(k for k in bad if (k[0]=='original')==baseline);row=bad[slot]
        row['faults'][1]=1;row['statistics']['botFaults'][1]=1
        row['statistics_content_sha256']=digest(json.dumps(row['statistics'],ensure_ascii=False,sort_keys=True,separators=(',',':')))
        assert confirm.verify_rows(bad,freeze,plan,record,manifest)[1]==1
        bad=deepcopy(rows);row=bad[slot]
        row['stdout']['b']={'initializations':{'body':2},'reinitializations_observed':1}
        assert confirm.verify_rows(bad,freeze,plan,record,manifest)[2]==1
        accepted(lambda:None);accepted(lambda:None)

    first=next(iter(rows.values()));duplicate=deepcopy(first);duplicate['cached']=True
    with patch.object(confirm,'read',return_value={'games':[first,duplicate]}):
        assert len(confirm.load_confirmation_rows([Path('in-memory-fixture')]))==1
        accepted(lambda:None)
    duplicate['stdout']['a']['reinitializations_observed']=1
    with patch.object(confirm,'read',return_value={'games':[first,duplicate]}):
        refused(lambda:confirm.load_confirmation_rows([Path('in-memory-fixture')]))
    duplicate=deepcopy(first);duplicate['side']=False
    with patch.object(confirm,'read',return_value={'games':[duplicate]}):
        refused(lambda:confirm.load_confirmation_rows([Path('in-memory-fixture')]))

    x={'original':{'wins':1100,'losses':948,'p_two_sided':0.01},
       'panel':{'score_delta':100,'positive_maps':200,'negative_maps':100,'p_two_sided':0.01},
       'spar':{s:{'percentage_point_delta':0} for s in generation.REFERENCES if s!='original'}}
    assert all(confirm.confirmation_gates(x,0,0).values());accepted(lambda:None)
    for section,key,value in [('original','wins',948),('original','p_two_sided',0.05),
        ('panel','score_delta',0),('panel','positive_maps',100),('panel','p_two_sided',0.05)]:
        bad=deepcopy(x);bad[section][key]=value
        assert not all(confirm.confirmation_gates(bad,0,0).values());accepted(lambda:None)
    bad=deepcopy(x);bad['spar']['spar11']['percentage_point_delta']=-1.001
    assert not all(confirm.confirmation_gates(bad,0,0).values());accepted(lambda:None)
    bad['spar']['spar11']['percentage_point_delta']=-1
    assert all(confirm.confirmation_gates(bad,0,0).values());accepted(lambda:None)
    assert not all(confirm.confirmation_gates(x,1,0).values());accepted(lambda:None)
    assert not all(confirm.confirmation_gates(x,0,1).values());accepted(lambda:None)
    print(f'PASS: {CHECKS} pure confirmation contract checks; no files, maps, builds or games created.')


if __name__=='__main__':main()
