"""Content-addressed full-game study27 ablations, side-paired by opponent/map."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import Counter
from pathlib import Path
import argparse, hashlib, json, math, re, shutil, subprocess, time, zipfile
from lab import ROOT, ARENA, CLI, ENV, PRIOR_ROOT, read, write, sha, hashes, now, require, guard, plain_path, exclusive, valid_name

SETS={'official':'maps','gen':'maps_gen','dev':'maps_dev200','legacy':'maps_hold60'}
CACHE=ROOT/'game-cache'
PRIOR_CACHE=PRIOR_ROOT/'game-cache'
ENGINE=ROOT.parent/'battlecode-bot-v1/r2-research/v0_0_1-ctH8uuEb.wasm'
EXPECTED_ENGINE='0.0.1'

def sign_p(w,l):
    n=w+l
    return min(1.,2*sum(math.comb(n,k) for k in range(min(w,l)+1))/2**n) if n else 1.

def runtime_identity():
    version=subprocess.run([str(CLI),'--version'],cwd=ARENA,env=ENV,capture_output=True,text=True,check=True).stdout.strip()
    require(version,'Empty CLI version')
    return {'cli_version':version,'cli_sha256':sha(CLI),'project_config_sha256':sha(ARENA/'cambc.toml'),
        'sdk_header_sha256':sha(ARENA/'sdk/cpp/cambc.h'),'engine_version':EXPECTED_ENGINE,
        'reference_engine_wasm_sha256':sha(ENGINE),
        'engine_pin_limit':'CLI has no engine-file option. Version is verified in final statistics; reference WASM is the official map-generator engine, not a claim of CLI engine injection.',
        'settings':{'full_game':True,'fuel':'CLI default','language':'cpp','update_check':False}}

def physical_identity(wa,wb,map_sha,runtime):
    identity={'wasm_a_sha256':wa,'wasm_b_sha256':wb,'map_sha256':map_sha,'runtime':runtime}
    key=hashlib.sha256(json.dumps(identity,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return key,identity

def verify_runtime(runtime):
    require(sha(CLI)==runtime['cli_sha256'],'CLI changed after planning')
    require(sha(ARENA/'cambc.toml')==runtime['project_config_sha256'],'Project config changed after planning')
    require(sha(ARENA/'sdk/cpp/cambc.h')==runtime['sdk_header_sha256'],'SDK changed after planning')
    require(sha(ENGINE)==runtime['reference_engine_wasm_sha256'],'Reference engine changed after planning')

def stats_fields(data):
    require(data.get('outcome') in ('teamA','teamB','draw'),'Invalid completed-game outcome')
    require(type(data.get('round')) is int and 1<=data['round']<=2000,'Invalid completed-game round')
    require(str(data.get('engineVersion'))==EXPECTED_ENGINE,'Unexpected actual CLI engine version: '+str(data.get('engineVersion')))
    require(data.get('schemaVersion')==2,'Unexpected statistics schema')
    require(isinstance(data.get('teams'),list) and len(data['teams'])==2,'Invalid teams')
    faults=data.get('botFaults')
    require(isinstance(faults,list) and len(faults)==2 and all(type(n) is int and n>=0 for n in faults),'Unsupported botFaults schema')
    fields={'outcome':data['outcome'],'rounds':data['round'],'gems':[t['submittedGems'] for t in data['teams']],
        'deaths':[sum(c['deaths'] for c in data['champions'] if c['team']==t) for t in (0,1)],
        'kills':[sum(c['kills'] for c in data['champions'] if c['team']==t) for t in (0,1)],
        'faults':faults,'engine_version':data['engineVersion'],'statistics_schema':data['schemaVersion']}
    for field in ('collectedGems','championDamageDone','championDamageTaken','monsterDamageDone','monsterDamageTaken'):
        if any(field in c for c in data['champions']):
            fields[field]=[sum(c.get(field,0) for c in data['champions'] if c['team']==t) for t in (0,1)]
    return fields

def audit_stdout(text):
    text=text.replace('\0',''); initial=dict(Counter(re.findall(r'\[init\] (\S+)',text)))
    # Counters persist per champion body and are cumulative; keep maxima per
    # body rather than summing periodic status samples as independent actions.
    active=None;farm={}
    for line in text.splitlines():
        initialized=re.search(r'\[init\] (\S+)',line)
        if initialized:active=initialized.group(1)
        periodic=re.search(r'^\[r\d+\] (\S+)',line)
        if periodic:active=periodic.group(1)
        status=re.search(r'\[farmguard\] r=(\d+) checks=(\d+) blocks=(\d+)',line)
        if status:
            key=active or 'unknown_body'
            previous=farm.setdefault(key,{'checks':0,'blocks':0,'last_round':0,'samples':0})
            previous['checks']=max(previous['checks'],int(status[2]));previous['blocks']=max(previous['blocks'],int(status[3]))
            previous['last_round']=max(previous['last_round'],int(status[1]));previous['samples']+=1
    return {'initializations':initial,'reinitializations_observed':sum(max(0,n-1) for n in initial.values()),
        'caught_errors':dict(Counter(re.findall(r'\[err #\d+\] ([^\r\n]+)',text))),
        'low_fuel_logged':len(re.findall('mode=low-fuel',text)),
        'farm_guard_cumulative_samples':farm,
        'sha256':hashlib.sha256(text.encode()).hexdigest()}

def validate_cache(row,key,identity,owner):
    require(row.get('schema_version')==2 and row.get('valid') and row.get('key')==key and row.get('identity')==identity,'Cache identity changed: '+key)
    serialized=(json.dumps(row['statistics'],ensure_ascii=False,sort_keys=True,separators=(',',':'))).encode()
    require(hashlib.sha256(serialized).hexdigest()==row['statistics_content_sha256'],'Cached statistics content changed')
    require(all(row[k]==v for k,v in stats_fields(row['statistics']).items()),'Cached derived fields changed')
    if row.get('retained_replay'):
        replay=plain_path(owner/row['retained_replay'],owner)
        require(sha(replay)==row['replay_sha256'],'Retained replay changed')
    return row

def load_cache(key,identity):
    cache=guard(CACHE/(key+'.json'))
    if cache.exists():return validate_cache(read(cache),key,identity,ROOT)
    prior=plain_path(PRIOR_CACHE/(key+'.json'),PRIOR_ROOT)
    if not prior.exists():return None
    content=prior.read_bytes();row=validate_cache(json.loads(content),key,identity,PRIOR_ROOT)
    imported={**row,'imported_cache':{'source_experiment':'study27-micro','source_key':key,
        'source_cache_file_sha256':hashlib.sha256(content).hexdigest(),'imported_utc':now(),
        'policy':'Exact ordered WASM/map/runtime/config identity reused; never a newly simulated game.'}}
    if row.get('retained_replay'):
        source=PRIOR_ROOT/row['retained_replay'];target=guard(ROOT/'retained-replays'/(key+'.repl26a'))
        target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():require(sha(target)==row['replay_sha256'],'Existing imported replay differs')
        else:shutil.copyfile(source,target)
        imported['retained_replay']=str(target.relative_to(ROOT))
    write(cache,imported)
    return imported

def one(job):
    key,identity=job['key'],job['identity']; runtime=identity['runtime']
    def unchanged():
        # Large executable/reference-engine pins are verified once before and
        # after the complete stage; these fast mutable inputs are checked per game.
        require(sha(ARENA/'cambc.toml')==runtime['project_config_sha256'],'Config changed after planning')
        require(sha(job['map_path'])==identity['map_sha256'],'Map changed after planning')
        for team in ('a','b'):
            require(sha(guard(ARENA/'bots'/job['bot_'+team]/'.cambc/build/bot-injected.wasm'))==identity['wasm_'+team+'_sha256'],'WASM changed after planning')
    with exclusive(ROOT/'locks'/(key+'.lock')):
        unchanged();cached=load_cache(key,identity)
        if cached is not None:return cached,False
        start=time.monotonic();attempts=[];execution=time.time_ns()
        for retry in range(4):
            out=guard(ROOT/'game-output'/key/f'run-{execution}-attempt-{retry+1}');out.mkdir(parents=True,exist_ok=False)
            stats=out/'statistics.json'
            command=[str(CLI),'run','bots/'+job['bot_a'],'bots/'+job['bot_b'],'--map',str(job['map_path']),'-o',str(out),'--statistics',str(stats)]
            try:result=subprocess.run(command,cwd=ARENA,env=ENV,capture_output=True,text=True,errors='replace',timeout=240)
            except subprocess.TimeoutExpired as exc:
                write(out/'timeout.json',{'command':command,'timeout_seconds':240});raise RuntimeError('Game timed out '+key) from exc
            log=result.stdout+result.stderr
            access_failure=result.returncode!=0 and not stats.exists() and 'failed to persist temporary file: Access is denied' in log
            attempts.append({'returncode':result.returncode,'log_sha256':hashlib.sha256(log.encode()).hexdigest(),'pre_game_access_denied_retry':access_failure})
            if access_failure:
                write(out/'pre-game-failure.json',{'returncode':result.returncode,'log':log})
                if retry<3:continue
            break
        if result.returncode or not stats.exists():
            write(out/'failure.json',{'returncode':result.returncode,'log':log[-6000:]})
            raise RuntimeError('Game failed '+key+': '+log[-1000:])
        unchanged();data=read(stats);fields=stats_fields(data)
        replay_files=list(out.glob('*.repl26a'));require(len(replay_files)==1,'Expected one replay bundle')
        replay=guard(replay_files[0]);stdout={}
        with zipfile.ZipFile(replay) as archive:
            require(archive.testzip() is None,'Replay ZIP CRC failure')
            for team in ('a','b'):stdout[team]=audit_stdout(archive.read('team-'+team+'.stdout').decode('utf8',errors='replace'))
        content=json.dumps(data,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
        row={'schema_version':2,'valid':True,'key':key,'identity':identity,'created_utc':now(),**fields,
            'duration_seconds':time.monotonic()-start,'statistics_sha256':sha(stats),
            'statistics_content_sha256':hashlib.sha256(content).hexdigest(),'statistics':data,
            'replay_sha256':sha(replay),'stdout':stdout,'execution_attempts':attempts}
        reinit=sum(v['reinitializations_observed'] for v in stdout.values())
        if job['retain'] or any(fields['faults']) or reinit:
            evidence=guard(ROOT/'retained-replays'/(key+'.repl26a'));evidence.parent.mkdir(exist_ok=True)
            shutil.copyfile(replay,evidence);row['retained_replay']=str(evidence.relative_to(ROOT))
        write(CACHE/(key+'.json'),row)
        replay.unlink();stats.unlink()
        try:out.rmdir();out.parent.rmdir()
        except OSError:pass
        return row,True

def summarize_pair(rs):
    per={};w=l=d=0;gd=dd=0
    for r in rs:
        side=r['side'];winner={'teamA':0,'teamB':1,'draw':-1}[r['outcome']]
        outcome='D' if winner<0 else 'W' if winner==side else 'L'
        w+=outcome=='W';l+=outcome=='L';d+=outcome=='D'
        gd+=r['gems'][side]-r['gems'][1-side];dd+=r['deaths'][side]-r['deaths'][1-side]
        pair=per.setdefault((r['opponent'],r['map_sha256']),{})
        require(side not in pair,'Duplicate candidate/opponent/map/side slot')
        pair[side]=outcome
    require(all(set(v)=={0,1} for v in per.values()),'Incomplete paired sides')
    bw=sum(v[0]==v[1]=='W' for v in per.values());bl=sum(v[0]==v[1]=='L' for v in per.values())
    physical={r['key']:r for r in rs}
    return {'games':len(rs),'opponent_map_pairs':len(per),'unique_maps':len({k[1] for k in per}),
        'unique_physical_games':len(physical),'wins':w,'losses':l,'draws':d,
        'both_won':bw,'both_lost':bl,'split_or_draw':len(per)-bw-bl,
        'paired_sign_p_two_sided':sign_p(bw,bl),
        'mean_gem_difference':gd/max(1,len(rs)),'mean_death_difference':dd/max(1,len(rs)),
        'fault_games':sum(any(r['faults']) for r in physical.values()),
        'candidate_faults':sum(r['faults'][r['side']] for r in rs),
        'opponent_faults':sum(r['faults'][1-r['side']] for r in rs),
        'reinitialization_games':sum(any(v['reinitializations_observed'] for v in r['stdout'].values()) for r in physical.values()),
        'caught_error_samples':sum(sum(v['caught_errors'].values()) for r in physical.values() for v in r['stdout'].values()),
        'new_unique_games':len({r['key'] for r in rs if not r['cached']})}

def summarize(rows,names):
    results={}
    for name in names:
        rs=[r for r in rows if r['candidate']==name]
        results[name]={'overall_descriptive':summarize_pair(rs),
            'by_opponent':{o:summarize_pair([r for r in rs if r['opponent']==o]) for o in sorted({r['opponent'] for r in rs})}}
    return results

def run(stage,names,opponents,sets,jobs=24,limit=None):
    valid_name(stage);require(1<=jobs<=32,'Jobs must be 1..32')
    if isinstance(opponents,str):opponents=[opponents]
    require(names and opponents and len(names)==len(set(names)) and len(opponents)==len(set(opponents)),'Duplicate/empty candidate or opponent list')
    for name in names+opponents:valid_name(name)
    paths=[];aliases={};seen=set()
    for setname in sets:
        ms=sorted((ARENA/SETS.get(setname,setname)).glob('*.map26a'));require(ms,'Empty map set '+setname)
        for path in ms:
            digest=sha(path);aliases.setdefault(digest,[]).append(str(path.relative_to(ARENA)))
            if digest not in seen:paths.append(path);seen.add(digest)
    if limit is not None:
        require(limit>0,'Limit must be positive');paths=paths[:limit]
    records={name:read(ROOT/'candidates'/f'{name}.json') for name in set(names+opponents)}
    runtime=runtime_identity()
    for name,record in records.items():
        require(record['source_sha256']==hashes(ARENA/'bots'/name/'src'),'Source changed '+name)
        require(record['wasm_sha256']==sha(ARENA/'bots'/name/'.cambc/build/bot-injected.wasm'),'WASM changed '+name)
        require(record['cli_sha256']==runtime['cli_sha256'] and record['project_config_sha256']==runtime['project_config_sha256'] and record['sdk_header_sha256']==runtime['sdk_header_sha256'],'Build/runtime mismatch '+name)
    physical={};slots=[]
    for name in names:
        for opponent in opponents:
            for map_index,path in enumerate(paths):
                digest=sha(path)
                for side in (0,1):
                    a,b=(name,opponent) if side==0 else (opponent,name)
                    key,identity=physical_identity(records[a]['wasm_sha256'],records[b]['wasm_sha256'],digest,runtime)
                    physical.setdefault(key,{'key':key,'identity':identity,'bot_a':a,'bot_b':b,'map_path':path,'retain':map_index==0})
                    slots.append({'candidate':name,'opponent':opponent,'side':side,'map':path.stem,
                        'map_path':str(path.relative_to(ARENA)),'map_sha256':digest,'key':key})
    stamp={'stage':stage,'names':names,'opponents':opponents,'sets':sets,'maps':{str(p.relative_to(ARENA)):sha(p) for p in paths},
        'map_aliases':{sha(p):aliases[sha(p)] for p in paths},'sources':records,'slots':slots,
        'semantic_games':len(slots),'unique_physical_games':len(physical),'runtime':runtime}
    plan=ROOT/'stages'/f'{stage}-plan.json'
    if plan.exists():require(read(plan)['plan']==stamp,'Existing stage plan differs; choose a new stage name')
    else:write(plan,{'created_utc':now(),'plan':stamp})
    start=time.monotonic();results={};new=set();last=start
    with ThreadPoolExecutor(max_workers=jobs) as pool:
        futures={pool.submit(one,job):key for key,job in physical.items()}
        for future in as_completed(futures):
            key=futures[future];row,fresh=future.result();results[key]=row
            if fresh:new.add(key)
            t=time.monotonic()
            if t-last>20 or len(results)==len(physical):
                print(f'{stage}: {len(results)}/{len(physical)} unique games resolved ({len(new)} new) in {t-start:.0f}s',flush=True);last=t
    require(len(results)==len(physical),'Missing physical game results')
    verify_runtime(runtime)
    for name,record in records.items():
        require(hashes(ARENA/'bots'/name/'src')==record['source_sha256'],'Source changed during stage '+name)
        require(sha(ARENA/'bots'/name/'.cambc/build/bot-injected.wasm')==record['wasm_sha256'],'WASM changed during stage '+name)
    for path in paths:require(sha(path)==stamp['maps'][str(path.relative_to(ARENA))],'Map changed during stage')
    rows=[{**results[slot['key']],**slot,'cached':slot['key'] not in new} for slot in slots]
    summary=summarize(rows,names)
    write(ROOT/'results'/f'{stage}.json',{'stage':stage,'completed_utc':now(),'elapsed_seconds':time.monotonic()-start,
        'plan_sha256':sha(plan),'summary':summary,'semantic_games':len(slots),
        'unique_physical_games':len(physical),'new_unique_games':len(new),'cached_unique_games':len(physical)-len(new),
        'prior_experiment_cache_origin_games':sum('imported_cache' in r for r in results.values()),'games':rows})
    for name,result in summary.items():print(name,json.dumps(result),flush=True)
    return summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage');p.add_argument('names',nargs='+');p.add_argument('--opponents',default='original');p.add_argument('--opponent',help='Legacy singular alias');p.add_argument('--sets',default='official,gen,dev');p.add_argument('--jobs',type=int,default=24);p.add_argument('--limit',type=int)
    a=p.parse_args();run(a.stage,a.names,(a.opponent or a.opponents).split(','),a.sets.split(','),a.jobs,a.limit)
