"""Pure subprocess/executor mocks; never launches CLI or reads game outcomes."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch
import json,subprocess
import test_matches as m

checks=[]
def check(ok,label):
    if not ok:raise AssertionError(label)
    checks.append(label)
def command_case(label,failures=0,other=False,with_stats=False,timeout=False):
    calls=[];sleeps=[]
    with TemporaryDirectory(prefix='pure-retry-',dir=m.ROOT) as temporary:
        root=Path(temporary)
        def mocked(command,**kwargs):
            calls.append(command)
            if timeout:raise subprocess.TimeoutExpired(command,240)
            fail=len(calls)<=failures or other
            if not fail or with_stats:Path(command[command.index('--statistics')+1]).write_text('{}')
            log='failed to persist temporary file: Access is denied' if fail and not other else 'different error' if fail else 'mock success'
            return SimpleNamespace(returncode=int(fail),stdout=log,stderr='')
        with patch.object(m,'ROOT',root),patch.object(m,'ARENA',root),patch.object(m.subprocess,'run',mocked),patch.object(m.time,'sleep',sleeps.append):
            try:out,stats,result,attempts=m.execute_game({'bot_a':'a','bot_b':'b','map_path':root/'unused'},'fixture',1)
            except RuntimeError:
                check(timeout and len(calls)==1 and not sleeps and len(list(root.rglob('timeout.json')))==1,label);return
            expected=12 if failures>=12 else failures+1 if not other and not with_stats else 1
            check(len(calls)==expected,label+' process count')
            check(len(sleeps)==(expected-1 if not other and not with_stats else 0),label+' backoff count')
            check(all(0<v<=2 for v in sleeps),label+' bounded backoff')
            check(len(attempts)==expected,label+' attempt records')
            check(len(list(root.rglob('pre-game-failure.json')))==(min(failures,12) if not other and not with_stats else 0),label+' retained pregame records')
            check(result.returncode==(1 if failures>=12 or other or with_stats else 0),label+' final status')
command_case('eleven transient failures then success',11)
command_case('twelve transient failures exhausted',12)
command_case('unrelated error never retried',other=True)
command_case('statistics present never retried',failures=1,with_stats=True)
command_case('timeout never retried',timeout=True)

shutdowns=[];cancelled=[];failures=[]
class Future:
    def __init__(self,index):self.index=index
    def result(self):raise RuntimeError('mock fatal failure')
    def cancel(self):cancelled.append(self.index);return self.index>0
class Pool:
    def __init__(self,**kwargs):self.n=0
    def submit(self,*args):f=Future(self.n);self.n+=1;return f
    def shutdown(self,**kwargs):shutdowns.append(kwargs)
with patch.object(m,'ThreadPoolExecutor',Pool),patch.object(m,'as_completed',lambda fs:list(fs)),patch.object(m,'write',lambda p,v:failures.append(v)):
    try:m.resolve_physical({'first':{},'queued':{}},1,'mock-stage')
    except RuntimeError as e:check(str(e)=='mock fatal failure','fatal worker exception propagated')
    else:raise AssertionError('Failure swallowed')
check(cancelled==[0,1],'pending future cancellation requested')
check(shutdowns==[{'wait':True,'cancel_futures':True}],'shutdown waits only active workers after cancelling queue')
check(failures[0]['failed_key']=='first' and failures[0]['queued_futures_cancelled']==1,'failure provenance records failed key and cancellation')
out={'passed':True,'checks':len(checks),'cases':checks,'harness_sha256':m.sha(Path(m.__file__)),'subprocesses_launched':0,'game_outcomes_read':False,'maps_or_games_created':0}
target=m.ROOT/'recovery-contracts.json'
target.write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
print(json.dumps(out,indent=2))
