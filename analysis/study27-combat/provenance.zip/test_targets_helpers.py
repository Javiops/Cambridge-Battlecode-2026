"""Execute actual inserted C++ combat helpers using narrow SDK stand-ins; no games."""
from pathlib import Path
import hashlib
import json
import subprocess
import patch_combat_targets as patch

ROOT=Path(__file__).resolve().parent
CLANG=Path('C:/Users/frans/AppData/Local/cambc/wasi-sdk-33/bin/clang++.exe')
NODE=Path('C:/Users/frans/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')


def block(text,start):
    assert text.count(start)==1,start
    begin=text.index(start);brace=text.index('{',begin);depth=1;end=brace+1
    while depth:
        depth+=(text[end]=='{')-(text[end]=='}');end+=1
    return text[begin:end]


PREFIX=r'''
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <optional>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <variant>
#include <vector>
#define P_U34_ATTACK_LIVE 0
#define P_U34_RESET_LIVE 2
#define P_AOE 2
struct vec2 {int x=0,y=0;vec2()=default;vec2(int a,int b):x(a),y(b){};bool operator==(vec2 o)const{return x==o.x&&y==o.y;}};
int dist(vec2 a,vec2 b){return std::max(std::abs(a.x-b.x),std::abs(a.y-b.y));}
template<class F>bool attempt(F f){try{return f();}catch(...){return false;}}
std::vector<int> attack_ids,cast_ids;
std::vector<vec2> cast_points;
int fuel=100000;
bool fuel_ok(int n){return fuel>=n;}
namespace bc {
enum class passive_type {none,stun_immunity};
enum class Kind {none,damage,aoe,cc,reset,dash};
struct Props {bool exclusive_with_movement=false;};
struct ResetInfo:Props{};
struct RangeInfo:Props {float range=4;};
struct AoeInfo:Props {float range=4,radius=1;};
using Info=std::variant<ResetInfo,RangeInfo,AoeInfo>;
struct champion;
struct Ability {
    champion* owner=nullptr;
    Kind kind=Kind::none;int cd=0;float damage=0,range=4,radius=1;bool exclusive=false,enemy=true;
    bool is_ready()const;
    bool is_damage()const{return kind==Kind::damage;}
    bool is_aoe_damage()const{return kind==Kind::aoe;}
    bool is_cc()const{return kind==Kind::cc;}
    bool is_attack_reset()const{return kind==Kind::reset;}
    bool is_dash()const{return kind==Kind::dash;}
    bool can_target_enemies()const{return enemy;}
    std::optional<Info>info()const {
        if(kind==Kind::none)return std::nullopt;
        if(kind==Kind::reset)return ResetInfo{{exclusive}};
        if(kind==Kind::aoe)return AoeInfo{{exclusive},range,radius};
        return RangeInfo{{exclusive},range};
    }
    float damage_amount(const champion&)const;
    bool use()const;
    bool use(const champion&)const;
    bool use(vec2)const;
};
struct Buffs {bool stunned=false;bool has_stun()const{return stunned;}};
struct champion {
    int id=0,ar=1;vec2 p{10,10};mutable float hp=1000;float mhp=1000,st=50,shield=0,mitigation=1;
    bool visible=true,alive=true,attack_allowed=true,move_allowed=true,cast_allowed=true,moved=false,stunned=false;
    passive_type passive_value=passive_type::none;
    std::array<Ability,2>abs;
    bool is_visible()const{return visible;}
    bool is_alive()const{return alive;}
    float health()const{return hp;}
    float max_health()const{return mhp;}
    float strength()const{return st;}
    vec2 position()const{return p;}
    int attack_range()const{return ar;}
    bool can_attack()const{return attack_allowed&&alive;}
    bool can_move()const{return move_allowed&&alive;}
    bool can_cast()const{return cast_allowed&&alive;}
    passive_type passive()const{return passive_value;}
    Buffs buffs()const{return {stunned};}
    std::array<Ability,2>&abilities(){for(auto& a:abs)a.owner=this;return abs;}
    template<class T>void attack(const T&target){
        if(!can_attack()||!target.is_visible()||target.health()<=0||dist(p,target.position())>ar)throw std::runtime_error("illegal attack");
        attack_ids.push_back(target.id);target.hp=std::max(0.0f,target.hp-st);attack_allowed=false;if(ar>1)move_allowed=false;
    }
};
bool Ability::is_ready()const{return owner&&owner->can_cast()&&kind!=Kind::none&&cd==0;}
float Ability::damage_amount(const champion&t)const{return std::min(t.hp,std::max(0.0f,damage*t.mitigation-t.shield));}
bool Ability::use()const{if(!is_ready())throw std::runtime_error("not ready");owner->cast_allowed=false;if(kind==Kind::reset)owner->attack_allowed=true;return true;}
bool Ability::use(const champion&t)const{
    if(!is_ready()||!t.visible||dist(owner->p,t.p)>range||(exclusive&&owner->moved))throw std::runtime_error("illegal spell");
    cast_ids.push_back(t.id);owner->cast_allowed=false;if(exclusive)owner->move_allowed=false;t.hp-=damage_amount(t);return true;
}
bool Ability::use(vec2 p)const{
    if(!is_ready()||dist(owner->p,p)>range||(exclusive&&owner->moved))throw std::runtime_error("illegal ground spell");
    cast_points.push_back(p);owner->cast_allowed=false;if(exclusive)owner->move_allowed=false;return true;
}
struct camp {int id=90;vec2 p{11,10};mutable float hp=500;bool is_visible()const{return true;}float health()const{return hp;}vec2 position()const{return p;}};
namespace vision {std::vector<champion> enemies;std::vector<champion>&champions(int){return enemies;}}
int round_number(){return 123;}
}
enum class Slot {None,Reset,Dash,Targeted,Ground,Heal,Shield};
struct Mask {std::vector<vec2>tiles;bool is_set(vec2 p)const{return std::find(tiles.begin(),tiles.end(),p)!=tiles.end();}};
namespace v34de {constexpr int Corners=1,Interlock=2;}
struct State {std::optional<int>en=1;Mask en_spawn;int reset_slot=-1,dash_slot=-1,rooted_r=-1,sweep=3,de_map=0;Slot slots[2]{Slot::None,Slot::None};};
struct Foe {bc::champion c;vec2 p;float hp;int d,gems;bool channeling;};
namespace fight {int reach(const Foe&f){return f.c.ar+1;}}
constexpr int SPELL_RANGE=4;
struct AoeSlot {int radius=-1,range=0;double mod=0;};
int aoe_hits=1;
AoeSlot aoe_slot(bc::champion&me,int k){return {static_cast<int>(me.abs[k].radius),static_cast<int>(me.abs[k].range),0};}
bool slot_exclusive(State&,bc::champion&me,int k){return me.abs[k].exclusive;}
vec2 aoe_centre(State&,bc::champion&me,int k,vec2 p,int*hits=nullptr){
    if(hits)*hits=aoe_hits;
    int r=static_cast<int>(me.abs[k].range);
    return {std::clamp(p.x,me.p.x-r,me.p.x+r),std::clamp(p.y,me.p.y-r,me.p.y+r)};
}
const char*g_mode="test";
void reset(){attack_ids.clear();cast_ids.clear();cast_points.clear();bc::vision::enemies.clear();fuel=100000;aoe_hits=1;}
bc::champion enemy(int id,int x=11,int y=10,float hp=500){bc::champion c;c.id=id;c.p={x,y};c.hp=hp;return c;}
'''

CASES=r'''
int main(){
    int checks=0;auto test=[&](bool p,const char*label){if(!p)std::printf("FAIL %s\n",label);assert(p);++checks;};
    reset();State s;bc::champion me;auto dead=enemy(1,11,10,0);bc::vision::enemies={enemy(2,11,10,30),enemy(3,10,11,80)};
    test(basic_attack(s,me,dead,dead.p),"dead visible preferred target gets free legal replacement");
    test(attack_ids==std::vector<int>{2},"lowest health legal champion selected");
    reset();me=bc::champion{};me.attack_allowed=false;test(!basic_attack(s,me,dead,dead.p)&&attack_ids.empty(),"no attack allowance adds no action");
    reset();me=bc::champion{};bc::vision::enemies={enemy(2,15,10,20)};test(!basic_attack(s,me,dead,dead.p),"out of range replacement excluded");
    reset();me=bc::champion{};auto live=enemy(1,11,10,500);test(basic_attack(s,me,live,{18,18}),"fresh actual position replaces stale position");
    test(attack_ids==std::vector<int>{1},"fresh live target retained");
    reset();me=bc::champion{};bc::camp camp;test(basic_attack(s,me,camp,camp.p)&&attack_ids==std::vector<int>{90},"camp basic path unchanged");
    reset();me=bc::champion{};s.reset_slot=0;me.abs[0].kind=bc::Kind::reset;live=enemy(1,11,10,500);
    test(basic_attack(s,me,live,live.p)&&attack_ids.size()==2,"living champion basic reset order retained");
    reset();me=bc::champion{};me.abs[0].kind=bc::Kind::reset;live=enemy(1,11,10,20);
    test(basic_attack(s,me,live,live.p)&&attack_ids.size()==1&&me.cast_allowed,"no reset spent after first attack kills");s.reset_slot=-1;

    reset();me=bc::champion{};s.slots[0]=Slot::Targeted;me.abs[0].kind=bc::Kind::damage;me.abs[0].damage=100;live=enemy(1,14,10,100);
    test(cm_spell_can_finish(s,me,0,live),"actual target damage lethal at range boundary");
    live.shield=1;test(!cm_spell_can_finish(s,me,0,live),"shield-aware damage is not lethal");
    live.shield=0;live.mitigation=.5;test(!cm_spell_can_finish(s,me,0,live),"mitigation-aware damage is not lethal");
    live.mitigation=1;me.abs[0].cd=1;test(!cm_spell_can_finish(s,me,0,live),"cooldown blocks finish");
    me.abs[0].cd=0;live.p={15,10};test(!cm_spell_can_finish(s,me,0,live),"out of cast range excluded");
    live.p={14,10};me.abs[0].exclusive=true;test(!cm_spell_can_finish(s,me,0,live,true),"free-only excludes rooting spell");
    me.abs[0].exclusive=false;me.abs[0].kind=bc::Kind::cc;me.abs[0].damage=0;test(!cm_spell_can_finish(s,me,0,live),"pure stun is not a lethal spell");
    me.abs[0].kind=bc::Kind::damage;me.abs[0].damage=100;me.abs[0].exclusive=true;me.moved=true;
    test(cm_spell_can_finish(s,me,0,live),"predictor documents per-ability moved-state limit");
    test(!attempt([&]{return me.abs[0].use(live);})&&cast_ids.empty(),"engine legality rejects exclusive spell after movement");

    reset();auto st=enemy(1);test(cm_stun_useful(st),"ordinary live target has stun value");
    st.stunned=true;test(!cm_stun_useful(st),"already stunned target has no new control value");
    st.stunned=false;st.passive_value=bc::passive_type::stun_immunity;test(!cm_stun_useful(st),"stun immunity excluded");
    st.passive_value=bc::passive_type::none;st.visible=false;test(!cm_stun_useful(st),"hidden stun target excluded");

    reset();State k;me=bc::champion{};live=enemy(1,11,10,500);test(cm_available_finish_damage(k,me,live)==50,"single available basic is not two attacks");
    me.abs[0].kind=bc::Kind::reset;test(cm_available_finish_damage(k,me,live)==100,"ready reset enables two basics");
    me.abs[0].cd=1;test(cm_available_finish_damage(k,me,live)==50,"cooldown reset not counted");
    me.abs[0].cd=0;me.abs[0].kind=bc::Kind::dash;me.abs[0].range=2;live.p={14,10};test(cm_available_finish_damage(k,me,live)==50,"melee dash two plus walk one plus basic one");
    me.abs[0].cd=1;test(cm_available_finish_damage(k,me,live)==0,"unready dash cannot finish distant foe");
    me=bc::champion{};me.ar=3;live.p={14,10};test(cm_available_finish_damage(k,me,live)==0,"ranged normal move cannot combine with basic");
    me=bc::champion{};k.slots[0]=Slot::Targeted;me.abs[0].kind=bc::Kind::damage;me.abs[0].damage=120;me.abs[0].exclusive=true;live.p={12,10};
    test(cm_available_finish_damage(k,me,live)==120,"rooting spell cannot add walked melee basic");
    me.abs[0].exclusive=false;test(cm_available_finish_damage(k,me,live)==170,"compatible spell can add walked melee basic");
    me.cast_allowed=false;test(cm_available_finish_damage(k,me,live)==50,"spent cast excludes every ready spell/reset route");
    me.attack_allowed=false;test(cm_available_finish_damage(k,me,live)==0,"spent basic and cast allow no burst");

    reset();State edge;me=bc::champion{};edge.slots[0]=Slot::Ground;me.abs[0].kind=bc::Kind::aoe;me.abs[0].damage=100;me.abs[0].exclusive=true;
    bc::vision::enemies={enemy(1,15,10,100)};
    test(cm_edge_aoe(edge,me,true,false)&&cast_points==std::vector<vec2>{{14,10}},"range five foe hit from legal range four centre");
    reset();me=bc::champion{};me.abs[0].kind=bc::Kind::aoe;me.abs[0].exclusive=true;bc::vision::enemies={enemy(1,15,10)};
    test(!cm_edge_aoe(edge,me,false,false)&&cast_points.empty(),"stand guard preserves rooting exclusion");
    test(!cm_edge_aoe(edge,me,true,false,true)&&cast_points.empty(),"free-only edge spell is movement compatible");
    bc::vision::enemies={enemy(1,16,10)};test(!cm_edge_aoe(edge,me,true,false),"beyond radius edge excluded");
    bc::vision::enemies={enemy(1,15,10)};me.abs[0].cd=1;test(!cm_edge_aoe(edge,me,true,false),"unready edge spell excluded");
    me.abs[0].cd=0;edge.en_spawn.tiles={{15,10}};test(!cm_edge_aoe(edge,me,true,false),"enemy spawn edge target excluded");
    std::printf("actual combat helpers: %d checks passed\n",checks);
}
'''


def main():
    base={p.name:p.read_text()for p in(ROOT/'baseline/src').iterdir()if p.is_file()}
    source=patch.apply_many(base,patch.FEATURES)['main.cpp']
    visible=block(base['main.cpp'],'template <class U>\nbool u34_target_visible(')
    retarget=block(source,'bool cm_retarget_basic(')
    basic=block(source,'template <class U>\nbool basic_attack(State& s, bc::champion& me, const U& tgt, vec2 tpos) {')
    helpers='\n'.join(block(source,start)for start in('bool cm_spell_can_finish(','bool cm_stun_useful(','double cm_available_finish_damage(','bool cm_edge_aoe('))
    prototype='template <class U>bool basic_attack(State&,bc::champion&,const U&,vec2);\n'
    cpp,wasm=ROOT/'targets-helper-fixture.cpp',ROOT/'targets-helper-fixture.wasm'
    cpp.write_text(PREFIX+visible+prototype+retarget+basic+helpers+CASES,newline='\n')
    proc=subprocess.run([str(CLANG),'-std=c++20','-fwasm-exceptions','-O2',str(cpp),'-lunwind','-o',str(wasm)],capture_output=True,text=True)
    if proc.returncode:raise RuntimeError(proc.stderr)
    runner=ROOT/'targets-helper-fixture.mjs'
    runner.write_text('''import fs from 'node:fs';
import {WASI} from 'node:wasi';
const wasi=new WASI({version:'preview1',args:[],env:{},preopens:{}});
const {instance}=await WebAssembly.instantiate(fs.readFileSync(new URL('./targets-helper-fixture.wasm',import.meta.url)),{wasi_snapshot_preview1:wasi.wasiImport});
wasi.start(instance);
''',newline='\n')
    proc=subprocess.run([str(NODE),str(runner)],capture_output=True,text=True)
    if proc.returncode:raise RuntimeError(proc.stdout+proc.stderr)
    output={'passed':True,'method':'Actual inserted basic/retarget/finish/stun/AoE helper bodies extracted, WASI-compiled and executed with narrow SDK stand-ins; full SDK builds are separate. No games.',
            'stdout':proc.stdout.strip(),'cpp_sha256':hashlib.sha256(cpp.read_bytes()).hexdigest(),
            'patch_sha256':hashlib.sha256((ROOT/'patch_combat_targets.py').read_bytes()).hexdigest()}
    (ROOT/'targets-helper-fixtures.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output,indent=2))


if __name__=='__main__':main()
