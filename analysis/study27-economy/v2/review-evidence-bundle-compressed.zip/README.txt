REVIEW / RERUN ASSETS — EXPERIMENTAL

This is NOT a Battlecode submission ZIP. It contains review sources, fixed
opponent sources and the exact 512 native fresh maps. Do not upload this bundle
as a bot. The separately labeled experimental source archive is the bot upload.

The fixed productive_walk package failed its predeclared fresh confirmation:
521 wins / 503 losses against the cleaned PR11 control, paired-map p=0.603397;
the matched five-reference panel improved by114/5120 game scores (+2.22656pp),
but its map-direction p=0.139357 also failed. This is NOT a validated stronger
replacement. All five reference deltas were positive; this remains descriptive.
The 11264 fresh games had zero reported faults/reinitializations. Caught SDK
errors and logged low-fuel samples were nonzero and are distinct diagnostics.

Layout:
  baseline/src/                     exact cleaned PR11 control (six files)
  candidate/productive_walk/src/     exact selected experimental sources
  references/                       original + five fixed opponent source trees
  maps/confirmation512/             all512 native maps and generator manifest
  portable-tools/                   eight source-reproduction support files
  portable-tools/baseline-src/       adjacent exact baseline for reproduction
  evidence/                         final independent audit and failed verdict
  manifests/                        source registrations/runtime/generation pins

The older spar11/spar12/spar16 bots have exactly three registered source files
(fight.h/main.cpp/params.h). Their original layouts are preserved. The other
three reference trees, baseline and selected candidate each contain six files;
no missing old-spar headers have been invented or borrowed from another bot.

Reproduce all six implemented package SOURCES (Python3.10+, no SDK needed):
  python portable-tools/rebuild_candidates.py --baseline portable-tools/baseline-src --out reproduced
The output parent must exist and 'reproduced' must not exist. This only writes
sources; it does not compile, run games, submit, or endorse all variants.

To rerun a match, use your own official CPP Battlecode project/CLI/SDK. Copy
candidate/productive_walk/src to bots/productive_walk/src, reference sources
to bots/<reference>/src, and maps/confirmation512 into that project. Build both
bots there, then, for example:
  cambc build bots/productive_walk
  cambc build bots/original
  cambc run bots/productive_walk bots/original --map maps/confirmation512/fresh-0000.map26a -o review-rerun --statistics review-rerun/statistics.json
Swap bot order for the other side. Match runtime hashes in the compact runtime
manifest for exact comparison; no SDK/CLI binaries are bundled here.

Internal MANIFEST.json lists every other archived file. The separate companion
review-evidence-bundle-manifest.json hashes EVERY archived file, including that
internal manifest, and pins the final archive bytes. ZIP order/times/modes are
fixed and ZIP_STORED avoids compressor-version variability.

Only explicitly allowlisted sources, native maps and review metadata are
included. No credentials, authentication material, private configurations,
raw game statistics/cache files, stdout/replays, executables or repository/
worktree metadata are included. This compact bundle cannot replace the full
raw evidence audit. Source hashes reproduce tested inputs; local references
and one procedural map distribution cannot establish universal or ladder gains.
