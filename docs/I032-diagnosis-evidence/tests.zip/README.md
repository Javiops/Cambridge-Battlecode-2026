# Portable source-level mechanism checks

Install `requirements.txt`, then run `python run.py --src BOT/src --sdk SDK/cpp --compiler WASI_SDK/bin/clang++ --out-dir BUILD` using WASI SDK33 with exception-enabled libc++ and the official Cambridge Battlecode C++ SDK2.2.5. Python wasmtime49 is required. `--wasmtime-pythonlib` optionally points to an existing local installation. Source directories remain unchanged; build output must be separate.

The runner compiles the full supplied production translation unit once with its shipped flags, then runs nine fixtures: ward API call handling, remote camp approach, three draft replacement settings, and four cache/anchor settings with actual alert/claim protocol definitions. It extracts current production functions and preference code and uses current cache headers. The original ward helper is retained as an explicitly frozen comparison. Source hashes and fixture outputs are recorded in `results.json`.

The separate callsite check ensures remote approach repair runs only after ordinary movement fails, movement is still available, and a fuel reserve remains. Native replay examples validate why this ordering matters: a bitboard precheck before the old movement fuel gate removed opening dashes again when individually correct fixes were first combined.

These are narrow mock tests plus an actual SDK object compile. They do not measure SDK fuel cost, replace release builds or native games, or establish competitive improvement. No test runs a match, submits a bot, accesses an account or changes the input source. The archived results were obtained from the final Cassi v2 source; verify the source SHA-256 manifest before treating them as applicable to another version.
