"""Read-only regression for the camp-approach fallback ordering.
This checks the actual farm callsite; helper mechanics are covered separately.
Usage: python check_approach_callsite.py path/to/src [--report report.json]
"""
from pathlib import Path
import argparse,hashlib,json,re
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('src',type=Path);ap.add_argument('--report',type=Path);args=ap.parse_args();p=args.src/'main.cpp';s=p.read_text();farm=s[s.index('void farm(State&'):s.index('// One turn',s.index('void farm(State&'))]
call=farm.rfind('cf_remote_approach(');assert call>=0,'Missing farm approach repair callsite'
normal=farm.rfind('bool moved = step_towards(s, me, goals, true);',0,call)
assert normal>=0,'Ordinary path attempt must run before repair work'
context=farm[normal:call];assert '!moved'in context,'Repair requires failed movement'
assert 'me.can_move()'in context,'Do not repair after successful/exhausted movement'
assert 'fuel_ok('in context,'Repair must reserve fuel before extra SDK work'
assert 'goals & ~s.blocked'not in farm[max(0,normal-240):normal],'Do not repeat occupied-goal bitboard precheck before ordinary path fuel gates'
assert 'step_towards(s, me, goals, true)'in farm[call+len('cf_remote_approach('):call+500],'Repair must retry actual production movement after adjusting goals'
report={'status':'pass','source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scope':'Read-only callsite order check. It verifies ordinary movement precedes fallback mask work and requires !moved, movement availability and a fuel reserve; it is not a fuel cost measurement.','callsite':farm[normal:call+450]}
if args.report:args.report.write_text(json.dumps(report,indent=2)+'\n')
print('PASS: ordinary path attempt runs before guarded remote-camp repair')
