
#include <bitset>
#include <vector>
#include <cstdio>
#include <cstdlib>
struct vec2 {int x,y;};
namespace bc {struct bitboard{
std::bitset<4096> bits;
void set(vec2 p,bool v=true){if(p.x>=0&&p.x<64&&p.y>=0&&p.y<64)bits.set(p.y*64+p.x,v);}
bool is_set(vec2 p)const{return p.x>=0&&p.x<64&&p.y>=0&&p.y<64&&bits.test(p.y*64+p.x);}
bool is_empty()const{return bits.none();}
std::vector<vec2> positions()const{std::vector<vec2> p;for(int y=0;y<64;y++)for(int x=0;x<64;x++)if(is_set({x,y}))p.push_back({x,y});return p;}
void draw_chebyshev(vec2 p,float r){for(int y=p.y-int(r);y<=p.y+int(r);y++)for(int x=p.x-int(r);x<=p.x+int(r);x++)set({x,y});}
friend bitboard operator~(bitboard a){a.bits.flip();return a;}
friend bitboard operator&(const bitboard&a,const bitboard&b){bitboard c;c.bits=a.bits&b.bits;return c;}
bitboard&operator&=(const bitboard&b){bits&=b.bits;return*this;}
};}
int checks=0;void require(bool c,const char*label){checks++;if(!c){std::fprintf(stderr,"FAIL %s\n",label);std::exit(1);}}

bool cf_remote_approach(const bc::bitboard& spawn, const bc::bitboard& blocked,
                        const bc::bitboard& visible_camps, bc::bitboard& goals) {
    if (!(goals & ~blocked).is_empty() || (goals & visible_camps).is_empty()) return false;
    bc::bitboard ring;
    for (auto tile : spawn.positions()) ring.draw_chebyshev(tile, 1.0f);
    ring &= ~spawn;
    ring &= ~blocked;
    if (ring.is_empty()) return false;
    goals = ring;
    return true;
}

int main(){
bc::bitboard spawn,blocked,camps,goals;spawn.set({3,9});spawn.set({4,9});blocked=spawn;camps=spawn;goals=spawn;
require((goals&~blocked).is_empty(),"baseline remote goals empty");
require(cf_remote_approach(spawn,blocked,camps,goals),"remote occupied camp rerouted");
require(!goals.is_empty()&&(goals&blocked).is_empty()&&(goals&spawn).is_empty(),"free neighbours exclude occupied spawn");
require(goals.is_set({2,8})&&goals.is_set({5,10}),"Monolith approach roots cover both wolves");
goals=spawn;bc::bitboard none;require(!cf_remote_approach(spawn,blocked,none,goals)&&goals.bits==spawn.bits,"unknown/champion-only occupied target unchanged");
blocked.set({4,9},false);goals=spawn;require(!cf_remote_approach(spawn,blocked,camps,goals)&&goals.bits==spawn.bits,"partly free spawn unchanged");
blocked=spawn;blocked.draw_chebyshev({3,9},2);blocked.draw_chebyshev({4,9},2);goals=spawn;
require(!cf_remote_approach(spawn,blocked,camps,goals)&&goals.bits==spawn.bits,"fully blocked neighbours fail without invalid roots");
spawn=bc::bitboard{};spawn.set({0,0});blocked=spawn;camps=spawn;goals=spawn;require(cf_remote_approach(spawn,blocked,camps,goals)&&goals.positions().size()==3,"edge clipped to map");
std::printf("PASS checks=%d\n",checks);}
