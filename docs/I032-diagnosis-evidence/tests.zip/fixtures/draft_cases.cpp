
#include <vector>
#include <string>
#include <algorithm>
#include <cassert>
#include <cstdio>
#include "draft_choice_policy.h"
struct Opt { std::string name; };
bool starts_with(const std::string& a,const std::string& b){return a.rfind(b,0)==0;}
std::vector<Opt> make_order(std::vector<const char*> prefs,const std::vector<Opt>& all){
    std::vector<Opt> order;
    auto has=[&](const std::string& n){for(auto& o:order)if(o.name==n)return true;return false;};
// ACTUAL_ORDER_BLOCK
    return order;
}
std::vector<std::string> names(const std::vector<Opt>& x){std::vector<std::string>r;for(auto& o:x)r.push_back(o.name);return r;}
int main(){
 const std::vector<Opt> all={{"ryth"},{"stellar"},{"prism"},{"ren"},{"tavi"},{"vendetta"},{"varg"},{"cassiandissac"},{"willow"}};
 auto order=names(make_order({"ryth","stellar","prism","ren","tavi","vendetta","varg","cassi","willow"},all));
#if P_DP_PRISM_SWAP==0
 const std::vector<std::string> expected={"ryth","stellar","prism","ren","tavi","vendetta","varg","cassiandissac","willow"};
#elif P_DP_PRISM_SWAP==1
 const std::vector<std::string> expected={"ryth","stellar","cassiandissac","ren","tavi","vendetta","varg","willow"};
#else
 const std::vector<std::string> expected={"ryth","stellar","willow","ren","tavi","vendetta","varg","cassiandissac"};
#endif
 assert(order==expected);
 for(int picks:{3,4,5}){std::vector<std::string> selected(order.begin(),order.begin()+picks);assert(std::equal(selected.begin(),selected.end(),expected.begin()));}
 auto no_preferences=names(make_order({},all));
#if P_DP_PRISM_SWAP
 assert(std::find(no_preferences.begin(),no_preferences.end(),"prism")==no_preferences.end());
 assert(std::find(order.begin(),order.end(),"prism")==order.end());
#else
 assert(std::find(no_preferences.begin(),no_preferences.end(),"prism")!=no_preferences.end());
#endif
 // A substitute already present in the recipe must remain a single choice.
 auto duplicate=names(make_order({"stellar","cassi","willow","prism","ren"},all));
 assert(std::count(duplicate.begin(),duplicate.end(),"cassiandissac")==1);
 assert(std::count(duplicate.begin(),duplicate.end(),"willow")==1);
 // With the requested substitute unavailable, later ordinary choices remain
 // legal; the discovered-catalogue fallback still cannot revive Prism.
 std::vector<Opt> unavailable=all;
#if P_DP_PRISM_SWAP==1
 unavailable.erase(std::remove_if(unavailable.begin(),unavailable.end(),[](auto o){return o.name=="cassiandissac";}),unavailable.end());
#elif P_DP_PRISM_SWAP==2
 unavailable.erase(std::remove_if(unavailable.begin(),unavailable.end(),[](auto o){return o.name=="willow";}),unavailable.end());
#endif
 auto missing=names(make_order({"ryth","stellar","prism","ren","tavi"},unavailable));
#if P_DP_PRISM_SWAP
 assert((std::vector<std::string>(missing.begin(),missing.begin()+5)==std::vector<std::string>{"ryth","stellar","ren","tavi","vendetta"}));
 assert(std::find(missing.begin(),missing.end(),"prism")==missing.end());
#endif
 // Only Prism is excluded: uncommon/unknown legal catalogue names preserve
 // the source's discovery order in fallback.
 const std::vector<Opt> unusual={{"willow"},{"prism"},{"cassiandissac"},{"championdraft"},{"ren"}};
 auto unknown=names(make_order({},unusual));
#if P_DP_PRISM_SWAP
 assert((unknown==std::vector<std::string>{"willow","cassiandissac","championdraft","ren"}));
#else
 assert((unknown==std::vector<std::string>{"willow","prism","cassiandissac","championdraft","ren"}));
#endif
 std::printf("PASS swap=%d actual final preference/filter/order cases\n",P_DP_PRISM_SWAP);
}
