#include "params.h"
#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>
#include <queue>
struct vec2 {
    int x=0,y=0;
    vec2()=default; vec2(int a,int b):x(a),y(b){}
    vec2 operator+(vec2 b) const { return {x+b.x,y+b.y}; }
    bool operator==(const vec2&) const=default;
};
int dist(vec2 a,vec2 b) { return std::max(std::abs(a.x-b.x),std::abs(a.y-b.y)); }
std::uint64_t fuel=1000000;
int errors=0,queries=0,fields=0,fail_field=0;
bool fuel_drop=false;
std::string fail_query;
bool fuel_ok(std::uint64_t n) { return fuel>n+6000; }
template<class F> bool attempt(F&& f) { try { return f(); } catch (...) { ++errors; return false; } }
void query(const char* name) { ++queries; if (fail_query==name) throw std::runtime_error(name); }
namespace bc {
enum class team { ally,enemy };
struct bitboard {
    std::vector<vec2> tiles;
    std::string tag;
    bool is_set(vec2 p) const { return std::find(tiles.begin(),tiles.end(),p)!=tiles.end(); }
    std::vector<vec2> positions() const { if (!tag.empty()) query(tag.c_str()); return tiles; }
    void set(vec2 p) { if (!is_set(p)) tiles.push_back(p); }
    bitboard operator|(const bitboard& b) const { auto v=*this; v.tag.clear(); for(auto p:b.tiles) v.set(p); return v; }
};
namespace map {
inline int W=20,H=20;
inline bitboard walls_v,holes_v,altars_v,bushes_v,ally_v,enemy_v;
int width() { query("width"); return W; }
int height() { query("height"); return H; }
bool is_in_bounds(vec2 p) { return p.x>=0 && p.y>=0 && p.x<W && p.y<H; }
const bitboard& walls() { query("walls"); return walls_v; }
const bitboard& holes() { query("holes"); return holes_v; }
const bitboard& altars() { query("altars"); return altars_v; }
const bitboard& bushes() { query("bushes"); return bushes_v; }
const bitboard& spawn_region(team t) { query("spawn"); return t==team::ally ? ally_v : enemy_v; }
}
namespace draft { inline int TS=5; int team_size() { query("team_size"); return TS; } }
struct distance_field {
    std::array<int,65536> d{};
    void compute(const bitboard& block,const bitboard& roots,bitboard& seen) {
        ++fields;
        if (fields==fail_field) throw std::runtime_error("field");
        d.fill(-1); seen={}; std::queue<vec2> q;
        for(auto p:roots.tiles) if (!block.is_set(p)) { d[p.y*256+p.x]=0; seen.set(p); q.push(p); }
        while(!q.empty()) {
            auto p=q.front(); q.pop();
            for(int dx=-1;dx<=1;++dx) for(int dy=-1;dy<=1;++dy) {
                auto n=p+vec2(dx,dy);
                if ((!dx&&!dy)||!map::is_in_bounds(n)||block.is_set(n)||d[n.y*256+n.x]>=0) continue;
                d[n.y*256+n.x]=d[p.y*256+p.x]+1; seen.set(n); q.push(n);
            }
        }
        if (fuel_drop && fields==1) fuel=25000;
    }
    int get(vec2 p) const { return d.at(p.y*256+p.x); }
};
inline std::vector<std::byte> memory(256);
inline int writes=0,fail_writes=0,fail_index=-1;
struct draft_memory_buffer {
    std::vector<std::byte> bytes;
    draft_memory_buffer():bytes(memory){}
    explicit draft_memory_buffer(std::vector<std::byte> b):bytes(std::move(b)){}
    std::size_t size() const { return bytes.size(); }
    const std::byte* data() const { return bytes.data(); }
    const std::byte& operator[](std::size_t i) const {
        if (static_cast<int>(i)==fail_index) throw std::out_of_range("injected read");
        return bytes.at(i);
    }
    draft_memory_buffer& operator=(std::span<const std::byte> s) {
        ++writes;
        if (fail_writes>0) { --fail_writes; throw std::runtime_error("submit"); }
        for(std::size_t i=0;i<std::min(s.size(),memory.size());++i) memory[i]=s[i];
        return *this;
    }
};
}
#define P_DP_BANK 1
#define P_DP_WARDS 1
#define P_UNI_PATH 45
#include "draft_plan.h"
int checks=0;
void check(bool yes,const char* why) { ++checks; if(!yes) { std::fprintf(stderr,"FAIL %s\n",why); std::exit(1); } }
void reset() {
    fuel=1000000; errors=queries=fields=fail_field=0; fuel_drop=false; fail_query.clear();
    bc::map::W=bc::map::H=20; bc::draft::TS=5;
    bc::map::walls_v={}; bc::map::holes_v={};
    bc::map::altars_v={{{10,10}},"altar_positions"};
    bc::map::bushes_v={{{7,7},{13,13},{8,7}},"bush_positions"};
    bc::map::ally_v={{{0,0}},"ally_positions"}; bc::map::enemy_v={{{19,19}},"enemy_positions"};
    bc::memory.assign(256,std::byte{0}); bc::writes=bc::fail_writes=0; bc::fail_index=-1;
    draftplan::packet.fill(std::byte{0}); draftplan::R={}; draftplan::prepared=false;
#if P_DP_MEMORY_FIX
    draftplan::preparation=draftplan::Preparation::fresh;
#endif
}
std::array<std::byte,256> make_packet() {
    std::array<std::byte,256> p{};
    p[0]=std::byte{'C'}; p[1]=std::byte{'M'}; p[2]=std::byte{'B'}; p[3]=std::byte{'1'};
    p[24]=std::byte{12}; p[25]=std::byte{54}; p[26]=std::byte{29}; p[27]=std::byte{90}; p[28]=std::byte{4};
    draftplan::copy_to(p); return p;
}
bc::draft_memory_buffer dm_of(const std::array<std::byte,256>& p,std::size_t n=256) {
    std::vector<std::byte> b(p.begin(),p.end()); b.resize(n); return bc::draft_memory_buffer(b);
}
int memory_regression() {
    reset(); auto good=make_packet();
    draftplan::load(dm_of(good)); check(draftplan::R.valid,"normal round trip");
    check(draftplan::R.ward[0]==vec2(8,7),"original first anchor score retained");
#if P_DP_ANCHOR_FIX
    check(draftplan::R.ward[1]==vec2(13,13)&&dist(draftplan::R.ward[0],draftplan::R.ward[1])>=6,"enabled fix spaces second anchor");
#else
    check(draftplan::R.ward[1]==vec2(7,7)&&dist(draftplan::R.ward[0],draftplan::R.ward[1])<6,"disabled fix retains original promotion behavior");
#endif
    std::printf("GEOMETRY path=%d open=%d flags=%d altar=%d,%d,%d,%d ward=%d:%d,%d:%d,%d quiet=%d penalty=%d\n",
        draftplan::R.path,draftplan::R.open,draftplan::R.flags,draftplan::R.altar[0].x,draftplan::R.altar[0].y,
        draftplan::R.altar[0].da,draftplan::R.altar[0].db,draftplan::R.ward_n,draftplan::R.ward[0].x,
        draftplan::R.ward[0].y,draftplan::R.ward[1].x,draftplan::R.ward[1].y,draftplan::quiet_bag(),draftplan::altar_penalty({10,10}));
    for(int i=0;i<32;++i) check(good[i]==(i==0?std::byte{'C'}:i==1?std::byte{'M'}:i==2?std::byte{'B'}:
        i==3?std::byte{'1'}:i==24?std::byte{12}:i==25?std::byte{54}:i==26?std::byte{29}:i==27?std::byte{90}:
        i==28?std::byte{4}:std::byte{0}),"legacy prefix preserved");
#if P_DP_MEMORY_FIX
    check(good[35]==std::byte{2} && good[55]==std::byte{3},"version and complete ready markers");
    const auto legacy=draftplan::read_legacy_settings(dm_of(good));
    check(legacy.tribute==12&&legacy.recall==54&&legacy.flee==29&&legacy.late==900&&legacy.family==4,"legacy settings actual helper");
    for (auto n : {0,32,80,81,223,255}) {
        draftplan::R.valid=true; draftplan::load(dm_of(good,n)); check(!draftplan::R.valid,"short packet resets runtime");
    }
    for(auto n : {256,300}) { draftplan::load(dm_of(good,n)); check(draftplan::R.valid,"supported larger capacity"); }
    for (auto [o,v] : std::vector<std::pair<int,int>>{{32,0},{35,1},{35,3},{55,0},{55,7},{36,21},{38,4},
        {39,2},{45,25},{54,3},{50,250},{80,9},{84,99},{85,1},{46,9},{44,128}}) {
        auto bad=good; bad[o]=static_cast<std::byte>(v); draftplan::R.valid=true;
        draftplan::load(dm_of(bad)); check(!draftplan::R.valid,"invalid packet resets all runtime");
        const auto l=draftplan::read_legacy_settings(dm_of(bad)); check(l.tribute==12&&l.late==900,"bad planner preserves legacy");
    }
    draftplan::Runtime untouched; untouched.w=77;
    auto bad=good; bad[35]=std::byte{1}; check(!draftplan::decode(dm_of(bad),untouched)&&untouched.w==77,"decode output atomic");
    bc::fail_index=80; draftplan::R.valid=true; draftplan::load(dm_of(good));
    check(!draftplan::R.valid,"thrown decode resets runtime");
    check(draftplan::read_legacy_settings(dm_of(good)).tribute==12,"thrown planner read cannot suppress legacy"); bc::fail_index=-1;
    for(const char* stage : {"width","spawn","altar_positions","bush_positions"}) {
        reset(); fail_query=stage; auto p=make_packet(); check(p[32]==std::byte{0},"query failure no packet magic");
        check(draftplan::preparation==draftplan::Preparation::unavailable,"failure status is not ready");
        const int q=queries; make_packet(); check(queries==q,"failed expensive preparation does not repeat");
    }
    reset(); fail_field=2; check(make_packet()[32]==std::byte{0},"second field failure atomic");
    reset(); fuel=65999; auto p=make_packet(); check(queries==0&&p[32]==std::byte{0},"low fuel refuses before geometry");
    check(draftplan::preparation==draftplan::Preparation::deferred,"low fuel status deferred");
    fuel=1000000; p=make_packet(); check(p[32]==std::byte{'D'},"recovered budget may prepare");
    reset(); fuel_drop=true; check(make_packet()[32]==std::byte{0}&&fields==1,"stage budget stops before second field");
    reset(); bc::map::bushes_v.tiles.clear(); p=make_packet(); draftplan::load(dm_of(p));
    check(draftplan::R.valid&&draftplan::R.ward_n==0&&!draftplan::use_ward_plan(),"completed empty anchors use original ward fallback");
    reset(); bc::map::W=256; check(make_packet()[32]==std::byte{0},"unsupported width no truncation");
    reset(); for(int i=0;i<25;++i) bc::map::altars_v.set({i%20,i/20});
    check(make_packet()[32]==std::byte{0},"too many altars no partial ranking");
    reset(); bc::memory.assign(good.begin(),good.end()); bc::fail_writes=1;
    p=good; p[24]=std::byte{22};
    check(draftplan::submit_plan(p)&&bc::writes==2,"full submission failure retries legacy prefix");
    check(bc::memory[24]==std::byte{22}&&bc::memory[32]==std::byte{0}&&bc::memory[35]==std::byte{0},"fallback clears retained magic");
    check(bc::memory[80]==good[80],"fallback mock preserves unwritten tail");
    draftplan::load(bc::draft_memory_buffer()); check(!draftplan::R.valid,"retained payload cannot reactivate");
    check(draftplan::read_legacy_settings(bc::draft_memory_buffer()).tribute==22,"fallback still loads updated legacy");
    reset(); bc::memory.assign(good.begin(),good.end()); bc::fail_writes=2;
    check(!draftplan::submit_plan(p)&&bc::writes==2&&bc::memory[32]==std::byte{'D'},"double failure reports failure without claiming invalidation");
    for(auto cap : {28,32,35,36,81,255}) {
        reset(); bc::memory.assign(cap,std::byte{99}); check(draftplan::submit_plan(good),"short capacity legacy write");
        check(bc::memory[24]==std::byte{12},"short capacity preserves legacy");
        draftplan::load(bc::draft_memory_buffer()); check(!draftplan::R.valid,"short capacity never planner");
    }
#else
    check(good[35]==std::byte{1}&&good[55]==std::byte{0},"disabled memory fix retains original packet format");
#endif
    // Exact promotion-bug witness: best arrives last adjacent to the former first.
    std::vector<vec2> bushes{{3,3},{12,12},{4,3}};
    auto score=[](vec2 p) { return p==vec2(4,3)?1:p==vec2(3,3)?2:3; };
    vec2 wp[2]; check(draftplan::spaced_anchors(bushes,score,wp)==2&&wp[0]==vec2(4,3)&&wp[1]==vec2(12,12),"late adjacent best keeps distant second");
    std::reverse(bushes.begin(),bushes.end()); draftplan::spaced_anchors(bushes,score,wp);
    check(wp[0]==vec2(4,3)&&wp[1]==vec2(12,12),"anchor iteration order independent");
    bushes={{3,3},{4,3}}; check(draftplan::spaced_anchors(bushes,score,wp)==1&&wp[1].x==-1,"one separated anchor only");
    bushes.clear(); check(draftplan::spaced_anchors(bushes,score,wp)==0,"no anchors");
    bushes={{12,12},{2,2},{2,1}}; draftplan::spaced_anchors(bushes,[](vec2){return 1;},wp);
    check(wp[0]==vec2(12,12)&&wp[1]==vec2(2,2),"equal scores preserve first SDK enumeration for both anchors");
    std::reverse(bushes.begin(),bushes.end()); draftplan::spaced_anchors(bushes,[](vec2){return 1;},wp);
    check(wp[0]==vec2(2,1)&&wp[1]==vec2(12,12),"reversed enumeration follows original first-equal-score rule");
    reset(); bc::map::bushes_v.tiles={{8,7},{7,8},{14,13},{13,14}};
    auto tied=make_packet(); draftplan::load(dm_of(tied));
    check(draftplan::R.valid&&draftplan::R.ward[0]==vec2(8,7),"actual prepare first tied anchor matches baseline enumeration");
    check(draftplan::R.ward[1]==vec2(14,13),"actual prepare second tied eligible anchor stable");
    reset(); bc::map::bushes_v.tiles={{7,8},{8,7},{13,14},{14,13}};
    tied=make_packet(); draftplan::load(dm_of(tied));
    check(draftplan::R.valid&&draftplan::R.ward[0]==vec2(7,8),"actual prepare honors first SDK tile instead of lexical coordinate");
    check(draftplan::R.ward[1]==vec2(13,14),"actual prepare reverses eligible tie with SDK enumeration");
    bushes={{0,0},{7,7}}; draftplan::spaced_anchors(bushes,[](vec2){return 1;},wp);
    check(wp[0]==vec2(0,0)&&wp[1]==vec2(7,7),"legitimate zero coordinate retained");
#if P_DP_MEMORY_FIX
    reset(); auto queued_good=make_packet();
    draftplan::load(dm_of(queued_good)); check(draftplan::R.valid,"queue baseline setup");
    auto original_dm=dm_of(queued_good); const int queue_queries=queries;
    draftplan::queue_load(original_dm);
    check(!draftplan::R.valid&&draftplan::memory_queued,"queue publishes no unvalidated state");
    check(queries==queue_queries&&bc::writes==0,"snapshot copy performs no engine calls or writes");
    original_dm.bytes[35]=std::byte{0};
    fuel=15999; const int waiting_queries=queries;
    check(!draftplan::finish_queued_load()&&!draftplan::R.valid&&draftplan::memory_queued,"low reserve keeps queued snapshot pending");
    check(queries==waiting_queries,"insufficient reserve does not start validation");
    fuel=1000000;
    check(draftplan::finish_queued_load()&&draftplan::R.valid&&!draftplan::memory_queued,"deferred owned snapshot validates fully");
    const int done_queries=queries;
    check(!draftplan::finish_queued_load()&&queries==done_queries,"completed validation is not repeated");
    auto invalid=queued_good; invalid[55]=std::byte{0};draftplan::queue_load(dm_of(invalid));
    check(draftplan::finish_queued_load()&&!draftplan::R.valid&&!draftplan::memory_queued,"invalid deferred payload rejected atomically");
    draftplan::queue_load(dm_of(queued_good,255));
    check(!draftplan::R.valid&&!draftplan::memory_queued&&!draftplan::finish_queued_load(),"short packet never queued");
#endif
    std::printf("PASS checks=%d memory=%d anchor=%d\n",checks,P_DP_MEMORY_FIX,P_DP_ANCHOR_FIX);
    return 0;
}


namespace bc {
struct SharedMemoryMock {
    std::array<std::byte,8> storage{};
    int reads=0,writes=0;
    void read(std::size_t off,std::span<std::byte> out) { ++reads; if(off+out.size()>8)throw std::out_of_range("shared read");std::copy_n(storage.data()+off,out.size(),out.data()); }
    void write(std::size_t off,std::span<const std::byte> in) { ++writes;if(off+in.size()>8)throw std::out_of_range("shared write");std::copy(in.begin(),in.end(),storage.begin()+off); }
};
inline SharedMemoryMock shared_memory;
}
struct State { int roster=5,ally_idx=0;std::vector<int> groups=std::vector<int>(63); };
#define P_CALLHELP 0

constexpr int SM_CLAIMS = 5;
constexpr int SM_ALERT_LO = 4;
constexpr int SM_BC_GROUP = 5, SM_BC_READY = 6;
constexpr int SM_ALERT_HI = 7;

#ifndef P_D5_PACKED_CLAIMS
#define P_D5_PACKED_CLAIMS 0
#endif
#ifndef P_DP_ALERTS
#define P_DP_ALERTS 0
#endif
#ifndef P_DP_ALERT_SINGLE_AGE
#define P_DP_ALERT_SINGLE_AGE 1
#endif
#ifndef P_DP_ALERT_GROUP_AGE
#define P_DP_ALERT_GROUP_AGE 2
#endif
#ifndef P_DP_ALERT_R
#define P_DP_ALERT_R 5
#endif
#ifndef P_DP_ALERT_SELF_R
#define P_DP_ALERT_SELF_R 8
#endif
#ifndef P_DP_ALERT_GEMS
#define P_DP_ALERT_GEMS 15
#endif
#ifndef P_DP_ALERT_PREY_HP
#define P_DP_ALERT_PREY_HP 60
#endif
#ifndef P_DP_ALERT_POWER
#define P_DP_ALERT_POWER 170
#endif

inline bool packed_claims(const State& s) {
    // 1..5 bodies fit in bytes0..3, six need bytes0..4 as in original Mate.
    // Groups >63 retain the baseline one-byte-per-champion fallback.
    return P_D5_PACKED_CLAIMS && s.roster >= 1 && s.roster <= 6 && s.groups.size() <= 63;
}
inline int claim_slots(const State& s) { return packed_claims(s) ? s.roster : SM_CLAIMS; }
inline bool shared_alert_memory(const State& s) {
    // Byte4 belongs to the sixth claim on six-body rosters, not to alerts.
    return P_DP_ALERTS && packed_claims(s) && s.roster <= 5 &&
           !P_CALLHELP && !P_PVKITE && draftplan::R.valid;
}

// Encoded claim value:0=none,1..63=group+1. No cooldown/danger byte is read.
inline std::uint8_t claim_value(const State& s, const std::array<std::uint8_t, 8>& sm, int body) {
    if (body < 0 || body >= claim_slots(s)) return 0;
    if (!packed_claims(s)) return sm[body];
    const int bit = body * 6, byte = bit / 8, shift = bit % 8;
    const unsigned word = static_cast<unsigned>(sm[byte]) | (static_cast<unsigned>(sm[byte + 1]) << 8);
    return static_cast<std::uint8_t>((word >> shift) & 63u);
}

std::array<std::uint8_t, 8> read_sm() {
    std::array<std::byte, 8> raw{};
    attempt([&] {
        bc::shared_memory.read(0, std::span<std::byte>(raw.data(), raw.size()));
        return true;
    });
    std::array<std::uint8_t, 8> out{};
    for (int i = 0; i < 8; ++i) out[i] = std::to_integer<std::uint8_t>(raw[i]);
    return out;
}

void write_sm(std::size_t off, std::uint8_t v) {
    std::byte b = static_cast<std::byte>(v);
    attempt([&] {
        bc::shared_memory.write(off, std::span<const std::byte>(&b, 1));
        return true;
    });
}


enum SharedAlertClass {
    SA_NONE = 0,
    SA_SINGLE_INFO = 1,       // one ordinary enemy: information, almost no avoidance
    SA_SINGLE_THREAT = 2,     // healthy / high-stat single
    SA_SINGLE_CARRIER = 3,    // valuable bag, but not vulnerable
    SA_SINGLE_PREY = 4,       // low HP and/or valuable vulnerable carrier
    SA_DUO_INFO = 5,
    SA_DUO_THREAT = 6,
    SA_DUO_CARRIER = 7,
    SA_PACK = 8,              // 3+ enemies
    SA_PACK_CARRIER = 9,
    SA_CRITICAL = 10          // 3+ healthy/high-power enemies nearby
};

struct SharedAlert {
    bool valid = false;
    vec2 p{0,0};
    int kind = 0, age = 99, round = -1000;
};

inline int alert_q(int v, int size) {
    if (size <= 1) return 0;
    return std::clamp((v * 16) / size, 0, 15);
}
inline int alert_u(int q, int size) {
    if (size <= 1) return 0;
    return std::clamp((q * size + size / 2) / 16, 0, size - 1);
}
inline bool alert_group(int kind) { return kind >= SA_DUO_INFO; }
inline bool alert_pack(int kind) { return kind >= SA_PACK; }
inline bool alert_prey(int kind) { return kind == SA_SINGLE_PREY; }
inline int alert_max_age(int kind) {
    return alert_group(kind) ? P_DP_ALERT_GROUP_AGE : P_DP_ALERT_SINGLE_AGE;
}
inline int alert_priority(int kind) {
    switch (kind) {
    case SA_CRITICAL: return 10;
    case SA_PACK: return 9;
    case SA_PACK_CARRIER: return 8;
    case SA_DUO_THREAT: return 7;
    case SA_DUO_INFO: return 6;
    case SA_DUO_CARRIER: return 5;
    case SA_SINGLE_THREAT: return 4;
    case SA_SINGLE_INFO: return 3;
    case SA_SINGLE_CARRIER: return 2;
    case SA_SINGLE_PREY: return 1;
    default: return 0;
    }
}

SharedAlert read_shared_alert(const State& s, int round, const std::array<std::uint8_t,8>* cached=nullptr) {
    SharedAlert a;
    if (!shared_alert_memory(s)) return a;
    const auto sm = cached ? *cached : read_sm();
    const std::uint16_t w = static_cast<std::uint16_t>(sm[SM_ALERT_LO]) |
                            (static_cast<std::uint16_t>(sm[SM_ALERT_HI]) << 8);
    const int kind = (w >> 8) & 15;
    if (!kind) return a;
    const int stamp = (w >> 12) & 15;
    const int age = ((round & 15) - stamp) & 15;
    if (age > alert_max_age(kind)) return a;
    const int qx = w & 15, qy = (w >> 4) & 15;
    a.valid = true; a.kind = kind; a.age = age; a.round = round - age;
    a.p = vec2(alert_u(qx, draftplan::R.w), alert_u(qy, draftplan::R.h));
    return a;
}

void write_shared_alert(const State& s, vec2 p, int kind, int round) {
    if (!shared_alert_memory(s) || kind < 1 || kind > 15) return;
    auto sm = read_sm();
    SharedAlert old = read_shared_alert(s, round, &sm);
    // Never let a low-value single overwrite a same-round group warning.  A
    // fresher packet may replace an older one; same-class alerts prefer nearer
    // information only through the normal last-writer order.
    if (old.valid && old.age == 0 && alert_priority(old.kind) > alert_priority(kind)) return;
    const std::uint16_t w = static_cast<std::uint16_t>(alert_q(p.x, draftplan::R.w)) |
                            (static_cast<std::uint16_t>(alert_q(p.y, draftplan::R.h)) << 4) |
                            (static_cast<std::uint16_t>(kind) << 8) |
                            (static_cast<std::uint16_t>(round & 15) << 12);
    write_sm(SM_ALERT_LO, static_cast<std::uint8_t>(w & 255));
    write_sm(SM_ALERT_HI, static_cast<std::uint8_t>((w >> 8) & 255));
}


void write_claim(State& s, int group) {
    if (s.ally_idx < 0 || s.ally_idx >= claim_slots(s)) return;
    if (!packed_claims(s)) {
        write_sm(static_cast<std::size_t>(s.ally_idx), static_cast<std::uint8_t>(group + 1));
        return;
    }
    if (group < -1 || group >= static_cast<int>(s.groups.size())) return;
    // 1..5 bodies use 4 bytes; 6 use 5 bytes, preserving the original 6th
    // claim. Never overwrite byte4 with a claim when shared alerts are active.
    if (!fuel_ok(2000)) return;
    const std::size_t claim_bytes = (s.roster == 6 ? 5 : 4);
    std::array<std::byte, 5> raw{};
    if (!attempt([&] {
            bc::shared_memory.read(0, std::span<std::byte>(raw.data(), claim_bytes));
            return true;
        })) return;
    std::uint64_t word = 0;
    for (std::size_t i = 0; i < claim_bytes; ++i)
        word |= static_cast<std::uint64_t>(std::to_integer<std::uint8_t>(raw[i])) << (i * 8);
    const int shift = s.ally_idx * 6;
    const std::uint64_t mask = std::uint64_t{63} << shift;
    word = (word & ~mask) | (static_cast<std::uint64_t>(group + 1) << shift);
    for (std::size_t i = 0; i < claim_bytes; ++i)
        raw[i] = static_cast<std::byte>((word >> (i * 8)) & 255u);
    attempt([&] {
        bc::shared_memory.write(0, std::span<const std::byte>(raw.data(), claim_bytes));
        return true;
    });
}

int alert_protocol_regression(){
    draftplan::R.valid=true;draftplan::R.w=20;draftplan::R.h=20;
    for(int n=1;n<=6;++n){
        State s;s.roster=n;
        bc::shared_memory={};bc::shared_memory.storage[5]=std::byte{77};bc::shared_memory.storage[6]=std::byte{88};bc::shared_memory.storage[7]=std::byte{99};
        for(int k=0;k<n;++k){s.ally_idx=k;write_claim(s,k+1);}
        auto before=read_sm();
        for(int k=0;k<n;++k)check(claim_value(s,before,k)==k+2,"all packed claims round trip");
        const int writes=bc::shared_memory.writes;
        write_shared_alert(s,{11,14},SA_PACK,17);
        auto after=read_sm();
        for(int k=0;k<n;++k)check(claim_value(s,after,k)==k+2,"alert never modifies any physical-body claim");
        check(after[5]==77&&after[6]==88,"alerts preserve lifecycle bytes");
        if(n<=5){
            check(bc::shared_memory.writes==writes+2,"alert writes exactly its two bytes");
            auto alert=read_shared_alert(s,17);check(alert.valid&&alert.kind==SA_PACK&&alert.age==0,"current alert round trip");
            check(read_shared_alert(s,19).valid&&!read_shared_alert(s,20).valid,"group expiration retained");
            for(int k=0;k<n;++k){s.ally_idx=k;write_claim(s,62);auto updated=read_sm();check(updated[4]==after[4]&&updated[7]==after[7],"claim updates preserve both alert bytes");}
        }else{
            check(bc::shared_memory.writes==writes&&after==before,"six-body alerts disabled with sixth claim preserved");
            check(!read_shared_alert(s,17).valid,"six-body receiver does not parse claim as alert");
            s.ally_idx=5;write_claim(s,62);check(claim_value(s,read_sm(),5)==63,"sixth claim supports max group");
        }
    }
#if P_DP_MEMORY_FIX
    reset();auto p=make_packet();const auto legacy=draftplan::read_legacy_settings(dm_of(p));
    draftplan::queue_load(dm_of(p));State s;auto before=bc::shared_memory.storage;const int writes=bc::shared_memory.writes;
    check(legacy.tribute==12&&legacy.recall==54&&legacy.flee==29&&legacy.late==900,"queued optional cache preserves immediate legacy settings");
    write_shared_alert(s,{11,14},SA_PACK,17);
    check(bc::shared_memory.writes==writes&&bc::shared_memory.storage==before,"pending cache does not publish alerts with unvalidated geometry");
    fuel=1000000;check(draftplan::finish_queued_load()&&draftplan::R.valid,"complete cache enables validated geometry");
    write_shared_alert(s,{11,14},SA_PACK,18);check(bc::shared_memory.writes==writes+2,"alerts enabled after deferred validation");
#endif
    std::printf("PASS V59 production alert/claim byte separation and deferred integration\n");return 0;
}
int main(){memory_regression();alert_protocol_regression();}
