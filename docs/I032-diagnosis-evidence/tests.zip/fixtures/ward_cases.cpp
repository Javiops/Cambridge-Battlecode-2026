
int main(){State s;int checks=0;
 reset();assert(cf_all_passing_wards(s));assert(fixture::placed==std::vector<vec2>({{18,22}}));assert(fixture::all_roster_reads==0&&fixture::forbidden_nonself_reads==0&&fixture::self_reads==1);checks++;
 reset();bc::vision::world={{{14,22},0,true}};assert(cf_all_passing_wards(s));assert(fixture::placed==std::vector<vec2>({{22,22}}));assert(fixture::ward_scans==1&&fixture::last_side==0&&fixture::forbidden_nonself_reads==0);checks++;
 reset();bc::vision::world={{{14,22},1,true}};assert(cf_all_passing_wards(s));assert(fixture::placed==std::vector<vec2>({{18,22}}));checks++;
 reset();bc::vision::world={{{14,22},0,false}};assert(cf_all_passing_wards(s));assert(fixture::placed==std::vector<vec2>({{18,22}}));checks++;
 reset();fixture::own_ward=true;assert(!cf_all_passing_wards(s));assert(fixture::ward_scans==0&&fixture::placed.empty()&&fixture::self_reads==1);checks++;
 reset();fixture::fuel=17000;bc::vision::world={{{14,22},0,true}};assert(cf_all_passing_wards(s));assert(fixture::ward_scans==0&&fixture::placed==std::vector<vec2>({{18,22}}));checks++;
 reset();bc::vision::world={{{14,22},0,true}};assert(old_cf_all_passing_wards(s));assert(fixture::placed==std::vector<vec2>({{18,22}}));assert(fixture::all_roster_reads==1&&fixture::forbidden_nonself_reads==2);checks++;
 std::printf("PASS %d actual-source ward API contract/spacing cases\n",checks);
}
