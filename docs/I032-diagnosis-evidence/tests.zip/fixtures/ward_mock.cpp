
#include <vector>
#include <array>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cassert>
#include <stdexcept>
struct vec2 { int x=0,y=0; vec2()=default;vec2(int a,int b):x(a),y(b){} bool operator==(const vec2&)const=default;vec2 operator+(vec2 b)const{return{x+b.x,y+b.y};}};
int dist(vec2 a,vec2 b){return std::max(std::abs(a.x-b.x),std::abs(a.y-b.y));}
struct Mask{std::vector<vec2> tiles;bool is_set(vec2 p)const{return std::find(tiles.begin(),tiles.end(),p)!=tiles.end();}};
namespace fixture {inline int round=10,fuel=30000,all_roster_reads=0,forbidden_nonself_reads=0,self_reads=0,ward_scans=0,last_side=-1;inline std::vector<vec2> placed;inline bool own_ward=false;}
bool fuel_ok(int need){return fixture::fuel>need;}
template<class F>bool attempt(F f){try{return f();}catch(...){return false;}}
namespace bc {
namespace constants{constexpr int ward_placement_radius=2,ward_vision_radius=5;}
enum class buff_restrictions{ward};struct Restrictions{bool contains(buff_restrictions)const{return false;}};
struct champion{
 int id=0;bool operator==(const champion&)const=default;bool is_alive()const{return true;}bool is_recalling()const{return false;}bool is_submitting_gems()const{return false;}bool is_teleporting()const{return false;}int ward_cooldown()const{return 0;}Restrictions restrictions()const{return{};}
 std::vector<vec2> ward_positions()const{if(id!=0){++fixture::forbidden_nonself_reads;throw std::runtime_error("self-only SDK API");}++fixture::self_reads;return fixture::own_ward?std::vector<vec2>{{5,5}}:std::vector<vec2>{};}
 vec2 position()const{return {20,20};} bool place_ward(vec2 p){fixture::placed.push_back(p);return true;}
};
inline champion own;champion& self(){return own;}int round_number(){return fixture::round;}
std::vector<champion> champions(int){++fixture::all_roster_reads;return{{0},{1},{2}};}
namespace map{inline Mask bush;const Mask& bushes(){return bush;}bool is_in_bounds(vec2 p){return p.x>=0&&p.x<50&&p.y>=0&&p.y<50;}}
struct ward {vec2 p;int side=0;bool visible=true;vec2 position()const{return p;}};
namespace vision{inline std::vector<ward> world;std::vector<ward> wards(int side){++fixture::ward_scans;fixture::last_side=side;std::vector<ward> r;for(auto w:world)if(w.side==side&&w.visible)r.push_back(w);return r;}bool has_champion(vec2){return false;}bool has_camp(vec2){return false;}bool has_teleport(vec2){return false;}bool has_ward(vec2,int){return false;}}
}
namespace draftplan{constexpr int F_CENTRAL_ALTAR=16;struct Runtime{bool valid=false;int flags=0;vec2 central;};inline Runtime R;}
struct Group{vec2 center;};inline int ally=0;
struct State{bool ready=true;int* my=&ally;int ally_idx=0;vec2 spawn_center{0,20},en_center{40,20};Mask static_block,my_spawn,en_spawn;std::vector<vec2> altars{{20,20}};int target=-1;std::vector<Group> groups;};
#ifndef P_CF_WARD_EVENT_LOG
#define P_CF_WARD_EVENT_LOG 0
#endif
void reset(){fixture::round+=10;fixture::fuel=30000;fixture::all_roster_reads=fixture::forbidden_nonself_reads=fixture::self_reads=fixture::ward_scans=0;fixture::last_side=-1;fixture::placed.clear();fixture::own_ward=false;bc::vision::world.clear();bc::map::bush.tiles={{18,22},{22,22}};}
