"""Portable actual-source mechanism checks; never runs a match or changes --src.
Requires Python wasmtime49 and an exception-enabled WASI SDK33 toolchain.
"""
from pathlib import Path
import argparse,hashlib,itertools,json,re,shutil,subprocess,sys
HERE=Path(__file__).resolve().parent

def extract(source,name):
 m=re.search(r'^(?:inline\s+)?[\w:<>]+\s+'+re.escape(name)+r'\s*\(',source,re.M)
 if not m:raise ValueError('Missing production function '+name)
 start=m.start();i=source.index('{',m.end());depth=0;state='code'
 while i<len(source):
  c=source[i];n=source[i:i+2]
  if state=='line':
   if c=='\n':state='code'
  elif state=='block':
   if n=='*/':state='code';i+=1
  elif state in ('"',"'"):
   if c=='\\':i+=1
   elif c==state:state='code'
  elif n=='//':state='line';i+=1
  elif n=='/*':state='block';i+=1
  elif c in ('"',"'"):state=c
  elif c=='{':depth+=1
  elif c=='}':
   depth-=1
   if depth==0:return source[start:i+1]
  i+=1
 raise ValueError('Unclosed function '+name)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--src',type=Path,required=True);ap.add_argument('--sdk',type=Path,required=True);ap.add_argument('--compiler',type=Path,required=True);ap.add_argument('--wasmtime-pythonlib',type=Path);ap.add_argument('--out-dir',type=Path,default=HERE/'build');args=ap.parse_args()
 if args.wasmtime_pythonlib:sys.path.insert(0,str(args.wasmtime_pythonlib.resolve()))
 import wasmtime
 src=args.src.resolve();sdk=args.sdk.resolve();compiler=args.compiler.resolve();out=args.out_dir.resolve();out.mkdir(parents=True,exist_ok=True)
 assert not out.is_relative_to(src),'Build output must stay outside source'
 initial={p.name:sha(p)for p in src.iterdir()if p.is_file()};maincpp=(src/'main.cpp').read_text();utility=(src/'utility.h').read_text();wasi=compiler.parent.parent;lib=wasi/'share/wasi-sysroot/lib/wasm32-wasip1/eh'
 base=[str(compiler),'--target=wasm32-wasip1','-std=c++20','-fwasm-exceptions','-mllvm','-wasm-use-legacy-eh=false','-msimd128','-mbulk-memory','-isystem',str(wasi/'share/wasi-sysroot/include/wasm32-wasip1/eh/c++/v1')]
 def run(cmd,label):
  p=subprocess.run(cmd,capture_output=True,text=True,timeout=180);(out/(label+'.log')).write_text(p.stdout+p.stderr)
  if p.returncode:raise RuntimeError(label+' failed: '+p.stderr)
 run(base+['-O0','-I',str(sdk),'-c',str(src/'main.cpp'),'-o',str(out/'production.o')],'full-production')
 call=subprocess.run([sys.executable,str(HERE/'check_approach_callsite.py'),str(src),'--report',str(out/'callsite.json')],capture_output=True,text=True);assert call.returncode==0,call.stderr
 fixtures=HERE/'fixtures';jobs=[]
 # Current actual ward helper, plus frozen original as an explicitly labelled comparison.
 ward='\n'.join([(fixtures/'ward_mock.cpp').read_text(),extract(utility,'cf_all_passing_wards'),(fixtures/'old_ward.cpp').read_text(),(fixtures/'ward_cases.cpp').read_text()]);jobs.append(('ward-api',ward,src,[]))
 # Preserve the narrow mock/cases but replace its helper with current source.
 approach=(fixtures/'approach.cpp').read_text();approach=approach.replace(extract(approach,'cf_remote_approach'),extract(maincpp,'cf_remote_approach'));jobs.append(('camp-approach',approach,src,[]))
 # The actual final preference/order block is injected into catalogue fixtures.
 start=maincpp.index('    draftchoice::replace_prism(prefs);');end=maincpp.index('\n\n    std::printf("[draft] %zu champions found:',start);order=maincpp[start:end]
 for flag in (0,1,2):jobs.append(('draft-swap-'+str(flag),(fixtures/'draft_cases.cpp').read_text().replace('// ACTUAL_ORDER_BLOCK',order),src,['-DP_DP_PRISM_SWAP='+str(flag)]))
 # Current actual protocol region and writer; current header supplies cache algorithms.
 mem=(fixtures/'memory.cpp').read_text();begin='constexpr int SM_CLAIMS = 5;';finish='inline double alert_unit_power(';region=maincpp[maincpp.index(begin):maincpp.index(finish)];mem=mem[:mem.index(begin)]+region+'\n'+extract(maincpp,'write_claim')+'\n'+mem[mem.index('int alert_protocol_regression()'):]
 for cache,anchor in itertools.product((0,1),repeat=2):
  folder=out/('headers-'+str(cache)+str(anchor));folder.mkdir(exist_ok=True)
  for p in src.iterdir():
   if p.is_file():shutil.copy2(p,folder/p.name)
  params=(folder/'params.h').read_text()
  for name,value in [('P_DP_MEMORY_FIX',cache),('P_DP_ANCHOR_FIX',anchor)]:
   params,n=re.subn(r'(?m)^(#define '+name+r')\s+[^\r\n]+',lambda m:m[1]+' '+str(value),params);assert n==1,name
  (folder/'params.h').write_text(params)
  jobs.append(('memory-alerts-'+str(cache)+str(anchor),mem,folder,[]))
 cfg=wasmtime.Config();cfg.wasm_exceptions=True;engine=wasmtime.Engine(cfg);results=[]
 for label,text,include,flags in jobs:
  cpp=out/(label+'.cpp');cpp.write_text(text);module=out/(label+'.wasm');run(base+['-O1','-I',str(include),'-L',str(lib),*flags,str(cpp),'-lunwind','-Wl,-z,stack-size=4194304','-o',str(module)],label)
  store=wasmtime.Store(engine);wc=wasmtime.WasiConfig();wc.stdout_file=str(out/(label+'.stdout'));wc.stderr_file=str(out/(label+'.stderr'));store.set_wasi(wc);link=wasmtime.Linker(engine);link.define_wasi();ins=link.instantiate(store,wasmtime.Module.from_file(engine,str(module)));ins.exports(store)['_start'](store);stdout=(out/(label+'.stdout')).read_text();stderr=(out/(label+'.stderr')).read_text();assert 'PASS'in stdout and not stderr,(label,stdout,stderr)
  results.append({'fixture':label,'status':'pass','fixture_sha256':sha(cpp),'wasm_sha256':sha(module),'stdout':stdout});print('PASS',label,flush=True)
 assert initial=={p.name:sha(p)for p in src.iterdir()if p.is_file()},'Production source changed during checks'
 report={'status':'pass','source_sha256':initial,'sdk_header_sha256':sha(sdk/'cambc.h'),'full_production_object_sha256':sha(out/'production.o'),'callsite':json.loads((out/'callsite.json').read_text()),'fixtures':results,'limits':['Full current production translation unit compiled once with its shipped flags; object compile is not a release link.','Nine fixture runs execute actual current helpers/order/protocol and cache headers with narrow mocks.','Mock bitboard/fuel behaviour does not measure native SDK costs or predict match strength.','Native opening and Monolith regression replays separately validate the two integration mechanisms.']};(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS all9 fixtures; source unchanged')
if __name__=='__main__':main()
