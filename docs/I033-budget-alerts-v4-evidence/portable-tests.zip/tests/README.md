# Portable v60 v4 mechanism tests (no-copy cohort view)

These tests exercise production protocol/functions and production cache headers with narrow SDK mocks. They also compile the complete supplied bot translation unit against the real C++ SDK. They run no games, access no network and leave the input source unchanged.

## Requirements and command

Use Python 3.10+, the Python `wasmtime` package with WebAssembly exception support, the Battlecode C++ SDK, and an exception-enabled WASI SDK (validated locally with WASI SDK 33 / Battlecode SDK 2.2.5).

```sh
python -m pip install -r tests/requirements.txt
python tests/run.py --source bots/team_baseline/src --sdk /path/to/cambc/sdk/cpp --compiler /path/to/wasi-sdk/bin/clang++ --report mechanisms.json
```

Replace the tool paths with your installation paths; on Windows use `clang++.exe`. `--source` accepts either `src/` or its parent bot directory. The runner detects the WASI SDK root from the compiler path; override with `--wasi-sdk` if needed. If using a bundled Python module directory, pass `--runtime-path /path/to/pythonlib` (alias `--wasmtime-pythonlib`). No private machine path is embedded in the package.

By default all four suites run. Select `--suite protocol`, `memo`, `budget` or `cohort` for a focused run. Outputs use a temporary directory unless `--build-dir` is supplied to retain generated fixtures, compiler logs and WASM. Put reports/build directories outside the bot source.

## What is covered

- **Protocol:** the actual final shared-memory region and complete `update_danger` function are extracted from `main.cpp`. Tests cover six-body full/compact layouts, every claim, lifecycle bytes, coordinates, timestamp freshness/wrap/gaps, failed/suspended reads and writes, feature-off behavior, and help/kite ownership. Four configurations were previously checked with 558 / 2,985 / 408 / 408 assertions.
- **Memo, gate and spawn:** all eight flag combinations run the same 504 `update_danger` calls (three roster sizes × seven enemy counts × twelve geometries × two rounds). Their complete observed alert/danger fields and shared-memory bytes must produce one identical semantic hash. Separate checks cover round changes, failed stat reads and cache lifetime. The portable matrix regenerates the **final six-body protocol** rather than assuming the historical pre-six-body packet hash remains valid.
- **Identity and budget fallback:** all four flag combinations use the actual immutable identity header and extracted `budget_back_off` helper. Checks cover identity queries/failures/sentinels, ordinary-budget fallthrough, low-budget retreat then attack, movement failure, hidden/stale targets, reset-body helper avoidance, and critical reserves.
- **Cohort:** both flags use the actual read-only allied roster cache. Checks cover order, live HP reads, invalidation, nesting, exceptions, round changes, list construction that crosses a round, zero champion copies, immutable move-only ranges, independent uncached ownership, and held ranges after invalidation or scope destruction. Static checks bind the final integration's eight selected ally reads, combat scope and four entry invalidators.

`bindings.json` records all 16 final source file hashes and normalized hashes for checkout newline differences, plus exact protocol/update/budget snippet hashes. The default command rejects unexpected source changes. To deliberately test a reviewed modification, use `--allow-source-changes`; functions are still extracted from the supplied source and safety fixtures still run.

## Evidence and limits

`recorded/` retains sanitized result summaries and original report hashes, including the earlier native six-body sharing audit. That native audit binds the unchanged alert protocol, not a fresh v4 native run. The v4 cohort fixture uses the new immutable owned/borrowed View; `v3-portable-validation.json` remains labeled historical evidence. Historical tests retain their original source hashes so they can be distinguished from the final integration. `recorded/portable-validation.json` records a run of this portable package against the final source.

The native audit observes six bodies sharing a full 16-bit alert on a ten-group map, while compact 12-bit layout behavior has fixture coverage. Six-body semantic alerts support **up to 63 camp groups**; at 64 or more groups the original nonpacked fallback has no semantic six-body alerts. Compact alerts intentionally coarsen coordinates/classes and do not prove exact enemy inventory.

These tests verify mechanisms and source binding. They do not measure native fuel, reproduce every SDK interaction, link a release executable, or prove competitive strength. Use the separately recorded paired-map validation for strength claims.

