
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <optional>
#include <memory>
#include <type_traits>
#include <stdexcept>
#include <vector>
#include "params.h"
inline int lists=0,metadata=0,fail_list=0,advance_list=0,copies=0,moves=0;
inline std::vector<int>visible{4,1,5};inline float hp[8]{0,100,200,300,400,500,600,700};
namespace bc {
enum class team {ally,enemy};inline int now=20;
std::uint32_t round_number(){return now;}
struct champion{
 int id=-1;champion()=default;champion(int i):id(i){}
 champion(const champion& c):id(c.id){++copies;}
 champion&operator=(const champion& c){id=c.id;++copies;return*this;}
 champion(champion&& c)noexcept:id(c.id){++moves;}
 champion&operator=(champion&& c)noexcept{id=c.id;++moves;return*this;}
 bool operator==(const champion&)const=default;float health()const{return hp[id];}
};
namespace vision {std::vector<champion> champions(team side){++lists;if(fail_list){--fail_list;throw std::runtime_error("query");}if(advance_list){--advance_list;++now;}std::vector<champion>out;out.reserve(visible.size());for(int i:visible){out.push_back({i});metadata+=2;}return out;}}
}
struct State{std::optional<bc::team>my=bc::team::ally;};

#include "combat_cohort.h"

void check(bool b,const char*why){if(!b){std::fprintf(stderr,"FAIL %s\n",why);std::exit(1);}}
template<class Range> std::vector<int>ids(const Range&v){std::vector<int>out;for(const auto&c:v)out.push_back(c.id);return out;}
int main(){
    State s;int readonly_lists=0;unsigned hash=0;
    using Range=decltype(combat_allies(s));static_assert(!std::is_copy_constructible_v<Range>);static_assert(std::is_same_v<decltype(*std::declval<Range&>().begin()),const bc::champion&>);
    {combatcohort::Scope scope(20);for(int k=0;k<5;++k){auto list=combat_allies(s);check(ids(list)==std::vector<int>({4,1,5}),"original iteration order");for(const auto&c:list)hash=hash*31+c.id;}readonly_lists=lists;check(copies==0,"first and repeated cache paths copy zero champion handles");hp[4]=123;check(combat_allies(s)[0].health()==123,"cached handle still reads live HP");
#if P_FUEL_COHORT
        check(readonly_lists==1,"one successful SDK list in read-only phase");
#else
        check(readonly_lists==5,"disabled mode keeps original SDK lists");
#endif
        combatcohort::invalidate();visible={5,2};int before=lists;check(ids(combat_allies(s))==visible,"first list after action is fresh");check(ids(combat_allies(s))==visible&&lists==before+2,"invalidated scope never re-caches");
    }
    check(combatcohort::active==nullptr,"scope restores on normal exit");int before=lists;combat_allies(s);combat_allies(s);check(lists==before+2,"no cache outside scope");
    {combatcohort::Scope outer(bc::now);combat_allies(s);{combatcohort::Scope inner(bc::now);combat_allies(s);combatcohort::invalidate();}before=lists;combat_allies(s);check(lists==before+1,"nested action also invalidates outer cache");}
    {combatcohort::Scope scope(bc::now);fail_list=1;bool threw=false;try{combat_allies(s);}catch(...){threw=true;}check(threw,"SDK error still propagates");before=lists;combat_allies(s);check(lists==before+1,"failed list was not published");}
    try{combatcohort::Scope scope(bc::now);combat_allies(s);throw std::runtime_error("scope");}catch(...){}check(combatcohort::active==nullptr,"scope restores after exception");
    {combatcohort::Scope scope(bc::now);combat_allies(s);++bc::now;visible={3,0,6};before=lists;check(ids(combat_allies(s))==visible,"round change refreshes list");combat_allies(s);check(lists==before+2,"round change disables remainder of scope");}
    {combatcohort::Scope scope(bc::now);advance_list=1;before=lists;combat_allies(s);combat_allies(s);check(lists==before+2,"suspended list construction is never published");}
    std::optional<Range> escaped;visible={4,1,5};
    {combatcohort::Scope scope(bc::now);escaped.emplace(combat_allies(s));combatcohort::invalidate();visible={0,2};auto fresh=combat_allies(s);check(ids(*escaped)==std::vector<int>({4,1,5})&&ids(fresh)==visible,"invalidating cannot replace an outstanding borrowed snapshot");}
    check(ids(*escaped)==std::vector<int>({4,1,5}),"borrowed snapshot lives after Scope destruction");auto moved=std::move(*escaped);escaped.reset();check(ids(moved)==std::vector<int>({4,1,5}),"moved view owns snapshot lifetime");
    auto owned=combat_allies(s);visible={7};auto other=combat_allies(s);check(ids(owned)==std::vector<int>({0,2})&&ids(other)==visible,"uncached view owns independent fresh vector");check(copies==0,"all tested view paths copy zero champion handles");
    std::printf("PASS readonly_hash=%u readonly_lists=%d metadata=%d copies=%d moves=%d\n",hash,readonly_lists,metadata,copies,moves);
}
