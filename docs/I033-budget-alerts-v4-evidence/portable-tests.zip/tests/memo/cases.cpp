
unsigned long long h=1469598103934665603ULL;
void hash_value(int v){h^=static_cast<unsigned>(v);h*=1099511628211ULL;}

void hash_state(const State&s){hash_value(s.danger_p.x);hash_value(s.danger_p.y);hash_value(s.danger_r);hash_value(s.alert_p.x);hash_value(s.alert_p.y);hash_value(s.alert_r);hash_value(s.alert_kind);hash_value(s.alert_raw);hash_value(s.alert_raw_r);hash_value(s.alert_observed_r);hash_value(s.alert_uncertainty);for(auto b:bc::shared_memory.data)hash_value(std::to_integer<int>(b));}
int main(){
    for(int roster:{3,5,6})for(int count=0;count<=6;++count)for(int geometry=0;geometry<12;++geometry){
        State s;s.roster=roster;s.groups.resize(12);draftplan::R={geometry%4!=0,50,50};fixture::round=50+geometry;bc::shared_memory.data.fill(std::byte{0});
        std::vector<Foe>foes;
        for(int i=0;i<count;++i){Foe f;f.p={geometry%3?10+(i%3)*(geometry%4):35+(i%2),10+(i/3)*3};f.hp=100+(i*173+geometry*53)%900;f.gems=(i*11+geometry*3)%35;f.c.str=40+i*23;f.c.foc=20+geometry*41;foes.push_back(f);}
        update_danger(s,foes,fixture::round);hash_state(s);
        ++fixture::round;update_danger(s,{},fixture::round);hash_state(s);
    }
    std::printf("SEMANTICS %llu stats=%d spawn=%d\n",h,(bc::hp_reads+bc::strength_reads+bc::focus_reads),spawn_queries);
#if P_FUEL_ALERT_MEMO
    Foe f;f.hp=600;fixture::round=100;double hp=0;
    const int initial=(bc::hp_reads+bc::strength_reads+bc::focus_reads);
    {alertfuel::Scope scope(100);const double a=alert_unit_power(f,hp);const int q=(bc::hp_reads+bc::strength_reads+bc::focus_reads);
        check(alert_unit_power(f,hp)==a&&(bc::hp_reads+bc::strength_reads+bc::focus_reads)==q,"same no-action reading reused");
        ++fixture::round;f.c.foc+=20;const double b=alert_unit_power(f,hp);check(b>a&&(bc::hp_reads+bc::strength_reads+bc::focus_reads)==q+3,"round change invalidates suspended reading");
    }
    f.c.foc+=20;const int outside=(bc::hp_reads+bc::strength_reads+bc::focus_reads);alert_unit_power(f,hp);check((bc::hp_reads+bc::strength_reads+bc::focus_reads)==outside+3,"no cache outside update scope");
    {alertfuel::Scope scope(fixture::round);bc::fail_stats=1;alert_unit_power(f,hp);const int q=(bc::hp_reads+bc::strength_reads+bc::focus_reads);alert_unit_power(f,hp);check((bc::hp_reads+bc::strength_reads+bc::focus_reads)==q+3,"failed reading is not cached");}
    check(alertfuel::active==nullptr&&(bc::hp_reads+bc::strength_reads+bc::focus_reads)>initial,"scope restored");
#endif
    std::puts("PASS actual update_danger semantics and scope/round/failure cases");
}
