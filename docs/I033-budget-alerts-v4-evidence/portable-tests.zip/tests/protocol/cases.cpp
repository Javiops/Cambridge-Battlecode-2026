
int main(){
 for(int n=1;n<=6;++n)for(int groups:{1,7,31,32,63,64}){
  reset();State s;s.roster=n;s.groups.resize(groups);write_sm(5,0xA9);write_sm(6,0xCE);
  const int slots=claim_slots(s);for(int k=0;k<slots;++k){s.ally_idx=k;write_claim(s,groups-1);}
  auto before=read_sm();for(int k=0;k<slots;++k)check(claim_value(s,before,k)==groups,"maximum group ID round trip");
  const bool enabled=shared_alert_memory(s);const int writes=fixture::writes;write_shared_alert(s,{89,70},SA_PACK,100);auto after=read_sm();
  for(int k=0;k<slots;++k)check(claim_value(s,after,k)==groups,"alert preserves every claim");
  check(after[5]==0xA9&&after[6]==0xCE,"alert preserves lifecycle");
  if(enabled){auto a=read_shared_alert(s,100);check(a.valid&&a.kind==SA_PACK,"current semantic alert round trip");check(read_shared_alert(s,102).valid&&!read_shared_alert(s,103).valid,"group age limits");check(fixture::writes-writes==(six_alert_layout(s)?1:2),"atomic six-body / original legacy write count");
   if(n<=5){const unsigned expected=alert_q(89,draftplan::R.w)|(alert_q(70,draftplan::R.h)<<4)|(SA_PACK<<8)|((100&15)<<12);check(after[4]==(expected&255u)&&after[7]==(expected>>8),"one-to-five-body wire bytes unchanged");}
   auto alert=alert_word(s,after);for(int k=0;k<slots;++k){s.ally_idx=k;write_claim(s,-1);check(alert_word(s,read_sm())==alert,"claim update preserves alert packet");}
  }else check(fixture::writes==writes,"unsupported layout never writes semantic packet");
  if(n<=5)check(claim_bits(s)==6,"one-to-five-body claim widths unchanged");
 }
 // All classes retain semantics in full packets; compact packets merge only
 // carrier subtypes into their ordinary threat/size class.
 for(int count:{31,32,63})for(int kind=1;kind<=10;++kind){reset();State s;s.groups.resize(count);write_shared_alert(s,{45,35},kind,100);auto a=read_shared_alert(s,100);
#if P_DP_ALERTS_SIX && !P_CALLHELP && !P_PVKITE
  check(a.valid&&a.kind==(compact_six_alert(s)?expand_alert_class(compact_alert_class(kind)):kind),"class round trip/coalescing");
#else
  check(!a.valid,"flag off preserves six-body disabled alerts");
#endif
 }
#if P_DP_ALERTS_SIX && !P_CALLHELP && !P_PVKITE
 // Exhaustive coordinate samples cover both grids, each map endpoint, skinny
 // maps, and nonmultiples of8/16. Compact uncertainty bounds every error.
 for(int width:{1,2,7,8,9,16,17,31,71,90,128,255})for(int count:{31,63})for(int v=0;v<width;++v){reset();State s;s.groups.resize(count);draftplan::R.w=width;draftplan::R.h=width;write_shared_alert(s,{v,v},SA_SINGLE_INFO,100);auto a=read_shared_alert(s,100);check(a.valid&&a.p.x>=0&&a.p.x<width&&a.p.y>=0&&a.p.y<width,"mapwide coordinate bounds");if(compact_six_alert(s))check(dist(a.p,{v,v})<=a.uncertainty,"compact coordinate uncertainty conservative");}
 for(int count:{31,63}){
  reset();State writer;writer.groups.resize(count);writer.ally_idx=5;write_claim(writer,count-1);auto before=read_sm();fixture::fail_read=true;write_shared_alert(writer,{20,20},SA_PACK,100);fixture::fail_read=false;check(read_sm()==before,"failed packet read preserves claims/lifecycle");
  fixture::fail_write=true;write_shared_alert(writer,{20,20},SA_PACK,100);fixture::fail_write=false;check(read_sm()==before,"failed packet commit preserves all bytes");
  fixture::advance_read=true;write_shared_alert(writer,{20,20},SA_PACK,100);fixture::advance_read=false;check(read_sm()==before,"cross-round snapshot cannot commit");
  fixture::round=100;fixture::fuel=3000;write_shared_alert(writer,{20,20},SA_PACK,100);check(read_sm()==before,"low fuel does not publish");fixture::fuel=100000;
  write_shared_alert(writer,{-1,20},SA_PACK,100);write_shared_alert(writer,{20,20},15,100);check(read_sm()==before,"invalid source coordinates/kind rejected");
  draftplan::R.valid=false;writer.danger_r=100;update_danger(writer,{},100);check(read_sm()==before,"pending cache cannot write legacy danger into reserved packet");draftplan::R.valid=true;
  // Priority requires an observed fresh packet, not just a timestamp alias.
  write_shared_alert(writer,{20,20},SA_CRITICAL,100);auto priority=read_sm();
  write_shared_alert(writer,{30,30},SA_SINGLE_INFO,100);check(read_sm()==priority,"same-round fresh critical report beats ordinary single");
  const int wrap=compact_six_alert(writer)?8:16;
  for(int r=101;r<100+wrap;++r){fixture::round=r;observe_alert_packet(writer,r,alert_word(writer,read_sm()));}
  fixture::round=100+wrap;write_shared_alert(writer,{30,30},SA_SINGLE_INFO,100+wrap);check(read_shared_alert(writer,100+wrap).kind==SA_SINGLE_INFO,"wrapped stale critical packet cannot veto new direct sighting");
  reset();writer=State{};writer.groups.resize(count);
  // Reader has no chronology proof on first observation. A subsequent observed
  // packet refresh is accepted; an unchanged payload never revives on wrap.
  State reader;reader.groups.resize(count);write_shared_alert(writer,{20,20},SA_PACK,100);update_danger(reader,{},100);check(reader.alert_kind==0,"first observation rejected without chronology proof");
  fixture::round=101;write_shared_alert(writer,{20,20},SA_PACK,101);update_danger(reader,{},101);check(reader.alert_kind==SA_PACK&&reader.alert_r==101,"fresh continuously observed packet accepted");
  for(int r=102;r<=140;++r){fixture::round=r;update_danger(reader,{},r);if(r>103)check(alert_camp_pct(reader,bc::champion{},reader.alert_p,reader.alert_p,r,reader.alert_kind)==100,"unchanged wrapped packet cannot reactivate penalty");}
  fixture::round=160;write_shared_alert(writer,{30,30},SA_PACK,160);update_danger(reader,{},160);check(reader.alert_r==101,"observation gap rejects first packet even if modulo age aliases");
  fixture::round=161;write_shared_alert(writer,{30,30},SA_PACK,161);update_danger(reader,{},161);check(reader.alert_r==161,"fresh refresh after gap restores reception");
  // Only current real Foe handles feed classification/publication; no packet
  // is emitted from a previously received alert when local vision is empty.
  auto stable=read_sm();fixture::round=162;update_danger(reader,{},162);check(read_sm()==stable,"no retransmission of hearsay as direct sighting");
  if(compact_six_alert(reader)){check(reader.danger_r==-1000,"compact reports do not seed long-lived precise danger");check(reader.alert_uncertainty>0,"compact uncertainty reaches consumer state");}
 }
 // Each six-bit ID must survive every other claim and every compact packet.
 for(int group=0;group<63;++group){reset();State s;s.groups.resize(63);for(int body=0;body<6;++body){s.ally_idx=body;write_claim(s,group);}write_shared_alert(s,{10,20},SA_CRITICAL,100);for(int body=0;body<6;++body)check(claim_value(s,read_sm(),body)==group+1,"all63 group IDs for allsix bodies retained");}
#endif

 // Run actual combined update_danger with direct observations, not just packet
 // consumers. The no-action memo reads each exact Foe only once; the gate may
 // skip classification but still retains the original local pack danger.
 for(int groups:{31,63}){
  reset();State observer;observer.groups.resize(groups);std::vector<Foe> foes;
  for(int i=0;i<4;++i){Foe f;f.p={20+i,20};f.hp=900;foes.push_back(f);}
  update_danger(observer,foes,100);
  check(observer.danger_r==100,"combined gate retains directly observed local pack danger");
  check(spawn_queries==4,"combined spawn memo reads each Foe once");
  if(shared_alert_memory(observer)){
   check(bc::hp_reads==4&&bc::strength_reads==4&&bc::focus_reads==4,"combined stat memo reads exact Foes once");
   check(observer.alert_kind==SA_CRITICAL,"combined direct publication/consumption uses real classified Foes");
  }else check(bc::hp_reads==0&&bc::strength_reads==0&&bc::focus_reads==0,"combined gate skips unsendable semantic stats");
 }
 std::printf("PASS six_alerts=%d help=%d kite=%d checks=%d actual protocol/update_danger cases\n",P_DP_ALERTS_SIX,P_CALLHELP,P_PVKITE,checks);
}
