#ifndef P_CALLHELP
#define P_CALLHELP 0
#endif
#ifndef P_PVKITE
#define P_PVKITE 0
#endif

#include <vector>
#include <array>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstddef>
#include <span>
#include <cstdio>
#include <cassert>
#include <stdexcept>
struct vec2 {int x=0,y=0;vec2()=default;vec2(int a,int b):x(a),y(b){}bool operator==(const vec2&)const=default;};
int dist(vec2 a,vec2 b){return std::max(std::abs(a.x-b.x),std::abs(a.y-b.y));}
inline int spawn_queries=0;
struct Mask{bool is_set(vec2)const{++spawn_queries;return false;}};
namespace fixture{inline int round=100,fuel=100000,reads=0,writes=0;inline bool fail_read=false,fail_write=false,advance_read=false;inline std::vector<std::pair<int,int>> spans;}
bool fuel_ok(int need){return fixture::fuel>need;}
template<class F>bool attempt(F f){try{return f();}catch(...){return false;}}
namespace bc{
int round_number(){return fixture::round;}
struct Memory{std::array<std::byte,8> data{};void read(std::size_t off,std::span<std::byte> out){++fixture::reads;if(fixture::fail_read)throw std::runtime_error("read");std::copy_n(data.begin()+off,out.size(),out.begin());if(fixture::advance_read)++fixture::round;}void write(std::size_t off,std::span<const std::byte> in){if(fixture::fail_write)throw std::runtime_error("write");assert(off+in.size()<=8);++fixture::writes;fixture::spans.push_back({off,in.size()});std::copy(in.begin(),in.end(),data.begin()+off);}};inline Memory shared_memory;
inline int hp_reads=0,strength_reads=0,focus_reads=0;
struct champion {double max_health()const{++hp_reads;return 900;}double strength()const{++strength_reads;return 40;}double focus()const{++focus_reads;return 70;}int gem_count()const{return 0;}double health()const{return 900;}};
}
namespace draftplan{struct Runtime{bool valid=true;int w=90,h=71;};inline Runtime R;}
struct Group{};struct Foe{bc::champion c;vec2 p;double hp=900;int gems=0;};
struct State{int roster=6,ally_idx=0;std::vector<Group> groups=std::vector<Group>(31);vec2 alert_p,danger_p;int alert_r=-1000,alert_kind=0,alert_raw_r=-1000,alert_observed_r=-1000,alert_uncertainty=0,danger_r=-1000,last_gems=0;std::uint16_t alert_raw=0;std::vector<vec2> altars{{20,20}};Mask en_spawn;};
struct Policy{int tribute_gems=12;};inline Policy P;
void reset(){spawn_queries=bc::hp_reads=bc::strength_reads=bc::focus_reads=0;bc::shared_memory.data.fill(std::byte{0});fixture::round=100;fixture::fuel=100000;fixture::reads=fixture::writes=0;fixture::fail_read=fixture::fail_write=fixture::advance_read=false;fixture::spans.clear();draftplan::R={true,90,71};}
int checks=0;void check(bool b,const char* why){++checks;if(!b){std::printf("FAIL %s\n",why);std::fflush(stdout);assert(b);}}
