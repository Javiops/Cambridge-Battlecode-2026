"""Portable actual-source mechanism fixtures. No engine, matchmaking or network calls."""
from __future__ import annotations
import argparse,hashlib,itertools,json,re,shutil,subprocess,sys,tempfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
normalize=lambda s:s.replace('\r\n','\n').replace('\r','\n')
sha=lambda b:hashlib.sha256(b).hexdigest()
def source_hashes(src):return {p.relative_to(src).as_posix():sha(p.read_bytes()) for p in sorted(src.rglob('*')) if p.is_file()}
def normalized_hashes(src):return {p.relative_to(src).as_posix():sha(normalize(p.read_text(encoding='utf8')).encode()) for p in sorted(src.rglob('*')) if p.is_file()}
def function(text,name):
    m=re.search(r'^(?:inline\s+)?[^\n;{}]+\b'+re.escape(name)+r'\([^\n]*\)\s*\{',text,re.M)
    if not m:raise ValueError('Missing production function '+name)
    first=text.index('{',m.start());depth=0;state='code';i=first
    while i<len(text):
        c=text[i];pair=text[i:i+2]
        if state=='line':
            if c=='\n':state='code'
        elif state=='block':
            if pair=='*/':state='code';i+=1
        elif state in ('"',"'"):
            if c=='\\':i+=1
            elif c==state:state='code'
        elif pair=='//':state='line';i+=1
        elif pair=='/*':state='block';i+=1
        elif c in ('"',"'"):state=c
        elif c=='{':depth+=1
        elif c=='}':
            depth-=1
            if not depth:return text[m.start():i+1]
        i+=1
    raise ValueError('Unterminated production function '+name)
def override(params,values):
    for name,value in values.items():
        expression=r'(?m)^(\s*#\s*define\s+'+re.escape(name)+r')\s+[^\r\n]+'
        params,count=re.subn(expression,lambda m:m[1]+' '+str(value),params)
        if count>1:raise ValueError('Ambiguous parameter '+name)
        if not count:params+='\n#undef '+name+'\n#define '+name+' '+str(value)+'\n'
    return params

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source',type=Path,required=True,help='Bot src directory or its parent')
    ap.add_argument('--sdk',type=Path,required=True,help='Official Battlecode SDK cpp directory or sdk parent')
    ap.add_argument('--compiler',type=Path,required=True,help='WASI SDK clang++ executable')
    ap.add_argument('--wasi-sdk',type=Path,help='WASI SDK root (default compiler.parent.parent)')
    ap.add_argument('--runtime-path','--wasmtime-pythonlib',type=Path,help='Optional directory containing the Python wasmtime package')
    ap.add_argument('--suite',choices=['all','protocol','memo','budget','cohort'],default='all')
    ap.add_argument('--build-dir',type=Path,help='Optional retained logs/objects/fixtures directory; default temporary')
    ap.add_argument('--report',type=Path,help='Optional JSON result path outside --source')
    ap.add_argument('--allow-source-changes',action='store_true',help='Explicitly test changed source rather than require the recorded final manifest')
    args=ap.parse_args();src=args.source.resolve();src=src/'src' if (src/'src').is_dir() else src
    sdk=args.sdk.resolve();sdk=sdk/'cpp' if (sdk/'cpp').is_dir() else sdk
    compiler=args.compiler.resolve();wasi=(args.wasi_sdk or compiler.parent.parent).resolve()
    for p in [src/'main.cpp',src/'params.h',src/'alert_fuel.h',src/'combat_identity.h',src/'combat_cohort.h',sdk/'cambc.h',compiler]:
        if not p.is_file():ap.error('Missing required input '+str(p))
    for p in [args.build_dir,args.report]:
        if p and p.resolve().is_relative_to(src):ap.error('Outputs must be outside --source')
    inc=wasi/'share/wasi-sysroot/include/wasm32-wasip1/eh/c++/v1';lib=wasi/'share/wasi-sysroot/lib/wasm32-wasip1/eh'
    if not inc.is_dir() or not lib.is_dir():ap.error('This runner needs the WASI SDK exception-enabled libc++ layout')
    if args.runtime_path:sys.path.insert(0,str(args.runtime_path.resolve()))
    try:import wasmtime
    except ImportError:ap.error('Install requirements.txt or provide --runtime-path containing wasmtime')
    original=source_hashes(src);norm=normalized_hashes(src);binding=json.loads((HERE/'bindings.json').read_text())
    if not args.allow_source_changes and norm!=binding['normalized_source_sha256']:raise ValueError('Source differs from recorded final source. Review changes or use --allow-source-changes intentionally.')
    text=normalize((src/'main.cpp').read_text());fight=normalize((src/'fight.h').read_text());verdict=normalize((src/'verdict.h').read_text())
    a=text.index('constexpr int SM_CLAIMS');protocol=text[a:text.index('// P_DPSFARM:',a)];update=function(text,'update_danger');budget=function(fight,'budget_back_off')
    snippets={'protocol':sha(protocol.encode()),'update_danger':sha(update.encode()),'budget_back_off':sha(budget.encode())}
    if not args.allow_source_changes and snippets!=binding['snippets_sha256']:raise ValueError('Production snippet binding mismatch')
    # Cohort is safe only while all four action wrappers invalidate on entry.
    for name in ('step_towards','cast_offense','basic_attack','support_spells'):
        if not re.search(r'\{\s*combatcohort::invalidate\(\);',function(text,name)):raise ValueError('Missing action invalidator '+name)
    if text.count('combat_allies(s)')!=1 or fight.count('combat_allies(s)')!=6 or verdict.count('combat_allies(s)')!=1:raise ValueError('Selected cohort integration call sites changed')
    if 'combatcohort::Scope combat_cohort_scope(round);' not in text:raise ValueError('Missing combat cohort scope')
    temp=None
    if args.build_dir:build=args.build_dir.resolve();build.mkdir(parents=True,exist_ok=True)
    else:temp=tempfile.TemporaryDirectory(prefix='battlecode-mechanisms-');build=Path(temp.name)
    base=[str(compiler),'--target=wasm32-wasip1','-std=c++20','-fwasm-exceptions','-mllvm','-wasm-use-legacy-eh=false','-msimd128','-mbulk-memory','-isystem',str(inc)]
    def compile(extra,folder,label):
        proc=subprocess.run(base+extra,capture_output=True,text=True,timeout=180)
        (folder/(label+'.log')).write_text(proc.stdout+proc.stderr,encoding='utf8')
        if proc.returncode:raise RuntimeError('Compilation failed: '+label+'\n'+proc.stdout+proc.stderr)
    # Compile the complete final bot once against the real SDK. Fixture behavior
    # uses narrow mocks below, not a fabricated copy of the production helper.
    compile(['-O0','-I',str(sdk),'-c',str(src/'main.cpp'),'-o',str(build/'production.o')],build,'production')
    cfg=wasmtime.Config();cfg.wasm_exceptions=True;engine=wasmtime.Engine(cfg)
    modes=[]
    if args.suite in ('all','protocol'):
        for six,help_,kite in ((0,0,0),(1,0,0),(1,1,0),(1,0,1)):
            modes.append(('protocol',{'P_DP_ALERTS_SIX':six,'P_CALLHELP':help_,'P_PVKITE':kite}))
    if args.suite in ('all','memo'):
        for values in itertools.product((0,1),repeat=3):modes.append(('memo',dict(zip(('P_FUEL_ALERT_MEMO','P_FUEL_ALERT_GATE','P_FUEL_ALERT_SPAWN'),values))))
    if args.suite in ('all','budget'):
        for identity,fallback in itertools.product((0,1),repeat=2):modes.append(('budget',{'P_FUEL_IDENTITY':identity,'P_FUEL_FIGHT_FALLBACK':fallback}))
    if args.suite in ('all','cohort'):
        for enabled in (0,1):modes.append(('cohort',{'P_FUEL_COHORT':enabled}))
    results=[]
    for index,(suite,flags) in enumerate(modes):
        folder=build/(suite+'-'+''.join(str(x) for x in flags.values()));target=folder/'src';target.mkdir(parents=True,exist_ok=True)
        for p in src.iterdir():
            if p.is_file():shutil.copy2(p,target/p.name)
        (target/'params.h').write_text(override((target/'params.h').read_text(),flags),encoding='utf8')
        if suite in ('protocol','memo'):
            fixture='#include "params.h"\n'+(HERE/suite/'mock.cpp').read_text()+protocol+'\n'+update+'\n'+(HERE/suite/'cases.cpp').read_text()
        elif suite=='budget':fixture=(HERE/'budget/fixture.cpp.in').read_text().replace('@@BUDGET_BACK_OFF@@',budget)
        else:fixture=(HERE/'cohort/fixture.cpp').read_text()
        cpp=folder/'fixture.cpp';cpp.write_text(fixture,encoding='utf8');module=folder/'fixture.wasm'
        compile(['-O1','-I',str(target),'-L',str(lib),str(cpp),'-lunwind','-Wl,-z,stack-size=4194304','-o',str(module)],folder,'fixture')
        store=wasmtime.Store(engine);wasi_config=wasmtime.WasiConfig();wasi_config.stdout_file=str(folder/'stdout');wasi_config.stderr_file=str(folder/'stderr');store.set_wasi(wasi_config)
        linker=wasmtime.Linker(engine);linker.define_wasi();instance=linker.instantiate(store,wasmtime.Module.from_file(engine,str(module)))
        try:instance.exports(store)['_start'](store)
        except Exception:
            print((folder/'stdout').read_text(),(folder/'stderr').read_text());raise
        stdout=(folder/'stdout').read_text();stderr=(folder/'stderr').read_text()
        if stderr or 'PASS' not in stdout:raise RuntimeError('Fixture failed '+suite+'\n'+stdout+'\n'+stderr)
        result={'suite':suite,'flags':flags,'stdout':stdout,'fixture_sha256':sha(cpp.read_bytes()),'wasm_sha256':sha(module.read_bytes())}
        if suite=='memo':
            m=re.search(r'SEMANTICS (\d+) stats=(\d+) spawn=(\d+)',stdout)
            if not m:raise ValueError('Missing semantic hash')
            result.update(semantic_hash=m[1],stats_queries=int(m[2]),spawn_queries=int(m[3]),update_calls=504)
        results.append(result);print(suite,flags,stdout.strip(),flush=True)
    memo=[r for r in results if r['suite']=='memo']
    if memo and len({r['semantic_hash'] for r in memo})!=1:raise ValueError('Memo/gate/spawn variants changed state or shared-memory output')
    if original!=source_hashes(src):raise ValueError('Input source changed while tests ran')
    report={'status':'pass','suite':args.suite,'full_sdk_translation_unit_compile':True,'source_files':len(original),'source_sha256':original,'normalized_source_sha256':norm,'source_unchanged':True,'snippets_sha256':snippets,'results':results,'limits':['Actual production snippets/headers under narrow SDK mocks, plus one full SDK object compile.','No release linking, game simulation, native fuel measurement or win-rate proof.','Protocol supports six-body semantic alerts only up to 63 camp groups.']}
    if args.report:args.report.resolve().parent.mkdir(parents=True,exist_ok=True);args.report.write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    print('PASS portable mechanism package; fixtures='+str(len(results))+'; source unchanged',flush=True)
    if temp:temp.cleanup()
if __name__=='__main__':main()
