# I034 optional postkill study evidence

Read-only ledger for156 scheduled study slots: exact teammate40, adapted transplant versus unchanged v440, adapted transplant versus raw v5940, and adapted transplant versus three sparring bots36. These different sources/opponents are never pooled as one strength result. The36 unchanged-v4 spar controls are separate historical slots.

study-games.csv binds source/WASM/runtime/map/seed/statistics/replay archive/raw replay/stdout hashes and separate fuel/native-fault/caught-error counts. caught-errors.json preserves captured marker strings; truncated/selective stdout is not a complete SDK-error census. No large raw native replays or executable binaries are included.

source-manifest.json identifies the exact teammate ZIP, both unselected prototypes and the unchanged selected v4 source. optional-postkill.patch changes only main.cpp and params.h relative to that frozen v4. portable-postkill-tests.zip contains a parameterized actual-source fixture runner, recorded33-case results and the exact teammate comparison block. It requires an external official SDK/WASI compiler/wasmtime. This is mechanism evidence, not playing-strength proof.

The20-map native diagnostic set was locked before this study's outcomes, but includes known official/developer maps rather than sealed unseen tournament maps. Paired outcomes, repeated native stream counts and matched control flips are retained. The optional patch was not selected after33–3 sparring results versus unchanged v4's36–0. There is no upload/activation recommendation or claimed promotion-gate pass.
