# Bounded audit of the three postkill sparring losses

Production **v4 remains unchanged**. This audit reads3 saved combined losses and3 matched v4 controls; no games or source changes were made. Every pair has the same seed, draft and geometry, and all6 native reconstructions pass final/death checks.

| Opponent / slot | Combined | Frozen v4 | Gem loss combined / v4 | First change |
|---|---:|---:|---:|---|
| spar11 / elkring B | 576–1008 | 1008–900 | 216 / 72 | Ryth r15: [27, 22] → [26, 22] |
| spar11 / fresh-compact-open A | 716–1012 | 1014–372 | 168 / 44 | Ryth r17: [11, 8] → [12, 8] |
| spar16 / elkring B | 576–1008 | 1008–900 | 216 / 72 | Ryth r15: [27, 22] → [26, 22] |

Both Elkring opponent labels produce **identical complete timelines** in each variant; these are2 recorded losses but1 distinct mechanism.

## What is established

The first381 Elkring action records match. At r15 Ryth lands the final camp hit, then the new block moves him onto group1; v4 yields and steps on next turn. The new version receives36 gems at r21 instead ofr22. There are no enemies within8 at that move and no fuel exhaustion in either game.

The first427 compact action records match. At r17 Ryth kills the final monster and steps onto group4, receiving36 gems at r23 instead ofr24. Again, no enemy is within8. These initial changes work as intended; they are not witnesses of the stale-round, failed-query or occupied-ally bugs covered by the fixtures.

The later games are worse: Elkring loses216 gems instead of72 and compact168 instead of44. That does not establish a direct causal chain from the one-turn gain to the final defeats. Earlier reward, recall and rotation timing changes subsequent decisions. No harmful capturer-rank or lock interaction was established from these records.

## Concrete later capture interaction

In compact, Ryth clears group0 at r457 and steps onto it. He waits throughr460, then leaves at r461 as an opponent approaches within6; by r462 the capture timer has reset. He casts toward the opponent at r463 and finally collects the44-gem reward only at r483. The optional-entry rule checks current distance and damage, but does not decide whether the team can hold the objective for the full capture duration. This is a real capture-persistence/contest-policy interaction to investigate, not proof that it causes this defeat or a justification for guessing a new distance threshold.

The block bypasses the complete existing capturer election until the next turn. Special tank/priority exclusions are inactive in the present profile (`dpsfarm=capprio=0`); no harmful role assignment was demonstrated in the first divergences. No shared-memory or cohort conflict was found.

The supplied teammate archive changes postkill capture and the final Prism filter; it contains **no new camp damage or tanking mathematics**. Our combined candidate imports only adapted postkill capture and retains our existing Cassi draft policy.

The evidence supports keeping this candidate experimental: local capture acceleration works, but its interaction with capture duration, contest decisions and later rotations is not yet understood. `loss-audit.json` pins all6 records, sources, command excerpts, rewards, later gem losses and attribution limits.
