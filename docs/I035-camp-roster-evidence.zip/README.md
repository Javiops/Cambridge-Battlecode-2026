# I035 physical-roster bound evidence

Read-only ledger for224 scheduled roster-bound slots:74 versus unchanged v4 on37 locked maps,74 versus raw v59 on those maps,40 versus unchanged v4 on a separate20-map diagnostic set, and36 versus three sparring bots. Controls are separate:74 unchanged-v4 versus raw-v59 slots on those same37maps, plus36 historical unchanged-v4 sparring slots. The oldI033 228-slot final ledger is included under its historical name; it is not added to this study. The74-game matched summary uses the separate control37 identity; the original96-map192-game result remains preserved in immutable view-validation.json and the I033 ledger. These different samples are never substituted or pooled.

study-games.csv binds source/WASM/runtime/map/seed/statistics/replay archive/raw replay/stdout hashes and separate fuel/native-fault/caught-error counts. caught-errors.json preserves captured markers; selectively printed/truncated stdout is not a complete SDK-error census. Large raw replays and executable binaries are omitted.

source-manifest.json and roster-bound.patch identify the exact two-file change against frozen v4. portable-roster-tests.zip contains the parameterized actual-function runner,720086 deterministic arithmetic checks and full-SDK on/off compilation evidence. This is correctness evidence, not720086 games or playing-strength proof.

mechanisms/current-engine-contract.json and compressed observations bind a read-only current0.0.3 camp audit of two existing streams through round300. They establish concentrated incoming-hit counterexamples, full-health awake and wounded-asleep cases, and a resource-hit sibling wake sequence. This patch does not replace the inherited equal-share damage model, state proxy, tank assignment or contest policy.

The map sets were locked before these candidate outcomes, but are historical official/developer maps, not sealed unseen tournament maps. The confirmed correctness patch is selected for draft review only, without demonstrated superiority, upload readiness, online A/B, activation or a complete promotion-gate pass. Both frozen source directories remain byte-identical to their tested builds.
