# Current0.0.3 camp mechanics: bounded replay audit

Two existing replay streams were reconstructed through round300 using editor engine SHA `1919c5a6…109e3f96f`. Both native records pin engine0.0.3/build `d7e29ae3…d2a5`. The existing decoder ABI was reused; camp HP/strength and design range were cross-checked against direct engine APIs. No games, runner actions or candidate edits were performed.

**Camp incoming damage is concentrated, not evenly shared.** Of770 damaging camp steps,557 have multiple alive bodies geometrically in range. All297 strict-nearest cases hit that nearest body alone;264 show the complete unmitigated raw hit. This includes13 cross-team nearest cases (11 unmitigated). These are observed matches, with visibility limitations below.

| Existing replay witness | Bodies in range | Actual damage | Equal-share premise |
|---|---:|---|---|
| Elkring r4, elk1 `(26,23)` |4; Issac at distance1, Tavi2, Cassi/Ren3 | Issac900→840; others unchanged |60/4=15 each is false |
| Elkring r6, elk0 `(3,6)` |4; Tavi uniquely nearest at2 | Tavi750→690 alone | Full60 concentrates on one body |
| Compact r166, wolf2 `(8,9)` | Our Tavi3; opposing Issac2 | Opposing Issac880→860 alone | Both teams affect tank assignment |

**Health history is not awake state.**82 damaging camp attacks occur while the attacker is still at full HP. Conversely,289 wounded positive-strength round samples are explicitly asleep. One concrete asleep elk is group6/camp12 at `(19,2)`, r71:2065/2400HP,60strength, engine state2.

The earliest group1 sequence is particularly useful: both members are asleep at the start of Elkring r3. Issac attacks the zero-strength resource at `(26,22)` (500→460); immediately afterward both the resource and its untouched2400/2400HP elk sibling are awake. The elk then hits Issac60 in the next round's phase9, before champion inputs. A future-attack forecast must include such full-health siblings; blindly replacing the current HP proxy with current awake state would still miss the danger created by our own next attack.

Damaged zero-strength resources also appear near champions. They cannot be counted as incoming damage themselves, while their damaging siblings must remain in the forecast.

## Consequences for the current code

`squad_needed` assumes total clear time improves by n and incoming damage per body is also divided by n. The per-volley second division is contradicted above. The independent target scorer repeats `incoming = strength * t_clear / team`, so fixing only squad size leaves optimistic objective/recovery costs. A sound replacement needs per-monster target assignment and per-body exposure, not a blanket “never farm dangerous camps” rule.

For each living monster, assign its possible next hit using current positions, actual attack range and both teams; conservatively charge full potential exposure on nearest ties or uncertain visibility. A larger squad can shorten the clear through real available DPS, but that does not automatically divide the tank's individual volley. Planned attacks must include all newly awakened group members. Arrival timing, heterogeneous ready damage, mitigation/shields, movement and kill order still need separate treatment.

## Limits

Geometric eligibility here means alive, outside own spawn and within Chebyshev design range; camp-side vision/bush eligibility was not independently reconstructed. Exact tie ordering remains unknown across260 tied cases. Do not assume a physical-ID tiebreak. Shield/mitigation/linked-life effects can alter HP deltas; the raw-hit witnesses isolate the distribution claim. Attack/sleep periods and shield timing were not newly established. The source remains unchanged.

`contract.json` contains exact command/state witnesses, source and runtime pins, counts and limitations. `observations.json.gz` contains all770 retained attack observations and sampled engine states.
