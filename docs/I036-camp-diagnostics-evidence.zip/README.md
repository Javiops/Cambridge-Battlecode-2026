# I036 diagnostic evidence

Intended GitHub report URL (available after publication): https://github.com/Javiops/Cambridge-Battlecode-2026/blob/main/docs/I036-camp-lifecycle-diagnostics.md

The Markdown report and this archive retain separate sources/datasets. Source archives contain C++ only; no binary, account token, raw large replay or private absolute path is bundled. `scheduled-slots.csv` includes summary reuse markers; `summary.json` reports distinct records/streams and pending inputs. Probe slots reused by later panels are not independent new games. `input-bindings.json` hashes original inputs before portable path normalization.

`sources/`, `patches/`, `mechanisms/`, `causal/` and `tests/` retain exact source flags and recorded actual-source validation. Tests have not been rerun by the export. See tests/README.md for external compiler/SDK instructions. I035 remains the selected review source; these follow-up candidates are not promoted by this package.
