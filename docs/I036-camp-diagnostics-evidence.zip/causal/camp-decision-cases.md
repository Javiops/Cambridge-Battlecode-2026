# Decisions before three camp fatalities

Existing0.0.3 replays only: exact pre-action APIs, current personal camp visibility, ability designs and native legal movement masks were queried at8 decisions. No alternate action or game was executed.

**The two own deaths involve global low-HP flee, not `pv_out`.** A correction only inside combat retreat would miss them.

## Own Stellar, Elkring: earlier safe exit ignored

At r106/input2558 Stellar has225/825HP at `(27,20)`. The awake elk1 at `(26,23)` is personally visible, with919HP and60 strength. Three native-legal moves—`(26,19)`, `(27,19)`, `(28,19)`—leave its range3, with no enemy champion nearby. Instead the homeward retreat walks south:

`(27,20) → (27,21) → (27,22) → (27,23) → (27,24) → (27,25)`

Stellar loses60 in each of camp phases108–110 and the remaining45 at111. He still has225HP at107: intervening ally movement can change which body tanks, so this is not a claim that every earlier exposed step immediately deals damage. Its previous commands through105 were attacks on that camp; r100 stdout explicitly shows `farm/fight-camp target=1`. Low-HP source predicates then select `flee/recall → flee → step_towards(spawn)`. Both spells are damage spells, with no dash/shield. At r106 they are on cooldown1/2. The northern exit remains distance4 from the camp, within published spell range4, so safe steering need not permanently abandon the objective.

At the last r110 decision, every legal neighbor is still in camp range. There is no proven final single-step rescue: the fix must act at106 or earlier.

## Own Ryth, compact: two camps overlap the selected escape

At r185/input3953 Ryth has68.25HP at `(9,7)`. Personally visible active camps are wolf2 `(8,9)`,332.5HP/20 strength, and elk6 `(12,8)`,2300HP/60 strength. The actual move to `(9,8)` remains in both ranges; next phase9 deals18 then54 after observed mitigation and kills him.

The native-legal `(8,8)` endpoint avoids the elk, remains adjacent to the same wolf and retains a125-point basic attack opportunity. It risks only the18-point wolf hit. Both this endpoint and actual `(9,8)` are distance4 from nearby Willow `(6,4)` and Prism `(8,4)`; current radial champion threat is not increased. This is a concrete lower camp-envelope alternative, with later enemy reactions unresolved.

Ryth's r184 yield was forced: canMove/Attack/Cast are allfalse, restrictions63 and the movement mask is empty. He is melee and therefore does not qualify for a first ranged-only correction.

The second camp was awakened by combat: at r183 Ryth's AoE centred `(11,8)` hits enemy Issac100 and the full-health sleeping elk100. Native area coverage at `(10,7)` includes the same enemy while excluding the elk. Current `aoe_centre` scores enemy damage/kills and a target-centre bonus, without a neutral-wake cost. Published range/ground/readiness conditions permit considering that centre, but no alternative cast was executed or fully validated.

## Opposing Stellar, Elkring: retreat already too late

At r177,32.4HP opposing Stellar moves `(17,0) → (16,0)` away from elk12 `(19,2)`. Every legal one-step endpoint remains in range3; the chosen tile already improves exit distance. He dies in a nearest-distance tie at r178. Opponent stdout confirms `flee/recall` at175. This corroborates the need to account for exit time earlier, rather than inventing a safe final step or tie rule.

## Supported narrow correction

Start in the global badly-hurt branch, before `hit_now`, for ranged champions that can move and have no dash. Prefer a legal neighbor with strictly lower active-camp hit exposure and no increased champion threat; retain legacy behavior if none exists. Stellar r106 meets these conditions exactly. `hit_now` already declines to attack when a ranged champion can move, so the proposed insertion preserves attack order and does not discard a stronger ready dash.

Equal-exposure steps-to-exit is a separate useful extension, but neither last lethal turn here proves a surviving1-step rescue. Per-body exposure, earlier safe routing and accidental AoE wake are distinct issues from the old squad n² arithmetic.

`decision-cases.json` pins exact inputs, commands, sources and runtime; `observations.json.gz` contains all queried decisions. No production changes were made.
