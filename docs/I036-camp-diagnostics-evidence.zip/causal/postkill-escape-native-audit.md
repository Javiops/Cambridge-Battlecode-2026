# Native audit: postkill capture plus camp escape v2

This audit reads three saved new slots and three matched cached postkill controls. They contain **two distinct patterns**: both Elkring opponent labels have identical full timelines in each version. All six streams pass current-engine final/death checks. No games or production edits were performed.

| Slot | Old postkill | New combo | First changed decision | Focal death old → new |
|---|---:|---:|---|---|
| spar11 / elkring B | 576–1008 | 1008–828 | R106, body 7: [27, 20] → [28, 19] | R111 → R113 |
| spar16 / elkring B | 576–1008 | 1008–828 | R106, body 7: [27, 20] → [28, 19] | R111 → R113 |
| spar11 / fresh-compact-open A | 716–1012 | 1014–904 | R185, body 0: [9, 7] → [8, 8] | R186 → R187 |

## Elkring: the intended step occurs, then return movement re-enters range

The first **2,537 global commands** match. Immediately before R106 / input 2558, the complete native world hashes match (`2ded75ac…6989c`). Stellar body 7 has 225/825 HP at `(27,20)`. The new command moves to `(28,19)` instead of `(27,21)`. Personally visible legal endpoint envelopes are 0 versus 60 raw camp damage; all eight adjacent poses have reconstructed champion danger 0. The elk is at `(26,23)`, strength 60, range 3. Stellar and allied Tavi are tied at geometric distance 3; that tie does not imply damage sharing.

This does **not** become a safe completed retreat. At R107 Stellar returns from `(28,19)` to `(28,20)`, re-entering the elk envelope despite legal visible zero-envelope neighbors. Current exposure is 0, so the narrow escape selector cannot authorize a strict reduction from there. Stellar then alternates safe and unsafe rows, takes 60 at R108/R110/R112, moves to `(29,21)` at R112 and dies at R113. The control dies at R111. Neither version receives a camp hit at R107, so the first geometrically safer tile is not described as an immediate saved 60-damage hit.

## Compact: the two-hit death is postponed by exactly one turn

The first **3,932 global commands** match. Immediately before R185 / input 3953, the complete native world hashes match (`ad1bd554…27ff1`). Ryth body 0 has 68.25/1200 HP at `(9,7)`. The new step is `(8,8)` instead of `(9,8)`: raw camp envelope 20 versus 80. All eight neighboring poses have reconstructed champion danger 80. The wolf at `(8,9)` has strength 20/range 3; the elk at `(12,8)` has strength 60/range 3. Ryth is the elk’s unique geometric in-range target at the shared prestate.

At R186 the new Ryth takes **18 wolf damage only**, remaining at 50.25 HP. The old Ryth takes wolf 18 plus the elk’s lethal remainder and dies. This is native evidence of the intended immediate two-hit avoidance, not merely a fixture. However, on the new R186 turn Ryth then moves `(8,8) → (9,9)`, restoring the raw 80 envelope. No legal visible neighbor offers exposure below the current 20, so the strict-improvement escape selector cannot choose a 20→20 continuation. At R187 wolf 18 plus the elk kills Ryth. The extra turn also changes allied Tavi’s R186 movement, after which final outcomes cannot be reduced to a single isolated step.

## Interpretation and limits

Both intended initial states are preserved until the actual escape decisions; these are not wins explained by an earlier unrelated trajectory change. The source and native evidence support **local exposure reduction**, while persistent retreat and safe fallback destinations remain incomplete. All three match outcomes improve, but both focal champions still die; the score flips are not presented as proof that these two deaths are fixed or that the changes alone explain victory.

The cached postkill control predates the confirmed six-body roster-sentinel fix, which is also present in the new selected-base prototype. Exact pre-world equality rules out an earlier state divergence here, but the comparison is not a one-flag native ablation. Reconstructed champion danger uses current SDK values rather than private live caches. Release replays do not expose `g_mode`, fuel admission or SDK-read success; no internal branch log was invented. Raw envelopes do not resolve fog, attack timing, mitigation or tied target selection.

`audit.json` binds exact record keys, sources, command/damage excerpts and world hashes. `native-states.json` contains all eight poses, visible camp and foe queries, and actual commands at each shared prestate and the next re-entry turn.
