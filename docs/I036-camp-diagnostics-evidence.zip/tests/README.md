# Portable actual source fixtures

Extract the relevant `sources/v60-*.zip` to a new directory. Each matching `.cpp` file contains the exact production mechanism or branch used by its recorded source-bound test; its SDK calls are controlled mocks. Source and recorded validation hashes identify the exact tested composition. Complete production SDK off/on compilation is recorded separately in each mechanism report.

With an external WASI SDK, official Battlecode SDK and Python wasmtime supporting exceptions, compile a fixture (replace placeholders):

```text
<wasi>/bin/clang++ --target=wasm32-wasip1 -std=c++20 -O1 -fwasm-exceptions -mllvm -wasm-use-legacy-eh=false -msimd128 -mbulk-memory -isystem <wasi>/share/wasi-sysroot/include/wasm32-wasip1/eh/c++/v1 -I <extracted>/src -L <wasi>/share/wasi-sysroot/lib/wasm32-wasip1/eh <fixture.cpp> -lunwind -o fixture.wasm
```

Run `_start` with WASI imports using `wasmtime.Config.wasm_exceptions=True`. For feature-off checks, copy the extracted source to a separate directory and set the relevant `P_CAMP_STATE_GUARD`, `P_RECALL_WINDOW`, `P_CAMP_ESCAPE` or `P_CF_POSTKILL_CAPTURE` definition in that copy's params.h to0; avoid duplicate macro definitions. The postkill+escape reports retain all four flag combinations. Do not use fixture results as match outcomes.

To compile the full bot's translation unit, use the same target/exception/include flags with `-O0 -I <official-sdk>/cpp -c <extracted>/src/main.cpp`. No compiler, engine binary, raw replay, account token or private absolute path is bundled. This packaging operation does not rerun the recorded tests.
