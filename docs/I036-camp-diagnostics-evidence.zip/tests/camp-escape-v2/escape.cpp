
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <optional>
#include <map>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>
#include "params.h"
struct vec2{int x=0,y=0;vec2()=default;vec2(int a,int b):x(a),y(b){}bool operator==(const vec2&)const=default;vec2 operator+(vec2 p)const{return{x+p.x,y+p.y};}int dot(vec2 p)const{return x*p.x+y*p.y;}int chebyshev_distance(vec2 p)const{return std::max(std::abs(x-p.x),std::abs(y-p.y));}};
int now_round=106,owner=7,errors=0,camp_reads=0,moves=0,invalidations=0,shoots=0,hits=0,flees=0,pos_reads=0;
std::uint64_t fuel=100000;bool movable=true,move_success=true;vec2 live_pos{27,20};int range_value=3;
std::string throw_at,advance_at,drop_at;bool move_crosses=false,shift_final_position=false;std::vector<std::string> actions;
std::map<std::string,int> query_counts;
int throw_on_call=1,advance_on_call=1,drop_on_call=1;
void hook(const char*n){const int call=++query_counts[n];if(throw_at==n&&call==throw_on_call){throw_at.clear();throw std::runtime_error(n);}if(advance_at==n&&call==advance_on_call){advance_at.clear();++now_round;}if(drop_at==n&&call==drop_on_call){drop_at.clear();fuel=20000;}}
namespace bc{
std::uint64_t fuel_remaining(){hook("fuel");return fuel;}std::uint32_t round_number(){hook("round");return now_round;}
struct champion{int id=7;bool operator==(const champion&)const=default;bool can_move()const{hook("can_move");return movable;}int attack_range()const{hook("attack_range");return range_value;}vec2 position()const{++pos_reads;hook("me_position");if(shift_final_position&&pos_reads==2)live_pos={28,20};return live_pos;}bool move_absolute(vec2 p){hook("move");actions.push_back("move");if(!move_success)return false;if(move_crosses)++now_round;live_pos=p;movable=false;++moves;return true;}};
champion& self(){static champion me;me.id=owner;return me;}
struct bitboard{std::set<std::pair<int,int>> blocked;bool all=false;bool is_set(vec2 p)const{return all?!blocked.count({p.x,p.y}):blocked.count({p.x,p.y});}void set(vec2 p,bool value=true){if(value)blocked.insert({p.x,p.y});else blocked.erase({p.x,p.y});}};
struct camp_state{int value=1;bool is_awake()const{return value==1;}};
struct camp{vec2 p;double str=60,hp=2400;int r=3,st=1;camp_state state()const{++camp_reads;hook("camp_state");return{st};}double strength()const{++camp_reads;hook("camp_strength");return str;}double health()const{++camp_reads;hook("camp_health");return hp;}vec2 position()const{++camp_reads;hook("camp_position");return p;}int attack_range()const{++camp_reads;hook("camp_range");return r;}};
namespace map{int width(){hook("width");return 36;}int height(){hook("height");return 36;}}
}
struct Threat{vec2 p;double xd=0;int xr=-9;double fd=0;int fr=-9;int sr=-9;double atk=0;int ar=1;double ready=0;};
struct State{int dash_slot=-1,thr_r=106;bc::bitboard blocked,vis;vec2 spawn_center{29,25};std::vector<Threat>thr;State(){vis.all=true;}};
struct Foe{bc::champion c;vec2 p;float hp=100;int d=0;};
constexpr std::uint64_t FUEL_RESERVE=6000;
void note_error(const char*){++errors;}
namespace combatcohort{void invalidate(){++invalidations;actions.push_back("invalidate");}}
const char*g_mode="old";
void cast_offense(State&,bc::champion&,const bc::champion&,vec2,bool){actions.push_back("cast");}
bool basic_attack(State&,bc::champion&,const bc::champion&,vec2){++hits;actions.push_back("hit");return true;}
bool flee(State&,bc::champion&){++flees;actions.push_back("flee");return false;}
void shoot_back(State&,bc::champion&,const std::vector<Foe>&){++shoots;actions.push_back("shoot");}

inline int dist(vec2 a, vec2 b) { return static_cast<int>(a.chebyshev_distance(b)); }
inline int X(vec2 v) { return static_cast<int>(v.dot(vec2(1, 0))); }
inline int Y(vec2 v) { return static_cast<int>(v.dot(vec2(0, 1))); }
inline bool fuel_ok(std::uint64_t need) { return bc::fuel_remaining() > need + FUEL_RESERVE; }
inline double danger_at(const std::vector<Threat>& th, vec2 t) {
    double sum = 0;
    bool stun = false;
    for (auto& x : th) {
        int d = dist(t, x.p);
        double sp = 0;
        if (d <= x.xr) sp = x.xd;
        if (d <= x.fr + 1) sp = std::max(sp, x.fd);
        sum += sp + (d <= x.ar ? x.atk : 0.0);
        if (d <= x.sr + 1) stun = true;
    }
    if (stun)  // stunned for a round: the ready casters one step out get to stand and cast after
        for (auto& x : th) {
            int d = dist(t, x.p);
            if (d > x.xr && d <= x.xr + 1) sum += 0.5 * x.xd;
        }
    return sum;
}
template <class F>
bool attempt(F&& f) {
    try {
        return f();
    } catch (const std::exception& e) {
        note_error(e.what());
        return false;
    } catch (...) {
        note_error("unknown exception");
        return false;
    }
}
#include "camp_escape.h"
namespace fight{
inline bool hit_now(State& s, bc::champion& me, const std::vector<Foe>& foes) {
    // Measured: a ranged champion that attacks can no longer move this turn (64 of 64 Cassi hits on
    // packs), so ranged champions step first and shoot after (shoot_back) unless they are stuck anyway.
    if (me.attack_range() > 1 && me.can_move()) return false;
    vec2 pos = me.position();
    const Foe* best = nullptr;
    for (auto& f : foes) {
        if (f.hp <= 0 || dist(pos, f.p) > me.attack_range()) continue;
        if (!best || f.hp < best->hp) best = &f;
    }
    if (!best) return false;
    cast_offense(s, me, best->c, best->p, true);
    return basic_attack(s, me, best->c, best->p);
}
}

void check(bool value,const char*why){if(!value){std::fprintf(stderr,"FAIL %s/n",why);std::exit(1);}}
void fallback(State&s,bc::champion&me,std::vector<bc::camp>&camps,std::vector<Foe>&foes,int round,vec2 pos,bool camps_complete=true,bool own_vision_complete=true){bool rsafe=false,recalled=false;
        if (!rsafe || (P_U34_FAILED_CHANNELS && !recalled)) {
            // An ordinary escape may reduce known camp exposure before a
            // ranged/no-target hit_now that would otherwise return false.
            if (campescape::step(s, me, camps, foes, round, pos,
                                 camps_complete && own_vision_complete)) {
                g_mode = "camp-escape";
                shoot_back(s, me, foes);
                return;
            }
            bool hit = P_HITFIRST && fight::hit_now(s, me, foes);
            flee(s, me);
            if (!hit) shoot_back(s, me, foes);
        }
}
struct Setup{State s;bc::champion me{7};std::vector<bc::camp>camps;std::vector<Foe>foes;int round=106;vec2 pos{27,20};Setup(){now_round=106;owner=7;errors=camp_reads=moves=invalidations=shoots=hits=flees=pos_reads=0;fuel=100000;movable=move_success=true;live_pos=pos;range_value=3;throw_at.clear();advance_at.clear();drop_at.clear();actions.clear();query_counts.clear();throw_on_call=advance_on_call=drop_on_call=1;move_crosses=shift_final_position=false;g_mode="old";camps.push_back({{26,23},60,2400,3,1});}bool step(bool complete=true){return campescape::step(s,me,camps,foes,round,pos,complete);}void go(bool complete=true,bool visible=true){fallback(s,me,camps,foes,round,pos,complete,visible);}void north(){s.blocked.set({26,19});s.blocked.set({27,19});s.blocked.set({28,19});}};
int main(){int cases=0;
#if !P_CAMP_ESCAPE
 {Setup x;x.go();check(moves==0&&camp_reads==0&&invalidations==0&&flees==1&&shoots==1,"disabled preserves old ranged flee/shoot ordering without camp reads");++cases;}
 {Setup x;range_value=1;x.foes.push_back({{9},{27,21},5,1});x.go();check(hits==1&&flees==1&&shoots==0&&camp_reads==0,"disabled old melee hit/flee order");++cases;}
#else
 {Setup x;x.go();check(moves==1&&live_pos.y==19&&g_mode==std::string("camp-escape"),"StellarR106 exits full-HP awake elk range north");check(shoots==1&&flees==0&&hits==0&&invalidations==1,"successful escape retains shoot after move and skips ranged no-op hit_now");check(actions==std::vector<std::string>({"invalidate","move","shoot"}),"cache invalidation before direct action");++cases;}
 {Setup x;x.round=now_round=185;x.s.thr_r=185;x.pos=live_pos={9,7};x.me.id=owner=0;range_value=1;x.s.spawn_center={3,17};x.camps={{{8,9},20,1350,3,1},{{12,8},60,2400,3,1}};x.foes.push_back({{10},{13,8},300,4});x.go();check(moves==1&&live_pos==vec2(8,8),"RythR185 no in-range hit escapes80 raw camp envelope to20 toward home");check(shoots==1&&hits==0&&flees==0,"melee no-target hit_now remains a no-op before escape");++cases;}
 {Setup x;x.s.dash_slot=0;x.go();check(moves==0&&camp_reads==0&&flees==1,"any dash slot retains original path even if not ready");++cases;}
 {Setup x;movable=false;x.go();check(moves==0&&camp_reads==0,"cannot-move body not overridden");++cases;}
 {Setup x;range_value=1;x.foes.push_back({{9},{27,21},5,1});x.go();check(hits==1&&flees==1&&shoots==0&&moves==0&&camp_reads==0,"available melee hit/cast is never displaced");++cases;}
 {Setup x;range_value=1;x.foes.push_back({{9},{27,21},0,1});x.go();check(moves==1&&hits==0,"dead foe is not an available melee hit_now target");++cases;}
 {Setup x;x.camps[0].r=30;x.go();check(moves==0&&flees==1,"no strictly lower camp tile retains original");++cases;}
 {Setup x;x.camps.clear();x.go();check(moves==0&&camp_reads==0,"empty input has no camp SDK work");++cases;}
 {Setup x;x.camps[0].st=2;x.camps[0].hp=100;x.go();check(moves==0&&camp_reads==1,"wounded asleep camp is not awake danger");++cases;}
 {Setup x;x.camps[0].st=0;x.go();check(moves==0&&camp_reads==1,"dead camp is not active danger");++cases;}
 {Setup x;x.camps[0].str=0;x.camps[0].hp=100;x.go();check(moves==0&&camp_reads==2,"damaged zero-strength resource has no hit envelope");++cases;}
 {Setup x;x.camps.push_back({{27,20},0,100,3,1});x.go();check(moves==1,"awake full-health damaging sibling remains despite zero-strength resource");++cases;}
 {Setup x;x.north();x.go();check(moves==0&&flees==1,"blocked lower tiles excluded");++cases;}
 {Setup x;x.s.vis.set({26,19});x.s.vis.set({27,19});x.s.vis.set({28,19});x.go();check(moves==0&&flees==1,"blind lower tiles cannot authorize escape");++cases;}
 {Setup x;for(int px=26;px<=28;++px){Threat t;t.p={px,19};t.atk=1;t.ar=0;x.s.thr.push_back(t);}x.go();check(moves==0&&flees==1,"greater champion danger vetoes every lower camp tile");++cases;}
 {Setup x;Threat t;t.p={27,20};t.atk=50;t.ar=2;x.s.thr.push_back(t);x.go();check(moves==1,"equal existing same-round champion danger permits lower camp exposure");++cases;}
 {Setup x;Threat t;t.p=x.pos;t.atk=100;t.ar=0;x.s.thr.push_back(t);for(int px=26;px<=28;++px){t.p={px,19};x.s.thr.push_back(t);}x.go();check(moves==0&&flees==1,"champion100 camp0 exit cannot displace available champion0 camp60 neighbor; original fallback retained");++cases;}
 {Setup x;x.s.thr_r=105;x.go();check(moves==0&&camp_reads==0,"stale champion risk snapshot veto");++cases;}
 {Setup x;x.go(false);check(moves==0&&camp_reads==0,"partial camp acquisition remains unknown");++cases;}
 {Setup x;x.go(true,false);check(moves==0&&camp_reads==0,"failed own-vision acquisition remains unknown");++cases;}
 {Setup x;owner=4;x.go();check(moves==0&&camp_reads==0,"different current owner veto");++cases;}
 {Setup x;live_pos={28,20};x.go();check(moves==0&&camp_reads==0,"changed initial position veto");++cases;}
 {Setup x;shift_final_position=true;x.go();check(moves==0&&invalidations==0,"position revalidated after snapshot before chosen movement");++cases;}
 {Setup x;fuel=24000;x.go();check(moves==0&&camp_reads==0,"strict eighteen-thousand plus six-thousand reserve boundary");++cases;}
 {Setup x;fuel=24001;x.go();check(moves==1,"above reserve boundary can build snapshot under cost-free mocks");++cases;}
 {Setup x;drop_at="camp_strength";x.go();check(moves==0&&camp_reads==4,"reserve falling during read-only camp batch aborts before movement");++cases;}
 {Setup x;x.camps.assign(25,{{26,23},0,500,3,1});x.go();check(moves==0&&camp_reads==0,"twenty-five input handles fail closed before scans");++cases;}
 {Setup x;x.camps.assign(24,{{26,23},0,500,3,1});x.go();check(moves==0&&camp_reads==48,"twenty-four harmless inputs are bounded and complete");++cases;}
 {Setup x;for(int i=0;i<7;++i)x.camps.push_back({{i,0},20,100,1,1});x.go();check(moves==1&&camp_reads==32,"eight hazard snapshot accepted with no redundant health or per-pose reads");++cases;}
 {Setup x;for(int i=0;i<8;++i)x.camps.push_back({{i,0},20,100,1,1});x.go();check(moves==0&&invalidations==0,"ninth positive awake hazard aborts whole snapshot");++cases;}
 for(const char*phase:{"camp_state","camp_strength","camp_position","camp_range","can_move","attack_range","me_position","width","height"}){Setup x;throw_at=phase;x.go();check(moves==0&&errors==1,"failed snapshot read retains original path");++cases;}
 for(const char*phase:{"camp_state","camp_strength","camp_position","camp_range","can_move","attack_range","me_position","width","height"}){Setup x;advance_at=phase;x.go();check(moves==0&&invalidations==0,"round-crossed read-only batch cannot authorize movement");++cases;}
 {Setup x;throw_at="camp_health";x.go();check(moves==1&&errors==0&&query_counts["camp_health"]==0,"awake state already means living; health SDK is never consulted");++cases;}
 for(const char*phase:{"can_move","me_position"}){Setup x;advance_at=phase;advance_on_call=2;x.go();check(moves==0&&invalidations==0,"round crossing during final once-read guard aborts before mutation");++cases;}
 {Setup x;throw_at="me_position";throw_on_call=2;x.go();check(moves==0&&errors==1&&invalidations==0,"failed final position read aborts before mutation");++cases;}
 {Setup x;drop_at="me_position";drop_on_call=2;x.go();check(moves==0&&invalidations==0,"reserve drop during final guard prevents move");++cases;}
 {Setup x;x.round=now_round=66;x.s.thr_r=66;x.pos=live_pos={26,12};x.me.id=owner=11;range_value=3;x.s.spawn_center={28,28};x.camps={{{26,9},60,2400,3,1}};Threat ryth;ryth.p={23,9};ryth.atk=170;ryth.ar=2;Threat ren;ren.p={22,7};ren.atk=40;ren.ar=2;ren.xd=200;ren.xr=4;x.s.thr={ryth,ren};campescape::Snapshot snap;snap.count=1;snap.hazards[0]={{26,9},60,3};check(campescape::exposure(snap,{25,11})==60,"exact native Tavi pose camp envelope");check(danger_at(x.s.thr,{25,11})==370,"exact native Tavi pose champion danger");check(campescape::exposure(snap,{25,12})==60,"exact native Tavi pose camp envelope");check(danger_at(x.s.thr,{25,12})==0,"exact native Tavi pose champion danger");check(campescape::exposure(snap,{25,13})==0,"exact native Tavi pose camp envelope");check(danger_at(x.s.thr,{25,13})==0,"exact native Tavi pose champion danger");check(campescape::exposure(snap,{26,11})==60,"exact native Tavi pose camp envelope");check(danger_at(x.s.thr,{26,11})==200,"exact native Tavi pose champion danger");check(campescape::exposure(snap,{26,13})==0,"exact native Tavi pose camp envelope");check(danger_at(x.s.thr,{26,13})==0,"exact native Tavi pose champion danger");check(campescape::exposure(snap,{27,11})==60,"exact native Tavi pose camp envelope");check(danger_at(x.s.thr,{27,11})==0,"exact native Tavi pose champion danger");check(campescape::exposure(snap,{27,12})==60,"exact native Tavi pose camp envelope");check(danger_at(x.s.thr,{27,12})==0,"exact native Tavi pose champion danger");check(campescape::exposure(snap,{27,13})==0,"exact native Tavi pose camp envelope");check(danger_at(x.s.thr,{27,13})==0,"exact native Tavi pose champion danger");x.go();check(moves==1&&live_pos==vec2(26,13),"TaviR66 official direction order preserves equally safe legacy cardinal endpoint");check(shoots==1&&hits==0,"Tavi ranged step then shoot order retained");++cases;}
 {Setup x;move_success=false;x.go();check(moves==0&&flees==1&&shoots==1&&invalidations==1,"failed chosen move falls back to exact old policy");++cases;}
 {Setup x;throw_at="move";x.go();check(moves==0&&errors==1&&flees==1,"throwing chosen action falls back without successful-escape claim");++cases;}
 {Setup x;move_crosses=true;x.go();check(moves==1&&now_round==107&&shoots==1,"move itself can suspend; no atomicity guarantee is asserted");++cases;}
 {Setup x;campescape::Snapshot q;q.hazards[0]={{26,23},60,3};q.count=1;const int prior=camp_reads;auto p=campescape::choose(x.s,q,x.pos,36,36);check(p&&p->y==19&&camp_reads==prior&&pos_reads==0,"pose selection has no SDK reads");++cases;}
#endif
 std::printf("PASS enabled=%d cases=%d/n",P_CAMP_ESCAPE,cases);
}
