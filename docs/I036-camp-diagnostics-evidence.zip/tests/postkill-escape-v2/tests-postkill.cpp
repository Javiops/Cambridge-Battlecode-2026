
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <variant>
#include <vector>
#include "params.h"
struct vec2{int x=0,y=0;vec2()=default;vec2(int xx,int yy):x(xx),y(yy){}bool operator==(const vec2&)const=default;double chebyshev_distance(vec2 p)const{return std::max(std::abs(x-p.x),std::abs(y-p.y));}};
inline int now_round=20;inline std::uint64_t fuel=90000;inline int errors=0,moves=0,move_attempts=0,lists=0,unit_queries=0,state_queries=0;
inline std::string advance_at,throw_at;inline int fail_move_count=0;inline bool advance_move=false;
void hook(const char*name){if(advance_at==name){++now_round;advance_at.clear();}if(throw_at==name){throw_at.clear();throw std::runtime_error(name);}}
namespace bc{
std::uint32_t round_number(){return now_round;}std::uint64_t fuel_remaining(){hook("fuel");return fuel;}
struct bitboard{std::set<std::pair<int,int>> bits;bool is_set(vec2 p)const{hook("mask");return bits.count({p.x,p.y});}void add(vec2 p){bits.insert({p.x,p.y});}};
inline vec2 positions[10];inline bool alive[10];inline float hp[10];inline bool movable=true;
struct champion{int id=0;bool operator==(const champion&)const=default;bool can_move()const{hook("can_move");return movable;}vec2 position()const{hook(id==0?"self_position":"ally_position");return positions[id];}bool is_alive()const{hook("ally_alive");return alive[id];}float health()const{hook("health");return hp[id];}bool move_absolute(vec2 p){++move_attempts;hook("move");if(advance_move){++now_round;advance_move=false;}if(fail_move_count){--fail_move_count;return false;}positions[id]=p;movable=false;++moves;return true;}};
inline std::vector<champion> roster;inline bitboard units;
namespace vision{std::vector<champion> champions(int){++lists;hook("allies");return roster;}bitboard champion_tiles(){++unit_queries;hook("units");return units;}}
namespace map{struct camp_group_reward_available{};struct camp_group_alive{};using group_state=std::variant<camp_group_reward_available,camp_group_alive>;struct camp_group{group_state value=camp_group_reward_available{};group_state state()const{++state_queries;hook("state");return value;}};}
}
struct Threat{vec2 p;double xd=0;int xr=-9;double fd=0;int fr=-9;int sr=-9;double atk=0;int ar=1;double ready=0;};
struct State{int nf_r=20,nf_d=7,thr_r=20,cap_start=-1;std::optional<int>my=1;bc::bitboard static_block,blocked;std::vector<Threat>thr;};
struct Group{std::optional<bc::map::camp_group>obj;bc::bitboard mask;std::vector<vec2>tiles;};
constexpr std::uint64_t FUEL_RESERVE=6000;
const char*g_farm="original";void note_error(const char*){++errors;}

inline int dist(vec2 a, vec2 b) { return static_cast<int>(a.chebyshev_distance(b)); }
inline bool fuel_ok(std::uint64_t need) { return bc::fuel_remaining() > need + FUEL_RESERVE; }
template <class F>
bool attempt(F&& f) {
    try {
        return f();
    } catch (const std::exception& e) {
        note_error(e.what());
        return false;
    } catch (...) {
        note_error("unknown exception");
        return false;
    }
}
inline double danger_at(const std::vector<Threat>& th, vec2 t) {
    double sum = 0;
    bool stun = false;
    for (auto& x : th) {
        int d = dist(t, x.p);
        double sp = 0;
        if (d <= x.xr) sp = x.xd;
        if (d <= x.fr + 1) sp = std::max(sp, x.fd);
        sum += sp + (d <= x.ar ? x.atk : 0.0);
        if (d <= x.sr + 1) stun = true;
    }
    if (stun)  // stunned for a round: the ready casters one step out get to stand and cast after
        for (auto& x : th) {
            int d = dist(t, x.p);
            if (d > x.xr && d <= x.xr + 1) sum += 0.5 * x.xd;
        }
    return sum;
}
#define EXPECT_ADAPTED 1

void check(bool b,const char*why){if(!b){std::fprintf(stderr,"FAIL %s/n",why);std::exit(1);}}
void run(State&s,bc::champion&me,Group&g,int round){
#if P_CF_POSTKILL_CAPTURE
        // A finisher may still move after its attack. Authoritative group state,
        // rather than our pre-attack live list, proves the whole reward is ready.
        // Queries can suspend across a round: abandon the extra move if the
        // enemy-distance/threat snapshot no longer belongs to this round.
        if (me.can_move() && bc::round_number() == round &&
            s.nf_r == round && s.nf_d > 6 && fuel_ok(12000)) {
            bool fully_cleared = false;
            if (g.obj) attempt([&] {
                fully_cleared = std::holds_alternative<bc::map::camp_group_reward_available>(g.obj->state());
                return true;
            });
            if (fully_cleared && bc::round_number() == round) {
                const vec2 now = me.position();
                // Already on the footprint: retain capture without rebuilding
                // the allied roster just to discover that no move is needed.
                if (!g.mask.is_set(now)) {
                    bool occupied_by_ally = false;
                    const bool occupancy_known = attempt([&] {
                        for (const auto& a : bc::vision::champions(*s.my)) {
                            if (a == me || !a.is_alive()) continue;
                            if (g.mask.is_set(a.position())) { occupied_by_ally = true; break; }
                        }
                        return true;
                    });
                    if (occupancy_known && !occupied_by_ally && bc::round_number() == round) {
                        // s.blocked still contains killed monsters; query live
                        // champion occupancy instead of rejecting vacated tiles.
                        const bc::bitboard current_units = bc::vision::champion_tiles();
                        for (auto t : g.tiles) {
                            if (bc::round_number() != round) break;
                            if (dist(now, t) != 1 || s.static_block.is_set(t) || current_units.is_set(t)) continue;
                            if (s.thr_r == round && danger_at(s.thr, t) >= me.health() * 0.3) continue;
                            if (bc::round_number() != round) break;
                            if (attempt([&] { return me.move_absolute(t); })) {
                                g_farm = "postkill-capture";
                                // The action itself is not atomic with the
                                // preceding SDK checks; record its actual round.
                                s.cap_start = static_cast<int>(bc::round_number());
                                break;
                            }
                        }
                    }
                }
            }
        }
#endif
}
struct Setup{State s;bc::champion me{0};Group g;Setup(){now_round=20;fuel=90000;errors=moves=move_attempts=lists=unit_queries=state_queries=0;advance_at.clear();throw_at.clear();fail_move_count=0;advance_move=false;bc::movable=true;bc::units={};bc::roster={{0}};g_farm="original";for(int i=0;i<10;++i){bc::positions[i]={15,15};bc::alive[i]=true;bc::hp[i]=1000;}bc::positions[0]={0,0};g.obj=bc::map::camp_group{};g.tiles={{1,0}};g.mask.add({1,0});s.blocked.add({1,0});}void go(){run(s,me,g,20);}};
int main(){int cases=0;
#if !P_CF_POSTKILL_CAPTURE
    Setup x;x.go();check(moves==0&&lists==0&&state_queries==0&&unit_queries==0,"disabled block has no extra queries/actions");++cases;
#else
    {Setup x;x.go();check(moves==1&&bc::positions[0]==vec2(1,0)&&x.s.cap_start==20,"newly vacated stale-blocked tile captures immediately");check(std::string(g_farm)=="postkill-capture","successful marker");++cases;}
    {Setup x;x.g.obj->value=bc::map::camp_group_alive{};x.go();check(moves==0&&lists==0,"authoritative hidden group member prevents false clearance");++cases;}
    {Setup x;x.g.obj.reset();x.go();check(moves==0&&lists==0,"missing group handle is no proof of clearance");++cases;}
    {Setup x;throw_at="state";x.go();check(moves==0&&errors==1,"group-state error fails safely");++cases;}
    {Setup x;bc::movable=false;x.go();check(moves==0&&state_queries==0,"no remaining movement");++cases;}
    {Setup x;x.s.nf_r=19;x.go();check(moves==0&&state_queries==0,"stale nearest-enemy snapshot");++cases;}
    {Setup x;x.s.nf_d=6;x.go();check(moves==0&&state_queries==0,"nearby enemy suppresses optional capture move");++cases;}
    {Setup x;fuel=18000;x.go();check(moves==0&&state_queries==0,"strict real reserve boundary");++cases;}
    {Setup x;fuel=18001;x.go();check(moves==1,"reserve above boundary permits useful move");++cases;}
    {Setup x;bc::roster={{0},{1}};bc::positions[1]={1,0};x.go();check(moves==0,"living ally on footprint retains sole capture");++cases;}
    {Setup x;bc::roster={{0},{1}};bc::positions[1]={1,0};bc::alive[1]=false;x.go();check(moves==1,"dead ally does not reserve reward");++cases;}
    {Setup x;bc::units.add({1,0});x.go();check(moves==0,"fresh occupancy prevents stepping into a current champion");++cases;}
    {Setup x;x.s.static_block.add({1,0});x.go();check(moves==0,"static blocked tile excluded");++cases;}
    {Setup x;x.g.tiles={{2,0}};x.g.mask={};x.g.mask.add({2,0});x.go();check(moves==0,"only one-step reward tile considered");++cases;}
    {Setup x;Threat t;t.p={1,0};t.atk=300;x.s.thr={t};x.go();check(moves==0,"30 percent health threat excluded");++cases;}
    {Setup x;Threat t;t.p={1,0};t.atk=299;x.s.thr={t};x.go();check(moves==1,"threat threshold unchanged below30percent");++cases;}
    {Setup x;throw_at="move";x.go();check(moves==0&&x.s.cap_start==-1&&errors==1,"failed SDK move never publishes capture");++cases;}
    {Setup x;x.g.tiles.push_back({0,1});x.g.mask.add({0,1});fail_move_count=1;x.go();check(moves==1&&move_attempts==2&&bc::positions[0]==vec2(0,1),"failed candidate can try next safe tile");++cases;}
    {Setup x;bc::positions[0]={1,0};x.go();
#if EXPECT_ADAPTED
        check(lists==0&&unit_queries==0&&moves==0,"already on reward avoids roster/occupancy work");
#else
        check(lists==1&&moves==0,"counterexample original needlessly scans allies on reward");
#endif
        ++cases;}
    {Setup x;throw_at="allies";x.go();
#if EXPECT_ADAPTED
        check(moves==0&&errors==1,"failed whole occupancy query fails closed");
#else
        check(moves==1&&errors==1,"counterexample original moves after failed ally scan");
#endif
        ++cases;}
    {Setup x;bc::roster={{0},{1}};throw_at="ally_position";x.go();
#if EXPECT_ADAPTED
        check(moves==0&&errors==1,"partial occupancy scan fails closed");
#else
        check(moves==1&&errors==1,"counterexample original moves after partial ally scan");
#endif
        ++cases;}
    for(const char*phase:{"can_move","fuel","state","self_position","mask","allies","units","health"}){
        Setup x;if(std::string(phase)=="health"){Threat t;t.p={1,0};t.atk=1;x.s.thr={t};}advance_at=phase;x.go();
#if EXPECT_ADAPTED
        check(moves==0,"round-advancing SDK query cannot use stale threat/distance snapshot");
#else
        check(moves==1,"counterexample original uses old round after SDK suspension");
#endif
        ++cases;
    }
    for(const char*phase:{"self_position","units","health"}){
        Setup x;if(std::string(phase)=="health"){Threat t;t.p={1,0};t.atk=1;x.s.thr={t};}throw_at=phase;bool threw=false;try{x.go();}catch(...){threw=true;}
        check(threw&&moves==0&&x.s.cap_start==-1,"uncaught read failure unwinds before any extra move");++cases;
    }
    {Setup x;advance_move=true;x.go();check(moves==1,"move SDK itself may suspend; no atomicity claim");
#if EXPECT_ADAPTED
        check(x.s.cap_start==21,"successful capture records actual action round");
#else
        check(x.s.cap_start==20,"counterexample original records stale capture round");
#endif
        ++cases;}
#endif
    std::printf("PASS cases=%d enabled=%d adapted=%d/n",cases,P_CF_POSTKILL_CAPTURE,EXPECT_ADAPTED);
}
