# I036-r2 corrected packaging revision

This is a packaging correction to the immutable original I036 snapshot. The original report and ZIP remain available at their original names and hashes; they are historical provenance, not the corrected executable fixture package. The accompanying report links both original artifacts explicitly.

The earlier exporter globally replaced backslashes. All 14 CPP fixture entries differed from their bound tested inputs; r2 restores all 14 byte-for-byte. Of 8 source patches, 0 contained changed escapes beyond line endings; r2 regenerates all canonical LF diffs from the unchanged source ZIPs and verifies exact output bytes. The audit also checks all 77 bound JSON inputs: 0 entries and 0 leaves need semantic corrections beyond the original representation. Each change is recorded in packaging-correction-audit.json; no arbitrary escape rewriting is applied.

All 96 original input hashes still match. Source archives, native summary/ledger bytes, source identities, match results and recorded test outcomes are unchanged. No tests, compiler builds or games were rerun. Restoring code to its already-tested input is not a fresh test pass or a completed promotion gate. I035 remains selected.

Historical report SHA256: cd5362c48289c9d2fc728218f164943670e08f4f1749130c818e865383b99c4e
Historical ZIP SHA256: 36c541f3506fb224f2cf267007e216a07feae0cf66cea3c7029241e652b15de5

Intended corrected report: https://github.com/Javiops/Cambridge-Battlecode-2026/blob/main/docs/I036-r2-camp-lifecycle-diagnostics.md

The original portable fixture instructions remain under tests/README.md. Fixtures now preserve exact original bytes, including escapes; the matching source ZIPs were never altered. Patches preserve canonical generated LF text rather than claiming the raw source snapshots had LF line endings. The original integrity manifest is preserved under historical/; the r2 integrity manifest binds this corrected artifact.

---

# I036 diagnostic evidence

Intended GitHub report URL (available after publication): https://github.com/Javiops/Cambridge-Battlecode-2026/blob/main/docs/I036-camp-lifecycle-diagnostics.md

The Markdown report and this archive retain separate sources/datasets. Source archives contain C++ only; no binary, account token, raw large replay or private absolute path is bundled. `scheduled-slots.csv` includes summary reuse markers; `summary.json` reports distinct records/streams and pending inputs. Probe slots reused by later panels are not independent new games. `input-bindings.json` hashes original inputs before portable path normalization.

`sources/`, `patches/`, `mechanisms/`, `causal/` and `tests/` retain exact source flags and recorded actual-source validation. Tests have not been rerun by the export. See tests/README.md for external compiler/SDK instructions. I035 remains the selected review source; these follow-up candidates are not promoted by this package.
