# Camp lifecycle guard: concrete decision audit

The lifecycle predicate is behaving correctly in the inspected streams. The useful regression is a coupling to recall admission: once a harmless resource no longer falsely blocks recall, the existing near-recall policy starts a channel which a visible enemy can interrupt. Keep the truthful camp predicate; fix the channel decision rather than restoring the false HP proxy.

This audit reconstructed four saved native replays and queried the two candidate-A streams with the official current-engine API. No new game, hypothetical action or production edit was made. All streams use engine0.0.3/native build `d7e29ae3546357b011419c764204b7b9e2232bdb1b07868250c6b35d4c18d2a5`; editor WASM SHA256 is `1919c5a6f2ea039041071166aef38f6f1ede8d5c29b062db8c2e028109e3f96f`.

## Exact controls and first divergences

Each comparison below has the same map, recorded seed, unchanged opponent source/binary and an exactly identical command prefix, including input/sequence metadata. These are one-side controls, unlike comparing candidate-A and candidate-B games with both physical policies swapped.

| Map | State-guard A score | Unchanged A score | First changed command | Identical preceding commands |
| --- | --- | --- | --- | --- |
| fresh-compact-open |592–1028|774–1028|Ren R59/input1404: recall instead of yield|1383|
| elkring |936–1008|864–1008|Cassi R145/input3539: recall instead of walking5,14|3518|

The four-slot state-guard panel itself finished2–2, splitting by map side. Neither these controls nor that panel establish a strength improvement.

## Compact: correct harmless classification opens an unsafe recall

At the first changed command Ren is at `(12,12)`,395/900HP,90gold and0gems. The only personally visible nearby camp is resource10 at `(15,16)`:400/500HP, strength0, awake state1, distance4. The old `health < max_health` proxy marks this dangerous; the new strength/awake test correctly does not. Enemy Ryth6 is personally visible at `(19,15)`, distance7.

The source accepts this through the existing `rsafe` relaxation: `P_RECALL_NEAR=7`, no recent hit and no awake damaging camp. `safe` itself is false because the nearest enemy is within8. Ren is above the33% emergency-flee threshold and below the healing threshold, making the near-recall branch at main.cpp4289–4296 the source-supported admission path. No per-call handler trace is present in this replay.

| Round | State guard | Unchanged control |
| --- | --- | --- |
|59|Starts recall at12,12|Yields at12,12|
|60|Channels,4 remaining|Walks to11,11|
|61|Channels,3 remaining|Walks to10,10|
|62|Channels,2 remaining|Starts recall at10,10|
|63|Ryth casts from16,12;100damage, channel interrupted with1 remaining|Channels unharmed|
|65|Spends dash and ordinary movement to9,10|Continues recall|
|66|Starts second recall|Continues recall|
|67|Channels|Arrives on spawn at end of round|
|71|Arrives on spawn at end of round|Already returned to field|

The candidate loses100HP and returns four rounds later despite starting recall three rounds earlier. Its position remains fixed while visible Ryth advances19,15→18,14→17,13→16,12. This is a demonstrated local cost of the newly admitted channel, not evidence a resource camp could damage Ren or that this one event explains the final182-gem score difference. No camp hit occurs in this channel sequence.

The next narrow correction should evaluate whether the visible foe can enter an interrupt envelope before the remaining channel completes. Reuse the same-round threat snapshot and account for attack/spell reach, approach, relevant cooldown recovery and dashes. The observed control supplies a concrete alternative: move two tiles away, then recall. A uniform `threat_at + 4` radius is only a conservative approximation: cooldowns, speed, terrain, future vision and pursuit matter. Do not turn this into a blanket refusal to farm or recall.

## Elkring: an earlier safe return also changes capture participation

At R145 Cassi is at `(6,15)`,351.25/771.25HP. Resource19 at `(3,19)` is300/500HP, strength0 and awake. No enemy is personally visible within the queried12-tile vicinity. The candidate correctly ignores this harmless camp and recalls immediately, arriving healed at spawn at end R150.

The unchanged control walks to `(3,12)` over three turns and recalls at R149, arriving at end R154. During its channel the control receives36gems and195gold on replay capture transition R153/group4. The candidate has already left and gets neither in this sequence. This demonstrates an opportunity tradeoff when recall timing and reward participation interact; neither path is a lifecycle classification error. The candidate still finishes with72 more submitted gems overall, so the local missed reward must not be promoted into a complete explanation of the game result.

## What the guard does, and what remains broken

At candidate first-command snapshots, Elkring has38 differing classifications:22 full-health awake damaging warnings newly recognized and16 stale/harmless HP warnings removed. Compact has356 differences:6 newly recognized and350 removed. These are repeated decision snapshots, not independent games or unique camps. There are1 and4 newly admitted recall starts respectively. The observed state/strength classifications match the API. Early full-HP awake warnings still permit normal forward movement and camp attacks; they do not globally stop farming.

The isolated source changes the `play_turn` `awake_camp_near` predicate used by `in_combat`, `safe` and `rsafe`. It does **not** replace farm's separate HP-based `engaged`/bail assumptions or the incoming-damage arithmetic. It is therefore not a tanking fix by itself.

Fuel is unresolved at function level. Elkring has zero exhaustion events in both exact controls. Compact has17 own/4 opposing events with the guard, versus12 own/13 opposing events unchanged. The earliest own event is Cassi R60 at the same statistics ordinal12408 in both streams (input1420 versus1419 after the extra recall command). The first policy divergence at R59 occurs before it; the later fuel difference cannot be attributed to this helper from these data. Do not interpret owner-grouped event order as chronological: R60 is the earliest event, not R279.

## Reproduction and bindings

`decision-audit.json` contains every source-file SHA256, both exact native record keys, map/seed/opponent checks, first changed commands, API camp/foe observations, trajectories, damage events, capture rewards and fuel timestamps. `manifest.json` and `control-manifest.json` bind extracted replay bytes to the original record files. `classifications.json` contains the complete recorded classification/recall samples. `write_report.py` rebuilds the compact JSON from those files and the decoded streams.

Current state-guard source binding: main.cpp SHA256 `fad83c13ffd2a88a0bb5cfa20e6af8279776d151774f9d67861ff12b7cc764b0`; params.h `b9123e389488e0437790d82d75cfe44685282a61cbdb3114ceea0cbbbcceb049`. Other source hashes are in the JSON. Camp API observations and decoded coordinates were read without applying alternative actions.
