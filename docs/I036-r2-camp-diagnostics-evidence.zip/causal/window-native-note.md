# First native recall-window decision

The replay does not isolate prevention of the old Ren R59 interruption: the world already changes at R34. The first observable window decision is nevertheless cleanly matched and confirms the intended admission change, together with its conservative tradeoff.

Native candidate record `9bb4224f34ea0898e2fc3fd3fb2f2ddfede7752319598b24ad4d6c2809e9fc0e` is state-window A versus unchanged roster-bound B on fresh-compact-open, finishing730–1028. Map, seed and opponent binary match the saved unchanged control. Its production source hashes exactly match `work/mate-v60/state-window/src`.

Against both the state-only replay and the unchanged control, the first837 commands match exactly, including sequence/input metadata. At R34/input858 Issac is at `(9,9)`,460/900HP,0gems and0gold. State-window moves to `(8,8)`; both other replays instead start recall at `(9,9)`.

The current native personal API shows one visible foe: Ryth6 at `(17,1)`, distance8, ordinary movement speed1, attack range1. Its damaging AoE has range4 plus radius1, is movement-exclusive and has1 remaining cooldown. Therefore legacy ready-only spell threat is absent, but the new helper projects range5 plus four ordinary approach turns: envelope9, covering distance8. It rejects the relaxed recall admission. This is a source reconstruction from authoritative visible metadata; private runtime `Threat` fields or a per-call branch reason were not logged.

| Observable result | State-window | Unchanged control |
| --- | --- | --- |
|R34|Moves9,9→8,8|Starts recall9,9|
|Recall start|R36 at8,8|R34 at9,9|
|Damage during this return|0|0|
|Spawn arrival|EndR41|EndR39|
|Local capture reward|44gems/180gold at R40/group0|None during this sequence|

Ryth actually moves away, so the old recall succeeds. The projection delays return by two rounds in this case rather than rescuing an observed failed channel. Moving onto8,8 also permits reward capture during the later recall. Those are the demonstrated local costs and benefits; neither establishes why the eventual match score differs.

By R59 the new Ren is at `(10,9)`,110/900HP, already channeling a recall begun at R56. The original state-only witness had Ren at `(12,12)`,395/900HP, starting an unsafe recall at R59. These states are not interchangeable. The existing actual-source fixture rejects the saved Ren packet (exact cooldown3; round-start snapshot4), proving helper arithmetic, while this native replay proves an earlier admission change. Do not claim that this game causally demonstrates a saved Ren at R59.

`decision-note.json` binds candidate/control identity, source hashes, exact first differing commands, API metadata, trajectories, damage and capture events. `actual-veto-inputs.json` contains the native read-only pre-command snapshots. No additional game, source revision or hypothetical action was applied.
