"""Correct packaging of the immutable I036 snapshot; no tests or games.

The old report/archive stay unchanged. Sources and outcomes are taken from
that archive; original input bindings restore the exact already-tested CPP.
"""
from pathlib import Path
import difflib
import hashlib
import io
import json
import re
import zipfile

DOCS = Path(__file__).resolve().parent
ROOT = DOCS.parents[1]
WORKSPACE = ROOT.parents[1]
sha = lambda value: hashlib.sha256(value).hexdigest()
file_sha = lambda path: sha(Path(path).read_bytes())
old_report = DOCS / 'I036-camp-lifecycle-diagnostics.md'
old_archive = DOCS / 'I036-camp-diagnostics-evidence.zip'
historical = {'report': old_report.name, 'report_sha256': file_sha(old_report), 'archive': old_archive.name, 'archive_sha256': file_sha(old_archive)}
assert historical['report_sha256'] == 'cd5362c48289c9d2fc728218f164943670e08f4f1749130c818e865383b99c4e'
assert historical['archive_sha256'] == '36c541f3506fb224f2cf267007e216a07feae0cf66cea3c7029241e652b15de5'
with zipfile.ZipFile(old_archive) as archive:
    assert archive.testzip() is None
    original = {name: archive.read(name) for name in archive.namelist()}
entries = dict(original)
bindings = json.loads(original['input-bindings.json'])
source_manifest = json.loads(original['source-manifest.json'])

def portable(value):
    """Only redact actual path prefixes; never rewrite arbitrary escapes."""
    if isinstance(value, dict): return {key: portable(item) for key, item in value.items()}
    if isinstance(value, list): return [portable(item) for item in value]
    if not isinstance(value, str): return value
    absolute_path = bool(re.match(r'^[A-Za-z]:[/\\]', value)) and '\n' not in value and '\r' not in value
    for prefix in [str(WORKSPACE), str(WORKSPACE).replace('\\', '/')]: value = value.replace(prefix, 'workspace')
    value = re.sub(r'[A-Za-z]:[/\\]+Users[/\\]+[^/\\\s"\']+', '<user>', value)
    return value.replace('\\', '/') if absolute_path else value

def json_bytes(value): return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
def difference(old, new, path='$'):
    if isinstance(old, dict) and isinstance(new, dict):
        return sum((difference(old.get(key), new.get(key), path + '.' + str(key)) for key in old.keys() | new.keys()), [])
    if isinstance(old, list) and isinstance(new, list) and len(old) == len(new):
        return sum((difference(a, b, path + '[' + str(i) + ']') for i, (a, b) in enumerate(zip(old, new))), [])
    return [] if old == new else [{'field': path, 'historical_value': old, 'corrected_value': new}]

input_audit, cpp_audit, json_audit, text_audit = [], [], [], []
for name, binding in bindings.items():
    path = WORKSPACE / binding['original_input']
    raw = path.read_bytes()
    assert sha(raw) == binding['original_input_sha256'], (name, 'bound original changed; do not substitute a new input')
    input_audit.append({'entry': name, 'original_input': binding['original_input'], 'original_input_sha256': sha(raw), 'still_matches_historical_binding': True})
    if name.endswith('.cpp'):
        assert not re.search(rb'[A-Za-z]:[/\\]+Users[/\\]+frans', raw)
        entries[name] = raw
        cpp_audit.append({'entry': name, 'historical_archive_sha256': sha(original[name]), 'bound_input_sha256': sha(raw), 'corrected_archive_sha256': sha(entries[name]), 'historical_byte_identity': original[name] == raw, 'corrected_byte_identity': True, 'historical_lost_backslash_count': raw.count(b'\\') - original[name].count(b'\\')})
    elif name.endswith('.json'):
        old = json.loads(original[name]); corrected = portable(json.loads(raw))
        changes = difference(old, corrected)
        if changes: entries[name] = json_bytes(corrected)
        json_audit.append({'entry': name, 'semantic_changes': changes, 'changed_leaf_count': len(changes), 'unchanged_json_bytes_retained_when_semantics_match': not changes})
    else:
        # Preserve bound prose bytes where no privacy redaction is necessary.
        text = raw.decode(); corrected = portable(text)
        entries[name] = raw if corrected == text else corrected.encode()
        text_audit.append({'entry': name, 'historical_archive_sha256': sha(original[name]), 'corrected_archive_sha256': sha(entries[name]), 'bound_input_sha256': sha(raw), 'corrected_byte_identity': entries[name] == raw})

# Patches were generated, not bound as standalone inputs. Reconstruct each
# untransformed canonical LF diff exclusively from the embedded frozen sources.
sources = {}
for candidate, info in source_manifest['sources'].items():
    with zipfile.ZipFile(io.BytesIO(original[info['source_archive']])) as archive:
        assert archive.testzip() is None
        files = {Path(name).name: archive.read(name) for name in archive.namelist()}
    assert {name: sha(raw) for name, raw in files.items()} == info['source_sha256']
    sources[candidate] = files
selected = sources['v60-camp-roster-bound']
patch_audit = []
for name in sorted(original):
    if not name.endswith('.patch'): continue
    candidate = Path(name).stem
    target = sources[candidate]
    patch = ''
    for filename in sorted(target):
        if sha(target[filename]) == (sha(selected[filename]) if filename in selected else None): continue
        old = selected[filename].decode().replace('\r\n', '\n').splitlines(True) if filename in selected else []
        new = target[filename].decode().replace('\r\n', '\n').splitlines(True)
        patch += ''.join(difflib.unified_diff(old, new, fromfile='selected/src/' + filename if filename in selected else '/dev/null', tofile=candidate + '/src/' + filename))
    entries[name] = patch.encode()
    patch_audit.append({'entry': name, 'historical_archive_sha256': sha(original[name]), 'canonical_untransformed_diff_sha256': sha(entries[name]), 'corrected_archive_sha256': sha(entries[name]), 'canonical_byte_identity': True, 'historical_matches_after_line_ending_normalization': original[name].replace(b'\r\n', b'\n') == entries[name], 'historical_lost_backslash_count': entries[name].count(b'\\') - original[name].count(b'\\'), 'line_endings': 'Canonical generated patch uses LF; frozen source bytes and their original raw hashes remain in the unchanged source ZIPs.'})

# Byte-unchanged source ZIPs and native outcomes are a strict revision boundary.
for name, raw in original.items():
    if name.startswith('sources/') or name in ['summary.json', 'native-summaries.json', 'scheduled-slots.csv', 'matched-selected-raw-controls.csv', 'maps.json', 'maps.zip']:
        assert entries[name] == raw
json_changes = [row for row in json_audit if row['changed_leaf_count']]
audit = {'status': 'corrected packaging only; original snapshot retained', 'historical_snapshot': historical, 'bound_inputs_checked': len(input_audit), 'stale_inputs': 0, 'cpp_fixture_entries': len(cpp_audit), 'cpp_entries_different_from_original_bound_bytes': sum(not row['historical_byte_identity'] for row in cpp_audit), 'cpp_entries_restored_byte_for_byte': len(cpp_audit), 'patch_entries': len(patch_audit), 'patch_entries_with_material_escape_changes_beyond_line_endings': sum(not row['historical_matches_after_line_ending_normalization'] for row in patch_audit), 'bound_json_entries_checked': len(json_audit), 'json_entries_with_semantic_changes': len(json_changes), 'json_changed_leaves': sum(row['changed_leaf_count'] for row in json_audit), 'json_semantic_changes': json_changes, 'input_bindings': input_audit, 'cpp': cpp_audit, 'patches': patch_audit, 'bound_text': text_audit, 'source_archives_byte_unchanged': True, 'native_summary_and_ledger_bytes_unchanged': True, 'sources_tests_games_and_outcomes_changed': False, 'tests_builds_or_games_rerun': False, 'reason': 'The original global backslash replacement changed escapes in executable CPP after the tests were recorded. This revision restores the actual bound tested fixtures. All source patches and bound JSON were reviewed as well; no material escape corruption was found there. Canonical patch bytes are verified without claiming raw source snapshots use LF. No tests, source, games, outcomes or policy are changed.'}
entries['historical/I036-original-integrity.json'] = original['integrity.json']
entries['packaging-correction-audit.json'] = json_bytes(audit)
entries['historical/snapshot.json'] = json_bytes(historical)
notice = f'''# I036-r2 corrected packaging revision

This is a packaging correction to the immutable original I036 snapshot. The original report and ZIP remain available at their original names and hashes; they are historical provenance, not the corrected executable fixture package. The accompanying report links both original artifacts explicitly.

The earlier exporter globally replaced backslashes. All {len(cpp_audit)} CPP fixture entries differed from their bound tested inputs; r2 restores all {len(cpp_audit)} byte-for-byte. Of {len(patch_audit)} source patches, {sum(not row['historical_matches_after_line_ending_normalization'] for row in patch_audit)} contained changed escapes beyond line endings; r2 regenerates all canonical LF diffs from the unchanged source ZIPs and verifies exact output bytes. The audit also checks all {len(json_audit)} bound JSON inputs: {len(json_changes)} entries and {sum(row['changed_leaf_count'] for row in json_audit)} leaves need semantic corrections beyond the original representation. Each change is recorded in packaging-correction-audit.json; no arbitrary escape rewriting is applied.

All {len(input_audit)} original input hashes still match. Source archives, native summary/ledger bytes, source identities, match results and recorded test outcomes are unchanged. No tests, compiler builds or games were rerun. Restoring code to its already-tested input is not a fresh test pass or a completed promotion gate. I035 remains selected.

Historical report SHA256: {historical['report_sha256']}
Historical ZIP SHA256: {historical['archive_sha256']}

Intended corrected report: https://github.com/Javiops/Cambridge-Battlecode-2026/blob/main/docs/I036-r2-camp-lifecycle-diagnostics.md

The original portable fixture instructions remain under tests/README.md. Fixtures now preserve exact original bytes, including escapes; the matching source ZIPs were never altered. Patches preserve canonical generated LF text rather than claiming the raw source snapshots had LF line endings. The original integrity manifest is preserved under historical/; the r2 integrity manifest binds this corrected artifact.
'''
entries['README.md'] = notice.encode() + b'\n---\n\n' + original['README.md']
old_text = old_report.read_text()
r2_report = '# I036-r2: packaging correction\n\n' + notice.split('\n', 2)[2] + '\nThe [original report](I036-camp-lifecycle-diagnostics.md) and [original historical ZIP](I036-camp-diagnostics-evidence.zip) are preserved. Use the [corrected r2 evidence ZIP](I036-r2-camp-diagnostics-evidence.zip) for the executable fixture bytes.\n\n---\n\n' + old_text.replace('[evidence ZIP](I036-camp-diagnostics-evidence.zip)', '[corrected evidence ZIP](I036-r2-camp-diagnostics-evidence.zip)')
reportfile = DOCS / 'I036-r2-camp-lifecycle-diagnostics.md'; reportfile.write_bytes(r2_report.encode())
entries['packaging-revision-builder.py'] = Path(__file__).read_bytes()
entries.pop('integrity.json')
entries['integrity.json'] = json_bytes({'status': 'pass', 'revision': 'I036-r2 packaging correction', 'report_sha256': file_sha(reportfile), 'builder_sha256': file_sha(__file__), 'historical_snapshot': historical, 'source_archives_byte_unchanged': True, 'native_summary_and_ledger_bytes_unchanged': True, 'cpp_input_byte_identity': True, 'patch_canonical_byte_identity': True, 'no_tests_builds_games_sources_or_outcomes_changed': True, 'files': {name: sha(raw) for name, raw in sorted(entries.items())}})

def zip_bytes(files):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(files.items()):
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0)); info.compress_type = zipfile.ZIP_DEFLATED; info.external_attr = 0o100644 << 16
            archive.writestr(info, raw, compresslevel=9)
    raw = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(raw)) as archive: assert archive.testzip() is None
    return raw

raw = zip_bytes(entries); assert raw == zip_bytes(entries)
archivefile = DOCS / 'I036-r2-camp-diagnostics-evidence.zip'; archivefile.write_bytes(raw)
assert file_sha(old_report) == historical['report_sha256'] and file_sha(old_archive) == historical['archive_sha256']
assert all(not re.search(rb'[A-Za-z]:[/\\]+Users[/\\]+frans', data) for name, data in entries.items() if not name.endswith('.zip'))
result = {'status': 'pass packaging correction only', 'report': reportfile.name, 'report_sha256': file_sha(reportfile), 'archive': archivefile.name, 'archive_sha256': file_sha(archivefile), 'archive_entries': len(entries), 'archive_bytes': len(raw), 'historical_snapshot': historical, 'audit_counts': {key: audit[key] for key in ['bound_inputs_checked', 'stale_inputs', 'cpp_fixture_entries', 'cpp_entries_different_from_original_bound_bytes', 'patch_entries', 'patch_entries_with_material_escape_changes_beyond_line_endings', 'bound_json_entries_checked', 'json_entries_with_semantic_changes', 'json_changed_leaves']}, 'deterministic_zip_crc_input_byte_equality': True, 'no_tests_builds_games_sources_or_outcomes_changed': True}
(DOCS / 'I036-r2-package-audit.json').write_bytes(json_bytes(result))
print(json.dumps(result, indent=2))
