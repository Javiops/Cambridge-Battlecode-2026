
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <exception>
#include <stdexcept>
#include <string>
#include <vector>
#include "params.h"
std::string reads;
int live_round=40, errors=0;
char fail_op=0, advance_op=0;
int fail_nth=0, advance_nth=0, call_counts[256]{};
void read(char op) {
    reads.push_back(op); int n=++call_counts[static_cast<unsigned char>(op)];
    if(op==advance_op && n==advance_nth) ++live_round;
    if(op==fail_op && (!fail_nth || n==fail_nth)) throw std::runtime_error("unavailable mock API");
}
namespace bc {
struct vec2 {int x=0,y=0;vec2(int a=0,int b=0):x(a),y(b){};
    int chebyshev_distance(vec2 o)const{return std::max(std::abs(x-o.x),std::abs(y-o.y));}};
struct camp_state {int value;bool is_awake()const{return value==1;}};
struct camp {
    vec2 p{4,0}; float hp=500,max_hp=1000,str=60; int lifecycle=1;
    vec2 position()const{read('P');return p;}
    float health()const{read('H');return hp;}
    float max_health()const{read('M');return max_hp;}
    float strength()const{read('S');return str;}
    camp_state state()const{read('A');return {lifecycle};}
};
unsigned round_number(){read('R');return live_round;}
}
using bc::vec2;
void note_error(const char*){++errors;}

constexpr int CAMP_RANGE = 3;    // all monsters attack at range 3
inline int dist(vec2 a, vec2 b) { return static_cast<int>(a.chebyshev_distance(b)); }
template <class F>
bool attempt(F&& f) {
    try {
        return f();
    } catch (const std::exception& e) {
        note_error(e.what());
        return false;
    } catch (...) {
        note_error("unknown exception");
        return false;
    }
}
bool damaging_camps_awake_near(const std::vector<bc::camp>& camps, vec2 pos, int owner_round) {
    const auto legacy_near = [&](const bc::camp& c) {
        bool near = false;
        attempt([&] {
            if (dist(c.position(), pos) <= CAMP_RANGE + 1 && c.health() < c.max_health()) near = true;
            return true;
        });
        return near;
    };
    const auto legacy_all = [&] {
        bool near = false;
        for (const auto& c : camps)
            if (legacy_near(c)) near = true;
        return near;
    };
    if (!P_CAMP_STATE_GUARD) return legacy_all();
    if (camps.empty()) return false;

    const bool fresh_begin = attempt([&] {
        return static_cast<int>(bc::round_number()) == owner_round;
    });
    bool active = false, failed_legacy = false;
    for (const auto& c : camps) {
        bool local_active = false;
        const bool known = attempt([&] {
            if (dist(c.position(), pos) <= CAMP_RANGE + 1 && c.strength() > 0)
                local_active = c.state().is_awake();
            return true;
        });
        if (local_active) active = true;
        if (!known && legacy_near(c)) failed_legacy = true;
    }
    const bool fresh_end = attempt([&] {
        return static_cast<int>(bc::round_number()) == owner_round;
    });
    if (fresh_begin && fresh_end) return active || failed_legacy;
    return active || failed_legacy || legacy_all();
}
bool legacy_loop(std::vector<bc::camp>& camps, vec2 pos, int round) {
    bool awake_camp_near = false;
    for (auto& c : camps)
        attempt([&] {
            if (dist(c.position(), pos) <= CAMP_RANGE + 1 && c.health() < c.max_health()) awake_camp_near = true;
            return true;
        });
    return awake_camp_near;
}
bool actual_loop(std::vector<bc::camp>& camps, vec2 pos, int round) {
    bool awake_camp_near = damaging_camps_awake_near(camps, pos, round);
    return awake_camp_near;
}

int checks=0;
void check(bool value,const char*why){++checks;if(!value){std::fprintf(stderr,"FAIL %s reads=%s errors=%d round=%d\n",why,reads.c_str(),errors,live_round);std::exit(1);}}
void reset(){reads.clear();live_round=40;errors=0;fail_op=advance_op=0;fail_nth=advance_nth=0;for(auto&n:call_counts)n=0;}
bool single(const bc::camp& c,int owner=40){return damaging_camps_awake_near(std::vector<bc::camp>{c},{0,0},owner);}
bool legacy_single(bc::camp c){std::vector<bc::camp> list{c};return legacy_loop(list,{0,0},40);}
void expect(bc::camp c,bool enabled,bool disabled,const char*why){reset();check(single(c)==(P_CAMP_STATE_GUARD?enabled:disabled),why);}
int main(){
 bc::camp c;
 c.hp=1000;expect(c,true,false,"full HP awake damaging camp is detected");
 c.hp=500;c.lifecycle=2;expect(c,false,true,"wounded dormant camp is not active");
 c.hp=1000;expect(c,false,false,"full HP dormant camp remains harmless to guard");
 c.hp=500;c.lifecycle=1;expect(c,true,true,"wounded awake monster remains active");
 c.str=0;expect(c,false,true,"zero strength resource is not a damaging threat");
 c.str=-1;expect(c,false,true,"nonpositive strength is not a damaging threat");
 c.str=60;c.lifecycle=0;expect(c,false,true,"dead wounded camp is not a current threat");
 c.lifecycle=1;c.p={4,4};expect(c,true,true,"existing Chebyshev boundary four stays inclusive");
 c.p={5,0};expect(c,false,false,"outside unchanged radius is excluded");

 // Fresh success has at most one info read each for position/strength/state,
 // and exactly two cheap round reads. No HP/max/roster/inventory queries.
 c.p={3,0};c.str=60;c.lifecycle=1;c.hp=1000;reset();single(c);
#if P_CAMP_STATE_GUARD
 check(reads=="RPSAR","fresh damaging camp reads exactly position strength state and two round guards");
 c.str=0;reset();single(c);check(reads=="RPSR","harmless camp skips state query");
 c.p={5,0};reset();single(c);check(reads=="RPR","out of range camp only reads position and round guards");
#else
 check(reads=="PHM","disabled helper preserves legacy position-health-max order and no new APIs");
#endif

 c.p={2,0};c.str=60;c.lifecycle=2;c.hp=500;
#if P_CAMP_STATE_GUARD
 for(char op:std::string("SA")){
  reset();fail_op=op;check(single(c),"failed strength/state read retains legacy wounded warning");
  check(errors==1,"SDK failure remains caught");check(reads.find("PHM")!=std::string::npos,"failed refined observation retries exact old predicate");
 }
 reset();fail_op='P';check(!single(c),"hidden camp with no readable position remains legacy false");check(errors==2,"both new and legacy hidden reads are caught");
 reset();fail_op='R';fail_nth=1;check(single(c),"first round query failure falls back rather than escaping");check(errors==1,"round failure caught");
 reset();fail_op='R';fail_nth=2;check(single(c),"last round query failure cannot clear legacy warning");
 c.hp=1000;c.lifecycle=1;reset();fail_op='R';fail_nth=2;check(single(c),"positive awake evidence is retained even if final round read fails");check(reads.find('H')==std::string::npos,"positive conservative result avoids legacy retry");
 c.hp=500;c.lifecycle=2;
 for(char op:std::string("PSA")){
  reset();advance_op=op;advance_nth=1;
  check(single(c),"suspended observation cannot clear owner-round legacy warning");check(live_round==41,"fixture suspension crossed a round");
  check(reads.find("PHM")!=std::string::npos,"stale negative observation triggers legacy fallback");
  reads.clear();for(auto&n:call_counts)n=0;advance_op=0;
  check(!single(c,41),"next fresh owner-round observation refines without sticky cache");
 }
 reset();live_round=41;check(single(c,40),"already stale owner round cannot accept negative refinement");
 reset();live_round=41;check(!single(c,41),"same physical camp is correctly classified with current owner round");
 c.hp=1000;c.lifecycle=1;reset();advance_op='A';advance_nth=1;check(single(c),"positive awake evidence survives suspension conservatively");
 c.hp=500;c.lifecycle=2;reset();fail_op='A';advance_op='S';advance_nth=1;check(single(c),"query failure plus suspension falls back conservatively");
#endif

 // Finite state/property matrix: success path uses actual state, never HP;
 // off preserves the exact old scalar and full multi-camp loop behavior.
 int rows=0;
 for(int dx=-6;dx<=6;++dx)for(int dy=-6;dy<=6;++dy)
 for(int h:{0,500,1000})for(int strength:{-1,0,60})for(int life:{0,1,2}){
  c.p={dx,dy};c.hp=h;c.str=strength;c.lifecycle=life;reset();
  const bool got=single(c);const std::string actual_reads=reads;const int actual_errors=errors;
  const bool in_range=std::max(std::abs(dx),std::abs(dy))<=4;
#if P_CAMP_STATE_GUARD
  check(got==(in_range&&strength>0&&life==1),"fresh finite matrix follows lifecycle and damaging strength");
  check(call_counts['P']==1&&call_counts['H']==0&&call_counts['M']==0,"normal path bounded and has no HP queries");
  check(call_counts['S']==(in_range?1:0)&&call_counts['A']==(in_range&&strength>0?1:0)&&call_counts['R']==2,"normal API count and cheap early exclusions");
#else
  reset();const bool old=legacy_single(c);check(got==old,"disabled scalar matches exact legacy predicate");
  check(actual_reads==reads&&actual_errors==errors,"disabled getter trace/error count equals legacy");
#endif
  ++rows;
 }

 // Failed fresh observations retain a successful legacy true over a matrix;
 // no implicit assumption is made that a hidden camp is known harmless.
#if P_CAMP_STATE_GUARD
 for(int life:{0,1,2})for(int strength:{0,60})for(char fail:std::string("SA")){
  c.p={1,0};c.hp=500;c.str=strength;c.lifecycle=life;reset();fail_op=fail;
  const bool query_needed=fail=='S'||strength>0;
  if(query_needed)check(single(c),"unknown refined state never clears readable legacy warning");
 }
#else
 for(char fail:std::string("PHM")){
  c.p={1,0};c.hp=500;c.str=60;c.lifecycle=2;reset();fail_op=fail;
  bool got=single(c);std::string log=reads;int errs=errors;
  reset();fail_op=fail;bool before=legacy_single(c);
  check(got==before&&log==reads&&errs==errors,"disabled exceptions match exact old call trace");
 }
#endif

 // Loop integration still visits every camp and preserves accumulated true;
 // flag 0 reproduces both old query trace and caught failure count exactly.
 for(int mask=0;mask<16;++mask){
  std::vector<bc::camp> camps(4);
  for(int i=0;i<4;++i){camps[i].p={i+2,0};camps[i].hp=(mask&(1<<i))?500:1000;camps[i].str=i==1?0:60;camps[i].lifecycle=i==2?2:1;}
  reset();bool got=actual_loop(camps,{0,0},40);std::string log=reads;int errs=errors;
#if P_CAMP_STATE_GUARD
  check(got,"full HP first awake monster sets accumulated result");check(call_counts['P']==4,"new loop visits every camp without hidden short circuit");
#else
  reset();bool before=legacy_loop(camps,{0,0},40);check(got==before&&log==reads&&errs==errors,"disabled integrated loop exact legacy result and SDK trace");
#endif
 }

#if P_CAMP_STATE_GUARD
 // Cross-camp freshness guards all negative refinements, not just the last
 // getter on each member. No positive evidence or failed legacy warning is lost.
 {std::vector<bc::camp> list(2);list[0].lifecycle=2;list[1].p={9,0};
  reset();advance_op='P';advance_nth=2;
  check(actual_loop(list,{0,0},40),"later-camp suspension restores earlier dormant wounded legacy warning");
  check(call_counts['R']==2&&call_counts['P']==4,"one start/end round guard and complete old fallback after stale collection");
  reads.clear();for(auto&n:call_counts)n=0;advance_op=0;
  check(!actual_loop(list,{0,0},41),"fresh next collection clears obsolete warning without cache");}
 {std::vector<bc::camp> list(3);for(auto&x:list)x.lifecycle=2;list[2].str=0;
  reset();fail_op='A';fail_nth=2;
  check(actual_loop(list,{0,0},40),"only failed camp receives old warning while fresh known negatives stay refined");
  check(call_counts['R']==2&&call_counts['H']==1&&call_counts['M']==1&&errors==1,"single failed member uses one exact legacy fallback, not whole scan retry");}
 {std::vector<bc::camp> list(2);list[0].hp=1000;list[1].p={9,0};
  reset();advance_op='P';advance_nth=2;
  check(actual_loop(list,{0,0},40),"positive full-health awake evidence survives later member suspension");
  check(call_counts['H']==0,"positive evidence avoids unnecessary complete legacy retry");}
 {std::vector<bc::camp> list(2);for(auto&x:list)x.lifecycle=2;
  reset();fail_op='R';fail_nth=1;
  check(actual_loop(list,{0,0},40),"failed begin round read triggers complete legacy fallback");
  check(call_counts['R']==2&&call_counts['H']==2,"begin failure still reads current evidence and both legacy warnings");
  reset();fail_op='R';fail_nth=2;
  check(actual_loop(list,{0,0},40),"failed end round read triggers complete legacy fallback");}
 {std::vector<bc::camp> list(2);list[0].hp=1000;list[1].lifecycle=2;
  reset();live_round=41;
  check(actual_loop(list,{0,0},40),"already stale owner retains positive awake evidence gathered by collection");
  check(call_counts['H']==0,"stale positive evidence avoids legacy retry");}
 {std::vector<bc::camp> empty;reset();fail_op='R';
  check(!actual_loop(empty,{0,0},40)&&reads.empty()&&errors==0,"empty collection needs no round or camp queries");}
 for(int n:{1,8,24}){
  std::vector<bc::camp> list(n);
  reset();check(actual_loop(list,{0,0},40),"nearby awake collection positive");
  check(call_counts['R']==2&&call_counts['P']==n&&call_counts['S']==n&&call_counts['A']==n,"round reads stay two for one/eight/twenty-four camps");
  for(auto&x:list)x.p={9,0};reset();check(!actual_loop(list,{0,0},40),"far collection negative");
  check(call_counts['R']==2&&call_counts['P']==n&&call_counts['S']==0&&call_counts['A']==0,"far collection gets no strength/state reads and only two round calls");
 }
#endif
 std::printf("PASS state_guard=%d checks=%d matrix_rows=%d\n",P_CAMP_STATE_GUARD,checks,rows);
}
