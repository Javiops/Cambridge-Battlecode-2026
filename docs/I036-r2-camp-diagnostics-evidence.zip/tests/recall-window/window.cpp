
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <stdexcept>
#include <string>
#include <optional>
#include <variant>
#include <type_traits>
#include <vector>
#include "params.h"
struct vec2 {int x=0,y=0;};
int dist(vec2 a,vec2 b){return std::max(std::abs(a.x-b.x),std::abs(a.y-b.y));}
std::string reads;char fail=0;int errors=0;
void read(char code){reads.push_back(code);if(fail==code)throw std::runtime_error("mock unavailable");}
template<class F>bool attempt(F f){try{return f();}catch(...){++errors;return false;}}
namespace bc {
enum class ability_kind {attack_reset,damage,aoe_damage,cc,heal};
struct ResetInfo {static constexpr auto kind=ability_kind::attack_reset;};
struct DamageInfo {static constexpr auto kind=ability_kind::damage;double modifier=1,range=4;bool exclusive_with_movement=true;};
struct AreaInfo {static constexpr auto kind=ability_kind::aoe_damage;double modifier=1,range=4,radius=1;bool exclusive_with_movement=true;};
struct StunInfo {static constexpr auto kind=ability_kind::cc;double modifier=0,range=4;bool exclusive_with_movement=false;};
using Info=std::variant<ResetInfo,DamageInfo,AreaInfo,StunInfo>;
std::optional<Info> infos[2];
struct ability {int cd=0,slot=0;int cooldown()const{read(slot?'1':'0');return cd;}
 std::optional<Info> info()const{read(slot?'j':'i');return infos[slot];}};
struct champion {double foc=100,str=50;int cd[2]{0,0};int identity=0;
 double focus()const{read('F');return foc;}double strength()const{read('S');return str;}
 std::vector<ability> abilities()const{read('A');return {{cd[0],0},{cd[1],1}};}
};
}
int combat_identity_type(const bc::champion&c){read('I');return c.identity;}
struct RecallWindowSpell {
    int cooldown = -1;
    int range = -1;
    bool exclusive = false;
    bool interrupts = false;
};

struct Threat {
    vec2 p;
    double xd = 0;  // best ready spell that needs the caster to stand, and its range
    int xr = -9;
    double fd = 0;  // best ready spell that can follow a step
    int fr = -9;
    int sr = -9;  // range of a ready free stun
    double atk = 0;
    int ar = 1;      // basic attack reach next round
    double ready = 0;  // the biggest ready spell
    // Retain only values already queried by threat_of. Legacy damage fields
    // above stay ready-only; recall needs spells that recover during its wait.
    RecallWindowSpell recall_spells[2];
    bool recall_complete = false;
};



struct SpellInfo {
    int kind = 0;  // 1 attack reset, 2 damage, 3 cc with damage, 4 free pure stun, 0 nothing that hurts
    double mod = 0;
    int range = 0;
    bool excl = false;
};
struct ChampSpells {
    int type = -1;
    SpellInfo k[2];
    bool recall_design_complete = false;
};
ChampSpells cs; const ChampSpells& spells_of(const bc::champion&){return cs;}

#include "recall_window.h"
inline const ChampSpells& legacy_design_of(const bc::champion& c) {
    static std::vector<ChampSpells> cache;
    int type = -2;
    attempt([&] {
        type = static_cast<int>(combat_identity_type(c));
        return true;
    });
    for (auto& cs : cache)
        if (cs.type == type) return cs;
    ChampSpells cs;
    cs.type = type;
    attempt([&] {
        auto abs = c.abilities();
        for (int k = 0; k < 2; ++k) {
            try {
                auto inf = abs[k].info();
                if (!inf) continue;
                std::visit([&](auto& x) {
                    using T = std::decay_t<decltype(x)>;
                    SpellInfo& si = cs.k[k];
                    if constexpr (T::kind == bc::ability_kind::attack_reset) {
                        si.kind = 1;
                    } else if constexpr (T::kind == bc::ability_kind::damage || T::kind == bc::ability_kind::aoe_damage ||
                                         T::kind == bc::ability_kind::cc) {
                        si.mod = x.modifier;
                        si.range = static_cast<int>(x.range);
                        if constexpr (requires { x.radius; }) si.range += static_cast<int>(x.radius);
                        si.excl = x.exclusive_with_movement;
                        if (x.modifier > 0) si.kind = 2;
                        else if (T::kind == bc::ability_kind::cc && !x.exclusive_with_movement) si.kind = 4;
                    }
                }, *inf);
            } catch (...) {
            }
        }
        return true;
    });
    if (type == -2) {  // unknown type: do not cache
        static ChampSpells tmp;
        tmp = cs;
        return tmp;
    }
    cache.push_back(cs);
    return cache.back();
}
inline const ChampSpells& production_design_of(const bc::champion& c) {
    static std::vector<ChampSpells> cache;
    int type = -2;
    attempt([&] {
        type = static_cast<int>(combat_identity_type(c));
        return true;
    });
    for (auto& cs : cache)
        if (cs.type == type) return cs;
    ChampSpells cs;
    cs.type = type;
    if (P_RECALL_WINDOW) cs.recall_design_complete = type >= 0;
    const bool design_known = attempt([&] {
        auto abs = c.abilities();
        for (int k = 0; k < 2; ++k) {
            try {
                auto inf = abs[k].info();
                if (!inf) continue;
                std::visit([&](auto& x) {
                    using T = std::decay_t<decltype(x)>;
                    SpellInfo& si = cs.k[k];
                    if constexpr (T::kind == bc::ability_kind::attack_reset) {
                        si.kind = 1;
                    } else if constexpr (T::kind == bc::ability_kind::damage || T::kind == bc::ability_kind::aoe_damage ||
                                         T::kind == bc::ability_kind::cc) {
                        si.mod = x.modifier;
                        si.range = static_cast<int>(x.range);
                        if constexpr (requires { x.radius; }) si.range += static_cast<int>(x.radius);
                        si.excl = x.exclusive_with_movement;
                        if (x.modifier > 0) si.kind = 2;
                        else if (T::kind == bc::ability_kind::cc && !x.exclusive_with_movement) si.kind = 4;
                    }
                }, *inf);
            } catch (...) {
                if (P_RECALL_WINDOW) cs.recall_design_complete = false;
            }
        }
        return true;
    });
    if (P_RECALL_WINDOW) cs.recall_design_complete = cs.recall_design_complete && design_known;
    if (type == -2) {  // unknown type: do not cache
        static ChampSpells tmp;
        tmp = cs;
        return tmp;
    }
    cache.push_back(cs);
    return cache.back();
}
inline Threat legacy_threat_of(bc::champion c, vec2 p, int atk_reach) {
    Threat t;
    t.p = p;
    t.ar = atk_reach;
    double foc = 0, str = 0;
    attempt([&] {
        foc = c.focus();
        str = c.strength();
        return true;
    });
    t.atk = str;
    const ChampSpells& cs = spells_of(c);
    if (!cs.k[0].kind && !cs.k[1].kind) return t;
    attempt([&] {
        auto abs = c.abilities();
        for (int k = 0; k < 2; ++k) {
            const SpellInfo& si = cs.k[k];
            if (!si.kind) continue;
            try {
                if (abs[k].cooldown() > 0) continue;
            } catch (...) {
                continue;
            }
            if (si.kind == 1) {
                t.atk += str;
            } else if (si.kind == 4) {
                t.sr = std::max(t.sr, si.range);
            } else {
                double d = si.mod * foc;
                t.ready = std::max(t.ready, d);
                if (si.excl) {
                    t.xd = std::max(t.xd, d);
                    t.xr = std::max(t.xr, si.range);
                } else {
                    t.fd = std::max(t.fd, d);
                    t.fr = std::max(t.fr, si.range);
                }
            }
        }
        return true;
    });
    return t;
}
inline Threat threat_of(bc::champion c, vec2 p, int atk_reach) {
    Threat t;
    t.p = p;
    t.ar = atk_reach;
    double foc = 0, str = 0;
    const bool stats_known = attempt([&] {
        foc = c.focus();
        str = c.strength();
        return true;
    });
    t.atk = str;
    const ChampSpells& cs = spells_of(c);
    if (P_RECALL_WINDOW) t.recall_complete = stats_known && cs.type >= 0 && cs.recall_design_complete;
    if (!cs.k[0].kind && !cs.k[1].kind) return t;
    const bool abilities_known = attempt([&] {
        auto abs = c.abilities();
        for (int k = 0; k < 2; ++k) {
            const SpellInfo& si = cs.k[k];
            if (!si.kind) continue;
            try {
                const int cooldown = abs[k].cooldown();
                if (P_RECALL_WINDOW) {
                    t.recall_spells[k] = {cooldown, si.range, si.excl, si.kind == 2 || si.kind == 4};
                    if (cooldown < 0) t.recall_complete = false;
                }
                if (cooldown > 0) continue;
            } catch (...) {
                if (P_RECALL_WINDOW) t.recall_complete = false;
                continue;
            }
            if (si.kind == 1) {
                t.atk += str;
            } else if (si.kind == 4) {
                t.sr = std::max(t.sr, si.range);
            } else {
                double d = si.mod * foc;
                t.ready = std::max(t.ready, d);
                if (si.excl) {
                    t.xd = std::max(t.xd, d);
                    t.xr = std::max(t.xr, si.range);
                } else {
                    t.fd = std::max(t.fd, d);
                    t.fr = std::max(t.fr, si.range);
                }
            }
        }
        return true;
    });
    if (P_RECALL_WINDOW) t.recall_complete = t.recall_complete && abilities_known;
    return t;
}
struct LocalState {int rnear=7,hit_round=38,nf_r=40,thr_r=40;std::vector<Threat>thr;};
bool production_gate(LocalState&s,vec2 pos,bool safe,int nearest_foe,int round,bool awake_camp_near,std::size_t nfoes){
 std::vector<int>foes(nfoes);
    bool near_recall = s.rnear && nearest_foe >= s.rnear && round - s.hit_round >= 1 && !awake_camp_near;
    if (P_RECALL_WINDOW && near_recall && !safe)
        near_recall = s.nf_r == round && recall_window_safe(s.thr, pos, s.thr_r, round, foes.size());
    bool rsafe = safe || near_recall;
 return rsafe;
}

int checks=0;void check(bool value,const char*why){++checks;if(!value){std::fprintf(stderr,"FAIL %s flag=%d reads=%s\n",why,P_RECALL_WINDOW,reads.c_str());std::exit(1);}}
void reset(){reads.clear();fail=0;errors=0;cs={};cs.type=0;cs.recall_design_complete=true;bc::infos[0].reset();bc::infos[1].reset();}
bool legacy_equal(const Threat&a,const Threat&b){return a.p.x==b.p.x&&a.p.y==b.p.y&&a.xd==b.xd&&a.xr==b.xr&&a.fd==b.fd&&a.fr==b.fr&&a.sr==b.sr&&a.atk==b.atk&&a.ar==b.ar&&a.ready==b.ready;}
Threat packet(int distance=7){Threat t;t.p={distance,0};t.atk=50;t.ar=2;t.recall_complete=true;return t;}
bool window(const Threat&t,int stamp=40,int now=40,std::size_t count=1){return recall_window_safe({t},{0,0},stamp,now,count);}
void expected(bool got,bool enabled,const char*why){check(got==(P_RECALL_WINDOW?enabled:true),why);}
int main(){
 // Actual production snapshot: Ryth's spell is excluded from legacy ready-only
 // damage, but must still count when it recovers before a five-round channel.
 reset();cs.k[0]={2,1,5,true};cs.k[1]={1,0,0,false};bc::champion ryth;ryth.cd[0]=3;
 auto t=threat_of(ryth,{7,0},2);
 check(t.xd==0&&t.xr==-9&&t.fd==0&&t.fr==-9&&t.atk==100,"recorded Ryth has no currently ready damage spell; legacy fields unchanged");
 check(reads=="FSA01","no extra SDK getter for future cooldown projection");
 if(P_RECALL_WINDOW){check(t.recall_complete&&t.recall_spells[0].cooldown==3&&t.recall_spells[0].range==5&&t.recall_spells[0].exclusive,"exact recorded pre-Ren R59 packet");}
 expected(window(t),false,"native Ren R59 cooldown3 interrupt is forecast");
 ryth.cd[0]=4;reset();cs.k[0]={2,1,5,true};cs.k[1]={1,0,0,false};t=threat_of(ryth,{7,0},2);expected(window(t),false,"cooldown4 within five future rounds still rejects");
 t=packet();t.recall_spells[0]={5,5,true,true};expected(window(t),false,"inclusive cooldown-five boundary");
 t.recall_spells[0].cooldown=6;expected(window(t),true,"far melee plus spell unavailable throughout horizon can allow");
 t.recall_spells[0]={0,5,true,true};t.p={9,0};expected(window(t),false,"exclusive cast uses four approach turns and exact range equality");
 t.p={10,0};expected(window(t),true,"exclusive cast just outside bounded ordinary approach can allow");
 t.recall_spells[0].exclusive=false;expected(window(t),false,"nonexclusive cast can follow fifth ordinary move");
 t.p={11,0};expected(window(t),true,"nonexclusive cast just outside its envelope can allow");
 t=packet(6);expected(window(t),false,"basic reach already includes one step plus only four remaining steps");
 t.p={7,0};expected(window(t),true,"far melee alone need not stop near recall");
 t.atk=0;t.recall_spells[0]={2,4,false,true};expected(window(t),false,"zero-damage pure stun can interrupt");
 t=packet(20);t.recall_complete=false;expected(window(t),false,"unknown/incomplete packet cannot authorize relaxed recall");
 t=packet(20);expected(window(t,39),false,"stale threat round cannot authorize relaxed recall");
 expected(window(t,40,40,2),false,"uncovered visible foe cannot authorize relaxed recall");
 expected(recall_window_safe({}, {0,0},40,40,0),true,"fresh complete no-foe snapshot allows");
 expected(recall_window_safe({}, {0,0},39,40,0),false,"stale no-foe snapshot not promoted to safe");
 t=packet(20);t.recall_spells[0]={-1,4,true,true};expected(window(t),false,"unknown cooldown cannot authorize");
 t.recall_spells[0]={2,-1,true,true};expected(window(t),false,"unknown spell reach cannot authorize");
 // Exact production rsafe expression: original safe and bank priority remain
 // separate. No new helper is called in already-safe admission.
 LocalState s;s.thr={packet()};s.thr[0].recall_spells[0]={3,5,true,true};
 check(production_gate(s,{0,0},false,7,40,false,1)==!P_RECALL_WINDOW,"actual near-recall integration rejects recorded packet");
 check(production_gate(s,{0,0},true,7,40,false,1),"original safe admission stays unchanged");
 s.nf_r=39;check(production_gate(s,{0,0},false,7,40,false,1)==!P_RECALL_WINDOW,"existing current-round marker also required");
 s.nf_r=40;s.thr.clear();check(production_gate(s,{0,0},false,99,40,false,0),"fresh no-foe recent-camp hit can still recall");
 check(!production_gate(s,{0,0},false,99,40,true,0),"original awake-camp gate retained");
 s.hit_round=40;check(!production_gate(s,{0,0},false,99,40,false,0),"original recent-hit gate retained");
 s.hit_round=38;s.rnear=0;check(!production_gate(s,{0,0},false,99,40,false,0),"disabled near recall not newly enabled");
 // Exact extracted old/new threat_of: same legacy fields, SDK getter sequence
 // and exception count under failures and a broad finite property matrix.
 int rows=0;
 for(int k0:{0,1,2,4})for(int k1:{0,1,2,4})for(int cd0:{0,1,4,6})for(int cd1:{0,2,5,8})for(char f:std::string("-FSA01")){
   reset();cs.type=3;cs.k[0]={k0,1.5,4,true};cs.k[1]={k1,2.0,3,false};bc::champion c;c.cd[0]=cd0;c.cd[1]=cd1;fail=f=='-'?0:f;
   auto a=threat_of(c,{4,6},3);const auto ar=reads;const int ae=errors;
   reads.clear();errors=0;auto b=legacy_threat_of(c,{4,6},3);
   check(legacy_equal(a,b),"all legacy threat fields bit-for-bit equal");check(reads==ar&&errors==ae,"same SDK getter sequence/count and caught failures");
   if(P_RECALL_WINDOW&&fail&&ar.find(fail)!=std::string::npos)check(!a.recall_complete,"failed known threat read vetoes relaxation");
   ++rows;
 }
 reset();cs.type=-2;cs.k[0]={2,1.0,4,true};auto unknown=threat_of(ryth,{7,0},2);if(P_RECALL_WINDOW)check(!unknown.recall_complete,"unknown identity cannot publish recall packet");
 reset();cs.k[0]={2,1.0,4,true};ryth.cd[0]=-1;auto negative=threat_of(ryth,{7,0},2);if(P_RECALL_WINDOW)check(!negative.recall_complete,"negative cooldown marked incomplete");
 // Actual static-design getter failures remain cached exactly as before, but
 // their unknown defaults cannot authorize the new near-recall relaxation.
 int identity=100;
 for(char failure:std::string("-AijI")){
   reset();bc::champion c;c.identity=identity++;bc::infos[0]=bc::AreaInfo{};bc::infos[1]=bc::StunInfo{};fail=failure=='-'?0:failure;
   const auto a=production_design_of(c);const auto ar=reads;const int ae=errors;
   reads.clear();errors=0;const auto b=legacy_design_of(c);
   check(a.type==b.type,"static design type unchanged");
   for(int k=0;k<2;++k)check(a.k[k].kind==b.k[k].kind&&a.k[k].mod==b.k[k].mod&&a.k[k].range==b.k[k].range&&a.k[k].excl==b.k[k].excl,"static legacy design fields unchanged");
   check(reads==ar&&errors==ae,"static design uses identical existing SDK getters");
   cs=a;reads.clear();fail=0;auto threat=threat_of(c,{7,0},2);
   if(P_RECALL_WINDOW){check(a.recall_design_complete==(failure=='-'),"static metadata failure is tracked");check(threat.recall_complete==(failure=='-'),"unknown static design prevents relaxed recall");}
   expected(window(threat),false,"known damaging or unknown spell design cannot authorize witness recall");
   if(failure=='i'||failure=='j'){
     reads.clear();auto cached=production_design_of(c);check(reads=="I","failed metadata cache behavior retained without retry");
     if(P_RECALL_WINDOW)check(!cached.recall_design_complete,"cached incomplete design stays unavailable to new window");
   }
 }
 reset();bc::champion absent;absent.identity=identity++;cs=production_design_of(absent);
 check(cs.k[0].kind==0&&cs.k[1].kind==0,"empty optional means absent harmless slot");
 if(P_RECALL_WINDOW)check(cs.recall_design_complete,"clean optional absence is complete metadata");
 auto harmless=threat_of(absent,{7,0},2);expected(window(harmless),true,"known empty spell slots do not block distant melee");
 std::printf("PASS window=%d checks=%d legacy_identity_rows=%d\n",P_RECALL_WINDOW,checks,rows);
}
