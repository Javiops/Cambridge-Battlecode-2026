
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>
#include "params.h"
struct vec2{int x=0,y=0;vec2()=default;vec2(int a,int b):x(a),y(b){}bool operator==(const vec2&)const=default;vec2 operator+(vec2 p)const{return{x+p.x,y+p.y};}int dot(vec2 p)const{return x*p.x+y*p.y;}int chebyshev_distance(vec2 p)const{return std::max(std::abs(x-p.x),std::abs(y-p.y));}};
int recalls=0; int now_round=106,owner=7,errors=0,camp_reads=0,moves=0,invalidations=0,shoots=0,hits=0,flees=0,pos_reads=0;
std::uint64_t fuel=100000;bool movable=true,move_success=true;vec2 live_pos{27,20};int range_value=3;
std::string throw_at,advance_at,drop_at;bool move_crosses=false,shift_final_position=false;std::vector<std::string> actions;
void hook(const char*n){if(throw_at==n){throw_at.clear();throw std::runtime_error(n);}if(advance_at==n){advance_at.clear();++now_round;}if(drop_at==n){drop_at.clear();fuel=20000;}}
namespace bc{
std::uint64_t fuel_remaining(){hook("fuel");return fuel;}std::uint32_t round_number(){hook("round");return now_round;}
struct champion{int id=7;bool operator==(const champion&)const=default;bool can_move()const{hook("can_move");return movable;}int attack_range()const{hook("attack_range");return range_value;}vec2 position()const{++pos_reads;hook("me_position");if(shift_final_position&&pos_reads==2)live_pos={28,20};return live_pos;}void recall(){++recalls;actions.push_back("recall");}bool move_absolute(vec2 p){hook("move");actions.push_back("move");if(!move_success)return false;if(move_crosses)++now_round;live_pos=p;movable=false;++moves;return true;}};
champion& self(){static champion me;me.id=owner;return me;}
struct bitboard{std::set<std::pair<int,int>> blocked;bool all=false;bool is_set(vec2 p)const{return all?!blocked.count({p.x,p.y}):blocked.count({p.x,p.y});}void set(vec2 p,bool value=true){if(value)blocked.insert({p.x,p.y});else blocked.erase({p.x,p.y});}};
struct camp_state{int value=1;bool is_awake()const{return value==1;}};
struct camp{vec2 p;double str=60,hp=2400;int r=3,st=1;double max_health()const{++camp_reads;hook("camp_max_health");return 2400;}camp_state state()const{++camp_reads;hook("camp_state");return{st};}double strength()const{++camp_reads;hook("camp_strength");return str;}double health()const{++camp_reads;hook("camp_health");return hp;}vec2 position()const{++camp_reads;hook("camp_position");return p;}int attack_range()const{++camp_reads;hook("camp_range");return r;}};
namespace map{int width(){hook("width");return 36;}int height(){hook("height");return 36;}}
}
struct RecallWindowSpell {
    int cooldown = -1;
    int range = -1;
    bool exclusive = false;
    bool interrupts = false;
};

struct Threat {
    vec2 p;
    double xd = 0;  // best ready spell that needs the caster to stand, and its range
    int xr = -9;
    double fd = 0;  // best ready spell that can follow a step
    int fr = -9;
    int sr = -9;  // range of a ready free stun
    double atk = 0;
    int ar = 1;      // basic attack reach next round
    double ready = 0;  // the biggest ready spell
    // Retain only values already queried by threat_of. Legacy damage fields
    // above stay ready-only; recall needs spells that recover during its wait.
    RecallWindowSpell recall_spells[2];
    bool recall_complete = false;
};




struct State{int hit_round=0,rnear=0,casters=0,nf_r=106;int dash_slot=-1,thr_r=106;bc::bitboard blocked,vis;vec2 spawn_center{29,25};std::vector<Threat>thr;State(){vis.all=true;}};
struct Foe{bc::champion c;vec2 p;float hp=100;int d=0;};
constexpr std::uint64_t FUEL_RESERVE=6000;
void note_error(const char*){++errors;}
namespace combatcohort{void invalidate(){++invalidations;actions.push_back("invalidate");}}
const char*g_mode="old";
void cast_offense(State&,bc::champion&,const bc::champion&,vec2,bool){actions.push_back("cast");}
bool basic_attack(State&,bc::champion&,const bc::champion&,vec2){++hits;actions.push_back("hit");return true;}
bool flee(State&,bc::champion&){++flees;actions.push_back("flee");return false;}
void shoot_back(State&,bc::champion&,const std::vector<Foe>&){++shoots;actions.push_back("shoot");}

#ifndef P_CAMP_ESCAPE
#define P_CAMP_ESCAPE 0
#endif
constexpr int CAMP_RANGE=3;
struct {int flee_pct=25;} P;
std::optional<vec2> best_altar(State&,vec2,int){return std::nullopt;}
bool go_tribute(State&,bc::champion&,int){return false;}

inline int dist(vec2 a, vec2 b) { return static_cast<int>(a.chebyshev_distance(b)); }
inline int X(vec2 v) { return static_cast<int>(v.dot(vec2(1, 0))); }
inline int Y(vec2 v) { return static_cast<int>(v.dot(vec2(0, 1))); }
inline bool fuel_ok(std::uint64_t need) { return bc::fuel_remaining() > need + FUEL_RESERVE; }
inline double danger_at(const std::vector<Threat>& th, vec2 t) {
    double sum = 0;
    bool stun = false;
    for (auto& x : th) {
        int d = dist(t, x.p);
        double sp = 0;
        if (d <= x.xr) sp = x.xd;
        if (d <= x.fr + 1) sp = std::max(sp, x.fd);
        sum += sp + (d <= x.ar ? x.atk : 0.0);
        if (d <= x.sr + 1) stun = true;
    }
    if (stun)  // stunned for a round: the ready casters one step out get to stand and cast after
        for (auto& x : th) {
            int d = dist(t, x.p);
            if (d > x.xr && d <= x.xr + 1) sum += 0.5 * x.xd;
        }
    return sum;
}
template<class F>
bool attempt(F&& f) {
    try {
        return f();
    } catch (const std::exception& e) {
        note_error(e.what());
        return false;
    } catch (...) {
        note_error("unknown exception");
        return false;
    }
}
bool damaging_camps_awake_near(const std::vector<bc::camp>& camps, vec2 pos, int owner_round) {
    const auto legacy_near = [&](const bc::camp& c) {
        bool near = false;
        attempt([&] {
            if (dist(c.position(), pos) <= CAMP_RANGE + 1 && c.health() < c.max_health()) near = true;
            return true;
        });
        return near;
    };
    const auto legacy_all = [&] {
        bool near = false;
        for (const auto& c : camps)
            if (legacy_near(c)) near = true;
        return near;
    };
    if (!P_CAMP_STATE_GUARD) return legacy_all();
    if (camps.empty()) return false;

    const bool fresh_begin = attempt([&] {
        return static_cast<int>(bc::round_number()) == owner_round;
    });
    bool active = false, failed_legacy = false;
    for (const auto& c : camps) {
        bool local_active = false;
        const bool known = attempt([&] {
            if (dist(c.position(), pos) <= CAMP_RANGE + 1 && c.strength() > 0)
                local_active = c.state().is_awake();
            return true;
        });
        if (local_active) active = true;
        if (!known && legacy_near(c)) failed_legacy = true;
    }
    const bool fresh_end = attempt([&] {
        return static_cast<int>(bc::round_number()) == owner_round;
    });
    if (fresh_begin && fresh_end) return active || failed_legacy;
    return active || failed_legacy || legacy_all();
}
#include "recall_window.h"
#include "camp_escape.h"
namespace fight{
inline bool hit_now(State& s, bc::champion& me, const std::vector<Foe>& foes) {
    // Measured: a ranged champion that attacks can no longer move this turn (64 of 64 Cassi hits on
    // packs), so ranged champions step first and shoot after (shoot_back) unless they are stuck anyway.
    if (me.attack_range() > 1 && me.can_move()) return false;
    vec2 pos = me.position();
    const Foe* best = nullptr;
    for (auto& f : foes) {
        if (f.hp <= 0 || dist(pos, f.p) > me.attack_range()) continue;
        if (!best || f.hp < best->hp) best = &f;
    }
    if (!best) return false;
    cast_offense(s, me, best->c, best->p, true);
    return basic_attack(s, me, best->c, best->p);
}
}

void combined(State&s,bc::champion&me,std::vector<bc::camp>&camps,std::vector<Foe>&foes,int round,vec2 pos){
    bool awake_camp_near=damaging_camps_awake_near(camps,pos,round);
    int nearest_foe=99;for(auto&f:foes)nearest_foe=std::min(nearest_foe,f.d);
    bool safe = nearest_foe > 7 && !awake_camp_near;
    if (P_SAFE_RECALL) safe = safe && nearest_foe > 8 && round - s.hit_round > 2;
    // P_RECALL_NEAR: a recall only needs nobody to hit us while it channels, not an empty screen
    bool near_recall = s.rnear && nearest_foe >= s.rnear && round - s.hit_round >= 1 && !awake_camp_near;
    if (P_RECALL_WINDOW && near_recall && !safe)
        near_recall = s.nf_r == round && recall_window_safe(s.thr, pos, s.thr_r, round, foes.size());
    bool rsafe = safe || near_recall;
    bool capture_before_recall=false,camps_complete=true,own_vision_complete=true;
    float hpr=0.10f;int gems=0;
    if (!capture_before_recall &&
        hpr * 100 < ((P_UNI_FLEE && P_DRAFTUNI && s.casters) ? P_UNI_FLEE : P.flee_pct)) {
        if (gems > 0 && nearest_foe > 3) {
            auto a = best_altar(s, pos, round);
            if (a && dist(*a, pos) <= 1) {  // tribute is not interrupted by damage
                bool acted = go_tribute(s, me, round);
                if (acted || !P_U34_FAILED_CHANNELS) return;
            }
        }
        bool recalled = false;
        if (rsafe) recalled = attempt([&] {
            me.recall();
            return true;
        });
        if (!rsafe || (P_U34_FAILED_CHANNELS && !recalled)) {
            // An ordinary escape may reduce known camp exposure before a
            // ranged/no-target hit_now that would otherwise return false.
            if (campescape::step(s, me, camps, foes, round, pos,
                                 camps_complete && own_vision_complete)) {
                g_mode = "camp-escape";
                shoot_back(s, me, foes);
                return;
            }
            bool hit = P_HITFIRST && fight::hit_now(s, me, foes);
            flee(s, me);
            if (!hit) shoot_back(s, me, foes);
        }
        return;
    }
}

int checks=0;void check(bool value,const char*why){++checks;if(!value){std::fprintf(stderr,"FAIL %s\n",why);std::exit(1);}}
struct Setup{State s;bc::champion me{7};std::vector<bc::camp>camps;std::vector<Foe>foes;Setup(){now_round=106;owner=7;recalls=errors=camp_reads=moves=invalidations=shoots=hits=flees=pos_reads=0;fuel=100000;movable=move_success=true;live_pos={27,20};range_value=3;throw_at.clear();advance_at.clear();drop_at.clear();actions.clear();move_crosses=shift_final_position=false;g_mode="old";camps.push_back({{26,23},60,2400,3,1});}void go(){combined(s,me,camps,foes,106,{27,20});}
 void near(){camps.clear();s.rnear=5;s.hit_round=105;foes.push_back({{9},{34,20},300,7});Threat t;t.p={34,20};t.recall_complete=true;t.atk=30;t.ar=3;s.thr.push_back(t);}};
int main(){
 {Setup x;x.go();
#if P_CAMP_STATE_GUARD
  check(recalls==0&&moves==(P_CAMP_ESCAPE?1:0),"authoritative full-HP awake warning blocks recall; escape runs only if integrated");
  check(P_CAMP_ESCAPE?live_pos.y==19:flees==1,"full-health awake state reaches the exact lowHP flee branch");
#else
  check(recalls==1&&moves==0&&flees==0,"legacy full-HP proxy starts recall before escape is reachable");
  check(actions==std::vector<std::string>({"recall"}),"legacy branch preserves recall action");
#endif
 }
 {Setup x;x.camps[0].hp=500;x.camps[0].st=2;x.go();check(recalls==(P_CAMP_STATE_GUARD?1:0)&&moves==0,"dormant wounded state no longer blocks safe recall");}
 {Setup x;x.camps[0].hp=500;x.camps[0].str=0;x.go();check(recalls==(P_CAMP_STATE_GUARD?1:0)&&moves==0,"harmless damaged resource no longer blocks safe recall");}
 {Setup x;x.camps[0].st=2;x.go();check(recalls==1&&moves==0,"full-health asleep still permits recall");}
 {Setup x;x.camps[0].hp=500;x.go();check(recalls==0&&moves==(P_CAMP_ESCAPE?1:0),"wounded awake camp reaches actual flee/escape policy");}
 {Setup x;x.s.hit_round=105;x.go();check(recalls==0&&moves==(P_CAMP_ESCAPE?1:0),"recent damage also makes lowHP branch reachable");}
 {Setup x;x.near();x.go();check(recalls==(P_RECALL_WINDOW?0:1),"visible approaching basic attack gates only relaxed recall");}
 {Setup x;x.near();x.s.thr[0].atk=0;x.s.thr[0].recall_spells[0]={2,4,false,true};x.go();check(recalls==(P_RECALL_WINDOW?0:1),"cooling interrupt available during wait blocks near-recall in composed source");}
 {Setup x;x.near();x.s.thr[0].atk=0;x.s.thr[0].recall_spells[0]={6,4,false,true};x.go();check(recalls==1,"interrupt beyond fixed five-opportunity window does not block near-recall");}
 {Setup x;x.near();x.s.thr[0].recall_complete=false;x.go();check(recalls==(P_RECALL_WINDOW?0:1),"unknown threat completeness blocks relaxed recall only when window is enabled");}
 {Setup x;x.near();x.s.nf_r=105;x.go();check(recalls==(P_RECALL_WINDOW?0:1),"stale foe observation cannot authorize new relaxed recall");}
 {Setup x;x.near();x.s.thr.clear();x.go();check(recalls==(P_RECALL_WINDOW?0:1),"partial threat coverage cannot authorize relaxed recall");}
 {Setup x;x.camps.clear();x.s.rnear=5;x.foes.push_back({{9},{35,20},300,12});x.go();check(recalls==1,"original distant safe recall remains outside new near-recall gate");}
 std::printf("PASS composed_state=%d window=%d escape=%d checks=%d\n",P_CAMP_STATE_GUARD,P_RECALL_WINDOW,P_CAMP_ESCAPE,checks);
}
