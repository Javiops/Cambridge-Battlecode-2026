"""Build the separate I037 diagnostic snapshot from saved evidence only.

No compiler, tests, games, source promotion, or GitHub action is run here.
Completed v5 probe/audit files can be incorporated by rerunning this builder.
"""
from pathlib import Path
import argparse
import collections
import csv
import difflib
import hashlib
import io
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORKSPACE = ROOT.parents[1]
DOCS = Path(__file__).resolve().parent
TESTING = ROOT.parent / 'mate-bwf-fixes/testing'
ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument('--report-url', default='https://github.com/Javiops/Cambridge-Battlecode-2026/blob/main/docs/I037-retreat-continuation-diagnostics.md')
args = ap.parse_args()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
digest = lambda b: hashlib.sha256(b).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
manifest = lambda p: {x.name: sha(x) for x in sorted(p.iterdir()) if x.is_file()}
checkpoint = {n: sha(DOCS / n) for n in ['I036-camp-lifecycle-diagnostics.md', 'I036-camp-diagnostics-evidence.zip']}
corrected_I036 = {n: sha(DOCS / n) for n in ['I036-r2-camp-lifecycle-diagnostics.md', 'I036-r2-camp-diagnostics-evidence.zip']}
entries, inputs, pending = {}, {}, []

def clean(obj):
    if isinstance(obj, dict): return {k: clean(v) for k, v in obj.items()}
    if isinstance(obj, list): return [clean(v) for v in obj]
    if isinstance(obj, str):
        original = obj
        for prefix in [str(WORKSPACE), str(WORKSPACE).replace('\\', '/')]: obj = obj.replace(prefix, 'workspace')
        obj = re.sub(r'[A-Za-z]:[/\\]+Users[/\\]+[^/\\\s"\']+', '<user>', obj)
        return obj.replace('\\', '/') if obj != original else obj
    return obj

def put_json(name, obj): entries[name] = (json.dumps(clean(obj), indent=2, sort_keys=True) + '\n').encode()
def put_text(name, text): entries[name] = clean(text).encode()
def copy(name, path):
    path = Path(path)
    if not path.exists(): pending.append({'input': str(path.relative_to(ROOT)), 'status': 'not ready at snapshot'}); return
    inputs[name] = {'input': str(path.relative_to(WORKSPACE)), 'sha256': sha(path)}
    if path.suffix == '.json': put_json(name, read(path))
    elif path.suffix in ['.cpp', '.h', '.py']: entries[name] = path.read_bytes()
    else: put_text(name, path.read_text())

def zipdata(files):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, content in sorted(files.items()):
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0)); info.compress_type = zipfile.ZIP_DEFLATED; info.external_attr = 0o100644 << 16
            archive.writestr(info, content, compresslevel=9)
    data = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(data)) as archive: assert archive.testzip() is None
    return data

locations = {
    'v60-camp-roster-bound': 'camp-roster-bound',
    'v60-camp-escape-v2': 'camp-escape-v2',
    'v60-postkill-escape-v2': 'postkill-escape-v2',
    'v60-postkill-route-escape-v3': 'postkill-route-escape-v3',
    'v60-postkill-route-escape-v4': 'postkill-route-escape-v4',
    'v60-postkill-route-escape-v5': 'postkill-route-escape-v5',
}
if (ROOT / 'route-only-v5/freeze.json').exists(): locations['v60-route-only-v5'] = 'route-only-v5'
else: pending.append({'input': 'route-only-v5 exact-source validation/freeze', 'status': 'component ablation source being validated'})
sources = {name: ROOT / path / 'src' for name, path in locations.items()}
before = {name: manifest(source) for name, source in sources.items()}
source_info = {}
for name, source in sources.items():
    freeze = read(source.parent / 'freeze.json'); assert freeze['source_sha256'] == before[name], name
    archive_name = 'sources/' + name + '.zip'
    entries[archive_name] = zipdata({'src/' + p.name: p.read_bytes() for p in source.iterdir() if p.is_file()})
    buildfile = TESTING / 'builds' / (name + '.json')
    build = read(buildfile) if buildfile.exists() else None
    if build:
        assert build['source_sha256'] == before[name]
        assert sha(build['frozen_module']) == build['wasm_sha256']
    flags = {flag: int(m[1]) if (m := re.search(r'^#define ' + flag + r' (\d+)', (source / 'params.h').read_text(), re.M)) else 0 for flag in ['P_CAMP_ESCAPE', 'P_CAMP_ESCAPE_ROUTE', 'P_CF_POSTKILL_CAPTURE', 'P_CAMP_ROSTER_BOUND']}
    source_info[name] = {'source_sha256': before[name], 'flags': flags, 'archive': archive_name, 'archive_sha256': digest(entries[archive_name]), 'release_wasm_sha256': build['wasm_sha256'] if build else None, 'source_fingerprint': build['source_fingerprint'] if build else None}
    for artifact in ['freeze.json', 'results.json', 'README.md']:
        path = source.parent / artifact
        if path.exists(): copy('mechanisms/' + name + '/' + artifact, path)
    if '-route-' in name:
        parent_name = 'v60-camp-escape-v2' if name == 'v60-route-only-v5' else 'v60-postkill-escape-v2'
        parent = sources[parent_name]
        patch = ''.join(''.join(difflib.unified_diff((parent / p.name).read_text().splitlines(True) if (parent / p.name).exists() else [], p.read_text().splitlines(True), fromfile=parent_name+'/src/' + p.name, tofile=name + '/src/' + p.name)) for p in sorted(source.iterdir()) if p.is_file() and before[name][p.name] != before[parent_name].get(p.name))
        put_text('patches/' + name + '-from-v2.patch', patch)
        fixture = source.parent / 'tests/route1/fixture.cpp'
        assert fixture.exists()
        copy('tests/' + name + '/fixture.cpp', fixture)
assert not list((ROOT / 'results').glob('v60-postkill-route-escape-v3-vs-*.json')), 'v3 must remain design-only, never silently treat it as played'

# Actual saved records, source/binary/map/runtime bindings and scheduled-slot reuse.
record_cache, rows, panels, maps = {}, [], [], {}
def record(key):
    if key in record_cache: return record_cache[key]
    path = TESTING / 'records' / (key + '.json'); data = read(path)
    assert data['native_valid'] and data['key'] == key
    assert sha(data['statistics']) == data['statistics_sha256'] and sha(data['replay']) == data['replay_sha256'] and sha(data['map']) == data['identity']['map']
    with zipfile.ZipFile(data['replay']) as archive:
        assert archive.testzip() is None
        rawsha = digest(archive.read('replay.repl26a'))
        for side in ['a', 'b']: assert digest(archive.read('team-' + side + '.stdout')) == data['stdout'][side]['sha256']
    for side in ['a', 'b']:
        build = read(data['build_' + side])
        assert build['source_sha256'] == data['source_' + side] and data['actual_identity'][side] == data['identity'][side]
    assert data['summary']['engine_version'] == '0.0.3'
    assert data['summary']['engine_build'] == 'd7e29ae3546357b011419c764204b7b9e2232bdb1b07868250c6b35d4c18d2a5'
    record_cache[key] = (data, rawsha, sha(path))
    return record_cache[key]

def row_for(slot, candidate, opponent, label, role):
    data, rawsha, recordsha = record(slot['key']); side = slot['side']; other = 'b' if side == 'a' else 'a'; ci = int(side == 'b'); oi = 1 - ci; stats = data['summary']
    assert data['source_' + side] == before[candidate]
    winner = 'teamB' if ci else 'teamA'
    outcome = 1 if stats['outcome'] == winner else 0 if stats['outcome'] not in ['teamA', 'teamB'] else -1
    maps[data['identity']['map']] = Path(data['map'])
    if opponent in before: assert data['source_' + other] == before[opponent]
    return {'summary': label, 'role': role, 'candidate': candidate, 'opponent': opponent, 'map': slot['map'], 'side': side, 'key': slot['key'], 'physical_key': data['physical_key'], 'record_sha256': recordsha, 'raw_replay_sha256': rawsha, 'replay_zip_sha256': data['replay_sha256'], 'statistics_sha256': data['statistics_sha256'], 'map_sha256': data['identity']['map'], 'actual_seed': stats['actual_seed'], 'runtime': data['identity']['runtime'], 'candidate_binary': data['identity'][side], 'opponent_binary': data['identity'][other], 'candidate_source_fingerprint': data['identity']['source_' + side + '_fingerprint'], 'opponent_source_fingerprint': data['identity']['source_' + other + '_fingerprint'], 'candidate_score': stats['scores'][ci], 'opponent_score': stats['scores'][oi], 'outcome': outcome, 'candidate_fuel': stats['event_counts'][winner].get('fuelExhausted', 0), 'opponent_fuel': stats['event_counts']['teamA' if ci else 'teamB'].get('fuelExhausted', 0), 'candidate_faults': stats['faults'][ci], 'opponent_faults': stats['faults'][oi], 'candidate_caught_sdk_markers': data['stdout'][side]['caught_errors'], 'opponent_caught_sdk_markers': data['stdout'][other]['caught_errors'], 'candidate_max_reported_error_counter': data['stdout'][side]['max_reported_error_counter'], 'opponent_max_reported_error_counter': data['stdout'][other]['max_reported_error_counter'], 'candidate_stdout_sha256': data['stdout'][side]['sha256'], 'opponent_stdout_sha256': data['stdout'][other]['sha256']}

for candidate in ['v60-postkill-route-escape-v4', 'v60-postkill-route-escape-v5'] + (['v60-route-only-v5'] if 'v60-route-only-v5' in before else []):
    summaries = sorted((ROOT / 'results').glob(candidate + '-vs-*.json'))
    for path in summaries:
        try: data = read(path)
        except json.JSONDecodeError: pending.append({'input': path.name, 'status': 'incomplete summary'}); continue
        if data.get('candidate') != candidate or 'games_detail' not in data: continue
        items = [row_for(slot, candidate, data['opponent'], path.stem, 'experimental') for slot in data['games_detail']]
        assert len(items) == data['games']
        assert sum(x['outcome'] == 1 for x in items) == data['wins'] and sum(x['outcome'] == -1 for x in items) == data['losses']
        assert [sum(x[k] for x in items) for k in ['candidate_fuel', 'opponent_fuel']] == data['fuel_events']
        for row in items: row['same_record_in_earlier_summary'] = any(r['key'] == row['key'] for r in rows); rows.append(row)
        panels.append({'candidate': candidate, 'opponent': data['opponent'], 'label': path.stem, 'map_manifest_sha256': data.get('map_manifest_sha256'), 'maps': len({r['map_sha256'] for r in items}), 'slots': len(items), 'wins': data['wins'], 'losses': data['losses'], 'draws': data['draws'], 'maps_won_both_sides': data.get('maps_won_both_sides'), 'maps_lost_both_sides': data.get('maps_lost_both_sides'), 'one_sided_map_sign_p': data.get('one_sided_map_sign_p'), 'fuel_events': data['fuel_events'], 'faults': data['faults'], 'input_sha256': sha(path), 'record_keys': [r['key'] for r in items]})
        copy('native-summaries/' + path.name, path)
    if not any(p['candidate'] == candidate for p in panels): pending.append({'input': candidate + ' native probe', 'status': 'not completed at snapshot'})

# Reuse only the exact matching old v2 slots, without importing its unrelated panel games.
controls, matched = {}, []
for parent_name in ['v60-postkill-escape-v2', 'v60-camp-escape-v2']:
    for path in sorted((ROOT / 'results').glob(parent_name+'-vs-*.json')):
        data = read(path)
        for slot in data.get('games_detail', []):
            possible = [r for r in rows if r['role'] == 'experimental' and r['map'] == slot['map'] and r['side'] == slot['side'] and r['opponent'] == data['opponent'] and ((r['candidate']=='v60-route-only-v5') == (parent_name=='v60-camp-escape-v2'))]
            # The parent controls retained here are the concrete four witness
            # slots. Do not re-import its unrelated already-published panels.
            if parent_name == 'v60-postkill-escape-v2': possible = [r for r in possible if '-probe-' in r['summary']]
            if not possible: continue
            old = row_for(slot, parent_name, data['opponent'], 'cached-parent-v2-matched-slots', 'cached-control')
            for new in possible:
                if all(old[k] == new[k] for k in ['map_sha256', 'side', 'actual_seed', 'runtime', 'opponent_binary', 'opponent_source_fingerprint']):
                    controls[old['key']] = old
                    matched.append({'experimental_key': new['key'], 'parent_v2_key': old['key'], 'summary': new['summary'], 'map': new['map'], 'side': new['side'], 'same_map_seed_runtime_opponent_binary': True, 'parent_outcome': old['outcome'], 'experimental_outcome': new['outcome'], 'parent_fuel': old['candidate_fuel'], 'experimental_fuel': new['candidate_fuel']})
rows += list(controls.values())
context_panels, context_rows = [], []
context_paths = [ROOT / 'results/v60-camp-roster-bound-vs-diagnosis-v59-holdout.json'] + [ROOT / ('results/v60-camp-roster-bound-vs-' + opponent + '-screen.json') for opponent in ['spar11', 'spar12', 'spar16']]
match_identity = lambda row: (row['map_sha256'], row['side'], str(row['actual_seed']), json.dumps(row['runtime'], sort_keys=True), row['opponent_binary'], row['opponent_source_fingerprint'])
for path in context_paths:
    data = read(path)
    items = [row_for(slot, 'v60-camp-roster-bound', data['opponent'], path.stem, 'cached-selected-context') for slot in data['games_detail']]
    reference = [row for row in rows if row['candidate'] == 'v60-postkill-route-escape-v5' and row['opponent'] == data['opponent'] and row['role'] == 'experimental']
    assert {match_identity(row) for row in items} <= {match_identity(row) for row in reference}, 'context must use actual matching maps/seeds/runtime/opponent binaries'
    assert len(items) == data['games'] and sum(row['outcome'] == 1 for row in items) == data['wins']
    context_rows += items
    context_panels.append({'candidate': 'v60-camp-roster-bound', 'opponent': data['opponent'], 'label': path.stem, 'maps': len({row['map_sha256'] for row in items}), 'slots': len(items), 'wins': data['wins'], 'losses': data['losses'], 'fuel_events': data['fuel_events'], 'actual_map_seed_runtime_opponent_match': True, 'input_sha256': sha(path)})
    copy('cached-selected-control-summaries/' + path.name, path)
rows += context_rows
assert all(row['candidate_faults'] == row['opponent_faults'] == 0 for row in rows)
put_json('native-ledger.json', rows); put_json('matched-cached-controls.json', matched)
entries['maps.zip'] = zipdata({'maps/' + key + '.map26a': path.read_bytes() for key, path in maps.items()})

for version in ['v4', 'v5']:
    folder = ROOT / ('retreat-' + version + '-audit/native')
    if (folder / 'integrity.json').exists():
        integrity = read(folder / 'integrity.json')
        assert integrity['source_sha256'] == before['v60-postkill-route-escape-' + version]
        for artifact, expected in integrity['artifact_sha256'].items(): assert sha(folder / artifact) == expected
    for name in ['audit.json', 'audit.md', 'integrity.json', 'native-states.json', 'first-decisions.json', 'manifest.json', 'pairs.json', 'compact-local-denial.json', 'combat-cascade-preserved.json', 'return-to-service.json', 'return-to-service.md', 'return-to-service-integrity.json']:
        path = folder / name
        if path.exists(): copy('causal/' + version + '/' + name, path)
        elif name in ['audit.json', 'audit.md', 'integrity.json']: pending.append({'input': str(path.relative_to(ROOT)), 'status': 'causal audit not completed at snapshot'})
    if (folder / 'return-to-service-integrity.json').exists():
        for name, expected in read(folder / 'return-to-service-integrity.json')['files'].items(): assert sha(folder / name) == expected
for name in ['resource-audit.json', 'resource-audit.md']:
    copy('causal/v4/resources/' + name, ROOT / 'retreat-v4-audit/resources' / name)
for name in ['v4-independent-audit.json', 'v5-independent-audit.json', 'audit_v4.py', 'audit_v5.py']:
    copy('mechanisms/independent/' + name, ROOT / 'retreat-continuation-audit' / name)
for name in ['route-inputs.json', 'route-check.json', 'route-check.py']:
    copy('mechanisms/geometric-inputs/' + name, ROOT / 'camp-escape/continuation-audit' / name)
copy('validation/predeclared-plan.json', ROOT / 'retreat-v5-validation-plan.json')
copy('validation/component-plan.json', ROOT / 'retreat-route-only-validation-plan.json')
for name in ['route-only-v5-independent-audit.json', 'audit_route_only_v5.py']:
    path = ROOT / 'retreat-continuation-audit' / name
    if path.exists(): copy('mechanisms/independent/' + name, path)
patchfile = DOCS / 'I037-camp-retreat-component.patch'
patch_audit = read(ROOT / 'retreat-continuation-audit/component-patch-validation.json')
assert patch_audit['patch_sha256'] == sha(patchfile)
assert patch_audit['baseline_source_sha256'] == before['v60-camp-roster-bound']
assert patch_audit['target_source_sha256'] == before['v60-route-only-v5']
copy('patches/' + patchfile.name, patchfile)
for name in ['component-patch-validation.json', 'validate_component_patch.py']:
    copy('mechanisms/patch-application/' + name, ROOT / 'retreat-continuation-audit' / name)
copy('provenance/I036-r2-package-audit.json', DOCS / 'I036-r2-package-audit.json')
put_json('provenance/I036-packaging-revisions.json', {'historical_original_artifacts_preserved': checkpoint, 'corrected_packaging_revision': corrected_I036, 'meaning': 'Original I036 remains historical provenance. I036-r2 restores14 bound CPP fixtures to exact tested bytes. Source archives, recorded tests/games/outcomes and native ledger remain unchanged; no new test, build or game was run. I037 itself preserves copied CPP/py inputs byte-for-byte.'})
for name in ['roster-validation-freeze.json', 'spar-freeze.json']:
    copy('validation/' + name, ROOT / name)

experimental = [r for r in rows if r['role'] == 'experimental']
plan = read(ROOT / 'retreat-v5-validation-plan.json')
assert plan['header_sha256'] == before['v60-postkill-route-escape-v5']['camp_escape.h']
plan_progress = []
for family, target in [('separate_confirmation', plan['separate_confirmation']), ('sparring', plan['sparring'])]:
    for opponent in target['opponents']:
        completed = [p for p in panels if p['candidate'] == plan['candidate'] and p['opponent'] == opponent and p['map_manifest_sha256'] == target['manifest_sha256']]
        expected = target['slots_per_opponent'] if family == 'separate_confirmation' else 2 * target['maps_per_opponent']
        plan_progress.append({'series': family, 'opponent': opponent, 'manifest_sha256': target['manifest_sha256'], 'expected_summary_slots': expected, 'status': 'complete' if any(p['slots'] == expected for p in completed) else 'pending', 'completed_summary_labels': [p['label'] for p in completed]})
component_panels = [p for p in panels if p['candidate'] == 'v60-route-only-v5']
component_plan = read(ROOT / 'retreat-route-only-validation-plan.json')
component_progress = []
for group in component_plan['comparisons']:
    for opponent in group['opponents']:
        completed = [p for p in component_panels if p['opponent'] == opponent and p['map_manifest_sha256'] == group['manifest_sha256']]
        component_progress.append({'opponent': opponent, 'manifest_sha256': group['manifest_sha256'], 'expected_slots': group['slots_each'], 'status': 'complete' if any(p['slots'] == group['slots_each'] for p in completed) else 'pending', 'summary_labels': [p['label'] for p in completed]})
summary = {'status': 'complete diagnostic snapshot, not selected or promoted', 'selected_current_I035': 'v60-camp-roster-bound', 'I036_historical_snapshot_preserved': checkpoint, 'I036_corrected_packaging_revision': corrected_I036, 'v3_design_only_no_native_games': True, 'panels': panels, 'cached_selected_context_panels': context_panels, 'cached_selected_context_slots': len(context_rows), 'validation_plan_progress': plan_progress, 'component_ablation': {'candidate': 'v60-route-only-v5', 'parent': 'v60-camp-escape-v2', 'postkill_capture_enabled': False, 'status': 'saved series included separately' if component_panels else 'pending finite native comparison', 'plan_progress': component_progress, 'summary_labels': [p['label'] for p in component_panels], 'interpretation': 'Complete strict escape plus scoped continuation without postkill. Not a pure route-flag ablation versus I035, which has neither. Same outcome-known historical panel, not new independent confirmation.'}, 'experimental_summary_slots': len(experimental), 'distinct_experimental_records': len({r['key'] for r in experimental}), 'distinct_experimental_physical_keys': len({r['physical_key'] for r in experimental}), 'distinct_experimental_native_streams': len({r['raw_replay_sha256'] for r in experimental}), 'reused_experimental_summary_slots': len(experimental) - len({r['key'] for r in experimental}), 'separate_reused_cached_control_records': len(controls), 'pending_inputs': pending, 'interpretation': ['Source/opponent/map-set rows remain separate; do not pool a strength estimate.', 'Matched v2 and selected-I035 controls were already executed before this follow-up, not new games.', 'No 37-map bare strict-escape-v2 control is invented: a cached control is included only when actual registered records match.', 'Native faults are zero in bound records; caught SDK errors remain and selective stdout is not a complete census.', 'Fuel exhaustion counts are whole trajectories, not the marginal cost of the route helper.']}
put_json('summary.json', summary); put_json('source-manifest.json', {'selected': 'v60-camp-roster-bound', 'sources': source_info}); put_json('input-bindings.json', inputs)

table = '\n'.join('|' + '|'.join(str(x) for x in [p['candidate'].removeprefix('v60-'), p['opponent'], p['maps'], p['slots'], str(p['wins']) + '–' + str(p['losses']), str(p['fuel_events'][0]) + ' / ' + str(p['fuel_events'][1])]) + '|' for p in panels)
context_table = '\n'.join('|' + '|'.join(str(x) for x in [p['candidate'].removeprefix('v60-'), p['opponent'], p['maps'], p['slots'], str(p['wins']) + '–' + str(p['losses']), str(p['fuel_events'][0]) + ' / ' + str(p['fuel_events'][1])]) + '|' for p in context_panels)
v5 = [p for p in panels if p['candidate'] == 'v60-postkill-route-escape-v5']
v5_audit_ready = (ROOT / 'retreat-v5-audit/native/integrity.json').exists()
v5_status = 'The v5 native probe is pending; its fixtures are not match results.' if not v5 else 'The completed v5 probe is listed below. Its native causal audit ' + ('is included separately.' if v5_audit_ready else 'is still pending in this snapshot; no broader panel is justified by the score alone.')
report = f'''# I037 Retreat continuation diagnostics

**Completed diagnostic follow-up. I035's `v60-camp-roster-bound` remains selected; no new bot is promoted or recommended for upload.** This work follows the observed failure of a successful first camp escape to continue: ordinary homeward fallback could immediately re-enter the same camp. We inspect concrete decisions before expanding tests.

The original I036 report and ZIP are preserved as historical artifacts with their original hashes. A [separate I036-r2 packaging correction](I036-r2-camp-lifecycle-diagnostics.md) restores14 exported CPP fixtures to their exact already-tested bytes; use its [corrected executable fixture evidence](I036-r2-camp-diagnostics-evidence.zip). The global backslash exporter error did not change the original source ZIPs, recorded tests, match outcomes or ledger. No tests, builds or games were rerun for that packaging correction. I037's copied CPP inputs are independently checked byte-for-byte. The historical and corrected packaging hashes are both retained under `provenance/`; this is not a claim that all packaging bytes are unchanged.

The [evidence ZIP](I037-retreat-continuation-evidence.zip) contains frozen sources, source patches, actual-header fixtures and their recorded SDK compilation, exact native record bindings, causal audits and resource accounting. Paths below refer to entries inside that archive. {v5_status}

The optional [complete experimental patch](I037-camp-retreat-component.patch) is a full diff from current I035 `bots/team_baseline/src/` to `route-only-v5`, including the new header with `/dev/null` as its old path. It changes only `main.cpp`, `params.h` and the added `camp_escape.h`; it does not change the PR baseline or select a new bot. Ordinary `git apply --check` and application passed in isolated LF and CRLF/autocrlf Git fixtures, reconstructing all 17 target files after explicit LF normalization; the CRLF fixture also matches target raw bytes. This checks applicability, not competitive readiness. The patch is **experimental and not upload-ready**. The exact input/output source hashes and application evidence are in `mechanisms/patch-application/`.

## Three deliberately separate sources

**V3, home-only routing, was rejected before native play.** One field toward home can prolong the currently hitting camp. At the saved compact R186 state, Ryth has 50.25 HP at `(8,8)` inside a wolf's range. The home route can retain three further 18-damage hits, whereas a geometric exit retains two. V3 was compiled and fixture-tested, but has no native games or fuel measurements. Its source is retained as a rejected design checkpoint, not as a tested candidate.

**V4 leaves the current camp first, then heads home.** The unchanged v2 strict-exposure chooser runs first. Only when it has no admissible strict decrease and a legal visible neighboring tile could increase raw camp exposure does continuation run. Non-covering awake hazards form forbidden walls; the complement of the intersection of currently covering hazard squares forms nearest lower-exposure roots. At zero exposure the roots become home. One field supplies a strictly decreasing route; moving allies filter only the immediate step. Champion danger is ranked globally before the route filter. Known completed no-route states may hold only at the current champion minimum; failures, stale inputs or insufficient reserve preserve legacy fallback.

This gives a bounded SDK call pattern, not a hard fuel bound or complete tanking policy: at most eight hazard range draws, one field and nine distance getters. Only fresh visible hazards are modeled. A held champion may still take camp damage. Static-graph descent does not prove progress under changing visibility, hazards, occupancy or enemy decisions.

**V5 narrows continuation to a zero known champion-danger minimum.** Its sole source change from V4 is `if (!(poses.minimum_champion <= 1e-6)) return {{}};`, before any continuation SDK call, scratch mutation or deliberate hold. The original strict-improvement selector still runs first. Equal positive inflated threat envelopes cannot justify a route override; those states return to v2's combat fallback. NaN also declines. This changes admission rather than inventing a new champion risk model. Zero means zero under the current ready-threat model, not guaranteed safety against unseen enemies, future cooldowns or movement.

## Exact v4 decisions and interactions

- **Elkring B, Stellar R107:** candidate and parent share 2,559 global commands and an identical complete 184,696-byte native prestate. V4 moves `(28,19)→(27,19)` instead of re-entering `(28,20)`. Stellar completes a detour west of the elk, retains 225 HP, recalls R120 and reaches home R125. Parent v2 dies to the elk R113. This is a real local rescue. The still-wounded elk outside actual range also matches the inherited nearby-camp warning until allied Tavi kills it R119, consistent with a delayed recall; private read/fuel/`rsafe` values are not recorded, so an earlier successful recall is not claimed.
- **Compact A, Ryth R186:** candidate and parent share 3,954 commands and an identical complete native prestate. V4 moves `(8,8)→(8,7)→(8,6)→(8,5)`, avoiding further camp hits. Stationary Willow at `(5,4)` attacks for 40.5 at R187 and kills Ryth R188. Willow does not chase. The enlarged attack envelope assigns 80 to every legal neighboring pose, so V4 cannot distinguish the approach using that tie. This motivates V5's conservative zero-danger admission gate; it does not validate another multi-turn route.
- **The ally/resource cascade matters:** vacating `(9,9)` lets allied Tavi enter an 80-damage camp zone. V4 Tavi takes 80, 80, 20 and 20 damage, falls from 330 to 130 HP, recalls R193 and reaches home R199. Parent Tavi instead stays at 290 HP and interrupts Prism's group-0 capture R197; own Tavi receives 44 gems R213. In V4 he cannot make that denial, and full-health Prism receives 44 R200. Other trajectories also differ, so the linked sequence is not a sole-cause proof for the final loss.
- **The final compact race is not a neglected winning bag:** own Ren deposits 22 R828 to tie 992–992; own held gems are zero at every round start R829–843. Enemy Stellar deposits 44 R843 to end 992–1036. V4 has less own camp damage and fewer dropped gems than the winning parent, but receives 58 fewer camp-reward gems while the opponent gains 74. Reducing damage alone does not establish better resource ownership or throughput.

The exact hashes, actions, damage, channels, resource receipts and remaining attribution limits are under `causal/v4/`. The local camp rescue and the champion/ally regression are both retained.

## What the scoped v5 native audit establishes

The entire Elkring v5 gameplay stream equals v4: Stellar retains the safe detour and reaches home R125 with 225 HP. Compact preserves 7,319 parent-v2 actions before its first difference; the original R185/R186 focal worlds also match byte-for-byte. Ryth still takes the original camp re-entry and dies R187. Tavi therefore retains the original low-damage route, R197 Prism denial and R213 own 44-gem capture. This avoids the observed V4 combat/ally cascade, while explicitly leaving Ryth's combat retreat unresolved.

The saved return-to-service addendum also distinguishes the detour from simply delaying activity: parent Stellar dies R113, is first alive/full in spawn R173, exits R175 and attacks R179. Scoped v5 arrives R125, reaches full HP R126, exits R129 and attacks R136. Both preserve the observed 102 gold and buy the same three 30-gold HP upgrades, leaving 12; the old death carries zero gems. This is a 43-round earlier observed offensive return in this episode, not a general rule that death is always worse or that the detour/recall timing is optimal.

The later first compact change is Cassi R357 at `(12,9)`, with 160/700 HP and zero reconstructed champion danger. V5 chooses `(12,10)` at raw camp envelope 60, while parent v2 enters `(11,10)` at 80. Later continuation avoids re-entry, recalls R367 and reaches home R372 with 160 HP and no further retreat damage. Parent v2 oscillates between `(11,11)` and `(12,12)`, takes eight 20-damage hits and dies R377. The full native prestates match at the first changed action. This is another local rescue, not proof that it alone causes the final result. Compact v5 has 39 fuel events versus the parent's 33; it does not show uniformly lower runtime cost. The bound details are under `causal/v5/`.

## Source-bound native probes

| Candidate | Opponent | Maps | Slots | Wins–losses | Fuel candidate / opponent |
|---|---|---:|---:|---:|---:|
{table}

V4's four-slot probe is 3–1 against spar11; the exact cached parent controls are kept separately. The four games are a causal diagnostic, not a strength estimate. Completed summaries contain {len(experimental)} experimental slots, {len({r['key'] for r in experimental})} distinct record keys, {len({r['physical_key'] for r in experimental})} distinct physical keys and {len({r['raw_replay_sha256'] for r in experimental})} distinct replay streams; reused records and {len(controls)} cached matched controls are explicitly labeled. Different sources or later map panels are not pooled. All verified native faults are zero; caught SDK errors remain. Whole-trajectory fuel counts cannot establish per-call fuel improvement.

The saved predeclared validation plan requires the four-probe causal audit before any expansion. It specifies separate 37-map/74-slot panels against raw v59 and selected I035, plus six maps against each of three sparring bots (36 slots), reusing the four witness probe records inside the spar11 panel. Those are historical generated maps with earlier control/candidate results, not globally unseen tournament maps or a repository promotion gate. Planned slots are not counted as played; completed series enter the table separately. No parameter sweep, automatic selection, upload, activation or merge is performed here.

The completed postkill-plus-route V5 panels are 37–37 against raw v59, 33–41 against selected I035 and 36–0 across the three sparring bots. This fails to demonstrate superiority to I035, so it is not promoted. A separate component comparison removes the teammate's postkill-capture block without changing the frozen V5 escape policy: `route-only-v5` is exact `camp-escape-v2` plus the frozen V5 header and flag. It therefore contains **the complete strict escape and scoped continuation without postkill capture**. I035 has neither escape nor postkill capture, so the direct I035 comparison is not a pure route-flag ablation. Its finite comparison is {('included as a separate series above' if component_panels else 'pending')}; it is never pooled with postkill-plus-route results. It uses the same historical outcome-known maps, explicitly post hoc rather than new independent confirmation. The composition distinguishes postkill presence, while scores against common opponents do not prove capture is universally harmful. No nonexistent 37-map bare strict-escape-v2 native control is inferred.

The completed component score is 36–38 versus raw v59 and 39–35 versus I035, with 36–0 on the three sparring bots. The direct I035 panel has three maps won on both sides versus one lost on both sides (paired sign p=0.3125): that small 39–35 edge does not demonstrate superiority. Component fuel is 36/66 against raw and 27/20 in the I035 head-to-head. Its matched sparring candidate total is 330, compared with selected I035's 302, so a blanket budget improvement is not established. No further sweep is included in this diagnostic; the component remains unpromoted.

For context, the exact source-bound selected-I035 controls use matching actual map bytes, seeds, runtime and opponent binaries. These cached controls are not additional new games and remain separate from every experimental head-to-head series:

| Cached source | Opponent | Maps | Slots | Wins–losses | Fuel candidate / opponent |
|---|---|---:|---:|---:|---:|
{context_table}

## Validation boundary

V4 full-SDK off/on compilation and actual-header fixtures pass (7 off, 130 on). V5 passes full-SDK off/on compilation and 7 off / 135 on fixture checks, including exact Ryth admission rejection before route queries, positive/infinite/NaN minima, preserved positive-danger strict escape, zero-danger Stellar continuation, consistent no-route holding, lower-champion escape, and failure/owner/round/position/fuel guards. Fixtures use a mocked eight-neighbor field and controlled SDK callbacks; they are not native survival evidence. Independent audits bind exact sources and confirm that main, State, draft, capture and the shared protocol are unchanged from the parent composition.

The physical farming/tanking model, closest victim allocation, future camp wake, fog memory, multi-turn combat risk and ally route coordination remain open. No complete source gate, online A/B, activation or source promotion is claimed. The pending-input list in `summary.json` makes this snapshot explicit; rerunning the builder only incorporates completed saved artifacts and runs no games or tests.
'''
reportfile = DOCS / 'I037-retreat-continuation-diagnostics.md'; reportfile.write_text(report, encoding='utf8')
put_text('tests/README.md', '''# Portable recorded actual-header fixtures

Extract the matching sources/v60-postkill-route-escape-vN.zip. Each tests/v60-postkill-route-escape-vN/fixture.cpp includes that exact source's params.h and camp_escape.h; SDK callbacks and the eight-neighbor field are controlled mocks. No compiler or runtime binary is bundled. The recorded results separately retain complete official-SDK translation-unit compilation.

Example external compilation (replace placeholders):

<wasi>/bin/clang++ --target=wasm32-wasip1 -std=c++20 -O1 -fwasm-exceptions -mllvm -wasm-use-legacy-eh=false -msimd128 -mbulk-memory -isystem <wasi>/share/wasi-sysroot/include/wasm32-wasip1/eh/c++/v1 -I <extracted>/src -L <wasi>/share/wasi-sysroot/lib/wasm32-wasip1/eh <fixture.cpp> -lunwind -o fixture.wasm

Invoke _start with WASI imports and wasmtime.Config.wasm_exceptions=True. For an off test, copy the source and set its single P_CAMP_ESCAPE_ROUTE definition to 0; do not add duplicate definitions. Compile the full production translation with the same target/exception options plus -O0 -I <official-sdk>/cpp -c <extracted>/src/main.cpp. This package builder did not rerun the recorded checks.
''')
put_text('README.md', f'''# I037 diagnostic evidence, review only

Intended report URL after publication: {args.report_url}

Selected source remains I035. V3 is rejected design-only with no native games. V4 and V5 have separate source identities, fixtures and native ledgers. Source archives contain source only; no binaries, tokens, credentials or raw large replays are bundled. Native raw/statistics/stdout hashes are retained for binding. Causal reports and their integrity manifests are sanitized copies of saved artifacts. Original I036 report/evidence hashes remain historical provenance. I036-r2 separately corrects its exported CPP fixture bytes without changing source ZIPs, tests, games or outcomes; use that corrected package for runnable I036 fixtures. Both original and corrected hashes are recorded in provenance/ and summary.json. I037 copied CPP/py inputs are byte-preserved and checked against original bindings.

Fixtures are portable with an external SDK/compiler/runtime; their recorded passing results are narrower than a full final-source gate. Each fixture includes the matching header/params from its source archive. Original workspace test generators and the included evidence/audit builder require this workspace's saved inputs and layout; those scripts are records of provenance, not standalone portable runners. Repeated summaries reusing the same native record are not new independent games. No publication, game, test or promotion is performed by the builder.
''')
copy('builder.py', Path(__file__))
assert all(manifest(source) == before[name] for name, source in sources.items())
assert checkpoint == {name: sha(DOCS / name) for name in checkpoint}
assert corrected_I036 == {name: sha(DOCS / name) for name in corrected_I036}
assert all(digest(entries[name]) == info['sha256'] for name, info in inputs.items() if Path(name).suffix in ['.cpp', '.py', '.h'])
assert not any(re.search(rb'[A-Za-z]:[/\\]+Users[/\\]+frans', content) for name, content in entries.items() if not name.endswith('.zip'))
put_json('integrity.json', {'status': 'pass', 'source_unchanged': True, 'I036_historical_artifacts_preserved': checkpoint, 'I036_corrected_packaging_revision': corrected_I036, 'selected_source_unchanged': before['v60-camp-roster-bound'], 'no_games_tests_builds_GitHub_or_promotion': True, 'report_sha256': sha(reportfile), 'builder_sha256': sha(__file__), 'files': {name: digest(content) for name, content in sorted(entries.items())}})
archive = DOCS / 'I037-retreat-continuation-evidence.zip'
archive_data = zipdata(entries)
assert archive_data == zipdata(entries), 'Archive ordering, dates and bytes must be deterministic.'
archive.write_bytes(archive_data)
for name, info in source_info.items():
    with zipfile.ZipFile(io.BytesIO(entries[info['archive']])) as source_archive:
        assert source_archive.testzip() is None
        assert {Path(n).name: digest(source_archive.read(n)) for n in source_archive.namelist()} == before[name]
        assert not any(re.search(rb'[A-Za-z]:[/\\]+Users[/\\]+frans', source_archive.read(n)) for n in source_archive.namelist())
assert not any(name.endswith(('.wasm', '.repl26a', '.exe', '.dll')) for name in entries)
audit = {'status': 'complete_diagnostic_snapshot_not_promoted', 'report': reportfile.name, 'report_sha256': sha(reportfile), 'archive': archive.name, 'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size, 'archive_entries': len(entries), 'optional_full_patch': patchfile.name, 'optional_full_patch_sha256': sha(patchfile), 'patch_validation_sha256': sha(ROOT / 'retreat-continuation-audit/component-patch-validation.json'), 'experimental_summary_slots': summary['experimental_summary_slots'], 'distinct_experimental_records': summary['distinct_experimental_records'], 'distinct_experimental_physical_keys': summary['distinct_experimental_physical_keys'], 'distinct_experimental_native_streams': summary['distinct_experimental_native_streams'], 'reused_summary_slots': summary['reused_experimental_summary_slots'], 'separate_cached_parent_control_records': len(controls), 'separate_cached_selected_context_slots': len(context_rows), 'pending': pending, 'validation_plan_progress': plan_progress, 'component_plan_progress': component_progress, 'source_archives_hash_verified': True, 'recorded_cpp_fixtures_preserved_byte_for_byte': True, 'nested_zip_crc_verified': True, 'deterministic_zip_bytes_verified': True, 'no_binaries_raw_replays_or_private_absolute_paths': True, 'I036_historical_snapshot_preserved': checkpoint, 'I036_corrected_packaging_revision': corrected_I036}
(DOCS / 'I037-package-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps(audit, indent=2))
