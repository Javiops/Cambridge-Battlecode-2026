# Separate exit-first route v4: exact native follow-up

The audit reads two distinct saved slots from the root four-game probe, against the exact cached postkill-plus-escape-v2 controls. Map bytes, actual seed, opponent source and draft match. The only production-source differences from v2 are the route header and its flag. No games, candidate edits or new native queries beyond the prepared target set were performed. I035 and the completed I036 checkpoint remain unchanged.

| Slot | Parent v2 | Exit-first v4 | First changed command | Focal outcome |
|---|---:|---:|---|---|
| Elkring B / spar11 | 1008–828 | 1008–900 | After 2,559 identical commands, Stellar R107/input2580: `(28,19)→(27,19)` instead of `(28,20)` | Completes retreat and recall; reaches home R125 with 225 HP instead of dying to elk R113 |
| Compact A / spar11 | 1014–904 | 992–1036 | After 3,954 identical commands, Ryth R186/input3975: `(8,8)→(8,7)` instead of `(9,9)` | Avoids later camp hits, but walks toward enemy firing range and dies to Willow R188 instead of camp R187 |

Both first-command prestates match not only in parsed state but in the **complete 184,696-byte native visualiser snapshot**. The first shared raw hashes are `67c19e73dc033f357c0abb4b7920670c91c1d292626f6bc96f2b6b052e291a1d` on Elkring and `05615dee0df4648170461653d15f4ad0e60fdab5b4bfb208bb5a7fe846f00611` on compact. These prefixes and states were measured, not assumed from fixtures.

## Elkring: the continuation prevents re-entry, with an inherited recall delay

Stellar retains 225 HP throughout the retreat: west along y19 to `(23,19)`, then `(22,20)` through `(22,26)`, then `(23,27)`. There are no further camp or champion hits before recall at R120 and home arrival at R125. Her later next death is an unrelated fight at R177, not this camp episode. The local continuation works here.

The already prepared R107 native query shows no personally queryable foes within 10, no omniscient enemies within 8, and one damaging camp within 5: awake elk1 `(26,23)`, HP664/2400, strength60, actual range3. Stellar `(28,19)` is at distance4 and has camp/champion envelopes0. That camp nevertheless matches the inherited `distance<=CAMP_RANGE+1 && health<max_health` warning. Allied Tavi kills it at R119/input2851 (24→0), immediately before the R120 recall. This is concrete evidence consistent with a false nearby-camp warning delaying a potentially earlier recall. Private `rsafe`, read success and fuel are not recorded, and no alternate recall was executed; an earlier successful channel is not claimed.

## Compact: camp exit succeeds but route direction meets enemy attacks

Ryth starts the first changed turn with 50.25 HP after the wolf’s 18 damage. V4 moves `(8,8)→(8,7)→(8,6)→(8,5)`, receiving no additional camp damage after the differing command. This removes the v2 re-entry failure.

The enemy is **not pursuing him**. At shared R186, visible Willow is `(6,5)` and Prism `(8,5)`; both move away to `(5,4)` and `(7,4)`. Ryth’s route advances toward them. Stationary Willow at `(5,4)` attacks `(8,6)` for40.5 at R187, leaving9.75 HP, then kills Ryth at `(8,5)` at R188. The source’s enlarged basic-danger envelope assigns80 to every legal neighbor at the exact R186 state, so its champion-minimum gate cannot distinguish that approach. A current one-step risk tie is not proof of multi-turn retreat safety. No better counterfactual route or complete pursuit model is validated here.

The new Ryth position also leaves `(9,9)` available for allied Tavi at R186, where the v2 Ryth occupied it. The separate resource audit confirms the following local chain. V2 Tavi moves to `(7,9)`, takes two wolf hits (330→290 HP), remains on field and interrupts Prism's group0 capture at R197 with a cast (617→331 HP). Own Tavi eventually captures44 at R213. V4 Tavi enters `(9,9)`, takes80 at both R187 and R188, then20 at R189 and R190 (330→130 HP), retreats and recalls at R193/homeR199. He cannot provide that R197 denial; full-health Prism captures44 at R200. Earlier Prism movements also differ, so this is a concrete tanking/return/denial interaction, not a sole-cause proof for the final defeat.

## What immediately ends the compact game

Own Ren deposits22 at R828, tying the score992–992. After that deposit, there are **zero own held gems at every round start from R829 through R843**. Enemy Stellar deposits44 at `(24,17)` at R843 to finish992–1036. This is a collection/contest race, not an already-winning bag ignored by delivery. Own final captures are44 at R786,36 at R806,36 at R811 and22 at R821; the enemy obtains its final44 at R823. The causal chain from an earlier route difference to those later opportunities is not established by this endpoint alone.

Whole-match fuel exhaustions are0 versus0 on Elkring and13 versus33 on compact, with zero native faults in these records. Caught SDK markers remain. These counts are trajectory-dependent and do not identify the route helper’s marginal fuel cost. No focal stall or deliberate hold is established: the recorded focal turns move until recall/death, and private mode/field/hold values are unavailable.

The mechanism has a real local success and a real champion-risk limitation. The four-game probe does not demonstrate strength and is not a reason for broader panels or promotion. Exact keys, sources, commands, damage, channel timing and native states are bound in `audit.json`, `first-decisions.json` and `native-states.json`.
