# Compact A resource audit: saved route v4 versus parent

Two exact same-map/seed/opponent saved native timelines; first movement divergence R186. Parent wins 1014–904 at R837; route v4 loses 992–1036 at R843. No games, new native queries or production edits.

| Metric | Own parent → v4 | Opponent parent → v4 |
|---|---:|---:|
| Collected gems | 1,138 → 1,080 | 1,072 → 1,146 |
| Banked gems | 1,014 → 992 | 904 → 1,036 |
| Kills | 16 → 16 | 20 → 21 |
| Deaths, all causes | 29 → 28 | 24 → 22 |
| Camp HP damage taken | 10,816.65 → 9,160.00 | 12,837.00 → 11,693.00 |
| Earned gold | 5,210 → 4,960 | 5,140 → 5,515 |
| Gems lost on death | 124 → 88 | 132 → 88 |
| Camp reward gems | 1050 → 992 | 984 → 1058 |
| Champion-loot gems | 88 → 88 | 88 → 88 |
| Camp hit recipient records | 364 → 348 | 462 → 410 |
| Camp-caused deaths | 4 → 0 | 2 → 0 |
| Recall start commands | 40 → 46 | 49 → 51 |
| Recall starts with gems | 7 → 9 | 11 → 19 |

## What actually changes

The new loss contains less own camp damage and fewer dropped gems, so neither a larger total tanking bill nor extra lost bags explains the endpoint regression.
Own campGroup receipts fall58 while opponent campGroup receipts rise74; champion-loot receipts remain88 for both teams in both versions. Resource ownership/throughput changes dominate the collection difference.
The first observed post-divergence ownership reversal is group0: opponent Prism collects44 atR200, versus own Tavi atR213 in the parent timeline. This is downstream temporal evidence, not proof that one R186 decision solely causes every later event.
The nearby ally interaction has a concrete chain: Ryth vacates9,9; new Tavi moves there atR186 and takes80 atR187 and80 atR188, eventually130HP/R190. Tavi recallsR193 and reacheshomeR199. Parent Tavi moves7,9 instead, takes only40 in two later20hits and remains290HP. Parent Tavi casts atPrism8,8 from4,12 atR197; Prism617to331HP retreats7,7 and its capture resets. New Tavi is recalling and cannot issue that contest cast, allowing the full-health Prism rewardR200. Other foes also chose different movement afterR186, so this is an observed linked interaction, not a single-variable final-win proof.
Opponent Stellar increases submitted gems298to458, avoids its parent's sole death and lost44-gem bag, and deposits the parent's final36-gem held balance as well as collecting80 more. Own Stellar deposits204to88; Ren116to248 and Ryth300to344 offset part of that drop.
AtR828 both new teams have banked992; own held bag balance is0 and remains0 at the endingR843. Opponent Stellar's44-gemR843 bank ends the match. This is not a friendly winning bag ignored in favor of denial.
Recall-start counts and sampled carried-gem burden are descriptive only. They cannot establish safe recall completion or per-function cost without private decision/fuel instrumentation.
Compact fuel events33to13 and the four-slot totals62to27 are whole trajectory counts; they do not prove the new routing helper costs less fuel per call.

## Resource ownership

Group0 is the own-side two-wolf reward (44 gems), group4 the own-side elk (36), group6 the own-side one-wolf reward (22); group1/5/7 are their opposite-side counterparts.

| Camp group | Own parent → v4 gems | Opponent parent → v4 gems |
|---|---:|---:|
| 0 | 484 → 440 | 0 → 44 |
| 1 | 0 → 0 | 484 → 528 |
| 4 | 324 → 252 | 0 → 36 |
| 5 | 0 → 36 | 324 → 252 |
| 6 | 220 → 242 | 0 → 22 |
| 7 | 22 → 22 | 176 → 176 |

The parent loses a 36-gem Issac bag to a camp at R377; v4 has no positive gem bag lost to camps. The opponent parent loses Stellar's 44-gem bag to a camp at R386; v4 Stellar never dies. These are large downstream differences, with opposing effects. Own total lost bags fall by36, while enemy lost bags fall by44.

## Banking tempo

| Round | Parent own / opponent bank | Route v4 own / opponent bank |
|---|---:|---:|
| 185 | 204 / 226 | 204 / 226 |
| 200 | 204 / 226 | 204 / 226 |
| 300 | 328 / 364 | 306 / 350 |
| 400 | 372 / 430 | 372 / 518 |
| 500 | 540 / 488 | 496 / 598 |
| 600 | 730 / 612 | 678 / 656 |
| 700 | 832 / 736 | 766 / 766 |
| 800 | 934 / 904 | 854 / 992 |
| 828 | 978 / 904 | 992 / 992 |
| 836 | 978 / 904 | 992 / 992 |

The new final bank race is 992–992 at R828. Own carriers have no remaining gems; enemy Stellar collects44 at R823 and delivers it at R843. The parent instead takes another own-side elk36 with Issac at R832 and banks it R837. Those are different resource/position histories, so a terminal own-bank priority patch is not demonstrated here.

## Limits

- Only two saved same-slot timelines, endingR837and843. Later actions/worlds are counterfactual continuations afterR186, not independent matched interventions.
- Final team deaths include camp deaths, so deaths differ from enemy credited kills. Camp-hit recipient events count exact HP-loss records, with fatal remainder damage rather than pre-mitigation nominal strength.
- Parent own Issac has420more camp-phase native HP loss than the official monsterDamageTaken metric; the other bodies reconcile within.01. This unresolved attribution/accounting discrepancy is preserved explicitly rather than forcing both quantities to agree.
- Round-sampled carried-gem integral is a censored stock-time burden, not an identified physical-gem transit latency.
- Clear-to-receipt includes the fixed reward capture channel and any delay; it is not a direct farming decision runtime.
- No new native queries, games or production edits. Frozen v4 is not promoted by this audit.

`resource-audit.json` contains source/record/statistics/decoded hashes, official metrics, all positive reward receipts/lost bags, checkpoint balances and carrier metrics. Raw native trajectory interpretation is separately audited in the sibling `native` directory.
