# Scoped zero-danger continuation v5: exact native witnesses

This read-only audit examines two distinct saved slots from the root four-game spar11 probe. Map bytes, actual seed, opponent source and draft match the cached postkill-plus-escape-v2 controls. V5 is frozen at WASM `0c76507051246af0a937c14cc30469425570e8322a61b8077c140ae2d3de34bc`. No additional matches, source changes or query expansion were performed. The I035 selected source and completed I036 checkpoint remain unchanged.

| Slot | Parent v2 | Scoped v5 | Actual first changed decision |
|---|---:|---:|---|
| Elkring B | 1008–828 | 1008–900 | After 2,559 identical actions, Stellar R107/input2580 `(28,19)→(27,19)` instead of re-entry `(28,20)` |
| Compact A | 1014–904 | 1014–976 | After 7,319 identical actions, Cassi R357/input7340 `(12,9)→(12,10)` instead of `(11,10)` |

Both first differences have identical complete 184,696-byte native visualiser snapshots and parsed states. The shared raw hashes are `67c19e73dc033f357c0abb4b7920670c91c1d292626f6bc96f2b6b052e291a1d` on Elkring and `7baea4bdbfc38a8760e90c1eb03eaabe5cd9b0afacb9ebfa3bc1049532bd14cd` on compact. The original R185/R186 compact focal worlds also match byte-for-byte. No prefix was assumed from the fixtures.

## The isolated Stellar retreat is preserved

The **entire Elkring v5 gameplay stream equals v4**, across all actions, round states, damage, deaths, captures, submissions, turns and final state. Stellar follows the verified safe detour, retains 225 HP, recalls at R120 and reaches home R125 without further retreat damage. V2 dies to the elk at R113. The inherited range4 warning despite an actual range3 camp still plausibly delays recall, as documented by the separate v4 audit; v5 does not change that policy.

## The threatened combat cascade is avoided

Compact v5 exactly preserves v2’s earlier interaction. Ryth R186 moves `(8,8)→(9,9)` and still dies to the camp at R187. Tavi therefore moves `(8,10)→(7,9)`, takes only two wolf hits, remains on field at 290 HP, casts at R197 to reduce Prism 617→331, and captures 44 gems at R213. All those native events match the control exactly. The v4 chain—Tavi occupying `(9,9)`, taking 80/80/20/20 damage, recalling and missing that denial—is absent.

This is a deliberate scope limit, not a claim that Ryth’s combat retreat is fixed. The existing strict camp-exposure step remains active; the new continuation is declined when known champion danger is positive. The observed gate preserves the original combat decisions in this case.

## A separate later noncombat retreat is repaired

The real first compact difference occurs much later. Cassi body 2 has160/700 HP at `(12,9)` in R357. The current raw camp envelope is60 and the reconstructed champion danger is0 across every legal neighbor. The new step `(12,10)` remains at raw60, while the old `(11,10)` enters raw80. The routes meet at `(12,11)` in R358 and `(12,12)` in R359, but continuation now prevents the later re-entry: v5 moves around the wolf along y13, recalls at `(5,14)` in R367 and arrives home R372 with160 HP and **zero further retreat damage**. V2 alternates `(11,11)↔(12,12)`, takes eight 20-damage wolf hits and dies at R377.

This is concrete local survival evidence beyond merely suppressing the v4 regression. It does not establish that the rescue alone explains the final 1014–976 result.

## Validation boundary

No new witness-level mechanism blocker was found for the root’s fixed finite validation. Four games cannot establish competitive strength or justify promotion. Ryth’s combat death, the full concentrated camp-damage/tanking model and the inherited recall warning remain unresolved.

In the audited slots, native exhaustion counts are 0 versus0 on Elkring and 39 versus 33 on compact. Those trajectory-dependent counts do not measure helper cost or show a uniform fuel improvement. Native faults are 0, while caught SDK markers remain. The root’s complete four-slot ledger is separate. Private mode, field, cache and fuel-admission state are unavailable; this audit records actual movement, damage and channel progression rather than inventing an internal trace.

`audit.json` binds source/record/WASM identities and exact excerpts; `native-states.json` contains raw and parsed world comparisons; `combat-cascade-preserved.json` retains the identical Ryth/Tavi/capture evidence. No experimental source was promoted or checkpoint bundle rebuilt.
