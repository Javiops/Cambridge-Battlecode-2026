# Stellar: safe detour versus death and respawn

These are actual own-command observations from the already decoded same-seed Elkring witness. No native queries, matches or source edits were performed.

| Observation | Parent v2: camp death | Scoped v5: safe detour | V5 earlier by |
|---|---:|---:|---:|
| Alive inside own spawn | R173, 1050/1050 HP | R125, 225/825 HP before purchases | 48 rounds |
| Full HP inside spawn | R173, 1050/1050 | R126, 1050/1050 | 47 rounds |
| First move outside spawn | R175 | R129 | 46 rounds |
| First offensive action after return | R179, camp spell toward `(20,27)` | R136, camp spell toward `(26,17)` | 43 rounds |

V2 Stellar dies to the elk at R113 carrying **0 gems**. The last alive and first dead own-command snapshots both show **102 gold**; she buys three HP upgrades while dead (30 gold each), leaving 12 gold and max 1050 HP. The first alive/full-HP own command in spawn occurs at R173, 60 rounds after death.

V5 completes the fourteen-move camp detour, recalls R120 and is observed in spawn at R125 with 225/825 HP. The same three HP purchases produce 450/1050 HP and 12 gold. At R126 she is full 1050/1050, moves within spawn at R127/R128, and leaves it at R129. Thus, despite the long detour and the inherited plausible recall-warning delay, the observed return to service is substantially earlier than the old death/respawn episode.

This is a local timing comparison, not a claim that intentional death is always bad, this route is optimal, or the timing difference alone causes a match victory. No alternate earlier recall was executed. `return-to-service.json` binds the exact commands, purchases, death and replay identities.
