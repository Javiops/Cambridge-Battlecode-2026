"""Offline read-only feasibility check, not a production policy or engine simulation."""
from pathlib import Path
from collections import deque
import json,hashlib
R=Path(__file__).resolve().parent;inp=json.loads((R/'route-inputs.json').read_text());proof=[]
directions=[(0,1),(1,1),(1,0),(1,-1),(0,-1),(-1,-1),(-1,0),(-1,1)]
def cheb(a,b):return max(abs(a[0]-b[0]),abs(a[1]-b[1]))
for w in inp['rows']:
 width,height=w['width'],w['height'];pos=(w['self']['x'],w['self']['y']);home=(w['spawnCentre']['x'],w['spawnCentre']['y'])
 cells={(c['x'],c['y']):c for c in w['cells']};newhaz=[h for h in w['hazards']if not h['coversCurrent']]
 blocked={p for p,c in cells.items()if c['staticBlocked']or c['occupied']or any(cheb(p,(h['position']['x'],h['position']['y']))<=h['range']for h in newhaz)}
 blocked.discard(pos)
 spawn=w['spawn'];roots=[(x,y)for x in range(spawn[0],spawn[2])for y in range(spawn[1],spawn[3])if(x,y)not in blocked]
 distance={p:0 for p in roots};q=deque(roots)
 while q:
  p=q.popleft()
  for dx,dy in directions:
   n=(p[0]+dx,p[1]+dy)
   if n in cells and n not in blocked and n not in distance:distance[n]=distance[p]+1;q.append(n)
 currentchamp=w['prestate']['current']['reconstructedChampionDanger'];legal=[p for p in w['prestate']['poses']if p['legal']and p['personallyVisible']]
 minimum=min([currentchamp]+[p['reconstructedChampionDanger']for p in legal]);rank=[]
 for c in legal:
  p=(c['x'],c['y']);rank.append({**c,'homeChebyshev':cheb(p,home),'routeDistance':distance.get(p),
    'admissible':c['reconstructedChampionDanger']<=minimum+1e-6 and c['rawCampEnvelope']<=w['currentExposure'] and p in distance and pos in distance and distance[p]<distance[pos]})
 eligible=[p for p in rank if p['admissible']];eligible.sort(key=lambda p:(p['routeDistance'],p['homeChebyshev']));best=eligible[0]if eligible else None
 path=[pos]
 if best:
  path.append((best['x'],best['y']))
  for _ in range(width*height):
   p=path[-1]
   if distance[p]==0:break
   successors=[(p[0]+dx,p[1]+dy)for dx,dy in directions if(p[0]+dx,p[1]+dy)in distance and distance[p[0]+dx,p[1]+dy]==distance[p]-1]
   n=min(successors,key=lambda n:cheb(n,home))
   path.append(n)
  assert distance[path[-1]]==0
 proof.append({'case':w['case'],'key':w['key'],'round':w['round'],'position':pos,'spawnCentre':home,'currentExposure':w['currentExposure'],
               'currentChampionDanger':currentchamp,'minimumChampionDanger':minimum,'currentHomeChebyshev':cheb(pos,home),'currentRouteDistance':distance.get(pos),
               'newly_entered_hazards_forbidden':newhaz,'poses':rank,'first_continuation':best,'static_route_example':path,
               'route_reaches_spawn':bool(best),'all_route_distances_strictly_decrease':all(distance[b]<distance[a]for a,b in zip(path,path[1:])),
               'first_move_is_native_legal_and_personally_visible':bool(best and best['legal']and best['personallyVisible']),
               'whole_path_visibility_required':False,'limits':'Only first-step legality/visibility is native evidence. Later path poses are geometric feasibility under this frozen known terrain/occupancy/hazard graph, not future action legality or enemy behavior.'})
out={'status':'read-only offline route calculation over saved native snapshot; not engine simulation','inputs_sha256':hashlib.sha256((R/'route-inputs.json').read_bytes()).hexdigest(),'rows':proof}
(R/'route-check.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps([{k:r[k]for k in ['case','position','currentHomeChebyshev','currentRouteDistance','first_continuation','static_route_example']}for r in proof],indent=2))
