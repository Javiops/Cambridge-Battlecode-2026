"""Read-only binding/composition audit; never compiles or runs a game."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent
SRC = ROOT / 'route-only-v5/src'
BASE = ROOT / 'camp-escape-v2/src'
V5 = ROOT / 'postkill-route-escape-v5/src'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest = lambda d: {p.name: sha(p) for p in sorted(d.iterdir()) if p.is_file()}
source, baseline = manifest(SRC), manifest(BASE)
results = json.loads((SRC.parent / 'results.json').read_text())
freeze = json.loads((SRC.parent / 'freeze.json').read_text())
composition = json.loads((SRC.parent / 'composition.json').read_text())
assert set(source) == set(baseline)
assert [n for n in source if source[n] != baseline[n]] == ['camp_escape.h', 'params.h']
assert source == freeze['source_sha256'] == results['source_sha256'] == composition['source_sha256']
assert (SRC / 'main.cpp').read_bytes() == (BASE / 'main.cpp').read_bytes()
assert (SRC / 'camp_escape.h').read_bytes() == (V5 / 'camp_escape.h').read_bytes()
params, original = (SRC / 'params.h').read_text(), (BASE / 'params.h').read_text()
flag = '\n// Continue a known camp escape toward lower exposure, then home.\n#define P_CAMP_ESCAPE_ROUTE 1\n'
assert params.count(flag) == 1 and params.replace(flag, '') == original
main = (SRC / 'main.cpp').read_text()
assert 'P_CF_POSTKILL_CAPTURE' not in main + params
assert 'cf-postkill' not in main
assert results['status'] == 'pass' and all(v['full_sdk_compile'] for v in results['variants'])
report = {
    'status': 'independent exact-source composition audit passed for finite component comparison',
    'source': {'path': 'route-only-v5/src', 'sha256': source},
    'parent': {'path': 'camp-escape-v2/src', 'sha256': baseline},
    'only_changed_files': ['camp_escape.h', 'params.h'],
    'checks': {
        'same_17_file_set': True,
        'main_and_other_14_nonparam_headers_byte_identical_to_bare_escape_v2': True,
        'header_byte_identical_to_independently_audited_frozen_postkill_route_v5': True,
        'params_only_add_route_flag_and_comment': True,
        'postkill_capture_flag_and_main_block_absent': True,
        'State_shared_protocol_draft_camp_farming_call_order_unchanged_from_parent': True,
    },
    'bindings': {n: sha(SRC.parent / n) for n in ['results.json', 'freeze.json', 'composition.json', 'change.patch', 'test_route.py']},
    'route_semantic_audit': {'path': 'v5-independent-audit.json', 'sha256': sha(HERE / 'v5-independent-audit.json')},
    'verification_reviewed_not_rerun': [{k: v[k] for k in ['route_enabled', 'stdout', 'full_sdk_compile']} for v in results['variants']],
    'interpretation': [
        'This removes the postkill-capture component from the combined composition without tuning or changing the frozen V5 route policy.',
        'The experimental parent already includes the strict escape-v2 mechanism; this is not selected I035 plus only the continuation flag.',
        'New native records must bind this exact source and remain separate from postkill-plus-route V5 panels.',
        'No outcome, budget improvement, complete tanking repair or source promotion is established by this audit.',
    ],
    'audit_ran_builds_tests_or_games': False,
    'selected_I035_and_published_I036_unchanged': True,
}
out = HERE / 'route-only-v5-independent-audit.json'
out.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'path': str(out), 'sha256': sha(out), 'main_sha256': source['main.cpp'], 'header_sha256': source['camp_escape.h'], 'params_sha256': source['params.h']}, indent=2))
