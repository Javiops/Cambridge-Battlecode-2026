"""Read-only source/binding audit; does not compile or run a game."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'postkill-route-escape-v4/src'
BASE = ROOT / 'postkill-escape-v2/src'
HERE = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest = lambda d: {p.name: sha(p) for p in sorted(d.iterdir()) if p.is_file()}
source, baseline = manifest(SRC), manifest(BASE)
freeze = json.loads((SRC.parent / 'freeze.json').read_text())
results = json.loads((SRC.parent / 'results.json').read_text())
assert source == freeze['source_sha256'] == results['source_sha256']
assert set(source) == set(baseline)
assert [n for n in source if source[n] != baseline[n]] == ['camp_escape.h', 'params.h']
assert (SRC / 'main.cpp').read_bytes() == (BASE / 'main.cpp').read_bytes()
assert results['status'] == 'pass'
assert all(v['full_sdk_compile'] for v in results['variants'])
header = (SRC / 'camp_escape.h').read_text()
assert header.count('s.df.compute_to(') == 1
assert 'const bc::bitboard roots = (leave_camp ? ~retained : s.my_spawn) & ~walls;' in header
assert 'c.champion > poses.minimum_champion + 1e-6' in header
assert 'c.camp > poses.current_camp' in header
assert 'distance >= here' in header
assert 'return complete ? result : Continuation{};' in header
assert 'if (hold) return true;' in header
assert not any(x in header for x in ['shared_memory', 'read_sm(', 'write_sm(', 'export_linear_buffer', 'move_towards'])

report = {
    'status': 'independent read-only audit complete; no semantic blocker found for bounded native experiment',
    'scope': 'Frozen experimental v4 only; selected I035 source and published I036 checkpoint remain unchanged.',
    'source': {'path': 'postkill-route-escape-v4/src', 'sha256': source},
    'baseline': {'path': 'postkill-escape-v2/src', 'sha256': baseline},
    'only_changed_files': ['camp_escape.h', 'params.h'],
    'bindings': {name: sha(SRC.parent / name) for name in ['freeze.json', 'results.json', 'change.patch', 'test_route.py']},
    'production_changes': {
        'main_unchanged': True,
        'state_layout_unchanged': True,
        'shared_protocol_unchanged': True,
        'draft_and_postkill_capture_unchanged': True,
        'route_flag': 'P_CAMP_ESCAPE_ROUTE, params.h:181, default 1 in this experiment; header fallback default 0',
    },
    'proofs': [
        {'claim': 'Global champion priority precedes camp/path filtering.',
         'source_lines': 'camp_escape.h:44-71,139-142',
         'reason': 'The minimum includes the current pose and all currently legal, personally visible adjacent poses; route membership does not remove a safer champion pose from that minimum.'},
        {'claim': 'Positive-phase roots are exactly strict-lower known raw exposure under the no-new-membership constraint.',
         'source_lines': 'camp_escape.h:101-119',
         'reason': 'Every retained hazard has positive finite strength and covers current. Forbidden is the union of every other known hazard. Outside the intersection of retained zones loses at least one positive current hazard; forbidden excludes any replacement. Inside the intersection retains all of them.'},
        {'claim': 'The field targets nearest lower exposure first, home only at zero.',
         'source_lines': 'camp_escape.h:117-132',
         'reason': 'An eight-neighbor distance field from all legal lower-exposure roots gives nearest geometric exit distance on the frozen graph. This avoids the rejected home-only objective that prolonged the wolf exposure.'},
        {'claim': 'Continuation does not authorize arbitrary equal-distance sidesteps.',
         'source_lines': 'camp_escape.h:134-146',
         'reason': 'Each selected step strictly decreases field distance; a fresh static graph is independent of moving champion occupancy. Immediate occupancy/visibility remains in the cached candidate filter. Stable-graph progress is the warranted claim, not future-world progress under changing hazards, visibility or threats.'},
        {'claim': 'Complete no-route holds do not suppress a known strictly safer champion escape.',
         'source_lines': 'camp_escape.h:121-126,151-159',
         'reason': 'Hold is returned only when current champion danger is at the global minimum. Otherwise the helper declines to existing flee. A held body can still take damage from its current camp.'},
        {'claim': 'Read or field failures cannot certify a held or moved turn.',
         'source_lines': 'camp_escape.h:98-100,120,133,150,159,209-216,220-236',
         'reason': 'Pose query exceptions are caught in the new enabled branch. The continuation attempt must complete and pass owner/round/fuel checks. Final checks also require current owner/round/position and movement readiness before either Hold or Move.'},
        {'claim': 'Scratch buffer changes do not mutate a persistent route or shared plan.',
         'source_lines': 'camp_escape.h:127-134; main.cpp:1728-1871,4268-4278',
         'reason': 'Only s.dest, s.visited and s.df scratch are written; existing main uses these in step_towards and recomputes them on normal field paths. Low-fuel legacy fallback does not consume those fields. No State field or shared-memory encoding changes.'},
    ],
    'sdk_cost_review': {
        'new_field_computations_per_continuation': 'at most 1',
        'hazard_rectangle_draws': 'at most 8',
        'distance_getters': 'current plus at most 8 cached candidates',
        'map_tile_sdk_loop': False,
        'qualification': 'The call pattern is bounded, but one board-sized host field search and several map-sized bitboard allocations/copies are not a hard fuel bound. Native fuel must be measured. No measured speed claim is made.',
        'important_existing_cost': 'choose uses up to 16 bitboard.is_set host queries across eight poses. Its inherited comment saying the pose loop has no SDK calls is inaccurate; calculations after those reads are local.',
        'sdk_reference': 'sdk/cpp/cambc.h:793-800 (bit test), 1309-1329 (compute_to), 1349-1373 (up to 9 next-move getters)',
    },
    'verification_reviewed_not_rerun': {
        'owner_results': [{k: v[k] for k in ['route_enabled', 'stdout', 'full_sdk_compile']} for v in results['variants']],
        'fixture_limits': 'Actual production headers and fallback branch with a mocked eight-neighbor field; compiler acceptance is actual official SDK. The repeated route and two-hit positive-phase assertions are geometry/planner fixtures, not a native survival claim.',
        'audit_ran_builds_or_games': False,
    },
    'remaining_limitations': [
        'Only fresh visible awake hazards enter the snapshot. Leaving vision can forget an active camp; no persistent fog memory is added.',
        'Raw envelope sums are a conservative potential, not actual next-phase damage: nearest target, cooldown, mitigation and other champion tanking are not modeled.',
        'Existing strict one-step exposure improvements retain their previous home tie-break and may precede this route objective.',
        'Held can continue taking current camp damage; no complete tanking or survival solution is claimed.',
        'Unknown/error/low-fuel/action-failure cases deliberately retain legacy fallback, which can re-enter a camp.',
        'The existing melee-hit precedence, future AoE wake, enemy moves and source action suspension can interrupt a geometric route.',
        'No blanket no-oscillation guarantee exists when hazard membership, visibility, threats or camp occupancy changes.',
    ],
    'minor_documentation_notes': [
        'The inherited no-SDK pose-loop comment is inaccurate because blocked/visibility tests are SDK calls.',
        'README empty-home-goal decline wording applies to zero-exposure home mode; positive mode can still route to lower exposure even if the spawn mask were empty.',
    ],
}
output = HERE / 'v4-independent-audit.json'
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'path': str(output), 'sha256': sha(output), 'source_header_sha256': source['camp_escape.h'], 'status': report['status']}, indent=2))
