"""Bind the one-condition v5 change to the independent frozen-v4 audit."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent
SRC = ROOT / 'postkill-route-escape-v5/src'
PARENT = ROOT / 'postkill-route-escape-v4/src'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest = lambda d: {p.name: sha(p) for p in sorted(d.iterdir()) if p.is_file()}
source, parent = manifest(SRC), manifest(PARENT)
freeze = json.loads((SRC.parent / 'freeze.json').read_text())
results = json.loads((SRC.parent / 'results.json').read_text())
v4audit = json.loads((HERE / 'v4-independent-audit.json').read_text())
assert source == freeze['source_sha256'] == results['source_sha256']
assert parent == v4audit['source']['sha256']
assert set(source) == set(parent)
assert [n for n in source if source[n] != parent[n]] == ['camp_escape.h']
new, old = (SRC / 'camp_escape.h').read_text(), (PARENT / 'camp_escape.h').read_text()
block = '''    // Equal positive champion envelopes cannot rank real imminent enemy fire.
    // Keep the original combat fallback unless a zero-known-danger pose exists.
    // NaN also declines; the strict camp-improvement selector already ran.
    if (!(poses.minimum_champion <= 1e-6)) return {};
'''
assert new.count(block) == 1 and new.replace(block, '') == old
entry = new.index('Continuation continue_retreat(')
gate = new.index('if (!(poses.minimum_champion <= 1e-6)) return {};', entry)
assert gate < new.index('Continuation result;', entry) < new.index('const bool complete = attempt(', entry)
assert new.index('best = choose(', new.index('inline bool step(')) < new.index('const auto continuation = continue_retreat(', new.index('inline bool step('))
assert results['status'] == 'pass' and all(v['full_sdk_compile'] for v in results['variants'])
report = {
    'status': 'independent read-only semantic and exact-delta audit passed for bounded native experiment',
    'source': {'path': 'postkill-route-escape-v5/src', 'sha256': source},
    'parent': {'path': 'postkill-route-escape-v4/src', 'sha256': parent},
    'only_delta_vs_v4': 'One continuation-entry condition plus its three comment lines in camp_escape.h:97-100. Removing that exact block restores normalized v4 header; every other source file is byte-identical.',
    'inherited_v4_audit_sha256': sha(HERE / 'v4-independent-audit.json'),
    'bindings': {n: sha(SRC.parent / n) for n in ['freeze.json', 'results.json', 'change.patch', 'test_route.py']},
    'gate_review': {
        'condition': 'if (!(poses.minimum_champion <= 1e-6)) return {};',
        'placement': 'After reentry/count admission, before any continuation SDK query, field computation, scratch mutation or Hold result.',
        'strict_escape_preserved': 'The v2 strict-exposure chooser still executes first; a valid strict decrease bypasses this new continuation gate.',
        'positive_minimum': 'If all current/legal-visible poses have positive modeled champion danger above tolerance, continuation declines to the unchanged v2 combat fallback.',
        'zero_minimum': 'A zero-minimum pose can be the current tile or a neighbor. A threatened current tile is not unnecessarily excluded when a zero-danger compatible neighbor exists; the gate tests minimum, not current danger.',
        'nonfinite_minimum': 'Positive infinity and NaN fail the <= comparison and decline. This is not a new general validation of all threat/candidate statistics.',
        'flag_off': 'The new condition is inside the continuation helper that the flag-off step never calls; original v2 query/result identity fixtures remain passing.',
        'scope': 'Zero means zero under the existing current ready-threat envelope. Inflated range, future cooldowns/movement and incomplete visibility are not repaired or certified by this gate.',
    },
    'unchanged_properties': [
        '17-file layout, main fallback/call order, State layout and shared-memory protocol',
        'Draft, postkill capture, original strict-exposure selector and its ties',
        'Exit-first/intersection root proof and membership-subset guarantee for admitted continuation',
        'One field, at most eight hazard draws and current plus at most eight distance reads',
        'Completed-no-route Hold requirement and owner/round/position/fuel guards',
        'Unknown/error/action-failure legacy fallback and visible-only hazard limitations',
    ],
    'verification_reviewed_not_rerun': [{k: v[k] for k in ['route_enabled', 'stdout', 'full_sdk_compile']} for v in results['variants']],
    'audit_ran_builds_or_games': False,
    'native_limit': 'No native outcome or fuel improvement is established by this audit. The v4 Ryth regression motivated the gate; v5 itself still requires its own source-bound native validation.',
    'selection': 'Selected I035 and the published I036 checkpoint remain unchanged; this audit does not promote v5.',
}
out = HERE / 'v5-independent-audit.json'
out.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'path': str(out), 'sha256': sha(out), 'header_sha256': source['camp_escape.h'], 'results_sha256': sha(SRC.parent / 'results.json')}, indent=2))
