"""Generate and validate the optional complete experimental review patch.

Uses isolated Git repositories under work only. No source parent is modified.
"""
from pathlib import Path
import difflib
import hashlib
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'camp-roster-bound/src'
TARGET = ROOT / 'route-only-v5/src'
DOCS = ROOT / 'publication-v4/docs'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest = lambda d: {p.name: sha(p) for p in sorted(d.iterdir()) if p.is_file()}
base, target = manifest(BASE), manifest(TARGET)
normal = lambda p: Path(p).read_bytes().replace(b'\r\n', b'\n')
baseline_normal = {p.name: hashlib.sha256(normal(p)).hexdigest() for p in BASE.iterdir() if p.is_file()}
target_normal = {p.name: hashlib.sha256(normal(p)).hexdigest() for p in TARGET.iterdir() if p.is_file()}
patch = ''
for name in sorted(set(base) | set(target)):
    if base.get(name) == target.get(name): continue
    old = normal(BASE / name).decode().splitlines(True) if name in base else []
    new = normal(TARGET / name).decode().splitlines(True) if name in target else []
    a, b = 'a/bots/team_baseline/src/' + name, 'b/bots/team_baseline/src/' + name
    patch += 'diff --git ' + a + ' ' + b + '\n'
    if name not in base: patch += 'new file mode 100644\n'
    if name not in target: patch += 'deleted file mode 100644\n'
    patch += ''.join(difflib.unified_diff(old, new, fromfile=a if name in base else '/dev/null', tofile=b if name in target else '/dev/null'))
patchfile = DOCS / 'I037-camp-retreat-component.patch'
patchfile.write_bytes(patch.encode())
assert '--- /dev/null\n+++ b/bots/team_baseline/src/camp_escape.h\n' in patch
git = shutil.which('git'); assert git
checks = []
for mode, autocrlf in [('lf-repository', 'false'), ('crlf-worktree-autocrlf', 'true')]:
    directory = ROOT / 'I037-patch-check' / mode
    assert not directory.exists(), 'Keep completed validation immutable; choose a new isolated directory for any new patch.'
    source = directory / 'bots/team_baseline/src'; source.mkdir(parents=True)
    def run(*args):
        result = subprocess.run([git, *args], cwd=directory, capture_output=True, text=True)
        assert result.returncode == 0, (args, result.stdout, result.stderr)
        return {'args': list(args), 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    run('init', '--quiet')
    run('config', 'core.autocrlf', autocrlf)
    for p in BASE.iterdir():
        if p.is_file(): (source / p.name).write_bytes(normal(p) if autocrlf == 'false' else p.read_bytes())
    before = manifest(source)
    assert {n: hashlib.sha256(normal(source / n)).hexdigest() for n in before} == baseline_normal
    run('add', '--all')
    check = run('apply', '--check', str(patchfile.resolve()))
    apply = run('apply', str(patchfile.resolve()))
    after = manifest(source)
    assert set(after) == set(target)
    assert {n: hashlib.sha256(normal(source / n)).hexdigest() for n in after} == target_normal
    checks.append({'mode': mode, 'core_autocrlf': autocrlf, 'git_apply_check': check['exit_code'], 'git_apply': apply['exit_code'], 'pre_apply_raw_sha256': before, 'post_apply_raw_sha256': after, 'normalized_target_matches_all_17_files': True, 'raw_target_byte_identity': after == target})
assert manifest(BASE) == base and manifest(TARGET) == target
report = {'status': 'pass', 'patch': patchfile.name, 'patch_sha256': sha(patchfile), 'baseline_source_sha256': base, 'target_source_sha256': target, 'normalized_lf_baseline_sha256': baseline_normal, 'normalized_lf_target_sha256': target_normal, 'changed_files': [n for n in sorted(set(base) | set(target)) if base.get(n) != target.get(n)], 'new_header_uses_dev_null': True, 'git_version': subprocess.check_output([git, '--version'], text=True).strip(), 'checks': checks, 'line_ending_policy': 'Patch text uses LF, as Git repository text. Source input snapshots use CRLF. Both isolated LF repository text and CRLF worktree with core.autocrlf=true pass ordinary git apply --check and git apply. Comparison of all17 files is explicitly normalized to LF; raw byte identity is reported separately per mode.', 'source_parents_unchanged': True, 'production_or_PR_source_changed': False, 'games_builds_or_bot_tests_run': False, 'interpretation': 'Optional experimental full strict-escape plus scoped-continuation patch, not upload-ready or promoted. This validation only checks patch applicability and reconstruction.'}
out = ROOT / 'retreat-continuation-audit/component-patch-validation.json'
out.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'patch': str(patchfile), 'patch_sha256': sha(patchfile), 'audit': str(out), 'audit_sha256': sha(out), 'modes': [{k: x[k] for k in ['mode', 'git_apply_check', 'git_apply', 'normalized_target_matches_all_17_files', 'raw_target_byte_identity']} for x in checks]}, indent=2))
