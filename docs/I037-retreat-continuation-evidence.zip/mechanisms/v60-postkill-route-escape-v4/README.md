# Experimental continuation after camp escape

This is a separate, unpromoted experiment based on the exact frozen `postkill-escape-v2/src`. Only `camp_escape.h` and the new `P_CAMP_ESCAPE_ROUTE` flag in `params.h` change. Draft, shared-memory protocol, postkill capture, combat ordering and the selected production source remain unchanged. No map name or map-family condition is added.

The original strict-exposure selector still runs first. It already handles Stellar's60→0 step and Ryth's80→20 step. Its missing case is a subsequent0→0 or20→20 continuation: returning false lets ordinary home movement re-enter a camp. Changing `<` to `<=` and greedily reducing straight-line home distance is insufficient. At Stellar's exact native position `(28,19)`, the zero-exposure route to spawn `(28,28)` must detour left around the elk; no safe immediate neighbor lowers the straight-line distance.

The first design-only checkpoint, `postkill-route-escape-v3`, used a protected home field for both cases. It was compiled and fixture-tested but never run natively. That design can prolong the currently hitting camp: Ryth50.25HP at `(8,8)` needs to leave the wolf before heading home. Three more18-damage hits would be lethal; a geometric exit in three moves exposes it to two intervening hits. V4 therefore routes to lower exposure first when current exposure is positive, and home only after exposure is zero.

## One bounded continuation decision

Continuation is considered only after no original strict-improvement step exists and at least one currently legal visible adjacent tile would increase the current raw camp envelope. Otherwise the old fallback proceeds. All existing admission checks remain: complete fresh camp acquisition and own visibility, current threat round/owner/position, movement readiness, fuel reserve, no dash slot, and preservation of an available melee `hit_now`.

For positive exposure, form two masks from the current visible awake positive-strength camps:

- `forbidden`: the union of ranges which do not currently cover the body.
- `retained`: the intersection of ranges which currently cover it.

The route walls are static terrain, current visible camp occupancy, and `forbidden`. Its roots are walkable tiles outside `retained`. Any root therefore leaves at least one currently covering positive hazard and enters none of the others, strictly reducing raw exposure without querying every tile or computing weighted masks. This also permits a lower nonzero exposure when an immediate zero-exposure route is unavailable. At zero exposure the same forbidden mask excludes all observed awake camps, and roots are our spawn.

One SDK `compute_to` search stops when the current tile is reached. Among the existing legal visible neighbors, select one at the global minimum known champion danger, with no greater camp exposure and a strictly smaller computed route distance. Straight-line home distance breaks route ties, followed by the existing SDK direction order. The first minimum-champion ranking includes the current tile and every legal visible neighbor, including those outside the camp-safe route. This prevents camp avoidance from masking a safer champion escape.

Moving champion occupancy filters the immediate step; it is not put into the route field, so an ally moving does not by itself reverse that field's potential. Future path tiles may be unseen, as in ordinary pathing; each actual next step still needs a fresh visible legal observation. The route uses at most8 range draws, one field computation and the current plus at most8 neighboring distance reads. Pose legality/visibility also uses up to16 SDK bit tests; the inherited header comment calling that loop entirely pure is inaccurate. There is no per-map SDK cell loop, second field search or greedy fallback through the forbidden camp mask. One field call may still suspend or consume substantial fuel: this is a bounded call pattern, not a hard fuel bound.

## Decline, move and deliberate hold

Unknown inputs, SDK failure, insufficient reserve, changed owner/round/position, unavailable movement, dash or melee precedence decline to the existing fallback. A failed selected movement also declines. A known completed route calculation that has no admissible descending step is different: it may deliberately hold only when the current tile itself has the minimum champion danger. If a neighbor has strictly lower champion danger, the helper declines so the existing emergency escape can choose it, even if it points away from home. At-home cases decline rather than taking an unrelated turn. Empty home roots decline in the zero-exposure home phase; the positive-exposure phase instead uses lower-exposure roots and does not depend on home roots.

Held means the caller can shoot back and then yield; it does not mean the body is safe, healed or guaranteed to survive. Fresh observations are reconsidered next turn. Under unchanged terrain and hazard membership, every continuation move strictly decreases a route potential. Leaving a covering camp removes a positive hazard from that membership; after zero exposure the protected home potential takes over. No arbitrary equal-distance lateral movement is authorized. A genuinely blocked route can still require waiting; the code does not pretend a safe route exists or promise progress through an impossible constraint set.

## Verification and limits

`test_route.py` extracts the actual production header, the unchanged original fallback branch and `hit_now`. It compiles the complete bot against the official SDK with the flag off/on. Fixtures include the exact saved Stellar R107 and Ryth R186 poses and threat values; blocked/unseen endpoints; known no-route holds versus lower-champion emergency escape; SDK/field failure; reserve loss; round/owner/position changes; dash and melee precedence; original strict-improvement decisions; and flag-off original-v2 query/result identity. A stable geometric Stellar detour progresses without revisiting tiles and hands control back when adjacent re-entry risk ends.

The Ryth two-hit example is a camp-only planner fixture, not a future native survival claim. In the actual opponent geometry, later steps may create a melee attack opportunity; that precedence remains intact and can interrupt the geometric retreat. Champion attacks, future wake, camp target ties, mitigation changes, AoE side effects, unseen camps and future state changes are not solved here. Only fresh visible hazards are represented; no new persistent fog memory or shared protocol is added. Static query/geometry completeness does not certify the whole future path. Native validation is left to the parent task after source freeze and independent review.
