# Portable recorded actual-header fixtures

Extract the matching sources/v60-postkill-route-escape-vN.zip. Each tests/v60-postkill-route-escape-vN/fixture.cpp includes that exact source's params.h and camp_escape.h; SDK callbacks and the eight-neighbor field are controlled mocks. No compiler or runtime binary is bundled. The recorded results separately retain complete official-SDK translation-unit compilation.

Example external compilation (replace placeholders):

<wasi>/bin/clang++ --target=wasm32-wasip1 -std=c++20 -O1 -fwasm-exceptions -mllvm -wasm-use-legacy-eh=false -msimd128 -mbulk-memory -isystem <wasi>/share/wasi-sysroot/include/wasm32-wasip1/eh/c++/v1 -I <extracted>/src -L <wasi>/share/wasi-sysroot/lib/wasm32-wasip1/eh <fixture.cpp> -lunwind -o fixture.wasm

Invoke _start with WASI imports and wasmtime.Config.wasm_exceptions=True. For an off test, copy the source and set its single P_CAMP_ESCAPE_ROUTE definition to 0; do not add duplicate definitions. Compile the full production translation with the same target/exception options plus -O0 -I <official-sdk>/cpp -c <extracted>/src/main.cpp. This package builder did not rerun the recorded checks.
