
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <optional>
#include <map>
#include <deque>
#include <limits>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>
#include "params.h"
struct vec2{int x=0,y=0;vec2()=default;vec2(int a,int b):x(a),y(b){}bool operator==(const vec2&)const=default;vec2 operator+(vec2 p)const{return{x+p.x,y+p.y};}int dot(vec2 p)const{return x*p.x+y*p.y;}int chebyshev_distance(vec2 p)const{return std::max(std::abs(x-p.x),std::abs(y-p.y));}};
int now_round=106,owner=7,errors=0,camp_reads=0,moves=0,invalidations=0,shoots=0,hits=0,flees=0,pos_reads=0;
std::uint64_t fuel=100000;bool movable=true,move_success=true;vec2 live_pos{27,20};int range_value=3;
std::string throw_at,advance_at,drop_at;bool move_crosses=false,shift_final_position=false;std::vector<std::string> actions;
int map_width=36,map_height=36;bool change_owner_on_field=false;
std::map<std::string,int> query_counts;
int throw_on_call=1,advance_on_call=1,drop_on_call=1;
void hook(const char*n){const int call=++query_counts[n];if(throw_at==n&&call==throw_on_call){throw_at.clear();throw std::runtime_error(n);}if(advance_at==n&&call==advance_on_call){advance_at.clear();++now_round;}if(drop_at==n&&call==drop_on_call){drop_at.clear();fuel=20000;}}
namespace bc{
std::uint64_t fuel_remaining(){hook("fuel");return fuel;}std::uint32_t round_number(){hook("round");return now_round;}
struct champion{int id=7;bool operator==(const champion&)const=default;bool can_move()const{hook("can_move");return movable;}int attack_range()const{hook("attack_range");return range_value;}vec2 position()const{++pos_reads;hook("me_position");if(shift_final_position&&pos_reads==2)live_pos={28,20};return live_pos;}bool move_absolute(vec2 p){hook("move");actions.push_back("move");if(!move_success)return false;if(move_crosses)++now_round;live_pos=p;movable=false;++moves;return true;}};
champion& self(){static champion me;me.id=owner;return me;}

struct bitboard{
 std::set<std::pair<int,int>> blocked;bool all=false;
 bool raw(vec2 p)const{return all?!blocked.count({p.x,p.y}):blocked.count({p.x,p.y});}
 bool is_set(vec2 p)const{hook("bit_test");return raw(p);}
 void set(vec2 p,bool value=true){hook("board_set");if(value!=all)blocked.insert({p.x,p.y});else blocked.erase({p.x,p.y});}
 void clear(){hook("board_clear");blocked.clear();all=false;}
 bool is_empty()const{hook("board_empty");for(int y=0;y<map_height;++y)for(int x=0;x<map_width;++x)if(raw({x,y}))return false;return true;}
 void draw_chebyshev(vec2 c,float r){hook("draw");for(int y=0;y<map_height;++y)for(int x=0;x<map_width;++x)if(std::max(std::abs(x-c.x),std::abs(y-c.y))<=r){if(!all)blocked.insert({x,y});else blocked.erase({x,y});}}
 friend bitboard operator~(bitboard a){hook("board_not");a.all=!a.all;return a;}
 friend bitboard operator|(const bitboard&a,const bitboard&b){hook("board_or");bitboard c;for(int y=0;y<map_height;++y)for(int x=0;x<map_width;++x)if(a.raw({x,y})||b.raw({x,y}))c.blocked.insert({x,y});return c;}
 friend bitboard operator&(const bitboard&a,const bitboard&b){hook("board_and");bitboard c;for(int y=0;y<map_height;++y)for(int x=0;x<map_width;++x)if(a.raw({x,y})&&b.raw({x,y}))c.blocked.insert({x,y});return c;}
 bitboard&operator|=(const bitboard&b){*this=*this|b;return*this;}
 bitboard&operator&=(const bitboard&b){*this=*this&b;return*this;}
};
bitboard camp_occupancy;
namespace vision{bitboard camp_tiles(){hook("camp_tiles");return camp_occupancy;}}
struct distance_field{
 static constexpr std::uint16_t unreachable=65535;std::vector<std::uint16_t> values;
 void compute_to(const bitboard& walls,const bitboard& roots,const bitboard&,bitboard& visited){
  hook("field_compute");if(change_owner_on_field)owner=99;
  values.assign(map_width*map_height,unreachable);visited.blocked.clear();visited.all=false;std::deque<vec2>q;
  for(int y=0;y<map_height;++y)for(int x=0;x<map_width;++x)if(roots.raw({x,y})&&!walls.raw({x,y})){values[y*map_width+x]=0;q.push_back({x,y});visited.blocked.insert({x,y});}
  while(!q.empty()){
   auto p=q.front();q.pop_front();
   for(int dx=-1;dx<=1;++dx)for(int dy=-1;dy<=1;++dy){if(!dx&&!dy)continue;vec2 t=p+vec2(dx,dy);if(t.x<0||t.y<0||t.x>=map_width||t.y>=map_height||walls.raw(t)||values[t.y*map_width+t.x]!=unreachable)continue;values[t.y*map_width+t.x]=values[p.y*map_width+p.x]+1;q.push_back(t);visited.blocked.insert({t.x,t.y});}
  }
 }
 std::uint16_t get(vec2 p)const{hook("field_get");return values.at(p.y*map_width+p.x);}
};

struct camp_state{int value=1;bool is_awake()const{return value==1;}};
struct camp{vec2 p;double str=60,hp=2400;int r=3,st=1;camp_state state()const{++camp_reads;hook("camp_state");return{st};}double strength()const{++camp_reads;hook("camp_strength");return str;}double health()const{++camp_reads;hook("camp_health");return hp;}vec2 position()const{++camp_reads;hook("camp_position");return p;}int attack_range()const{++camp_reads;hook("camp_range");return r;}};
namespace map{int width(){hook("width");return map_width;}int height(){hook("height");return map_height;}}
}
struct Threat{vec2 p;double xd=0;int xr=-9;double fd=0;int fr=-9;int sr=-9;double atk=0;int ar=1;double ready=0;};
struct State{int dash_slot=-1,thr_r=106;bc::bitboard blocked,vis,static_block,my_spawn,dest,visited;bc::distance_field df;vec2 spawn_center{29,25};std::vector<Threat>thr;State(){vis.all=true;}};
struct Foe{bc::champion c;vec2 p;float hp=100;int d=0;};
constexpr std::uint64_t FUEL_RESERVE=6000;
void note_error(const char*){++errors;}
namespace combatcohort{void invalidate(){++invalidations;actions.push_back("invalidate");}}
const char*g_mode="old";
void cast_offense(State&,bc::champion&,const bc::champion&,vec2,bool){actions.push_back("cast");}
bool basic_attack(State&,bc::champion&,const bc::champion&,vec2){++hits;actions.push_back("hit");return true;}
bool flee(State&,bc::champion&){++flees;actions.push_back("flee");return false;}
void shoot_back(State&,bc::champion&,const std::vector<Foe>&){++shoots;actions.push_back("shoot");}

inline int dist(vec2 a, vec2 b) { return static_cast<int>(a.chebyshev_distance(b)); }
inline int X(vec2 v) { return static_cast<int>(v.dot(vec2(1, 0))); }
inline int Y(vec2 v) { return static_cast<int>(v.dot(vec2(0, 1))); }
inline bool fuel_ok(std::uint64_t need) { return bc::fuel_remaining() > need + FUEL_RESERVE; }
inline double danger_at(const std::vector<Threat>& th, vec2 t) {
    double sum = 0;
    bool stun = false;
    for (auto& x : th) {
        int d = dist(t, x.p);
        double sp = 0;
        if (d <= x.xr) sp = x.xd;
        if (d <= x.fr + 1) sp = std::max(sp, x.fd);
        sum += sp + (d <= x.ar ? x.atk : 0.0);
        if (d <= x.sr + 1) stun = true;
    }
    if (stun)  // stunned for a round: the ready casters one step out get to stand and cast after
        for (auto& x : th) {
            int d = dist(t, x.p);
            if (d > x.xr && d <= x.xr + 1) sum += 0.5 * x.xd;
        }
    return sum;
}
template <class F>
bool attempt(F&& f) {
    try {
        return f();
    } catch (const std::exception& e) {
        note_error(e.what());
        return false;
    } catch (...) {
        note_error("unknown exception");
        return false;
    }
}
#include "camp_escape.h"
#pragma once
#ifndef P_CAMP_ESCAPE
#define P_CAMP_ESCAPE 0
#endif

// Local potential exposure only: full raw hits from known awake visible camps.
// No tank credit, future wake planner, tie rule, or exact next-phase prediction.
namespace legacyescape {
constexpr std::size_t max_hazards = 8, max_inputs = 24;
constexpr std::uint64_t reserve_need = 18000;
struct Hazard { vec2 position; double strength; int range; };
struct Snapshot {
    std::array<Hazard, max_hazards> hazards{};
    std::size_t count = 0;
};

inline double exposure(const Snapshot& snapshot, vec2 tile) {
    double total = 0;
    for (std::size_t i = 0; i < snapshot.count; ++i) {
        const auto& h = snapshot.hazards[i];
        if (dist(tile, h.position) <= h.range) total += h.strength;
    }
    return total;
}

inline std::optional<vec2> choose(const State& s, const Snapshot& snapshot,
                                  vec2 position, int width, int height) {
    const double current = exposure(snapshot, position);
    if (!(current > 0)) return std::nullopt;
    struct Candidate { vec2 position; double champion, camp; int home; };
    std::array<Candidate, 8> candidates{};
    std::size_t count = 0;
    double minimum_champion = danger_at(s.thr, position);
    double best_exposure = current;
    int best_home = 0;
    std::optional<vec2> best;
    // Every candidate evaluation is pure: no SDK calls in this pose loop.
    // Match distance_field::next_moves_from's N,NE,E,SE,S,SW,W,NW tie order.
    // Engine north is +y. This is not a full legacy-path-plan reconstruction.
    constexpr int directions[8][2] = {
        {0, 1}, {1, 1}, {1, 0}, {1, -1},
        {0, -1}, {-1, -1}, {-1, 0}, {-1, 1}};
    for (const auto& direction : directions) {
            const int dx = direction[0], dy = direction[1];
            const vec2 tile = position + vec2(dx, dy);
            if (X(tile) < 0 || Y(tile) < 0 || X(tile) >= width || Y(tile) >= height ||
                s.blocked.is_set(tile) || !s.vis.is_set(tile)) continue;
            const double champion = danger_at(s.thr, tile);
            minimum_champion = std::min(minimum_champion, champion);
            candidates[count++] = {tile, champion, exposure(snapshot, tile),
                                   dist(tile, s.spawn_center)};
        }
    // Do not choose a camp exit while ignoring an available neighbor with
    // strictly less known champion danger. Current position participates too.
    for (std::size_t i = 0; i < count; ++i) {
        const auto& c = candidates[i];
        if (c.champion > minimum_champion + 1e-6 || !(c.camp < current)) continue;
        if (!best || c.camp < best_exposure ||
            (c.camp == best_exposure && c.home < best_home)) {
            best = c.position; best_exposure = c.camp; best_home = c.home;
        }
    }
    return best;
}

inline bool step(State& s, bc::champion& me, const std::vector<bc::camp>& camps,
                 const std::vector<Foe>& foes, int round, vec2 expected_position,
                 bool input_complete) {
#if P_CAMP_ESCAPE
    if (!input_complete || camps.empty() || camps.size() > max_inputs ||
        s.dash_slot >= 0 || s.thr_r != round) return false;
    Snapshot snapshot;
    int width = 0, height = 0;
    const auto same_turn = [&] {
        return bc::self() == me && static_cast<int>(bc::round_number()) == round;
    };
    const bool known = attempt([&] {
        if (!fuel_ok(reserve_need) || !same_turn() || !me.can_move()) return false;
        const int range = static_cast<int>(me.attack_range());
        if (!(me.position() == expected_position)) return false;
        // Preserve a melee hit_now that could cast/attack before the old flee.
        // Ranged movable bodies already skip hit_now; no per-foe SDK reads.
        if (range <= 1)
            for (const auto& foe : foes)
                if (foe.hp > 0 && dist(expected_position, foe.p) <= range) return false;
        width = bc::map::width(); height = bc::map::height();
        for (const auto& camp : camps) {
            if (!fuel_ok(reserve_need)) return false;
            const auto state = camp.state();
            // SDK camp_state::alive means awake AND living; no second health
            // query is needed. All reads remain provisional until batch end.
            if (state.is_awake()) {
                const double strength = camp.strength();
                if (!std::isfinite(strength)) return false;
                if (strength > 0) {
                    if (snapshot.count == max_hazards) return false;
                    const vec2 position = camp.position();
                    const int range = camp.attack_range();
                    if (range < 0 || X(position) < 0 || Y(position) < 0 ||
                        X(position) >= width || Y(position) >= height) return false;
                    snapshot.hazards[snapshot.count++] = {position, strength, range};
                }
            }
            if (!fuel_ok(reserve_need)) return false;
        }
        // A failed or round-crossing read never authorizes a move, even if the
        // remaining read-only batch completes after the SDK resumes.
        return fuel_ok(reserve_need) && same_turn();
    });
    if (!known || snapshot.count == 0) return false;
    const auto best = choose(s, snapshot, expected_position, width, height);
    if (!best) return false;
    return attempt([&] {
        if (!fuel_ok(reserve_need)) return false;
        const vec2 position = me.position();
        const bool can_move = me.can_move();
        if (!(position == expected_position) || !can_move ||
            !fuel_ok(reserve_need) || !same_turn()) return false;
        // The SDK validates the final occupancy/action. It can itself suspend;
        // the preceding same-round checks are not an atomicity guarantee.
        combatcohort::invalidate();
        return me.move_absolute(*best);
    });
#else
    (void)s; (void)me; (void)camps; (void)foes; (void)round;
    (void)expected_position; (void)input_complete;
    return false;
#endif
}
} // namespace campescape

namespace fight{
inline bool hit_now(State& s, bc::champion& me, const std::vector<Foe>& foes) {
    // Measured: a ranged champion that attacks can no longer move this turn (64 of 64 Cassi hits on
    // packs), so ranged champions step first and shoot after (shoot_back) unless they are stuck anyway.
    if (me.attack_range() > 1 && me.can_move()) return false;
    vec2 pos = me.position();
    const Foe* best = nullptr;
    for (auto& f : foes) {
        if (f.hp <= 0 || dist(pos, f.p) > me.attack_range()) continue;
        if (!best || f.hp < best->hp) best = &f;
    }
    if (!best) return false;
    cast_offense(s, me, best->c, best->p, true);
    return basic_attack(s, me, best->c, best->p);
}
}

int checks=0;
void check(bool value,const char*why){++checks;if(!value){std::fprintf(stderr,"FAIL %s route=%d round=%d pos=%d,%d field=%d\n",why,P_CAMP_ESCAPE_ROUTE,now_round,live_pos.x,live_pos.y,query_counts["field_compute"]);std::exit(1);}}
void fallback(State&s,bc::champion&me,std::vector<bc::camp>&camps,std::vector<Foe>&foes,int round,vec2 pos,bool camps_complete=true,bool own_vision_complete=true){bool rsafe=false,recalled=false;
        if (!rsafe || (P_U34_FAILED_CHANNELS && !recalled)) {
            // An ordinary escape may reduce known camp exposure before a
            // ranged/no-target hit_now that would otherwise return false.
            if (campescape::step(s, me, camps, foes, round, pos,
                                 camps_complete && own_vision_complete)) {
                g_mode = "camp-escape";
                shoot_back(s, me, foes);
                return;
            }
            bool hit = P_HITFIRST && fight::hit_now(s, me, foes);
            flee(s, me);
            if (!hit) shoot_back(s, me, foes);
        }
}
struct Setup{
 State s;bc::champion me{7};std::vector<bc::camp>camps;std::vector<Foe>foes;int round=106;vec2 pos{27,20};
 Setup(){now_round=106;owner=7;errors=camp_reads=moves=invalidations=shoots=hits=flees=pos_reads=0;fuel=100000;movable=move_success=true;live_pos=pos;range_value=3;map_width=map_height=36;throw_at.clear();advance_at.clear();drop_at.clear();actions.clear();query_counts.clear();throw_on_call=advance_on_call=drop_on_call=1;move_crosses=shift_final_position=change_owner_on_field=false;g_mode="old";bc::camp_occupancy={};camps.push_back({{26,23},60,2400,3,1});for(int x=27;x<30;++x)for(int y=27;y<30;++y)s.my_spawn.set({x,y});query_counts.clear();}
 bool step(bool complete=true){return campescape::step(s,me,camps,foes,round,pos,complete);}
 void go(bool complete=true,bool visible=true){fallback(s,me,camps,foes,round,pos,complete,visible);}
 void frame(){pos=live_pos;++round;now_round=round;s.thr_r=round;movable=true;query_counts.clear();}
};
Setup stellar(){Setup x;x.round=now_round=107;x.s.thr_r=x.round;map_width=30;map_height=30;x.pos=live_pos={28,19};x.me.id=owner=7;range_value=3;x.s.spawn_center={28,28};x.s.my_spawn.clear();x.s.vis.clear();x.camps.clear();for(int tx=27;tx<30;++tx)for(int ty=27;ty<30;++ty)x.s.my_spawn.set({tx,ty});x.s.static_block.set({0,0});x.s.blocked.set({0,0});x.s.static_block.set({1,0});x.s.blocked.set({1,0});x.s.static_block.set({2,0});x.s.blocked.set({2,0});x.s.static_block.set({0,1});x.s.blocked.set({0,1});x.s.static_block.set({1,1});x.s.blocked.set({1,1});x.s.static_block.set({2,1});x.s.blocked.set({2,1});x.s.static_block.set({0,2});x.s.blocked.set({0,2});x.s.static_block.set({1,2});x.s.blocked.set({1,2});x.s.static_block.set({2,2});x.s.blocked.set({2,2});x.s.static_block.set({26,3});x.s.blocked.set({26,3});x.s.vis.set({23,11});x.s.vis.set({24,11});x.s.vis.set({25,11});x.s.vis.set({26,11});x.s.vis.set({27,11});x.s.vis.set({28,11});x.s.vis.set({29,11});x.s.static_block.set({12,12});x.s.blocked.set({12,12});x.s.static_block.set({13,12});x.s.blocked.set({13,12});x.s.static_block.set({14,12});x.s.blocked.set({14,12});x.s.static_block.set({15,12});x.s.blocked.set({15,12});x.s.static_block.set({16,12});x.s.blocked.set({16,12});x.s.static_block.set({17,12});x.s.blocked.set({17,12});x.s.vis.set({23,12});x.s.vis.set({24,12});x.s.vis.set({25,12});x.s.vis.set({26,12});x.s.vis.set({27,12});x.s.vis.set({28,12});x.s.vis.set({29,12});x.s.static_block.set({12,13});x.s.blocked.set({12,13});x.s.static_block.set({13,13});x.s.blocked.set({13,13});x.s.static_block.set({14,13});x.s.blocked.set({14,13});x.s.static_block.set({15,13});x.s.blocked.set({15,13});x.s.static_block.set({16,13});x.s.blocked.set({16,13});x.s.static_block.set({17,13});x.s.blocked.set({17,13});x.s.vis.set({20,13});x.s.vis.set({23,13});x.s.vis.set({24,13});x.s.vis.set({25,13});x.s.vis.set({26,13});x.s.blocked.set({27,13});x.s.vis.set({27,13});x.s.vis.set({28,13});x.s.vis.set({29,13});x.s.static_block.set({12,14});x.s.blocked.set({12,14});x.s.static_block.set({13,14});x.s.blocked.set({13,14});x.s.static_block.set({14,14});x.s.blocked.set({14,14});x.s.static_block.set({15,14});x.s.blocked.set({15,14});x.s.static_block.set({16,14});x.s.blocked.set({16,14});x.s.static_block.set({17,14});x.s.blocked.set({17,14});x.s.vis.set({20,14});x.s.vis.set({21,14});x.s.vis.set({23,14});x.s.vis.set({24,14});x.s.vis.set({25,14});x.s.vis.set({26,14});x.s.vis.set({27,14});x.s.vis.set({28,14});x.s.vis.set({29,14});x.s.static_block.set({12,15});x.s.blocked.set({12,15});x.s.static_block.set({13,15});x.s.blocked.set({13,15});x.s.static_block.set({14,15});x.s.blocked.set({14,15});x.s.static_block.set({15,15});x.s.blocked.set({15,15});x.s.static_block.set({16,15});x.s.blocked.set({16,15});x.s.static_block.set({17,15});x.s.blocked.set({17,15});x.s.vis.set({20,15});x.s.vis.set({21,15});x.s.vis.set({22,15});x.s.vis.set({23,15});x.s.vis.set({24,15});x.s.vis.set({25,15});x.s.vis.set({26,15});x.s.vis.set({27,15});x.s.vis.set({28,15});x.s.vis.set({29,15});x.s.static_block.set({12,16});x.s.blocked.set({12,16});x.s.static_block.set({13,16});x.s.blocked.set({13,16});x.s.static_block.set({14,16});x.s.blocked.set({14,16});x.s.static_block.set({15,16});x.s.blocked.set({15,16});x.s.static_block.set({16,16});x.s.blocked.set({16,16});x.s.static_block.set({17,16});x.s.blocked.set({17,16});x.s.vis.set({20,16});x.s.vis.set({21,16});x.s.vis.set({22,16});x.s.vis.set({23,16});x.s.vis.set({24,16});x.s.vis.set({25,16});x.s.vis.set({26,16});x.s.vis.set({27,16});x.s.vis.set({28,16});x.s.vis.set({29,16});x.s.static_block.set({12,17});x.s.blocked.set({12,17});x.s.static_block.set({13,17});x.s.blocked.set({13,17});x.s.static_block.set({14,17});x.s.blocked.set({14,17});x.s.static_block.set({15,17});x.s.blocked.set({15,17});x.s.static_block.set({16,17});x.s.blocked.set({16,17});x.s.static_block.set({17,17});x.s.blocked.set({17,17});x.s.vis.set({20,17});x.s.vis.set({21,17});x.s.vis.set({22,17});x.s.vis.set({23,17});x.s.vis.set({24,17});x.s.vis.set({25,17});x.s.vis.set({26,17});x.s.vis.set({27,17});x.s.vis.set({28,17});x.s.vis.set({29,17});x.s.vis.set({20,18});x.s.vis.set({21,18});x.s.vis.set({22,18});x.s.vis.set({23,18});x.s.vis.set({24,18});x.s.vis.set({25,18});x.s.vis.set({26,18});x.s.vis.set({27,18});x.s.vis.set({28,18});x.s.vis.set({29,18});x.s.vis.set({20,19});x.s.vis.set({21,19});x.s.vis.set({22,19});x.s.vis.set({23,19});x.s.vis.set({24,19});x.s.vis.set({25,19});x.s.vis.set({26,19});x.s.vis.set({27,19});x.s.vis.set({28,19});x.s.vis.set({29,19});x.s.vis.set({20,20});x.s.vis.set({21,20});x.s.vis.set({22,20});x.s.vis.set({23,20});x.s.vis.set({24,20});x.s.vis.set({25,20});x.s.vis.set({26,20});x.s.vis.set({27,20});x.s.vis.set({28,20});x.s.vis.set({29,20});x.s.vis.set({20,21});x.s.vis.set({21,21});x.s.vis.set({22,21});x.s.vis.set({23,21});x.s.vis.set({24,21});x.s.vis.set({25,21});x.s.vis.set({26,21});x.s.vis.set({27,21});x.s.vis.set({28,21});x.s.vis.set({29,21});x.s.vis.set({20,22});x.s.vis.set({21,22});x.s.vis.set({22,22});x.s.vis.set({23,22});x.s.vis.set({24,22});x.s.vis.set({25,22});x.s.vis.set({26,22});x.s.vis.set({27,22});x.s.vis.set({28,22});x.s.vis.set({29,22});x.s.vis.set({20,23});x.s.vis.set({21,23});x.s.vis.set({22,23});x.s.vis.set({23,23});x.s.vis.set({24,23});x.s.vis.set({25,23});x.s.blocked.set({26,23});x.s.vis.set({26,23});x.s.vis.set({27,23});x.s.vis.set({28,23});x.s.vis.set({29,23});x.s.vis.set({20,24});x.s.vis.set({21,24});x.s.vis.set({22,24});x.s.vis.set({23,24});x.s.vis.set({24,24});x.s.vis.set({25,24});x.s.vis.set({26,24});x.s.vis.set({27,24});x.s.vis.set({28,24});x.s.vis.set({29,24});x.s.vis.set({20,25});x.s.vis.set({21,25});x.s.vis.set({22,25});x.s.vis.set({23,25});x.s.vis.set({24,25});x.s.vis.set({25,25});x.s.vis.set({26,25});x.s.vis.set({27,25});x.s.vis.set({28,25});x.s.vis.set({29,25});x.s.static_block.set({3,26});x.s.blocked.set({3,26});x.s.vis.set({20,26});x.s.vis.set({21,26});x.s.vis.set({22,26});x.s.vis.set({23,26});x.s.vis.set({24,26});x.s.vis.set({25,26});x.s.vis.set({26,26});x.s.vis.set({27,26});x.s.vis.set({28,26});x.s.blocked.set({29,26});x.s.vis.set({29,26});x.s.blocked.set({20,27});x.s.vis.set({20,27});x.s.vis.set({21,27});x.s.vis.set({22,27});x.s.vis.set({23,27});x.s.vis.set({24,27});x.s.vis.set({25,27});x.s.vis.set({26,27});x.s.vis.set({27,27});x.s.vis.set({28,27});x.s.vis.set({29,27});bc::camp_occupancy.set({26,23});bc::camp_occupancy.set({20,27});x.camps.push_back({{26,23},60,100,3,1});query_counts.clear();return x;}

Setup ryth(){Setup x;x.round=now_round=186;x.s.thr_r=x.round;map_width=36;map_height=36;x.pos=live_pos={8,8};x.me.id=owner=0;range_value=1;x.s.spawn_center={2,16};x.s.my_spawn.clear();x.s.vis.clear();x.camps.clear();for(int tx=1;tx<5;++tx)for(int ty=15;ty<19;++ty)x.s.my_spawn.set({tx,ty});x.s.vis.set({0,0});x.s.vis.set({1,0});x.s.vis.set({2,0});x.s.vis.set({3,0});x.s.vis.set({4,0});x.s.vis.set({5,0});x.s.vis.set({6,0});x.s.vis.set({7,0});x.s.vis.set({8,0});x.s.vis.set({9,0});x.s.vis.set({10,0});x.s.vis.set({11,0});x.s.vis.set({12,0});x.s.vis.set({13,0});x.s.vis.set({14,0});x.s.vis.set({15,0});x.s.vis.set({16,0});x.s.vis.set({0,1});x.s.vis.set({1,1});x.s.vis.set({2,1});x.s.vis.set({3,1});x.s.vis.set({4,1});x.s.vis.set({5,1});x.s.vis.set({6,1});x.s.vis.set({7,1});x.s.vis.set({8,1});x.s.vis.set({9,1});x.s.vis.set({10,1});x.s.vis.set({11,1});x.s.vis.set({12,1});x.s.vis.set({13,1});x.s.vis.set({14,1});x.s.vis.set({15,1});x.s.vis.set({16,1});x.s.vis.set({0,2});x.s.vis.set({1,2});x.s.vis.set({2,2});x.s.vis.set({3,2});x.s.vis.set({4,2});x.s.vis.set({5,2});x.s.vis.set({6,2});x.s.vis.set({7,2});x.s.vis.set({8,2});x.s.vis.set({9,2});x.s.vis.set({10,2});x.s.vis.set({11,2});x.s.vis.set({12,2});x.s.vis.set({13,2});x.s.vis.set({14,2});x.s.vis.set({15,2});x.s.vis.set({16,2});x.s.vis.set({0,3});x.s.vis.set({1,3});x.s.vis.set({2,3});x.s.vis.set({3,3});x.s.vis.set({4,3});x.s.vis.set({5,3});x.s.vis.set({6,3});x.s.vis.set({7,3});x.s.vis.set({8,3});x.s.vis.set({9,3});x.s.vis.set({10,3});x.s.vis.set({11,3});x.s.vis.set({12,3});x.s.vis.set({13,3});x.s.vis.set({14,3});x.s.vis.set({15,3});x.s.vis.set({16,3});x.s.vis.set({0,4});x.s.vis.set({1,4});x.s.vis.set({2,4});x.s.vis.set({3,4});x.s.vis.set({4,4});x.s.vis.set({5,4});x.s.vis.set({6,4});x.s.vis.set({7,4});x.s.vis.set({8,4});x.s.vis.set({9,4});x.s.vis.set({10,4});x.s.vis.set({11,4});x.s.vis.set({12,4});x.s.vis.set({13,4});x.s.vis.set({14,4});x.s.vis.set({15,4});x.s.vis.set({16,4});x.s.vis.set({0,5});x.s.vis.set({1,5});x.s.vis.set({2,5});x.s.vis.set({3,5});x.s.vis.set({4,5});x.s.vis.set({5,5});x.s.blocked.set({6,5});x.s.vis.set({6,5});x.s.vis.set({7,5});x.s.blocked.set({8,5});x.s.vis.set({8,5});x.s.vis.set({9,5});x.s.vis.set({10,5});x.s.vis.set({11,5});x.s.vis.set({12,5});x.s.vis.set({13,5});x.s.vis.set({14,5});x.s.vis.set({15,5});x.s.vis.set({16,5});x.s.vis.set({0,6});x.s.vis.set({1,6});x.s.vis.set({2,6});x.s.vis.set({3,6});x.s.vis.set({4,6});x.s.vis.set({5,6});x.s.vis.set({6,6});x.s.vis.set({7,6});x.s.vis.set({8,6});x.s.vis.set({9,6});x.s.vis.set({10,6});x.s.vis.set({11,6});x.s.vis.set({12,6});x.s.vis.set({13,6});x.s.vis.set({14,6});x.s.vis.set({15,6});x.s.vis.set({16,6});x.s.vis.set({0,7});x.s.vis.set({1,7});x.s.vis.set({2,7});x.s.vis.set({3,7});x.s.vis.set({4,7});x.s.vis.set({5,7});x.s.vis.set({6,7});x.s.vis.set({7,7});x.s.vis.set({8,7});x.s.vis.set({9,7});x.s.vis.set({10,7});x.s.vis.set({11,7});x.s.vis.set({12,7});x.s.vis.set({13,7});x.s.vis.set({14,7});x.s.vis.set({15,7});x.s.vis.set({16,7});x.s.vis.set({0,8});x.s.vis.set({1,8});x.s.vis.set({2,8});x.s.vis.set({3,8});x.s.vis.set({4,8});x.s.vis.set({5,8});x.s.vis.set({6,8});x.s.vis.set({7,8});x.s.vis.set({8,8});x.s.vis.set({9,8});x.s.vis.set({10,8});x.s.vis.set({11,8});x.s.blocked.set({12,8});x.s.vis.set({12,8});x.s.vis.set({13,8});x.s.vis.set({14,8});x.s.vis.set({15,8});x.s.static_block.set({17,8});x.s.blocked.set({17,8});x.s.static_block.set({18,8});x.s.blocked.set({18,8});x.s.vis.set({0,9});x.s.vis.set({1,9});x.s.vis.set({2,9});x.s.vis.set({3,9});x.s.vis.set({4,9});x.s.vis.set({5,9});x.s.vis.set({6,9});x.s.vis.set({7,9});x.s.blocked.set({8,9});x.s.vis.set({8,9});x.s.vis.set({9,9});x.s.vis.set({10,9});x.s.vis.set({11,9});x.s.vis.set({12,9});x.s.vis.set({13,9});x.s.vis.set({14,9});x.s.vis.set({15,9});x.s.vis.set({16,9});x.s.vis.set({0,10});x.s.vis.set({1,10});x.s.vis.set({2,10});x.s.vis.set({3,10});x.s.vis.set({4,10});x.s.vis.set({5,10});x.s.vis.set({6,10});x.s.vis.set({7,10});x.s.blocked.set({8,10});x.s.vis.set({8,10});x.s.vis.set({9,10});x.s.vis.set({10,10});x.s.vis.set({11,10});x.s.vis.set({12,10});x.s.vis.set({13,10});x.s.vis.set({14,10});x.s.vis.set({15,10});x.s.vis.set({16,10});x.s.vis.set({0,11});x.s.vis.set({1,11});x.s.vis.set({2,11});x.s.vis.set({3,11});x.s.vis.set({4,11});x.s.vis.set({5,11});x.s.vis.set({6,11});x.s.vis.set({7,11});x.s.vis.set({8,11});x.s.vis.set({9,11});x.s.vis.set({10,11});x.s.vis.set({11,11});x.s.vis.set({12,11});x.s.vis.set({13,11});x.s.vis.set({14,11});x.s.vis.set({15,11});x.s.vis.set({16,11});x.s.vis.set({0,12});x.s.vis.set({1,12});x.s.vis.set({2,12});x.s.vis.set({3,12});x.s.vis.set({4,12});x.s.vis.set({5,12});x.s.vis.set({6,12});x.s.vis.set({7,12});x.s.vis.set({8,12});x.s.vis.set({9,12});x.s.vis.set({10,12});x.s.vis.set({11,12});x.s.vis.set({12,12});x.s.vis.set({13,12});x.s.vis.set({14,12});x.s.vis.set({15,12});x.s.vis.set({16,12});x.s.vis.set({0,13});x.s.vis.set({1,13});x.s.vis.set({2,13});x.s.vis.set({3,13});x.s.vis.set({4,13});x.s.vis.set({5,13});x.s.vis.set({6,13});x.s.vis.set({7,13});x.s.vis.set({8,13});x.s.vis.set({9,13});x.s.vis.set({10,13});x.s.vis.set({11,13});x.s.vis.set({12,13});x.s.vis.set({13,13});x.s.vis.set({14,13});x.s.vis.set({15,13});x.s.vis.set({16,13});x.s.vis.set({0,14});x.s.vis.set({1,14});x.s.vis.set({2,14});x.s.vis.set({3,14});x.s.vis.set({4,14});x.s.vis.set({5,14});x.s.vis.set({6,14});x.s.vis.set({7,14});x.s.vis.set({8,14});x.s.vis.set({9,14});x.s.vis.set({10,14});x.s.vis.set({11,14});x.s.vis.set({12,14});x.s.vis.set({13,14});x.s.vis.set({14,14});x.s.vis.set({15,14});x.s.vis.set({16,14});x.s.vis.set({0,15});x.s.vis.set({1,15});x.s.vis.set({2,15});x.s.vis.set({3,15});x.s.vis.set({4,15});x.s.vis.set({5,15});x.s.vis.set({6,15});x.s.vis.set({7,15});x.s.vis.set({8,15});x.s.vis.set({9,15});x.s.vis.set({10,15});x.s.vis.set({11,15});x.s.vis.set({13,15});x.s.vis.set({14,15});x.s.vis.set({15,15});x.s.vis.set({16,15});x.s.static_block.set({31,15});x.s.blocked.set({31,15});x.s.static_block.set({32,15});x.s.blocked.set({32,15});x.s.static_block.set({33,15});x.s.blocked.set({33,15});x.s.static_block.set({34,15});x.s.blocked.set({34,15});x.s.vis.set({0,16});x.s.vis.set({1,16});x.s.vis.set({2,16});x.s.vis.set({3,16});x.s.vis.set({4,16});x.s.vis.set({5,16});x.s.vis.set({6,16});x.s.vis.set({7,16});x.s.vis.set({8,16});x.s.vis.set({9,16});x.s.vis.set({10,16});x.s.vis.set({11,16});x.s.vis.set({14,16});x.s.blocked.set({15,16});x.s.vis.set({15,16});x.s.vis.set({16,16});x.s.static_block.set({31,16});x.s.blocked.set({31,16});x.s.static_block.set({32,16});x.s.blocked.set({32,16});x.s.static_block.set({33,16});x.s.blocked.set({33,16});x.s.static_block.set({34,16});x.s.blocked.set({34,16});x.s.static_block.set({31,17});x.s.blocked.set({31,17});x.s.static_block.set({32,17});x.s.blocked.set({32,17});x.s.static_block.set({33,17});x.s.blocked.set({33,17});x.s.static_block.set({34,17});x.s.blocked.set({34,17});x.s.static_block.set({10,18});x.s.blocked.set({10,18});x.s.static_block.set({25,18});x.s.blocked.set({25,18});x.s.static_block.set({31,18});x.s.blocked.set({31,18});x.s.static_block.set({32,18});x.s.blocked.set({32,18});x.s.static_block.set({33,18});x.s.blocked.set({33,18});x.s.static_block.set({34,18});x.s.blocked.set({34,18});bc::camp_occupancy.set({8,9});bc::camp_occupancy.set({12,8});bc::camp_occupancy.set({15,16});x.camps.push_back({{8,9},20,100,3,1});x.camps.push_back({{12,8},60,100,3,1}); {Threat t;t.xd=0;t.xr=-9;t.fd=0;t.fr=-9;t.sr=-9;t.atk=45;t.ar=4;t.ready=0;t.p={6,5};x.s.thr.push_back(t);} {Threat t;t.xd=0;t.xr=-9;t.fd=0;t.fr=-9;t.sr=-9;t.atk=35;t.ar=4;t.ready=0;t.p={8,5};x.s.thr.push_back(t);}x.foes.push_back({{10},{6,5},420,3});x.foes.push_back({{11},{8,5},617,3});query_counts.clear();return x;}

int main(){
 // Strict-improvement decisions precede the new route work in both modes.
 {Setup x;x.go();check(moves==1&&live_pos.y==19&&query_counts["field_compute"]==0,"Stellar initial strict camp escape stays first, no route search");check(flees==0&&shoots==1,"strict move then shoot preserved");}
 {Setup x;x.round=now_round=185;x.s.thr_r=185;x.pos=live_pos={9,7};x.me.id=owner=0;range_value=1;x.s.spawn_center={2,16};x.camps={{{8,9},20,1350,3,1},{{12,8},60,2400,3,1}};x.foes.push_back({{10},{13,8},300,4});x.go();check(moves==1&&live_pos==vec2(8,8)&&query_counts["field_compute"]==0,"Ryth initial80to20 escape preserved");}
 {auto x=stellar();x.go();if(P_CAMP_ESCAPE_ROUTE){check(moves==1&&live_pos==vec2(27,19),"exact native StellarR107 zero-to-zero home-route continuation");check(query_counts["field_compute"]==1&&query_counts["field_get"]<=9,"one field and at most9distance reads");check(flees==0&&shoots==1&&invalidations==1,"route step owns turn and retains shooting");}else check(moves==0&&flees==1&&query_counts["field_compute"]==0,"OFF exactv2 zero-exposure fallback");}
 {auto x=ryth();x.go();check(moves==0&&flees==1&&query_counts["field_compute"]==0&&query_counts["camp_tiles"]==0,"exact native RythR186 positive80 champion danger preserves original combat fallback before route queries");}
 // Off also has exactly the same SDK getter sequence/count as originalv2.
 if(!P_CAMP_ESCAPE_ROUTE){
  for(bool compact:{false,true}){auto x=compact?ryth():stellar();const bool a=x.step();const auto reads=query_counts;const auto p=live_pos;const int moved=moves,inv=invalidations,err=errors;auto y=compact?ryth():stellar();const bool b=legacyescape::step(y.s,y.me,y.camps,y.foes,y.round,y.pos,true);check(a==b&&p==live_pos&&moved==moves&&inv==invalidations&&err==errors&&reads==query_counts,"OFF originalv2 result, queries, invalidation and errors identical");}
 }
#if P_CAMP_ESCAPE_ROUTE
 // Positive/unknown champion danger never authorizes a continuation or hold.
 {auto x=stellar();campescape::Snapshot snap;snap.count=1;snap.hazards[0]={{26,23},60,3};campescape::Poses poses;auto direct=campescape::choose(x.s,snap,x.pos,map_width,map_height,&poses);check(!direct,"continuation gate fixture has no strict step");
  for(double danger:{80.,1.,.01,std::numeric_limits<double>::infinity(),std::numeric_limits<double>::quiet_NaN()}){poses.minimum_champion=danger;query_counts.clear();auto plan=campescape::continue_retreat(x.s,snap,x.pos,poses,[]{return true;});check(plan.kind==campescape::ContinuationKind::Declined&&query_counts.empty(),"positive or NaN champion minimum declines before any route SDK work");}
 }
 // Strict improvement remains admissible with a flat positive danger envelope.
 {Setup x;x.s.thr.push_back({});auto&t=x.s.thr.back();t.p=x.pos;t.atk=80;t.ar=99;x.go();check(moves==1&&live_pos.y==19&&query_counts["field_compute"]==0,"strict camp decrease is unchanged under positive champion danger");}
 // Native first-step legality and visibility are retained; later path actions
 // are fixtures over a stable graph, not a claim about the future native game.
 {auto x=stellar();x.s.blocked.set({27,19});x.go();check(moves==1&&!(live_pos==vec2(27,19))&&live_pos.y<=19,"blocked shortest endpoint never used");}
 {auto x=stellar();x.s.vis.set({27,19},false);x.go();check(moves==1&&!(live_pos==vec2(27,19)),"unseen shortest endpoint never used");}
 {auto x=stellar();for(int dx=-1;dx<=1;++dx)for(int dy=-1;dy<=1;++dy)if(dx||dy)x.s.blocked.set(x.pos+vec2(dx,dy));x.go();check(moves==0&&flees==1&&query_counts["field_compute"]==0,"no legal pose declines rather than gratuitous hold");}
 {auto x=stellar();for(int y=0;y<map_height;++y){x.s.static_block.set({22,y});x.s.blocked.set({22,y});}x.go();check(moves==0&&flees==0&&shoots==1&&invalidations==0,"consistent far wall closes safe home route while legal local poses remain; champion-minimum hold avoids reentry");}
 {auto x=stellar();for(int y=0;y<map_height;++y){x.s.static_block.set({22,y});x.s.blocked.set({22,y});}Threat t;t.p={28,15};t.atk=100;t.ar=4;x.s.thr.push_back(t);x.s.blocked.set(t.p);x.go();check(moves==0&&flees==1,"strictly safer champion neighbor preserves old emergency escape, not hold");}
 {auto x=stellar();x.s.my_spawn.clear();x.go();check(moves==0&&flees==1,"empty home goals decline rather than capture whole turn");}
 {auto x=stellar();x.s.my_spawn.set(x.pos);x.go();check(moves==0&&flees==1&&query_counts["field_compute"]==0,"already at home declines");}
 {auto x=stellar();x.camps.clear();x.camps.push_back({{0,0},60,100,1,1});x.go();check(moves==0&&flees==1&&query_counts["field_compute"]==0,"unrelated fleeing without reentry risk unchanged");}
 for(const char* op:{"bit_test","camp_tiles","draw","board_or","board_and","field_compute","field_get"}){auto x=stellar();throw_at=op;x.go();check(moves==0&&flees==1&&errors==1&&invalidations==0,"SDK failure including new zero-exposure pose read declines with old fallback");}
 for(const char* op:{"camp_tiles","draw","field_compute","field_get"}){auto x=stellar();advance_at=op;x.go();check(moves==0&&flees==1&&invalidations==0,"round-crossed route batch cannot authorize move or held turn");}
 for(const char* op:{"field_compute","field_get"}){auto x=stellar();drop_at=op;x.go();check(moves==0&&flees==1&&invalidations==0,"route budget loss cannot authorize action or hold");}
 {auto x=stellar();fuel=31000;x.go();check(moves==0&&flees==1&&query_counts["field_compute"]==0,"strict existing25k+6k reserve boundary declines");}
 {auto x=stellar();fuel=31001;x.go();check(moves==1,"above existing path reserve permits cost-free mock route");}
 {auto x=stellar();change_owner_on_field=true;x.go();check(moves==0&&flees==1&&invalidations==0,"changed authenticated owner after field aborts");}
 {auto x=stellar();advance_at="can_move";advance_on_call=2;x.go();check(moves==0&&invalidations==0,"final readiness round crossing aborts");}
 {auto x=stellar();shift_final_position=true;x.go();check(moves==0&&invalidations==0,"final position change aborts");}
 {auto x=stellar();move_success=false;x.go();check(moves==0&&flees==1&&invalidations==1,"failed route move uses unchanged old fallback");}
 {auto x=stellar();throw_at="move";x.go();check(moves==0&&flees==1&&errors==1,"throwing route move uses unchanged old fallback");}
 {auto x=stellar();x.s.dash_slot=1;x.go();check(moves==0&&flees==1&&camp_reads==0,"dash branch never displaced");}
 {auto x=ryth();x.foes.push_back({{9},{8,7},5,1});x.go();check(moves==0&&hits==1&&flees==1&&camp_reads==0,"melee available hit_now before flee retained");}
 {auto x=stellar();x.s.thr_r=x.round-1;x.go();check(moves==0&&flees==1&&camp_reads==0,"stale threat snapshot unchanged fallback");}
 {auto x=stellar();x.go(false);check(moves==0&&flees==1&&camp_reads==0,"partial camp input unchanged fallback");}
 {auto x=stellar();x.go(true,false);check(moves==0&&flees==1&&camp_reads==0,"failed own vision unchanged fallback");}
 // Equal exposure never licenses arbitrary lateral motion. Under a stable
 // terrain/hazard graph every continuation must lower the home potential.
 {auto x=stellar();x.s.vis.all=true;x.s.vis.blocked.clear();std::set<std::pair<int,int>>seen;int last=999,steps=0;bool handed_back=false;
  while(!x.s.my_spawn.raw(live_pos)&&steps<35){check(seen.insert({live_pos.x,live_pos.y}).second,"stable-world route never revisits tile");const int prior=moves;const bool handled=x.step();
   if(!handled){check(moves==prior&&query_counts["field_compute"]==0,"route work stops when unrelated normal home movement is sufficient");bool risk=false;for(int dx=-1;dx<=1;++dx)for(int dy=-1;dy<=1;++dy)if((dx||dy)&&std::max(std::abs(live_pos.x+dx-26),std::abs(live_pos.y+dy-23))<=3)risk=true;check(!risk,"handoff only after adjacent elk reentry risk ends");handed_back=true;break;}
   check(moves==prior+1,"stable zero-exposure route makes actual progress");check(query_counts["field_compute"]==1,"one search per continuation turn");int d=x.s.df.get(live_pos);check(d<last,"stable computed route distance strictly falls");last=d;check(std::max(std::abs(live_pos.x-26),std::abs(live_pos.y-23))>3,"never reenters elk envelope");++steps;x.frame();}
  check(steps==14&&handed_back&&live_pos==vec2(24,28),"finite14-step detour around elk reaches safe normal-home handoff");
  for(vec2 p:std::vector<vec2>{{25,28},{26,28},{27,28}})check(std::max(std::abs(p.x-26),std::abs(p.y-23))>3,"remaining ordinary home direction is outside elk");}
 // Camp-only planner trajectory: actual melee order is intentionally NOT
 // bypassed by step(). This exercises the pure continuation geometry over a
 // stable threat ranking; it does not predict the future native combat.
 {auto x=ryth();x.s.thr.clear();x.s.vis.all=true;x.s.vis.blocked.clear();campescape::Snapshot snap;snap.count=2;snap.hazards[0]={{8,9},20,3};snap.hazards[1]={{12,8},60,3};vec2 position=x.pos;double hp=50.25;int hits=0,steps=0;std::set<std::pair<int,int>>seen;
  while(campescape::exposure(snap,position)>0&&steps<8){check(seen.insert({position.x,position.y}).second,"stable positive-exposure route never revisits");campescape::Poses poses;auto direct=campescape::choose(x.s,snap,position,map_width,map_height,&poses);vec2 next;
   if(direct)next=*direct;else{auto plan=campescape::continue_retreat(x.s,snap,position,poses,[]{return true;});check(plan.kind==campescape::ContinuationKind::Move,"positive phase finds lower-exposure route");next=plan.tile;}
   check(campescape::exposure(snap,next)<=campescape::exposure(snap,position),"positive phase never increases raw camp exposure");position=next;++steps;if(campescape::exposure(snap,position)>0){hp-=18;++hits;}
  }
  check(steps==3&&hits==2&&hp==14.25&&campescape::exposure(snap,position)==0,"exit-first geometry incurs two18hits instead of home-route three lethal hits");}
 // Overlap: nearest lower exposure need not be zero. Retained intersection
 // roots avoid a second search or per-map weighted-sum tile scan.
 {Setup x;map_width=map_height=24;x.pos=live_pos={6,5};x.s.spawn_center={3,16};x.s.my_spawn.clear();x.s.my_spawn.set({3,16});campescape::Snapshot snap;snap.count=3;snap.hazards[0]={{5,5},20,3};snap.hazards[1]={{7,5},60,3};snap.hazards[2]={{10,5},10,3};campescape::Poses poses;auto direct=campescape::choose(x.s,snap,x.pos,24,24,&poses);check(!direct&&poses.reentry_risk,"overlap witness has no immediate lower compatible pose and a new camp to avoid");auto plan=campescape::continue_retreat(x.s,snap,x.pos,poses,[]{return true;});check(plan.kind==campescape::ContinuationKind::Move&&x.s.df.get(x.pos)==3,"one field reaches nearest lower nonzero exposure in3steps, before zero in4");}
#endif
 std::printf("PASS route=%d checks=%d\n",P_CAMP_ESCAPE_ROUTE,checks);
}
