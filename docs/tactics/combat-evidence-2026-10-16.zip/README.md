# Combat evidence,16October2026

This package accompanies docs/tactics/07-combat-and-survival.md and combat-research-2026-10-16.md. It contains no bot change, login token or queued match.

Primary empirical scope:730patch0.0.2 streams, including92unique current-top-four H2H streams. Full sensitivity scope:2498streams(1768patch0.0.1 +730patch0.0.2), current-ranked top-ten identities, cutoff2026-10-16T11:41:43.755965UTC.12bounded exact episodes include10earlier0.0.1 examples and2current0.0.2 examples. They are mechanism-selected, not a frequency sample.

Start with quant/patch002/findings.md, then episodes/episode-findings.md, policy/source-audit.md and policy/mechanics-current-002.md. The main controlled suite is27cases/85assertions on each pinned engine; separate supplements retain their own denominators.

Quant CSVs expose each numerator and denominator. Full-cohort JSONL rows are compressed; unavailable external API fields are absent, not validated zeros. The large expanded summary JSONs are not duplicated here; compact publication-tables.json and all aggregate CSV slices are retained. Full native traces are not included; selected raw replays and bounded exact frames are included. Remaining raw bundles can be downloaded read-only from https://2026a.battlecode.co.uk/api/v1/matches/{id}/bundle using the canonical IDs.

## Reconstructing

Use the official cambc2.2.2 distribution's embedded viewer assets, whose engine hashes are acquisition/runtime/manifest.json. The two required assets are v0_0_1-ctH8uuEb.wasm and v0_0_2-DFj19m76.wasm. No executable engine binary is redistributed here. Verify hashes before using the decoder; its snapshot ABI guard must pass184696/40152bytes. Header parsing follows the official viewer's three uint8 version bytes at8,9,10; see quant/official-replay-header-parser.js.txt.

Extract bundles, preserve original raw bytes, and rebase each manifest request's absolute `raw` path to the extracted replay on your machine. Preserve id/raw_sha256/teams/game/replay_patch/replay_format. Split the canonical manifest by replay_patch. In each process set COMBAT_ENGINE_PATH to that patch's verified WASM, then run:

    node decoder/scan-coordination.mjs --manifest PATCH_MANIFEST.json --out-dir TRACES

The source decoder reconstructs native states sequentially; it does not run bot strategy. Pass the resulting trace folder to the analyzer with explicit manifest/full-manifest/ladder/input-dir/out-dir flags. `--manifest` is the raw-deduplicated canonical list. Use `acquisition/manifest-native.json` as `--full-manifest`: it retains all 3422 selected source-ID records for exact per-pair/map/kind latest selection. The canonical manifest's alias maps are top-level metadata, not per-request action information. The sanitized rank projection can be used as the ladder input, documenting its intentionally different file hash. Numeric outputs are bound to original acquisition file hashes, so a rebased/projection rerun will intentionally have different provenance hashes.

    python quant/analyze-combat.py --manifest CANONICAL.json --full-manifest SOURCE_IDS.json --ladder acquisition/ladder-rank-projection.json --input-dir TRACES --out-dir RESULTS

The controlled harness accepts COMBAT_ENGINE_PATH, COMBAT_ENGINE_SCOPE and COMBAT_RESULT_PATH. It adapts the official draft function rename without changing the controlled cases. policy/native-version-comparison.json records the bounded0.0.1/0.0.2 comparison; it is not exhaustive engine equivalence.

The archive member manifest records byte sizes and SHA256 for every other member. Original local paths are provenance, not instructions to write to them. Source code identity is pinned in repository/source-reference.json and immutable GitHub links. No private opponent code or personal vision/permissions are inferred from the host replay.
