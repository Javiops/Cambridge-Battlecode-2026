from pathlib import Path
import json,collections
r=Path('work/combat-research');p=r/'matches/engine.mjs';s=p.read_text().replace('E._initialize();','E._initialize();\nif(E.Game_Visualiser_SnapshotSize()!==184696||E.Game_Visualiser_TimelineSnapshotSize()!==40152)throw Error("Unverified snapshot ABI");');p.write_text(s)
p=r/'matches/scan-coordination.mjs';s=p.read_text().replace('w.c.length===10','w.c.length>0').replace("if(initial.c.length!==10||final.c.length!==10||new Set(initial.c.map(c=>c.id)).size!==10)","if(initial.c.length!==final.c.length||new Set(initial.c.map(c=>c.id)).size!==initial.c.length)").replace('checks.nativeDeathCounters=10','checks.nativeDeathCounters=final.c.length');p.write_text(s)
x=json.load(open(r/'acquisition/manifest-unique.json'));groups=collections.defaultdict(list)
for a in x['requests']:
 b=Path(a['raw']).read_bytes()[:14]
 assert int.from_bytes(b[:8],'little')==125779999602273
 ver='.'.join(map(str,b[8:11]));fmt='.'.join(map(str,b[11:14]));assert ver in ['0.0.1','0.0.2'];assert not a['game'].get('patchId') or a['game']['patchId'].startswith(ver+':')
 a['replay_patch']=ver;a['replay_format']=fmt;groups[ver].append(a)
for ver,rs in groups.items():
 y={**x,'requests':rs};(r/f'matches/manifest-{ver}.json').write_text(json.dumps(y));(r/f'matches/pilot-{ver}.json').write_text(json.dumps({**y,'requests':rs[:2]}))
(r/'matches/manifest-bound.json').write_text(json.dumps(x));print({k:len(v)for k,v in groups.items()})
