// Pure local map utility using the official editor's WebAssembly exports.
// It reads source maps and writes new files; it never edits the source pool.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const taskRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const wasmPath = process.env.COMBAT_ENGINE_PATH; if (!wasmPath) throw Error('COMBAT_ENGINE_PATH required');
const mapDir = path.join(taskRoot, 'arena', 'maps');
const outDir = path.join(taskRoot, 'arena', 'r2maps-exact');
let instance;
const view = () => new DataView(instance.exports.memory.buffer);
const bytes = (p, n) => new Uint8Array(instance.exports.memory.buffer, p, n);
const cstring = p => {
  const buffer = new Uint8Array(instance.exports.memory.buffer);
  let end = p;
  while (end < buffer.length && buffer[end] !== 0) ++end;
  return new TextDecoder().decode(buffer.subarray(p, end));
};
const wasi = {
  environ_get: () => 0,
  environ_sizes_get: (p, n) => { view().setUint32(p, 0, true); view().setUint32(n, 0, true); return 0; },
  fd_close: fd => fd <= 2 ? 0 : 8,
  fd_fdstat_get: (fd, p) => {
    if (fd > 2) return 8;
    bytes(p, 24).fill(0); view().setUint8(p, 2); return 0;
  },
  fd_prestat_get: () => 8,
  fd_prestat_dir_name: () => 8,
  fd_read: (fd, p, n, result) => { if (fd !== 0) return 8; view().setUint32(result, 0, true); return 0; },
  fd_seek: fd => fd <= 2 ? 70 : 8,
  fd_write: (fd, p, n, result) => {
    if (fd !== 1 && fd !== 2) return 8;
    let written = 0;
    for (let i = 0; i < n; ++i) {
      const begin = view().getUint32(p + i * 8, true);
      const len = view().getUint32(p + i * 8 + 4, true);
      process.stderr.write(Buffer.from(bytes(begin, len))); written += len;
    }
    view().setUint32(result, written, true); return 0;
  },
  random_get: (p, n) => { crypto.randomFillSync(bytes(p, n)); return 0; },
  proc_exit: code => { throw new Error(`Official editor engine exited: ${code}`); },
};
const module = new WebAssembly.Module(fs.readFileSync(wasmPath));
instance = new WebAssembly.Instance(module, { wasi_snapshot_preview1: wasi });
const E = instance.exports;
E._initialize();
if(E.Game_Visualiser_SnapshotSize()!==184696||E.Game_Visualiser_TimelineSnapshotSize()!==40152)throw Error("Unverified snapshot ABI");
const out = E.Engine_Malloc(64);
function checked(name, ...args) {
  const error = E[name](...args);
  if (error !== 0) throw new Error(`${name}: engine error ${error}: ${cstring(E.GetLastErrorMsg())}`);
}

export {E,out,checked};
