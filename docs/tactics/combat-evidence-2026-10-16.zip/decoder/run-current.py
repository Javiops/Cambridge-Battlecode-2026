from pathlib import Path
import json,concurrent.futures,subprocess,os,time,hashlib
r=Path(__file__).resolve().parent;o=r/'current';o.mkdir(exist_ok=True);logs=o/'logs';logs.mkdir(exist_ok=True)
node=r'C:/Users/frans/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
engines={'0.0.1':r.parent/'acquisition/runtime/v0_0_1-ctH8uuEb.wasm','0.0.2':r.parent/'acquisition/runtime/v0_0_2-DFj19m76.wasm'}
def job(v,i):
 env={**os.environ,'COMBAT_ENGINE_PATH':str(engines[v])}
 with (logs/f'{v}-{i}.log').open('w',encoding='utf8')as f:p=subprocess.run([node,str(r/'scan-coordination.mjs'),'--manifest',str(r/f'manifest-{v}.json'),'--out-dir',str(o),'--stride','6','--index',str(i),'--resume'],env=env,stdout=f,stderr=subprocess.STDOUT)
 return {'patch':v,'worker':i,'exit_code':p.returncode}
start=time.time();a=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:
 fs=[pool.submit(job,v,i)for v in ['0.0.2','0.0.1']for i in range(6)]
 for f in concurrent.futures.as_completed(fs):a.append(f.result());print(json.dumps(a[-1]),flush=True)
x={'seconds':time.time()-start,'jobs':a,'completed':len(list(o.glob('*.coord.json.gz'))),'scanner_sha256':hashlib.sha256((r/'scan-coordination.mjs').read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256((r/'manifest-bound.json').read_bytes()).hexdigest()};(o/'run-report.json').write_text(json.dumps(x,indent=2));print(json.dumps(x),flush=True)
