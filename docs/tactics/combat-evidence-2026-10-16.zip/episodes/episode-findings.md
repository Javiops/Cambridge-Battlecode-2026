# Exact combat episode findings — twelve source-bound examples

Episodes01–10 use the frozen 15 October acquisition cohort and historical engine. Episodes11–12 use the refreshed16 October current-top-four cohort and separately fetched official patch0.0.2 engine. Mite is historical top-four context and currently fifth; its old rank field must not be presented as its current rank. The current top four are Fish, Sneaky, Univardisty and procless. Exact team names remain in the source JSON. Private bot versions are unknown in both cohorts. These12 examples span eight maps and are labeled by their own source/engine identity.
Names followed by digits identify stable native body IDs, for example Stellar5 means Stellar body5. Round labels refer to world rounds; source sequence and input indices preserve the order within them.

The examples were deliberately selected to expose mechanisms, including adverse continuations. They are neither a random sample nor a success-rate denominator. Each JSON preserves the representative game ID, all same-raw aliases, raw/bundle/trace/engine hashes, round/input/frame sequence, complete-roster round snapshots, actions, recipient HP-loss frames, owner-start observations and bounded capture/score follow-through. The base extraction reads cached traces and freshly hashes only selected source files. Seven selected shield/control/healing frames were separately re-seeked in the existing historical native replays, with exact input metadata and buffs queried. No new bot match or competitive experiment was run.

## 01 — A helper contributes, but the recipient remains alive

[d44a2517… source bundle](https://2026a.battlecode.co.uk/api/v1/matches/d44a2517-49ab-42f3-bb62-c791cf1d46a3/bundle), packs, R130–136. [Exact episode](01-helper-arrival-focus-d44a2517-49ab-42f3-bb62-c791cf1d46a3.json).

Fish Stellar5 moves [22,9] → [21,8] at R131 input2064. At R132 Ren4's basic input2074 reduces Sneaky Varg3 from832 to829.5 HP; Stellar5's slot1 cast at input2077, aimed at [17,4], reduces that recipient to689.5. Stellar is five tiles from Varg's [16,3] position, while the cast aim is four tiles away: recipient distance alone cannot substitute for spell aim/radius rules. The [bounded rich native frames](../policy/rich-replay-frames.json) now resolve the small HP change: R131 inputs2060/2061 consume Varg shield250 →205 →42.5 with HP unchanged; the R132 basic consumes the remaining42.5 shield and2.5 HP. Ren’s R131 slot0 also applies a stun. A zero-HP-loss frame was therefore still a real shield/control effect; that does not establish that spending the cast was optimal.

Varg remains alive with44 gems at the R136 snapshot and554.5 HP; Ren and Stellar have followed its changing position. This proves actual contribution after approach and continued pursuit, not an immediate kill or a private shared-target command. Original policy hypothesis: count the helper's legal spell footprint and time to contribute, then reassess pursuit against the value of the bag and the next objective.

## 02 — Shared recipient, linked deaths, then a later kill

[8bc79c59… source bundle](https://2026a.battlecode.co.uk/api/v1/matches/8bc79c59-04bf-4e79-bd5b-75314eade848/bundle), interlock, R272–279. [Exact episode](02-shared-recipient-adverse-linked-death-8bc79c59-04bf-4e79-bd5b-75314eade848.json).

Fish Ren4, Ryth8 and Issac7 have direct command frames with HP loss at Sneaky Ren2 during R273. Issac dashes, ordinarily moves, then attacks at inputs4756–4758; its attack frame also loses22 of its own HP. Sneaky Ren2 is still alive at102 HP at the R275 snapshot. Later in R275, Ren2's slot0 frame input4797 kills Fish Issac7 and linked Cassi6; Cassi was remote at[30,27] while Issac was at[21,16]. Issac carried22 gems. At R276 input4808 Fish Ryth8's basic frame kills Ren2, which then carries22 gems.

A two-snapshot ending would miss the later kill; a kill-only ending would hide the linked loss and transferred bag. Neither proves that the original pursuit was wrong. Original hypothesis: evaluate the full exchange, retaliation, linked partner exposure and converted resources over a stated horizon, rather than counting focus actors or a final kill alone.

## 03 — Spell/basic order has a visible return cost

[f9f576b4… source bundle](https://2026a.battlecode.co.uk/api/v1/matches/f9f576b4-c0a0-42d0-b864-c160bf7e48ea/bundle), corners, R24–30; historical Mite versus Fish. [Exact episode](03-spell-basic-counterdamage-and-move-f9f576b4-c0a0-42d0-b864-c160bf7e48ea.json).

At R26, Mite Stellar1 uses slot0 then a basic, inputs820–821: Fish Ren6 loses200 then35 HP, while Stellar loses20 HP in each frame. Mite Varg0 attacks then moves, inputs832–833, and Ryth4 moves then attacks, inputs839–840; their attack frames also contain20 self HP loss while Ren loses50 each. Ren falls from560 to225 HP across these Mite command frames. Fish Ren and Stellar meanwhile damage Varg during earlier inputs802 and809–810.

The R30 initial snapshot still has Ren alive at5 HP; a later R30 cast frame input961 kills it. These are sequential states, not contradictory outcomes. The observed self-loss and Ren's documented retaliation make multi-hit exchange accounting relevant; a recipient frame alone does not prove which secondary effect caused every loss. Original hypothesis: price each extra hit and its return damage, not just aggregate ally HP or two-hit killability.

## 04 — A ranged move can be followed by a reset and shot

[c58b2e34… source bundle](https://2026a.battlecode.co.uk/api/v1/matches/c58b2e34-29f8-47ef-8e18-a0edc1dd6317/bundle), corners, R18–24; Univardisty versus historical Mite. [Exact episode](04-move-reset-attack-versus-burst-c58b2e34-29f8-47ef-8e18-a0edc1dd6317.json).

At R20 Univ Tavi4 moves[31,30] → [32,30], casts slot0 on itself and basics Mite Vendetta7 for35 HP, inputs747–749. Univ Issac1 uses move → basic40 → slot0 → basic40, inputs719–722. At R21 Marcella2 uses move → basic45 → slot0 → basic45, inputs770–773. Thus the ranged move/attack allowance and the melee allowance require different legal sequence models; an attack-reset spell creates a specific exception, and consumes the turn's cast opportunity.

At R19 the [rich native frames](../policy/rich-replay-frames.json) confirm Cassi0 input676 applies stun duration1 before Vendetta's owner-start input677. Tavi4 input704 later deals220 HP and refreshes an existing stun from duration0 to1. Duration0 still has restriction mask63 until the next victim owner start, so a same-world-round reapplication after the victim's turn can extend control; counting casts per round would miss that timing. Mite Willow10 input707 then heals Vendetta480 →795 HP, exactly315, while the stun remains. This confirms control and healing effects, not peel intent or optimal cast allocation. Vendetta survives through R24 with195 HP.

## 05 — Reset sequences coexist with shared-target pressure

[9c830c09… source bundle](https://2026a.battlecode.co.uk/api/v1/matches/9c830c09-e7bf-4032-ad35-4cadfac6c49f/bundle), corners, R37–43. [Exact episode](05-multiple-basics-and-shared-target-9c830c09-e7bf-4032-ad35-4cadfac6c49f.json).

At R38 Sneaky Tavi5 uses basic35 → slot0 → basic35 against Fish Cassi8, inputs1013–1015. Fish Ryth10 uses basic50 → slot1 → basic50 against Sneaky Issac1, then moves, inputs1004–1007. The actors' canonical snapshot cooldown changes agree with slot use across the round, but are not owner-action-start readiness observations.

At R40 Fish Cassi8's basic frame input1072 kills both Sneaky Cassi0 and Issac1. This supports treating a linked pair's survival as a joint resource; it does not show that the bot intentionally selected a weaker partner or prove a focus algorithm. Original hypothesis: enumerate actual legal reset sequences, then evaluate the resulting recipient/linked-body state after each action before spending the next action.

## 06 — Approaching to trade is not successful kiting by definition

[9f57b5a5… source bundle](https://2026a.battlecode.co.uk/api/v1/matches/9f57b5a5-2065-4bb5-b134-70eceb78aee6/bundle), lanes, R60–66; Univardisty versus historical Mite. [Exact episode](06-ranged-move-reset-shot-9f57b5a5-2065-4bb5-b134-70eceb78aee6.json).

At R62 Univ Cassi2's slot0 frame input2277 reduces Mite Tavi10 from630 to490 HP. Tavi subsequently moves[51,5] → [50,4], resets with slot0 and basics Cassi for35, inputs2297–2299. Its distance to Cassi's [47,1] changes from4 to3, bringing the basic into normal range. Tavi remains at[50,4] through the R66 snapshot, then has280 HP versus Cassi's500. Both remain alive within this window.

This is an observed response trade with a legal reset, not evidence that movement always avoids retaliation or that the exchange was strategically wrong. Original hypothesis: compare approach-and-hit, stand-and-hit, cast-only and disengage sequences by enemy replies, cooldown consumption and the useful follow-up state.

## 07 — Separation can have an economic purpose

[8dfb72d3… source bundle](https://2026a.battlecode.co.uk/api/v1/matches/8dfb72d3-26f3-422a-ba5a-5311b4f3aa71/bundle), corners, R378–384. [Exact episode](07-separation-with-economic-continuation-8dfb72d3-26f3-422a-ba5a-5311b4f3aa71.json).

At R380 Univ Stellar6 and Tavi9 ordinarily move to[36,36] and[35,36], inputs10251 and10265. Their nearest actual enemy distances increase from5 to7 at the next snapshot; they remain alive and locally connected through R382. Stellar receives48 camp gems at R381 and begins a recall by R384, with205 HP. Tavi remains alive at460 HP.

Actual separation is stronger evidence than distance to prior enemy positions, but it still does not reveal retreat intent. The camp reward and later recall are competing explanations and concrete productive continuation. Original hypothesis: an exit should specify its destination and next reward/recovery opportunity, rather than maximize distance in isolation.

## 08 — Conversion can precede the next combat action

[fb3e09a7… source bundle](https://2026a.battlecode.co.uk/api/v1/matches/fb3e09a7-5bd4-4f27-8a67-1bff71093f7c/bundle), corners, R39–47. [Exact episode](08-contested-channel-conversion-fb3e09a7-5bd4-4f27-8a67-1bff71093f7c.json).

At R43, Fish Ren6's basic input1080 reduces Sneaky Willow4 from75 to35 HP. Fish Stellar7 completes a48-gem tribute at seq6971/input1083, phase14. Its following basic input1084 at seq6973 kills Willow4; a later R47 Stellar slot1 frame kills Sneaky Stellar2. The source preserves these score, HP and death events separately.

This is completed conversion followed by combat, not just a submitted-channel command. Nearby ally/enemy geometry does not prove that allies escorted the channel or that the delivery required protection. Original hypothesis: evaluate whether a legal channel completes before the relevant enemy response, and value banked score alongside a fight; once completion has occurred, refresh the actor's legal combat choices.


## 09 — Four sequential basics share a recipient

[42ad5cc9… source bundle](https://2026a.battlecode.co.uk/api/v1/matches/42ad5cc9-154f-4630-90c6-d94c5638597b/bundle), elkring, R50–57; Sneaky versus Univardisty. [Exact episode](09-sequential-four-actor-pressure-42ad5cc9-154f-4630-90c6-d94c5638597b.json).

At R52 Sneaky Stellar2, Willow3, Ren4 and Tavi5 have basic frames at inputs1654,1659,1665 and1670. Univ Issac8's HP successively changes307 →272 →227 →182 →147. These are four separately observed command frames at the same recipient, interleaved with the game's other owner turns; they do not imply simultaneous damage or prove a shared focus message. At R54 seq7895/input1728 both linked Univ Cassi7 and Issac8 die in Sneaky Ren4's slot0 frame. Univ also completes a36-gem tribute at R53 during the bounded encounter.

Original hypothesis: keep a live remaining-damage target after each executed action, accounting for opposing opportunities and concurrent conversion. A recipient's starting147 or307 HP is not a sufficient prediction of the state when a later ally finally acts.

## 10 — Three deaths do not mean three direct area hits

[066ab413… source bundle](https://2026a.battlecode.co.uk/api/v1/matches/066ab413-964f-4546-b8e6-3a7f0ed667a9/bundle), collision, R975–983; Sneaky versus historical Mite. [Exact episode](10-area-burst-with-remote-linked-death-066ab413-964f-4546-b8e6-3a7f0ed667a9.json).

At R978 Sneaky Stellar0 casts slot1 from[20,19] toward[19,23], input14879/seq99752. The frame records deaths of Mite Ryth4 at[20,24] with533.6002197 HP, Cassi5 at[18,24] with602 HP, and linked Issac6 at remote[8,34] with1,375 HP. The first two positions fit the local area footprint; Issac's remote position does not. Stellar's gold rises55 →155 and bag130 →152 in the frame, consistent with two kill rewards including the pair's combined22-gem bag.

Do not sum the three HP decreases as direct spell damage or infer that Stellar targeted the remote body. The known linked-life mechanic explains why a single area cast can produce a geographically remote death and why a simple multi-recipient count is an effect association. Original hypothesis: represent linked survival and local spell footprint separately when valuing a target or measuring focus.

## 11 — Current control on one front does not establish protection elsewhere

[cf45b81d… source bundle](https://2026a.battlecode.co.uk/api/v1/matches/cf45b81d-98a4-4e5b-a467-e5cca4222fb4/bundle), fragment, R282–290; current Univardisty versus procless, patch0.0.2. [Exact episode](11-current-control-and-separate-front-loss-cf45b81d-98a4-4e5b-a467-e5cca4222fb4.json).

At R285 procless Ren6's slot0 command input5595/seq28120 lowers Univ Tavi3 from479.9999695 to232.4999695 HP at[18,16]. Tavi survives through the R290 snapshot and moves to[14,12]; Ren moves from[21,18] to[17,14]. The [current rich native frames](../policy/rich-replay-frames-002.json) confirm a new duration1 stun and restriction mask63 on Tavi. This is an applied stun, not merely a stun-capable cast record.

Elsewhere in that same round, Univ Cassi1's slot0/basic inputs5588–5589 lower procless Stellar7 from648 to268 to234.5 HP at[2,8]. Univ Stellar0's area cast input5598/seq28130 then kills that body. The native event order is exact, but Ren's remote cast does not establish a peel attempt or failure. No personal awareness of the distant fight is inferred.

Original hypothesis: assess local legal contribution and time to protection, rather than treating a team-wide nearby-body total or a successful control effect as protection of every ally. An effect on one front and a loss elsewhere can coexist without proving a wrong target decision.

## 12 — Current Varg reset sequence has splash recipients

[3b104605… source bundle](https://2026a.battlecode.co.uk/api/v1/matches/3b104605-4d6e-4082-9904-da5d2a699cd9/bundle), swirl, R69–76; current procless versus Fish, patch0.0.2. [Exact episode](12-current-splash-reset-trade-3b104605-4d6e-4082-9904-da5d2a699cd9.json).

At R71 procless Varg3 ordinarily moves[21,13] →[21,14], basics toward Fish Stellar6 at[22,15], casts its slot0 reset and basics again, inputs1579–1582. Each basic frame lowers both Stellar6 and nearby Fish Ren5 by50 HP; the action's aim is Stellar's tile while Ren is at[23,16]. Varg's own HP remains630 in those frames. The [current rich supplement](../policy/rich-replay-frames-002.json) confirms Varg’s existing250-point shield at duration2 is also unchanged across both basics, while Ren has100 Focus and no buffs. Shield absorption therefore does not explain the absent actor HP loss here. Two [separate current controlled fixtures](../policy/native-secondary-mechanics-002.json) then distinguish the trigger: explicitly targeting Ren makes Varg’s shield fall250 →230; explicitly targeting Stellar leaves it250, although both enemy HP losses are50 in both setups. In those tested states, Ren’s secondary splash does not return the20 damage. The same recipient set therefore does not recover the primary target or imply retaliation for every recipient. The replay’s recorded aim and positions remain observations; why the bot chose that action is unknown.

At R72 Fish Stellar6's slot0 input1597 kills procless Ryth4 at[21,11], which had281 HP. By the R76 snapshot Varg remains alive at510 HP, Fish Ren at510 and Fish Stellar at135; the procless Ryth is dead. Thus the local sequence has real effects and adverse allied continuation, without establishing its causal value or either team's intent.

Original hypothesis: distinguish the selected basic aim from splash recipients and price the next opposing action, not just the current multi-recipient damage. A good reset mechanism is not a guarantee that the wider exchange is safe.
