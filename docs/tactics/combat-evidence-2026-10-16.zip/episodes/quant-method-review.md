# Bounded combat quantitative methods review

The reviewed source logic and sampled arithmetic pass the declared scope. This is not a full-corpus rerun or fresh-engine compatibility check.

Stored fixture:8 games,162 body-window rows. Current analyzer SHA:d2b5ddf9138cec8699627b76e005783e2e408d8a72b974cac32ec092a1d268c2; fixture-bound analyzer SHA:9bc8c61337d07f9c29f6eea41a7c99770f93724fbfc5c6b8cc6736886ef8ac88. All 8 declared checks pass, including independent outgoing/self-loss/linked-terminal recomputation for three source streams.

- **Ordering denominator:** Move/attack/cast order counters are conditional on alive outside-own-spawn owner starts with both retained actions in that actor/world round. They are not restricted to contact6 unless separately named, and are not available-action opportunities. First action order can differ from later attacks.
- **Control ability types:** Native abilityType4 control-cast counters do not count every applied stun. Marcella enhanced reset is type1; its later basic can stun. Type6 dash move-order counters are not offensive casting order.
- **Exit endpoint and censoring:** Three consecutive future owner-start observations and remaining window are required; absent endpoint is right-censored. Alive/field/noenemy6 is endpoint geometry only, allows intermediate contact, and does not require the same original enemy to be absent. Shield/control actions without enemy HP loss can enter the proxy.
- **HP attribution:** Actor self-loss is excluded from outgoing opposing-recipient HP totals and separately retained. These remain frame associations, including splash, retaliation interaction and linked remote deaths; incoming source-associated bins are not a full causal damage accounting.
- **Terminal linked sensitivity:** Both paired terminal recipients are removed together at the same native seq, conservatively discarding a true primary loss as well as its linked loss. The strict version is not recovered primary-target attribution; nonterminal AoE/splash remains.
- **Refreshed API and engine:** This reviewed worker indexes game.statistics and historical final champion counters. Fresh summary-style sides/score/draft inputs require explicit adaptation and declared unavailable fields; an empty cached error list cannot validate absent API fields. Engine compatibility must be established separately.
- **Fixture version:** The eight-game fixture summary binds an earlier analyzer revision. Its stored-row algebra and three independent source recomputations are valid bounded checks, not execution of every current-source branch.
- **API applicability:** Early-window API full-game counters are inapplicable, rather than measured zero. Owner reports CSV cells repaired to empty and future applicability flag added; this bounded review did not reread the full historical CSV or promote it to an API-null audit.

Exact input hashes, line scopes and checks are in [quant-method-review.json](quant-method-review.json). No quantitative producer output was edited.
