# Original combat policy hypotheses from bounded episodes

This is a proposed policy, not a reconstruction of another team's private code and not a measured optimum. The source observations are in [episode-findings.md](episode-findings.md) and the exact JSON files indexed by [index.json](index.json). The hypotheses combine those observations with separately verified engine mechanics. Episodes01–10 retain their historical engine;11–12 add current0.0.2 procless examples. The [bounded native version comparison](../policy/native-version-comparison.json) reruns the same27-case suite on both engines with85 current assertions and no observed differences in that suite; this does not prove universal engine equivalence. These examples do not determine threshold values, success rates or causal benefit.

## Represent useful actions before counting strength

Start from the owner's current legal actions and the actual remaining turn order. For each personally observed threat, enumerate a bounded set of feasible sequences: stationary cast/basic, melee attack and move in either legal order, ranged reposition without a basic, a compatible attack-reset sequence, and available escape/control choices. Include health, shield, stun/channel restrictions, per-slot cooldown, ordinary movement/attack allowance, cast allowance and the terrain/occupancy at every step. A nearby ally contributes only if a useful action can occur before the relevant enemy response; a stored claim and distance are insufficient.

Use actual spell aim footprints. Episode01 contains a five-tile-away recipient affected by a cast aimed four tiles away with an area footprint. A simple recipient-distance filter would omit the observed action; a radius-only filter could admit an illegal aim. A complete engine legality predicate or an equivalent verified geometry calculation is required.

**Trigger:** an enemy becomes a credible current threat, we can affect an enemy, or a mission requires an exchange. **Stop:** the actor loses the required allowance, target observation, route or timing. **Fallback:** a legal protective move, safe channel continuation or productive objective action, according to the current threat. **Test:** hold the same positions and stats while changing cooldowns, cast/move restrictions and which side acts first; the chosen action must change when contribution becomes unavailable.

## Evaluate the whole exchange, including secondary effects

Forecast the actions the opponent can take before our next useful response, rather than multiplying nearby headcount by average health. Include an awake camp's damage, enemy abilities, return damage, shields, healing and linked-body death. Do not double-count an area frame as several independently selected attacks. Current Episode12 also shows why the exact effect role matters: Varg’s two basics lower an adjacent Ren and Stellar while Varg’s HP and shield remain unchanged. Two [current controlled fixtures](../policy/native-secondary-mechanics-002.json) further show return damage when Varg explicitly attacks Ren, but no return when Ren is the secondary splash recipient, despite identical50-HP enemy losses. Model eligible primary-trigger effects separately; do not silently apply a direct-target retaliation rule to every splash recipient. Re-evaluate after every executed action because a shield break, kill, retaliatory loss or heal can change the best next action.

Episodes02,03 and05 show why a target's low HP is insufficient. A return-damage recipient can cost the attacker HP on each hit; a linked partner can die at a remote location; a later kill can coexist with an earlier valuable loss. Episode04 now has a rich native frame proving the315-HP heal after the220-HP burst; a burst amount is not a guaranteed kill. Episode01 likewise proves shield absorption and applied control despite zero initial HP loss.

**Trigger:** any trade, multi-hit/reset sequence, dive or linked-body exposure. **Stop:** the credible response makes survival or the mission infeasible, unless all feasible continuations lose and this action preserves the most useful result. **Fallback:** shorten the trade, use control/cover, disengage, or preserve a delivery. **Test:** compare the same target HP with and without return damage, shield, ready heal, linked partner exposure and next-actor order. The two current primary-versus-splash Ren fixtures supply a concrete regression pair; broaden it across positions, shields, Focus and lethal hits before generalizing. When multiple primary targets are actually legal, compare their full secondary/return effects rather than only the recipient HP set.

## Select targets by feasible mission result

First prevent an immediate decisive loss when an available legal action can do so. Then compare a secured removal, a dangerous actor, a valuable carrier and the target obstructing a concrete capture, delivery or escape. Allocate only enough timely damage to the intended result. A protector may have a different useful recipient from the principal damage actor: disabling a diver or healing a carrier can outrank adding damage to a distant focus target.

A shared recipient is evidence of overlapping effects, not proof of a negotiated focus command. Keep the target commitment short and local: identify the recipient and useful deadline, then release it on death, loss of visibility/reach, a newly decisive threat or exhaustion of useful support. A linked pair's joint survival can alter removal value, but the examples do not prove that any team intentionally selected the weaker partner.

**Trigger:** multiple legal enemy recipients or an ally's accepted actionable request. **Stop:** result achieved, commitment stale, or a better immediate mission overrides it. **Fallback:** the best personally legal target/action, without pretending that a hidden ally has acknowledged it. **Test:** change recipient HP, carried gems, partner state, available damage and teammate action order independently; inspect both overkill and split damage.

## Spend control for the enemy action it prevents

Choose a control target by which dangerous action, channel completion or escape it can still prevent. Check immunity and the actual remaining disable window. A cast from a stun-capable slot is not sufficient replay evidence that the stun applied. Existing disable time can make another control cast redundant, while an enemy acting before allied damage can make control urgent. Count exact owner-turn expiry: in Episode04 the victim acts between Cassi’s cast and Tavi’s refresh, so two casts in one world round need not cover the same remaining turn. A duration-zero stun can still restrict actions until the appropriate next owner start. Damage alone does not interrupt every channel.

Use the bounded richer native buff/restriction evidence before calling an observed case an applied stun; Episodes01/04 have that confirmation. A successful peel additionally needs the relevant threat and protected-ally follow-through. Even an applied stun does not reveal the bot's intention or establish its net benefit. Any claimed protected ally must have an observed relevant follow-through, not only a smaller enemy distance.

**Trigger:** a credible interruptible action or lethal enemy reply remains ahead. **Stop:** target becomes immune, already disabled through that window, no longer threatens the mission, or the interrupt deadline passes. **Fallback:** direct damage, another legal control recipient, heal/cover or escape. **Test:** target immunity, one existing disable, staggered turn order, tribute versus recall, and a target dying before its turn.

## Choose movement by the next response and destination

Treat movement as a transition to a useful legal state. A melee body can often attack then leave, while a ranged body normally trades movement for its basic unless a specific reset restores the attack allowance. A reset need not restore movement. Distinguish move → reset → basic from basic → reset → basic; spending the cast on a reset also forgoes a different slot's control or burst that turn.

Episodes04–06 demonstrate the legal sequence, not its universal value. Episode06 approaches into normal range and remains exposed through later snapshots; it should be described as a trade rather than declared successful kiting. Episode07 increases separation while collecting a reward and heading toward recovery, showing why a productive exit destination matters.

**Trigger:** a reposition improves survival, a legal action, mission access or escape. **Stop:** the destination becomes occupied, the target moves, the useful allowance disappears or the reply no longer improves. **Fallback:** a safe available neighbor or a stationary protective action; avoid repeated failed moves. **Test:** paired states with/without a reset, equivalent distance but different terrain, occupied landing tiles, and target movement before the owner acts.

## Reassess pursuit instead of extending the first commitment

Continue only while a timely legal action can achieve a useful result before escape, reinforcement, recovery or an objective deadline erases its value. Include travel and the camp, capture, bank or reset foregone by chasing. A large visible enemy bag can justify a brief interception; it does not remove route safety, linked-life or cooldown checks. When the chase ends, release any shared commitment and name a productive next task.

Episode01 reaches several later damaging states without a kill inside the window. Episode02 records a later kill after linked attacker deaths. Neither sequence proves an optimal chase duration or a wrong initial engage. They motivate a declared evaluation horizon and stop condition.

**Trigger:** the recipient leaves the immediate useful action footprint or the encounter materially changes. **Stop:** no useful intercept, adverse reinforcement/order, unsafe return or expired mission deadline. **Fallback:** safe resource work, recovery, conversion or protection. **Test:** the same initial target with differing escape routes, allied arrival delays, bag values and objective deadlines; record lost as well as completed conversions.

## Judge combat by conversion as well as effects

A fight can be useful because it enables a completed capture, safe delivery or recovery; damage alone is not that conversion. Keep attempted commands, actual HP/control changes, deaths, capture rewards and banked score as separate outcomes. Report what happens before the bounded window ends and censor later outcomes rather than assuming that a survivor eventually scores.

Episode08 has a real 48-gem score transition before the owner's next basic attack; Episode07 has an actual camp reward after separation. Neither proves an escort protocol or that combat caused the economic result. The proposed policy should compare these feasible continuations with pure damage and explicitly protect their timing.

**Trigger:** a delivery/capture can complete within the relevant action window or combat has just removed a threat. **Stop:** conversion completes, becomes impossible, or the credible interruption makes another action better. **Fallback:** preserve the bag/holder, choose another route or release excess helpers. **Test:** identical encounters with different capture/channel timers, altar locks, bags and match deadlines, preserving exact turn phase.


## Current case scope

Episodes11–12 add current0.0.2 control and multi-recipient trades against procless. The fragment case confirms applied control but also a remote allied death; it does not establish an attempted peel or a wrong control target. The swirl case confirms a move/basic/reset/basic sequence and later opposing response. Keep these local transitions separate from team-wide survival, conversion and private intent. The broader current cohort supplies any frequency denominators; these selected examples do not.
