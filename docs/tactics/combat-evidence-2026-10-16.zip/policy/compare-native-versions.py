from pathlib import Path
import hashlib
import json

base=Path(__file__).resolve().parent
old=json.loads((base/'native-combat-mechanics.json').read_text(encoding='utf-8'))
new=json.loads((base/'native-combat-mechanics-002.json').read_text(encoding='utf-8'))
differences=[]
def compare(a,b,path=''):
    if type(a)!=type(b):differences.append({'path':path,'old':a,'new':b});return
    if isinstance(a,dict):
        for k in sorted(set(a)|set(b)):
            if k not in a or k not in b:differences.append({'path':path+'/'+k,'old':a.get(k),'new':b.get(k)})
            else:compare(a[k],b[k],path+'/'+k)
    elif isinstance(a,list):
        if len(a)!=len(b):differences.append({'path':path+'/length','old':len(a),'new':len(b)})
        for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+'/'+str(i))
    elif a!=b:differences.append({'path':path,'old':a,'new':b})
compare(old['records'],new['records'],'records')
compare(old['checks'],new['checks'],'checks')
report={
 'method':'Same bounded27-case controlled suite; recursive exact JSON comparison of every retained records/checks field. Engine identity is expected to differ and excluded only from records comparison.',
 'old_engine':old['engine'],
 'current_engine':new['engine'],
 'current_cases':len(new['records']),
 'current_assertions':len(new['checks']),
 'current_failed_assertions':[c for c in new['checks'] if not c['pass']],
 'current_case_errors':[r for r in new['records'] if r.get('error')],
 'abi':{'full_snapshot_bytes':184696,'timeline_snapshot_bytes':40152,'guard_passed':True,'setup_adapter':'0.0.2 renames Game_Draft_Champion(game,choice) to Game_Runner_DraftChampion(game,choice,0); official viewer wrapper confirms this adapter'},
 'observed_difference_count':len(differences),
 'observed_differences':differences,
 'old_result_sha256':hashlib.sha256((base/'native-combat-mechanics.json').read_bytes()).hexdigest(),
 'current_result_sha256':hashlib.sha256((base/'native-combat-mechanics-002.json').read_bytes()).hexdigest(),
 'limit':'Equal bounded observations do not prove that the two engines are identical on all mechanics/maps/actions; no bot games, fuel benchmarks or competitive strategy test.'
}
(base/'native-version-comparison.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ('observed_differences','old_engine','current_engine')},indent=2))
print('Current engine:',new['engine']['sha256'])
if differences:print(json.dumps(differences[:15],indent=2))
assert len(new['records'])==27 and len(new['checks'])==85
assert not report['current_failed_assertions'] and not report['current_case_errors']
