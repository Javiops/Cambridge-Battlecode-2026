# Current0.0.2 combat mechanics confirmation

The same controlled **27 cases and85 assertions pass** on the official CLI2.2.2 viewer's0.0.2 engine, `v0_0_2-DFj19m76.wasm`, SHA-256 `e123b59d9dea198762ab7a04db9b3cb6d06dfa991088e41c24750fc4cb88b947`. Provenance is recorded in `../acquisition/runtime/manifest.json` and `pypi-cambc.json`.

`native-combat-mechanics-002.json` is a separate current-engine result; the0.0.1 report is preserved. `native-version-comparison.json` compares every retained case state, action result/error and assertion recursively: **zero observed differences** across this bounded suite, excluding engine identity metadata. Its current-result SHA-256 is `9340451b7626d7c878e00f230a1f1f855da41f8b01f41f6084eeb941d7fa2114`.

## ABI and adapter

Both engine exports report full-state size184696 and compact-timeline size40152. The harness refuses to decode a different size. Native roster/type, positions, HP, action flags, buffs, cooldowns and step-kind checks agree in the tested states. Equal sizes alone are not an exhaustive ABI proof.

The setup API changed:0.0.2 exposes `Game_Runner_DraftChampion(game,choice,0)` instead of the old `Game_Draft_Champion(game,choice)`. The official viewer JavaScript uses exactly that conditional adapter. Only this controlled setup call changed; game actions and their retained observations did not differ. This is not a bot-source modification or a claim that every future API export is compatible.

## Current-engine results usable in the policy

- Ranged ordinary movement and basic attack share an allowance. **Move→attack-reset→basic succeeds**; reset does not restore movement. Stationary basic→reset→basic also succeeds.
- A movement-exclusive spell can be followed by a basic, but cannot share a turn with normal movement. A compatible Cassi control or Willow heal can follow movement. One successful cast across the slots remains the budget.
- Vendetta's kill refreshes cooldowns without refunding a spent cast. A fresh basic kill can still leave a reset/new-target follow-up when that cast was not spent.
- The tested stun blocks the victim's next owner turn; duration0 can still impose restrictions until owner-start removal. Marcella takes damaging control's damage without the stun.
- In tested **direct** hits/spells, Ren returns0.2×effective Focus, including shielded/lethal triggering hits. Attacker mitigation and shields affect that return, and the counter can kill the actor. Do not compute it as20% of the incoming damage.
- Multiple-recipient basics/area casts and remote Cassi/Issac linked deaths share an action frame. A kind5/kind6 actor label does not establish a unique direct-damage recipient or intended focus. Targeted and ground casts have different visibility requirements.

These validate legal mechanics in the tested states. They do not validate the planned bot sequence selector, source risk estimates, private information, competitive improvement or C++ guest fuel cost. Equal bounded observations do not establish complete engine equivalence or prove server binary identity.

## Separate Varg/retaliation boundary

`native-secondary-mechanics-002.json` adds **two separate controlled cases with two passing assertions**, without changing the common27/85 comparison:

1. Varg explicitly attacks Ren as primary; Ren and neighbouring Stellar each lose50, while Varg's shield falls250→230 through Ren's20 counter.
2. Varg explicitly attacks Stellar as primary; Stellar and neighbouring Ren each lose50, but Varg's shield stays250.

Varg HP remains1000 in both. In these states **Ren's secondary Varg-splash damage does not trigger the direct-hit retaliation result**. Do not add return damage for every secondary recipient merely because the recipient is Ren. This is a tested boundary, not a universal assertion about all future area/passive damage sources.

## Current source-bound rich frames

`rich-replay-frames-002.json` preserves four selected inputs from two0.0.2 replays, with actual engine, raw hashes, actor/type/slot matching and successful buff/restriction reads. The historical rich file remains separate.

- `cf45b81d…`, input5595, R285: Ren6's control cast reduces Tavi3 HP479.999969→232.499969, adds stun1 and restrictions63. This establishes applied control at that instant, not its causal payoff.
- `3b104605…`, R71 inputs1580/1581/1582: Varg3 basic/reset/basic. Each basic removes50 HP from Ren5 and Stellar6. Varg remains630 HP with the same250-point shield through both basics; the reset changes no HP/buffs. Shield absorption therefore does **not** explain the absence of actor HP loss in this observed sequence. It is consistent with the separately tested secondary-splash boundary, without proving private target intent or optimality.

The host sees these states; the record does not grant that information to another body. Absolute sequence numbers come from the episode trace audit; the enrichment re-verifies the corresponding input/kind/actor/slot rather than claiming a new full replay recount.

## Other bounded current checks

`current-ability-enum.json` reads current native ability properties for Varg, Stellar, Ren and Willow, covering kinds1–7, and checks an actual Varg shield cast: four metadata checks plus one shield-effect check pass. The labels remain1 attack reset,2 damage,3 area damage,4 control,5 heal,6 dash,7 shield. A class4 cast can be damaging or pure control; class labels are not a complete list of every control effect, such as an enhanced reset.

`native-tavi-sequence-002.json` directly checks the movement/reset mechanism for Tavi in one supplemental case with three passing assertions: move→plain basic fails41; slot0 reset then allows a35-damage basic; a second ordinary move still fails36. The common-version suite already checks the analogous ranged mechanism with Vesper. This targeted extension validates Tavi's legal option, not when using it is profitable.

Both supplements are separate from the27-case/85-assertion cross-version comparison; no new champion bot or competitive game was run.
