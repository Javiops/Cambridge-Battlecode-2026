# Combat mechanics audit: pinned native evidence

These are controlled mechanics checks, not bot games, a strategy benchmark, or evidence of private coordination. `native-combat-mechanics.json` retains every before/after state, native result/error, roster identity and assertion. `probe-combat-native.mjs` creates each exact setup with sandbox operations, then exercises actual game actions.

**Version boundary:** The historical result in `native-combat-mechanics.json` uses the cached **0.0.1** editor engine `work/battlecode-bot-v1/r2-research/v0_0_1-ctH8uuEb.wasm`, SHA-256 `ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc`. The same27/85 suite now also passes on the official CLI2.2.2 viewer's **0.0.2** engine, SHA-256 `e123b59d9dea198762ab7a04db9b3cb6d06dfa991088e41c24750fc4cb88b947`, with a separate result and zero differences across all retained case/check fields. See [current confirmation and limits](mechanics-current-002.md). This establishes the bounded tested mechanics on both pinned engines, not complete engine equivalence, server binary identity or bot-policy validation.

The completed bounded suite has **27 cases and 85 passing assertions**. It covers selected released kits and interactions; it is not exhaustive testing of every champion, terrain, item, phase or possible action ordering. The native visualiser is unmetered for this work and establishes no C++ guest fuel cost.

## Actions and budgets

| Controlled interaction | Pinned native result | Policy consequence |
| --- | --- | --- |
| Ordinary ranged move → basic | Move succeeds; basic rejected, error41 | Ordinary ranged movement spends the shared basic allowance. |
| Ranged move → attack-reset cast → basic | All three succeed | A reset can enable an attack after moving. Current source does not deliberately construct this sequence. |
| Ranged basic → reset → basic | Both basics succeed | A stationary double basic is another candidate sequence. |
| Ranged basic → reset → ordinary move | Move remains rejected, error36 | Attack reset restores attack, not ordinary movement. It is not an escape-movement refund. |
| Melee move → basic → reset → basic | Succeeds; second ordinary move rejected | Melee's ordinary move and basic differ from the ranged shared allowance; reset still uses the cast budget. |
| Stellar movement-exclusive damage cast → basic | Both succeed | Exclusive-with-movement does not mean exclusive with a basic attack. |
| Exclusive cast → ordinary move; move → exclusive cast | Rejected127 and126 respectively | Decide stationary spell versus movement before spending either action. A failed post-move cast does not start that slot's cooldown in the fixture. |
| Two successful ability attempts across two slots | Second cast rejected27 | Compare damage, control, shield, heal, dash and reset as competing uses of the same successful-cast allowance. |
| Cassi nonexclusive control after a move | Succeeds | Read the slot attribute; do not ban every cast after movement. |
| Willow move → heal | Succeeds; target gains315 HP in fixture | A support cast can remain useful after movement, subject to actual range/readiness. |
| Cast cooldown | Eight immediately; seven after caster turn end; still seven at next caster start | Forecast cooldowns against owner turns and actual initiative. A world-round counter alone is insufficient. |

For Vendetta, a credited basic kill resets slot cooldowns, but **does not refund a successful cast already spent this turn**. Dash → kill → second cast is rejected27 even though both cooldowns show zero. With no prior cast, basic kill → reset → basic on a different living target succeeds. This prevents treating a cooldown refresh as an unlimited action loop.

## Control, shields and passive interactions

- Tavi's tested slot1 does220 HP damage and applies stun duration1. The target cannot act on its next owner turn. At that turn's end the buff can have duration0 while restrictions remain63; it is removed at the following owner start. Do not interpret zero duration between phases as already free to act.
- Marcella takes the same220 damage but receives no stun and can move on her next turn. A damaging control spell can retain damage value while its control value is zero.
- Ryth's tested area cast does100 initial damage and stuns. In this fixture it does not deal another100 before the next round's actor start. A metadata duration is not sufficient proof of repeated damage.
- For the tested direct hits/spells, Ren retaliates for **0.2 × his effective Focus**, not20% of incoming damage: at100 Focus both a50 basic and220 spell cause20 counter-damage; at160 Focus the basic causes32. A fully shielded Ren still retaliates; a lethal hit on Ren still produces the20 counter-damage in the tested state. An attacker at5 HP dies while the attacked Ren takes the basic's damage. A separate current-engine boundary probe shows secondary Varg splash does not trigger that return; do not generalize the direct-hit result to every damage source.
- Incoming mitigation/shields still affect that counter: the attacker's Durability changes20 HP loss to18, and a100-point attacker shield absorbs it to80 with no HP loss. Thus retaliation, attempted damage, absorbed damage and HP loss are different quantities.
- Varg's basic produces multiple opposing HP recipients in the same action frame. Killing Cassi in basic range kills her remote900-HP Issac partner in that same frame without a direct hit on him. These are different secondary mechanisms.

The tests explicitly verify fixture roster types. Native draft input order is interleaved between teams; physical body IDs are assigned by roster, with Cassi/Issac adding an extra body. Do not infer the target champion merely from its raw draft choice or ordinal input position.

## Vision and targeting

The targeted Stellar spell rejects an unobserved enemy with error30 and leaves its cooldown zero. A legal ground-centred area cast can hit an enemy hidden in a bush without supplying a visible unit target. This does **not** give the bot the hidden position: a blind cast needs a policy based on genuine last-seen/movement/mission evidence, not the host's omniscient coordinates. Unit-target legality and ground-centre legality must remain separate.

Existing ward/coordination probes establish personal rather than shared sight, hidden remote ally HP/position, owner-turn ordering and next-round priority changes within their own pinned-engine scope. They do not grant an actor access to all host snapshots or establish a complete future joint sequence.

## What kind5/kind6 frames establish

Successful controlled basics end with native kind5 and casts with kind6, actorKind1. The same frame can contain:

- damage to the selected opponent plus Ren counter-damage to the actor;
- Varg splash or ground-area secondary opposing recipients;
- remote Cassi/Issac linked death;
- only shield depletion or a new stun, with no target HP loss;
- a heal rather than opposing damage.

Therefore kind/actor alone is not sole direct damage attribution, primary-target selection, coordination intent, or combat quality. Keep actual HP-loss recipients separate from self-loss, shield changes, applied control, heals, and linked death. A zero-HP-loss frame can still be a useful hit or control action. Observed positive opposing HP loss does not prove a single-target attack or a deliberate shared focus.

`rich-replay-frames.json` adds native buffs/restrictions to seven selected historical replay inputs. Raw hashes and engine hash are retained; the engine directly re-verifies input/kind/actor/slot. Absolute source sequence IDs are supplied from the separate episode audit, not silently claimed to have been recounted from frame zero.

| Replay inputs | Additional directly observed evidence |
| --- | --- |
| `c58b2e34…`,676 | Cassi0 applies stun1 to Vendetta7, no HP loss; restrictions63. |
| Same match704 | Tavi4 damages the same Vendetta700→480 and refreshes an existing stun0→1. |
| Same match707 | Willow10 heals that Vendetta480→795; its stun remains. |
| `d44a2517…`,2060/2061 | Ren4 basic consumes shield250→205; control cast consumes205→42.5 and applies stun1. Both leave target HP832. |
| Same match2074/2077 | The next basic consumes the remaining42.5 shield and2.5 HP; Stellar's following area spell removes140 HP. |

These rich frames are omniscient evidence at the observed instant. They do not prove that every actor knew the buffs, that a stun prevented a particular alternative action, or that shielding/healing was optimally timed.

## Evidence limits and reuse

Cached SDK `cambc.h` SHA-256 `90f4242686f22305b28d76d4fa2297187931b3c974f96faf324199e93979203d`; `imports.h` SHA-256 `0945b55e8c313532560674aff9fa9215e5dbf4d0e4bc0ae283184f6bc9142eff`. Cached `GameRules.md` SHA-256 `1c7fcf111d95b4734070f8f676cd50a48154feb0673de73a31c79845afa34732`. These are local cached references, not a claim that the current0.0.2 SDK is byte-identical.

Earlier `combat-moves-fixtures.json` and `targets-helper-fixtures.json` use extracted helper bodies with narrow SDK stand-ins. Their contract checks are distinct from the native probes here and from validation of the shipped bot's full action policy. No existing stand-in fixture is promoted to current-engine or competitive proof by this report.
