// Version-selectable controlled engine harness. Refuse an unknown snapshot ABI.
import fs from 'node:fs';
import crypto from 'node:crypto';
export const enginePath=process.env.COMBAT_ENGINE_PATH??'work/battlecode-bot-v1/r2-research/v0_0_1-ctH8uuEb.wasm';
let instance;
export const v=()=>new DataView(instance.exports.memory.buffer);
const bytes=(p,n)=>new Uint8Array(instance.exports.memory.buffer,p,n);
export function cstring(p){const b=new Uint8Array(instance.exports.memory.buffer);let n=p;while(n<b.length&&b[n])n++;return new TextDecoder().decode(b.subarray(p,n));}
const wasi={environ_get:()=>0,environ_sizes_get:(p,n)=>{v().setUint32(p,0,true);v().setUint32(n,0,true);return 0;},fd_close:fd=>fd<=2?0:8,fd_fdstat_get:(fd,p)=>{if(fd>2)return 8;bytes(p,24).fill(0);v().setUint8(p,2);return 0;},fd_prestat_get:()=>8,fd_prestat_dir_name:()=>8,fd_read:(fd,p,n,r)=>{if(fd!==0)return 8;v().setUint32(r,0,true);return 0;},fd_seek:fd=>fd<=2?70:8,fd_write:(fd,p,n,r)=>{if(fd!==1&&fd!==2)return 8;let written=0;for(let k=0;k<n;k++){const b=v().getUint32(p+k*8,true),len=v().getUint32(p+k*8+4,true);process.stderr.write(Buffer.from(bytes(b,len)));written+=len;}v().setUint32(r,written,true);return 0;},random_get:(p,n)=>{crypto.randomFillSync(bytes(p,n));return 0;},proc_exit:code=>{throw Error('Native engine exited:'+code);}};
instance=new WebAssembly.Instance(new WebAssembly.Module(fs.readFileSync(enginePath)),{wasi_snapshot_preview1:wasi});
export const E=instance.exports;E._initialize();
if(E.Game_Visualiser_SnapshotSize()!==184696||E.Game_Visualiser_TimelineSnapshotSize()!==40152)throw Error('Unverified visualiser snapshot ABI; do not decode with cached offsets');
export const out=E.Engine_Malloc(64),scratch=E.Engine_Malloc(256),snap=E.Engine_Malloc(184696);
export function checked(name,...args){const code=E[name](...args);if(code)throw Error(name+':'+code+':'+cstring(E.GetLastErrorMsg()));}
export function pos(x,y){v().setInt32(scratch,x,true);v().setInt32(scratch+4,y,true);return scratch;}
export function entity(kind,id,off=8){v().setUint32(scratch+off,kind,true);v().setUint32(scratch+off+4,id,true);return scratch+off;}
export function perspective(team=2,id=4294967295){v().setUint32(scratch+16,team,true);v().setUint32(scratch+20,id,true);return scratch+16;}
export function state(g,team=2,id=4294967295){checked('Game_Visualiser_ReadState',g,perspective(team,id),snap);const d=v(),u=n=>d.getUint32(snap+n,true),i=n=>d.getInt32(snap+n,true),f=n=>d.getFloat32(snap+n,true);return{round:u(8),turn:u(12),team:u(16),input:!!u(20),phase:u(24),current:u(60),champs:Array.from({length:u(120)},(_,k)=>{const p=140+k*456;return{id:u(p+4),team:u(p+8),type:u(p+12),known:u(p+16),x:i(p+20),y:i(p+24),hp:f(p+28),flags:u(p+36),alive:!!u(p+224)};})};}
export function createGame(picks=[0,1,4,5]){checked('MapBuilder_Create',32,32,0,out);const m=v().getBigUint64(out,true);checked('MapBuilder_SetNumChampsPerTeam',m,2);[1,1,4,4].forEach((n,k)=>v().setInt32(scratch+k*4,n,true));checked('MapBuilder_SetTeamASpawnArea',m,scratch);for(const [kind,x,y] of [['Wall',14,15],['Hole',15,14],['Bush',14,14],['Bush',14,13],['Bush',13,13],['Bush',11,13],['Altar',13,15]])checked('MapBuilder_Add'+kind,m,x,y);checked('MapBuilder_AddCamp',m,0,13,14,out);checked('MapBuilder_VerifyIntegrity',m);checked('MapBuilder_Encode',m,out,out+4);const p=v().getUint32(out,true),n=v().getUint32(out+4,true);checked('Game_FromMapFileBytes',p,n,out,0);const g=v().getBigUint64(out,true);checked('MapBuilder_Destroy',m);checked('Game_Runner_Init',g);let k=0;for(let z=0;z<1000;z++){const s=state(g);if(s.input&&s.phase===12){const choice=picks[k++];if(E.Game_Runner_DraftChampion)checked('Game_Runner_DraftChampion',g,choice,0);else checked('Game_Draft_Champion',g,choice);}else if(s.input&&s.phase===10)return g;else checked('Game_Runner_Step',g);}throw Error('Draft initialization bound');}
export function teleport(g,id,x,y){checked('Game_Sandbox_Teleport',g,entity(1,id),pos(x,y));}
export function finish(g){checked('Game_Runner_EndTurn',g,0);for(let k=0;k<1000;k++){const s=state(g);if(s.input&&s.phase===10)return s;checked('Game_Runner_Step',g);}throw Error('Turn advancement bound');}
