from pathlib import Path
import hashlib
import json
import re

base=Path(__file__).resolve().parent
root=base.parents[2]
repo=base.parent/'repository'/'Cambridge-Battlecode-2026-main'
source=json.loads((base.parent/'repository'/'source-reference.json').read_text(encoding='utf-8-sig'))
draft=(base/'07-combat-and-survival.md').read_text(encoding='utf-8')
original=(repo/'docs/tactics/07-combat-and-survival.md').read_text(encoding='utf-8')
headings=lambda t:re.findall(r'^## [1-8]\. .+$',t,re.M)
statuses=re.findall(r'^\*\*Status:\*\* (\w+)',draft,re.M)
errors=[]
if headings(draft)!=headings(original) or len(headings(draft))!=8:errors.append('Chapter headings changed')
if statuses!=['Planned']*8:errors.append('Fuller proposed tactics must remain Planned')
source_links=re.findall(r'\]\((https://github\.com/[^)]+/blob/dee0fe7bf464d9f7b281af81f9650135fc541321/[^)]+)\)',draft)
for link in source_links:
    rel,_,frag=link.split('/blob/'+source['commit']+'/',1)[1].partition('#')
    path=repo/rel
    if not path.exists():errors.append('Missing pinned source:'+rel);continue
    nums=[int(x) for x in re.findall(r'\d+',frag)]
    if nums and max(nums)>len(path.read_text(encoding='utf-8').splitlines()):errors.append('Invalid source bounds:'+link)
native=json.loads((base/'native-combat-mechanics.json').read_text(encoding='utf-8'))
rich=json.loads((base/'rich-replay-frames.json').read_text(encoding='utf-8'))
current=json.loads((base/'native-combat-mechanics-002.json').read_text(encoding='utf-8'))
comparison=json.loads((base/'native-version-comparison.json').read_text(encoding='utf-8'))
current_rich=json.loads((base/'rich-replay-frames-002.json').read_text(encoding='utf-8'))
secondary=json.loads((base/'native-secondary-mechanics-002.json').read_text(encoding='utf-8'))
ability_enum=json.loads((base/'current-ability-enum.json').read_text(encoding='utf-8'))
tavi=json.loads((base/'native-tavi-sequence-002.json').read_text(encoding='utf-8'))
if any(not c['pass'] for c in native['checks']):errors.append('Failed controlled assertion')
if any(r.get('error') for r in native['records']):errors.append('Controlled fixture error')
if len({c['name'] for c in native['checks']})!=len(native['checks']):errors.append('Duplicate native assertion names')
if any(not c['pass'] for c in rich['checks']):errors.append('Failed rich-frame query assertion')
if any(not c['pass'] for c in current['checks']) or any(r.get('error') for r in current['records']):errors.append('Failed current controlled assertion/case')
if any(not c['pass'] for c in current_rich['checks']):errors.append('Failed current rich-frame query')
if any(not c['pass'] for c in secondary['checks']):errors.append('Failed current secondary boundary check')
if any(not c['pass'] for c in ability_enum['checks']+tavi['checks']):errors.append('Failed current metadata/Tavi supplement')
flags=json.loads((root/'work/handbook-completion/source-audit-07-08-10.json').read_text(encoding='utf-8'))['relevant_flags']
report={
 'source_reference':source,
 'live_upload_identity':'Unconfirmed; do not equate repository source with screenshot v43',
 'scope':'Static code audit, proposed policy, controlled native mechanics, seven source-bound historical rich frames; no bot changes/builds/competitive games/fuel benchmarks',
 'active_configuration':flags,
 'source_order':['pre-sweep when mode>=3','init/dead shop/reward bookkeeping/shop','active-channel and fuel return','fresh observations/threats/support','unstick/spawn heal/emergency/near recall','caster kite before front with KITEFRONT0','generic engage/avoid','ordinary recall','bank','farm/spare basic','mode2 post-sweep and enabled lock helper'],
 'material_source_gaps':['first cast can precede escape decision','incompatible reset-plus-other-spell threat sum','main volley misses separate dash correction','unready allies counted by HP/radius','different local focus policies','ranged move-reset-first-shot not deliberately constructed','dead-target reset preserved but no deliberate new-target continuation','support competes for cast without mission comparison','shields/mitigation/Ren return/linked death not complete lethal model','post-purchase maxHP can be stale','attempted failed branch can return without useful fallback'],
 'controlled_mechanics':{'historical_engine':native['engine'],'current_official_viewer_engine':current['engine'],'cases_per_engine':len(native['records']),'assertions_per_engine':len(native['checks']),'all_pass':all(c['pass'] for c in native['checks']+current['checks']),'current_official_002_checked':True,'server_binary_identity':'Not established by these controlled viewer-engine probes','observed_retained_field_differences':comparison['observed_difference_count'],'abi':comparison['abi']},
 'historical_rich_frames':{'engine':rich['engine'],'matches':len(rich['results']),'frames':sum(len(r['frames']) for r in rich['results']),'all_queries_pass':all(c['pass'] for c in rich['checks']),'attribution_limit':'Actor/kind does not distinguish direct outgoing damage, retaliation, splash, shield absorption, healing or linked partner death. Omniscient replay data is not personal bot knowledge.'},
 'current_rich_frames':{'engine':current_rich['engine'],'matches':len(current_rich['results']),'frames':sum(len(r['frames']) for r in current_rich['results']),'all_queries_pass':all(c['pass'] for c in current_rich['checks']),'attribution_limit':'Ren stun observed directly in fragment; Varg multi-recipient basics with unchanged actorHP and shield in swirl. Do not explain the latter as shield absorption.'},
 'current_secondary_boundary':{'engine':secondary['engine'],'cases':len(secondary['records']),'assertions':len(secondary['checks']),'all_pass':all(c['pass'] for c in secondary['checks']),'fact':'Explicit primary Ren hit triggers20 counter; Ren as Varg splash-only recipient does not trigger it in these tested states','separate_from_common_version_suite':True},
 'current_ability_enum':{'engine':ability_enum['engine'],'labels':ability_enum['labels'],'assertions':len(ability_enum['checks']),'all_pass':all(c['pass'] for c in ability_enum['checks']),'scope':ability_enum['scope']},
 'current_tavi_sequence':{'engine':tavi['engine'],'assertions':len(tavi['checks']),'all_pass':all(c['pass'] for c in tavi['checks']),'fact':'Tavi move then normalbasic rejected; reset restores attack and permits35damagebasic; ordinary movement stays spent','separate_from_common_version_suite':True},
 'proposal':{'headings':headings(draft),'statuses':statuses,'first_phases':['legal short sequences and fresh state','survival and returned-damage reply','local focus/protection and real readiness'],'remote_protocol':'Later only after existing8-byte allocation, ownership and freshness design','hypothesis_scope':'No measured optimal thresholds or improvement claim; legal possible sequence does not establish profitable use'},
 'checks':{'source_links_in_draft':len(source_links),'errors':errors},
 'artifacts':[{'path':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(base.iterdir()) if p.is_file() and p.name not in ('policy-audit.json',)]
}
(base/'policy-audit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'controlled_cases':len(native['records']),'controlled_checks':len(native['checks']),'rich_frames':sum(len(r['frames']) for r in rich['results']),'headings':len(headings(draft)),'statuses':statuses,'source_links':len(source_links),'errors':errors},indent=2))
raise SystemExit(bool(errors))
