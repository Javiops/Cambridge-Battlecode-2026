"""Aggregate existing sequential native coordination traces; no engine execution."""
from pathlib import Path
from collections import Counter,defaultdict
from concurrent.futures import ThreadPoolExecutor
import argparse,csv,gzip,hashlib,json,subprocess,sys,time,zlib

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parents[2]
p=argparse.ArgumentParser()
p.add_argument('--manifest',type=Path,default=BASE/'work/ward-research/matches/manifest-current-unique.json')
p.add_argument('--full-manifest',type=Path,default=BASE/'work/ward-research/acquisition/manifest-native.json')
p.add_argument('--ladder',type=Path,default=BASE/'work/ward-research/acquisition/api/ladder.json')
p.add_argument('--input-dir',type=Path,default=BASE/'work/coordination-research/matches/current')
p.add_argument('--out-dir',type=Path,default=ROOT/'historical')
p.add_argument('--label',default='Historical cohort frozen 2026-10-15T22:52:39.723421Z')
p.add_argument('--engine-sha256',default='ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc')
p.add_argument('--workers',type=int,default=4);p.add_argument('--worker',type=int);p.add_argument('--limit',type=int)
p.add_argument('--unknown-team-id',action='append',default=[])
p.add_argument('--wait-timeout-seconds',type=int,default=0)
p.add_argument('--reuse-dir',action='append',type=Path,default=[]);p.add_argument('--skip-ids-json',type=Path)
a=p.parse_args();a.out_dir.mkdir(parents=True,exist_ok=True)
SHA=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
EXPECTED_ENGINE=a.engine_sha256
ENGINE_HASHES={'0.0.1':'ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc','0.0.2':'e123b59d9dea198762ab7a04db9b3cb6d06dfa991088e41c24750fc4cb88b947'}

def csvwrite(path,rows):
    fields=list(dict.fromkeys(k for r in rows for k in r));nums={k for r in rows for k,v in r.items()if isinstance(v,(int,float))and not isinstance(v,bool)}
    with path.open('w',newline='',encoding='utf8')as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows({**{k:(''if k.startswith('api')and(r.get('window')!='full'or r.get('apiFullGameCountersAvailable')is False)else 0)for k in nums},**r}for r in rows)

def gzwrite(path,rows):
    with gzip.open(path,'wt',encoding='utf8')as f:
        for r in rows:f.write(json.dumps(r,separators=(',',':'))+'\n')

def jsonwrite(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8')

META={'side','rank','body','type','draftSlots','rosterBodies','attackRange','rounds','worldRoundSamples','fullEarlyWindow','top4_h2h','latest_slice'}
def summarize(rows,keys):
    result=[];buckets=defaultdict(list)
    for r in rows:buckets[tuple(r[k]for k in keys)].append(r)
    for k,values in sorted(buckets.items()):
        sums=Counter()
        for r in values:sums.update({x:v for x,v in r.items()if isinstance(v,(int,float))and not isinstance(v,bool)and x not in META})
        ranknote={x:values[0][x]for x in ['rankKnown','rankDisplay']if x in values[0]and len({r[x]for r in values})==1}
        result.append({**dict(zip(keys,k)),**ranknote,'streams':len({r['raw_sha256']for r in values}),'teamObservations':len({(r['raw_sha256'],r['side'])for r in values}),'bodyObservations':len(values)if'body'in values[0]else sum(r['rosterBodies']for r in values),'completeEarlyStreams':len({r['raw_sha256']for r in values if r['fullEarlyWindow']}),**dict(sums)})
    return result

if a.worker is None:
    started=time.time();parts=a.out_dir/'parts';parts.mkdir(exist_ok=True)
    bodies=[];games=[];audits=[];errors=[];candidate=defaultdict(list);reused=set();manifest_source=json.loads(a.manifest.read_bytes());active=manifest_source['requests'][:a.limit]if a.limit else manifest_source['requests'];activeBy={r['id']:r for r in active}
    for directory in a.reuse_dir:
        old=json.loads((directory/'summary.json').read_bytes());old_audit=json.loads((directory/'audit.json').read_bytes())
        if old.get('analyzer_sha256')!=SHA(Path(__file__))or old['ladder_sha256']!=SHA(a.ladder)or old['full_manifest_sha256']!=SHA(a.full_manifest):raise ValueError('Reuse requires identical analyzer, ladder and full latest-selection source')
        if old_audit['errors']:raise ValueError('Cannot reuse source audit errors')
        accepted=set()
        for row in old_audit['checks']:
            mid=row['id']
            if mid not in activeBy:continue
            if mid in reused:raise ValueError('Duplicate reused stream '+mid)
            if row['raw_sha256']!=activeBy[mid]['raw_sha256']or row['trace_sha256']!=SHA(a.input_dir/f'{mid}.coord.json.gz'):raise ValueError('Reused trace/source changed '+mid)
            accepted.add(mid);reused.add(mid);audits.append({**row,'reused_from':str(directory)})
        for name,destination in [('body-game-metrics.jsonl.gz',bodies),('team-game-metrics.jsonl.gz',games)]:
            with gzip.open(directory/name,'rt',encoding='utf8')as f:destination.extend(row for line in f if(row:=json.loads(line))['match_id']in accepted)
        for key,rows in json.loads((directory/'case-candidates.json').read_bytes()).items():candidate[key].extend(row for row in rows if row['match_id']in accepted)
    skip_file=parts/'reuse-ids.json';jsonwrite(skip_file,sorted(reused))
    def run(i):
        cmd=[sys.executable,__file__,'--manifest',str(a.manifest),'--full-manifest',str(a.full_manifest),'--ladder',str(a.ladder),'--input-dir',str(a.input_dir),'--out-dir',str(a.out_dir),'--label',a.label,'--engine-sha256',a.engine_sha256,'--wait-timeout-seconds',str(a.wait_timeout_seconds),'--workers',str(a.workers),'--worker',str(i)]
        if a.limit:cmd+=['--limit',str(a.limit)]
        cmd+=['--skip-ids-json',str(skip_file)]
        for teamid in a.unknown_team_id:cmd+=['--unknown-team-id',teamid]
        with(parts/f'worker-{i}.log').open('w',encoding='utf8')as f:return subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
    with ThreadPoolExecutor(max_workers=a.workers)as pool:codes=list(pool.map(run,range(a.workers)))
    if any(codes):raise SystemExit('worker failure: '+str(codes))
    for i in range(a.workers):
        d=json.loads((parts/f'worker-{i}.json').read_bytes());bodies+=d['bodies'];games+=d['games'];audits+=d['audit'];errors+=d['errors']
        for k,v in d['candidates'].items():candidate[k]+=v
    bodies.sort(key=lambda r:(r['match_id'],r['window'],r['body']));games.sort(key=lambda r:(r['match_id'],r['window'],r['side']));audits.sort(key=lambda r:r['id'])
    gzwrite(a.out_dir/'body-game-metrics.jsonl.gz',bodies);gzwrite(a.out_dir/'team-game-metrics.jsonl.gz',games)
    csvwrite(a.out_dir/'body-game-metrics.csv',bodies);csvwrite(a.out_dir/'team-game-metrics.csv',games)
    summaries={}
    for window in ['full','early25_150']:
        summaries[window]={}
        cohorts=[('all',lambda r:True),('top4_h2h',lambda r:r['top4_h2h']),('latest',lambda r:r['latest_slice']),('latest_h2h',lambda r:r['latest_slice']and r['top4_h2h']),('patch002_h2h',lambda r:r['top4_h2h']and r['patch']=='0.0.2'),('latest_patch002_h2h',lambda r:r['top4_h2h']and r['latest_slice']and r['patch']=='0.0.2')]
        if window=='early25_150':cohorts.append(('complete_h2h',lambda r:r['top4_h2h']and r['fullEarlyWindow']))
        for name,pred in cohorts:
            gs=[r for r in games if r['window']==window and pred(r)];bs=[r for r in bodies if r['window']==window and pred(r)]
            tables={'per_team':summarize(gs,['rank','team']),'per_map_team':summarize(gs,['rank','team','map']),'per_roster_team':summarize(gs,['rank','team','draftSlots','rosterBodies']),'per_champion_team':summarize(bs,['rank','team','champion','rangeRole']),'per_champion_team_map':summarize(bs,['rank','team','champion','map']),'per_patch_team':summarize(gs,['patch','rank','team']),'per_patch_champion_team':summarize(bs,['patch','rank','team','champion'])}
            summaries[window][name]={'rawStreams':len({r['raw_sha256']for r in gs}),'teamObservations':len(gs),'bodyObservations':len(bs),**tables}
            for table,rows in tables.items():csvwrite(a.out_dir/f'{window}-{name}-{table}.csv',rows)
    for k,rows in candidate.items():
        rows.sort(key=lambda r:r['score'],reverse=True);seen=set();keep=[]
        for r in rows:
            key=(r['match_id'],r.get('actor'),r.get('side'))
            if key not in seen:keep.append(r);seen.add(key)
            if len(keep)>=24:break
        candidate[k]=keep
    source=json.loads(a.manifest.read_bytes());fullsource=json.loads(a.full_manifest.read_bytes());byraw=defaultdict(list)
    for r in fullsource['requests']:byraw[r['raw_sha256']].append(r)
    crossaliases=[{'raw_sha256':raw,'source_ids':[r['id']for r in rows],'ordered_team_bindings':sorted({tuple(r['teams'][k]['teamId']for k in ['a','b'])for r in rows})}for raw,rows in byraw.items()if len({tuple(r['teams'][k]['teamId']for k in ['a','b'])for r in rows})>1]
    observed_raw={x['raw_sha256']for x in audits}
    summary={'label':a.label,'approved_engine_sha256':ENGINE_HASHES,'observed_engine_counts':dict(Counter(x['engine_sha256']for x in audits)),'observed_patch_counts':dict(Counter(x['patch']for x in audits)),'api_check_scopes':dict(Counter(x['api_checks']['scope']for x in audits)),'analyzer_sha256':SHA(Path(__file__)),'manifest_sha256':SHA(a.manifest),'full_manifest_sha256':SHA(a.full_manifest),'ladder_sha256':SHA(a.ladder),'streams':len(audits),'source_id_count':sum(r['raw_sha256']in observed_raw for r in fullsource['requests']),'full_selection_source_id_count':len(fullsource['requests']),'reused_streams':len(reused),'reused_from':[str(x)for x in a.reuse_dir],'data_cutoff_utc':source.get('data_cutoff_utc'),'cross_ordered_team_raw_alias_groups':crossaliases,'unknown_rank_team_ids':a.unknown_team_id,'rank_sentinel_note':'Rank999 is an internal sort/filter sentinel only for explicitly passed unknown-team IDs; rankKnown=false/rankDisplay=unknown. It is never an observed ladder rank.','windows':summaries,'definitions':'../method-plan.md','metric_notes':{'direct':'Native phase10 kind5/6 actorKind1 sub0 opposing HP decreases. Secondary effects and linked death possible; not chosen primary targets or damage exclusively caused by actor.','strict':'Exclude both Cassi/Issac terminal recipients when both same-team paired bodies die at exactly the same native seq. This conservatively removes both primary/linked losses because struck identity is not recovered here.','commands':'Retained native command frames; absence of HP loss is not classified failure. Readiness/personal vision unavailable.','contact':'Alive outside own spawn; Chebyshev six enemy geometry at owner-turn start, not action opportunities.','early':'Available canonical snapshots R25–150 inclusive. Endpoint continuation must also remain within this window; fullEarlyWindow marks126 snapshots.','hp':'Frame HP decreases, not uncapped API damage/shield trajectories. Actor self-loss during own attack/cast is separately counted, including potential Ren retaliation. API full-game damage fields retained separately, only when present; native KDA counters always checked.','control':'AbilityType4 is engine CC class, not all stuns (Marcella enhanced reset is type1), and can itself cause damage.','ordering':'Alive field owner-start turns containing both listed actions, not contact-only and not available-action opportunities.','exit':'Contact6 owner-turn ordinary displacement/no direct PvP HP loss; three consecutive future own starts. Endpoint context is geometric; intermediate contact can persist, not intention or causal success.'}}
    jsonwrite(a.out_dir/'summary.json',summary);jsonwrite(a.out_dir/'audit.json',{'label':a.label,'streams':len(audits),'errors':errors,'checks':audits});jsonwrite(a.out_dir/'case-candidates.json',dict(candidate));jsonwrite(a.out_dir/'run-report.json',{'workers':a.workers,'seconds':time.time()-started,'streams':len(audits),'bodyWindowRows':len(bodies),'teamWindowRows':len(games),'errors':len(errors),'summary_sha256':SHA(a.out_dir/'summary.json')})
    print(json.dumps({'streams':len(audits),'bodies':len(bodies),'errors':len(errors),'seconds':time.time()-started}));raise SystemExit(bool(errors))

m=json.loads(a.manifest.read_bytes());fm=json.loads(a.full_manifest.read_bytes());lad=json.loads(a.ladder.read_bytes());rank={r['teamId']:r for r in lad['teams']}
if len({r['raw_sha256']for r in m['requests']})!=len(m['requests']):raise ValueError('Manifest must contain exactly one row per raw SHA')
for r in m['requests']:
    for t in r['teams'].values():
        if t['teamId']not in rank and t['teamId']in a.unknown_team_id:rank[t['teamId']]={'teamId':t['teamId'],'name':t['name'],'rank':999,'rankKnown':False}
latest=set();strata=Counter()
for r in sorted(fm['requests'],key=lambda r:(r['created_at'],r['id']),reverse=True):
    key=(tuple(sorted(t['teamId']for t in r['teams'].values())),r['map'],r['kind'])
    if strata[key]<2:latest.add(r['raw_sha256']);strata[key]+=1
requests=m['requests'][:a.limit]if a.limit else m['requests'];skipids=set(json.loads(a.skip_ids_json.read_bytes()))if a.skip_ids_json else set();requests=[r for r in requests if r['id']not in skipids];bodies=[];games=[];audit=[];errors=[];candidates=defaultdict(list)
def dist(x,y):return max(abs(x[1]-y[1]),abs(x[2]-y[2]))
def inside(c,b):return b[0]<=c[1]<b[2]and b[1]<=c[2]<b[3]
def keepcat(category,score,meta,**data):
    rows=candidates[category];rows.append({**meta,**data,'score':score+(10000 if meta['top4_h2h']else 0)+(100 if meta['latest_slice']else 0)});rows.sort(key=lambda r:r['score'],reverse=True);del rows[100:]

for ix,r in enumerate(requests[a.worker::a.workers]):
    try:
        mid=r['id'];path=a.input_dir/f'{mid}.coord.json.gz';deadline=time.time()+a.wait_timeout_seconds;readtries=0
        while True:
            try:blob=path.read_bytes();g=json.loads(gzip.decompress(blob));break
            except FileNotFoundError:
                if time.time()>=deadline:raise
                time.sleep(.5)
            except(EOFError,zlib.error,json.JSONDecodeError):
                readtries+=1
                if not a.wait_timeout_seconds or readtries>=10:raise
                time.sleep(.5)
        errs=[]
        if g['id']!=mid or g['raw_sha256']!=r['raw_sha256']:errs.append('source_binding')
        if any(g['teams'][k]['teamId']!=r['teams'][k]['teamId']for k in ['a','b']):errs.append('ordered_team_binding')
        raw=Path(r['raw']).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=r['raw_sha256']:errs.append('raw_sha')
        if len(raw)<14 or int.from_bytes(raw[:8],'little')!=125779999602273:errs.append('raw_header')
        patch='.'.join(str(v)for v in raw[8:11]);fmt='.'.join(str(v)for v in raw[11:14]);expected=ENGINE_HASHES.get(patch)
        if expected is None or g['engine_sha256']!=expected:errs.append('header_engine_binding')
        if r.get('replay_patch',patch)!=patch or g.get('patch',patch)!=patch:errs.append('patch_binding')
        api_patch=r['game'].get('patchId')
        if api_patch and not api_patch.startswith(patch+':'):errs.append('api_header_patch')
        if g['apiFinalErrors']:errs.append('cached_api_final')
        api=r['game'].get('statistics');api_round=api['round']if api else r['game'].get('rounds');end_round=g['final']['round'];api_checks={'scope':'full-statistics'if api else'public-summary','round':api_round is not None,'score':0,'draft':0,'championCounters':0,'nativeDeathCounters':0};roster={c['id']:c for c in g['roster']};teams={id:c['team']for id,c in roster.items()};spawns=g['geometry']['spawn'];rounds={w['r']:w for w in g['rounds']};turns={(v[0],v[2]):v for v in g['turns']};acts=defaultdict(list)
        if len(rounds)!=len(g['rounds']):errs.append('duplicate_round')
        if len(turns)!=len(g['turns']):errs.append('duplicate_turn')
        if any(len(w['c'])!=len(roster)for w in g['rounds']):errs.append('incomplete_round_roster')
        if any(x['actor']not in roster or x['team']!=teams.get(x['actor'])for x in g['actions']):errs.append('command_actor_binding')
        if len({x['input']for x in g['actions']})!=len(g['actions']):errs.append('duplicate_command_input')
        if api_round is not None and end_round!=api_round:errs.append('final_round')
        finalBy={c['id']:c for c in g['final']['c']}
        if len(finalBy)!=len(g['final']['c'])or set(finalBy)!=set(roster):errs.append('final_roster_identity')
        for c in g['final']['c']:
            if c['id']not in roster or any(c[k]!=roster[c['id']][k]for k in ['team','type']):errs.append('native_final_body'+str(c['id']))
            if api:
                z=next((z for z in api['champions']if z['champion']==c['id']),None);api_checks['championCounters']+=1
                if not z or any(z[k]!=c[k2]for k,k2 in [('team','team'),('type','type'),('gold','gold'),('gems','gems'),('earnedGold','earned')])or [z['kills'],z['deaths'],z['assists']]!=c['kda']:errs.append('final_api_body'+str(c['id']))
        for c in roster:
            api_checks['nativeDeathCounters']+=1
            if sum(d['id']==c for d in g['deaths'])!=finalBy[c]['kda'][1]:errs.append('native_death_count'+str(c))
        last=g['rounds'][-1];finalscore=[last['score'][side]+sum(x['delta'][side]for x in g['submissions']if x['seq']>last['seq'])for side in [0,1]]
        for side,label in enumerate(['a','b']):
            if api:
                z=next(x for x in api['teams']if x['team']==side);score=z['submittedGems'];draft=z.get('draftPicks')
            else:
                z=next((x for x in r['game'].get('sides',[])if x['side']==label),None)
                if z is None or z['teamId']!=r['teams'][label]['teamId']:errs.append('summary_team'+label)
                score=z.get('score')if z else None;draft=z.get('draft')if z else None
            if score is not None:
                api_checks['score']+=1
                if score!=finalscore[side]:errs.append('summary_score'+label)
            if draft:
                api_checks['draft']+=1
                if list(map(int,draft))!=g['drafts'][side]:errs.append('summary_draft'+label)
        for x in g['actions']:acts[(x['r'],x['actor'])].append(x)
        apiBy={c['champion']:c for c in api['champions']}if api else{};ranks=[rank[t['teamId']]['rank']for t in r['teams'].values()];deathseq=defaultdict(set)
        for d in g['deaths']:deathseq[d['seq']].add(d['id'])
        linkedpairs=[{c['id']for c in roster.values()if c['team']==side and c['type']in[3,4]}for side in [0,1]]
        metas={}
        for side in [0,1]:
            t=r['teams']['a'if side==0 else'b'];rr=rank[t['teamId']]
            metas[side]={'match_id':mid,'raw_sha256':r['raw_sha256'],'patch':patch,'replay_format':fmt,'engine_sha256':g['engine_sha256'],'apiValidationScope':api_checks['scope'],'map':r['map'],'kind':r['kind'],'match_kind':r['kind'],'created_at':r['created_at'],'side':side,'teamId':t['teamId'],'team':rr['name'],'rank':rr['rank'],'rankKnown':rr.get('rankKnown',True),'rankDisplay':str(rr['rank'])if rr.get('rankKnown',True)else'unknown','top4_h2h':max(ranks)<=4,'latest_slice':r['raw_sha256']in latest,'draftSlots':g['draftCounts'][side],'rosterBodies':sum(c['team']==side for c in roster.values()),'rounds':end_round}
        for window,lo,hi in [('full',1,end_round),('early25_150',25,150)]:
            bs={id:Counter()for id in roster};ts=[Counter(),Counter()];pvp=defaultdict(lambda:defaultdict(lambda:defaultdict(set)));strictpvp=defaultdict(lambda:defaultdict(lambda:defaultdict(set)));recips=defaultdict(lambda:defaultdict(set));strictrecips=defaultdict(lambda:defaultdict(set));damaging=defaultdict(list)
            for d in g['damage']:
                if not lo<=d['r']<=hi:continue
                source=d['source'];sourceid=source.get('id')if source else None;direct=sourceid in roster and d['step'][0]==10 and d['step'][1]in[5,6]and d['step'][2]==1 and d['step'][4]==0
                spellowned=sourceid in roster and d['step'][2]==3
                terminal=set().union(*(pair for pair in linkedpairs if len(pair)==2 and pair<=deathseq[d['seq']]))
                if direct and terminal:
                    bs[sourceid]['directFramesWithLinkedPairTerminalRecipients']+=1
                    if window=='full':keepcat('linked_pair_terminal_frame',sum(z[3]for z in d['losses']if z[0]==1 and z[1]in terminal),metas[teams[sourceid]],round=d['r'],actor=sourceid,input=d['input'],seq=d['seq'],terminal_pair=sorted(terminal),losses=d['losses'])
                for loss in d['losses']:
                    kind,target,sideTarget,amount=loss[:4]
                    if kind!=1:continue
                    if target in roster:bs[target]['allFrameHpLoss']+=amount
                    if sourceid in roster and teams[sourceid]!=sideTarget:
                        cat='directFrame'if direct else'spellOwnedOtherFrame'if spellowned else'otherChampionAssociatedFrame'
                        bs[sourceid][cat+'EnemyHpLoss']+=amount
                        if target in roster:bs[target][cat+'IncomingHpLoss']+=amount
                        if direct:
                            pvp[teams[sourceid]][d['r']][target].add(sourceid);recips[sourceid][d['r']].add(target);damaging[(d['r'],sourceid)].append(d['seq'])
                            if target in terminal:bs[sourceid]['directFrameLinkedPairTerminalHpLoss']+=amount
                            else:
                                bs[sourceid]['directFrameEnemyHpLossExcludingLinkedPairTerminal']+=amount;strictpvp[teams[sourceid]][d['r']][target].add(sourceid);strictrecips[sourceid][d['r']].add(target)
                    elif target in roster:
                        bs[target]['neutralFriendlyUnknownHpLoss']+=amount
                        if direct and target==sourceid:bs[target]['ownAttackCastFrameSelfHpLoss']+=amount
            for side in [0,1]:
                for rnd,targets in pvp[side].items():
                    ts[side]['pvpTeamRounds']+=1;actors=set().union(*targets.values())
                    if len(actors)>=2:ts[side]['multiAttackerPvpTeamRounds']+=1
                    shared=[target for target,ac in targets.items()if len(ac)>=2]
                    if shared:ts[side]['sharedRecipientPvpTeamRounds']+=1
                    for target in shared:
                        if window=='full':keepcat('shared_recipient',len(targets[target])*100,metas[side],round=rnd,target=target,actors=sorted(targets[target]))
                for rnd,targets in strictpvp[side].items():
                    ts[side]['strictPvpTeamRounds']+=1;actors=set().union(*targets.values())
                    if len(actors)>=2:ts[side]['strictMultiAttackerPvpTeamRounds']+=1
                    if any(len(ac)>=2 for ac in targets.values()):ts[side]['strictSharedRecipientPvpTeamRounds']+=1
            for id,rs in recips.items():
                bs[id]['pvpDamagingActorRounds']+=len(rs)
                for rnd,targets in rs.items():
                    if rnd-1 in rs:
                        bs[id]['consecutivePvpActorRoundPairs']+=1
                        if targets&rs[rnd-1]:bs[id]['overlappingRecipientPairs']+=1
            for id,rs in strictrecips.items():
                bs[id]['strictPvpDamagingActorRounds']+=len(rs)
                for rnd,targets in rs.items():
                    if rnd-1 in rs:
                        bs[id]['strictConsecutivePvpActorRoundPairs']+=1
                        if targets&rs[rnd-1]:bs[id]['strictOverlappingRecipientPairs']+=1
            for w in g['rounds']:
                if not lo<=w['r']<=hi:continue
                for c in w['c']:
                    b=bs[c[0]];b['sampledBodyRounds']+=1
                    if not c[5]:b['deadBodyRounds']+=1;continue
                    b['aliveBodyRounds']+=1
                    if inside(c,spawns[teams[c[0]]]):b['spawnBodyRounds']+=1
                    else:
                        b['fieldBodyRounds']+=1
                        if c[9]:b['channelFieldBodyRounds']+=1
                        if c[11]==0 or c[12]==0:b['fieldSnapshotAtLeastOneZeroCooldown']+=1
            for (rnd,id),v in turns.items():
                if not lo<=rnd<=hi:continue
                b=bs[id];b['ownerTurnStarts']+=1
                if not v[3]:b['deadOwnerTurnStarts']+=1;continue
                if v[4]:b['spawnOwnerTurnStarts']+=1;continue
                b['fieldOwnerTurnStarts']+=1;commands=acts[(rnd,id)];commands=sorted(commands,key=lambda x:x['seq']);bykind=defaultdict(list)
                for x in commands:bykind[x['kind']].append(x)
                move=[x for x in bykind[4]if x['before'][1:3]!=x['after'][1:3]];casts=bykind[6];attack=bykind[5];dseq=damaging[(rnd,id)];offensive=[x for x in casts if x['abilityType']in[2,3,4]]
                hp=v[7]/max(v[8],1);contact=v[13]>0
                for rad,ei in [(3,11),(6,13),(8,15)]:
                    if v[ei]:b[f'contact{rad}OwnerTurnStarts']+=1
                if contact:
                    b['contactAllies6Sum']+=v[12];b['contactEnemies6Sum']+=v[13]
                    if v[12]>=2:b['contactWithAlly6OwnerTurns']+=1
                    for threshold in [25,35,50]:
                        if hp*100<threshold:b[f'contactBelow{threshold}HpOwnerTurns']+=1
                    if move:b['contactWithOrdinaryMoveTurns']+=1
                    if attack:b['contactWithAttackCommandTurns']+=1
                    if casts:b['contactWithCastCommandTurns']+=1
                    for typename,types in [('Offensive',[2,3,4]),('Damage',[2,3]),('Control',[4]),('Dash',[6]),('Reset',[1]),('Heal',[5]),('Shield',[7])]:
                        if any(x['abilityType']in types for x in casts):b['contactWith'+typename+'CastCommandTurns']+=1
                    if dseq:b['contactWithEnemyHpLossTurns']+=1
                    if not(move or attack or casts):b['contactNoMoveAttackCastTurns']+=1
                    if bykind[11]:b['contactWithRecallCommandTurns']+=1
                    if move and not dseq:
                        b['contactMoveNoEnemyHpLossTurns']+=1;follow=[turns.get((rnd+j,id))for j in [1,2,3]]
                        if rnd+3>hi or any(x is None for x in follow):b['contactExitRightCensoredTurns']+=1
                        else:
                            b['contactExitThreeTurnFollowups']+=1
                            if any(not x[3]for x in follow):b['contactExitDeathWithin3']+=1
                            z=follow[-1]
                            if z[3]and z[4]:b['contactExitSpawnAt3']+=1
                            if z[3]and not z[4]and not z[13]:
                                b['contactExitAliveFieldNoEnemy6At3']+=1
                                if window=='full':keepcat('geometric_contact_exit',10+(50 if hp<.5 else 0),metas[teams[id]],round=rnd,actor=id,followup_round=rnd+3,start_hp_fraction=hp,start_counts=v[10:16],end_counts=z[10:16],inputs=[x['input']for x in move])
                if move and attack:
                    b['moveAndAttackTurns']+=1
                    if move[0]['seq']<attack[0]['seq']:b['moveBeforeFirstAttackTurns']+=1
                    else:b['firstAttackBeforeMoveTurns']+=1
                if move and casts:
                    b['moveAndCastTurns']+=1
                    if move[0]['seq']<casts[0]['seq']:b['moveBeforeFirstCastTurns']+=1
                    else:b['firstCastBeforeMoveTurns']+=1
                if move and offensive:
                    b['moveAndOffensiveCastTurns']+=1
                    if move[0]['seq']<offensive[0]['seq']:b['moveBeforeFirstOffensiveCastTurns']+=1
                    else:b['firstOffensiveCastBeforeMoveTurns']+=1
                    if window=='full'and contact:keepcat('offensive_cast_move_order',20+10*len(offensive),metas[teams[id]],round=rnd,actor=id,inputs=[x['input']for x in commands],kinds=[x['kind']for x in commands],abilityTypes=[x['abilityType']for x in commands])
                if len(attack)>=2:
                    b['multipleAttackCommandTurns']+=1
                    if any(x['abilityType']==1 for x in casts):b['multipleAttackAndResetCastTurns']+=1
                    if window=='full'and contact:keepcat('multiple_attacks',len(attack)*20,metas[teams[id]],round=rnd,actor=id,inputs=[x['input']for x in commands],kinds=[x['kind']for x in commands])
                if dseq and move:
                    b['moveAndEnemyHpLossTurns']+=1
                    if move[0]['seq']<min(dseq):
                        b['moveBeforeEnemyHpLossTurns']+=1
                        if window=='full':keepcat('move_then_enemy_loss',len(dseq)*10+(30 if casts else 0),metas[teams[id]],round=rnd,actor=id,inputs=[x['input']for x in commands],kinds=[x['kind']for x in commands],targets=sorted(recips[id][rnd]))
                    else:b['enemyHpLossBeforeMoveTurns']+=1
            for x in g['actions']:
                if not lo<=x['r']<=hi:continue
                id=x['actor'];b=bs[id];kind=x['kind'];b['recordedCommands']+=1
                if kind not in [4,5,6]:continue
                cat={4:'move',5:'attack',6:'cast'}[kind];b[cat+'Commands']+=1
                if x['near'][3]>0:b[cat+'CommandsAtGeometricContact6']+=1
                if kind==4 and x['before'][1:3]!=x['after'][1:3]:b['ordinaryDisplacements']+=1
                if kind==6:
                    b['castType'+str(x['abilityType'])+'Commands']+=1;b['castSlot'+str(x['slot'])+'Commands']+=1
                    if x['near'][3]>0:b['castType'+str(x['abilityType'])+'CommandsAtGeometricContact6']+=1
                    if x['before'][1:3]!=x['after'][1:3]:b['castActorDisplacements']+=1
                enemies=[z for z in x['losses']if z[0]==1 and z[2]!=teams[id]];camps=[z for z in x['losses']if z[0]==2]
                if enemies:b[cat+'CommandsWithEnemyHpLoss']+=1
                if camps:b[cat+'CommandsWithCampHpLoss']+=1
                if not enemies and not camps:b[cat+'CommandsWithoutEnemyOrCampHpLoss']+=1
                if len(enemies)>=2:
                    b[cat+'MultiEnemyRecipientCommands']+=1
                    if window=='full':keepcat('multi_recipient_frame',len(enemies)*100+sum(z[3]for z in enemies)/10,metas[teams[id]],round=x['r'],actor=id,input=x['input'],seq=x['seq'],command_kind=kind,slot=x['slot'],abilityType=x['abilityType'],losses=enemies)
            for d in g['deaths']:
                if not lo<=d['r']<=hi:continue
                id=d['id'];b=bs[id];b['observedDeaths']+=1
                prior=[v for v in g['turns']if v[2]==id and v[1]<=d['input']and v[0]<=d['r']]
                if not prior:continue
                v=prior[-1]
                if d['r']-v[0]>1:b['deathsPriorTurnOlderThan1Round']+=1;continue
                b['deathsWithRecentOwnerTurnContext']+=1
                if v[3]and not v[4]:
                    b['deathsPriorFieldOwnerTurn']+=1
                    if v[13]:b['deathsPriorContact6OwnerTurn']+=1
                    if v[12]>=2:b['deathsPriorAlly6OwnerTurn']+=1
                    if v[12]==1:b['deathsPriorNoAlly6OwnerTurn']+=1
                    if v[12]<v[13]:b['deathsPriorOutnumbered6OwnerTurn']+=1
                if window=='full':keepcat('death_after_contact',d['gems']+100*(v[12]>=2),metas[teams[id]],round=d['r'],actor=id,input=d['input'],seq=d['seq'],gems=d['gems'],prior_turn=v)
            complete=sum(25<=w['r']<=150 for w in g['rounds'])==126
            for id,b in bs.items():
                side=teams[id];base={**metas[side],'window':window,'fullEarlyWindow':complete,'worldRoundSamples':sum(lo<=w['r']<=hi for w in g['rounds'])};champ=roster[id];ar=next(c[13]for w in g['rounds']for c in w['c']if c[0]==id)
                if window=='full':
                    b['nativeKills'],b['nativeDeaths'],b['nativeAssists']=finalBy[id]['kda'];b['nativeKdaBodyAppearances']=1;b['apiCounterBodyAppearances']=1 if api else 0
                    if api:
                        for field in ['kills','deaths','assists','championDamageDone','championDamageTaken','monsterDamageDone','monsterDamageTaken','healingDone','shieldingDone']:b['api'+field[0].upper()+field[1:]]=apiBy[id][field]
                row={**base,'body':id,'type':champ['type'],'champion':champ['name'],'attackRange':ar,'rangeRole':'melee'if ar<=1 else'ranged','bodyAppearances':1,'apiFullGameCountersApplicable':window=='full','apiFullGameCountersAvailable':bool(api)and window=='full',**dict(b)};bodies.append(row);ts[side].update(b)
            for side in [0,1]:games.append({**metas[side],'window':window,'fullEarlyWindow':complete,'worldRoundSamples':sum(lo<=w['r']<=hi for w in g['rounds']),'bodyAppearances':metas[side]['rosterBodies'],**dict(ts[side])})
        audit.append({'id':mid,'raw_sha256':r['raw_sha256'],'patch':patch,'replay_format':fmt,'header_hex':raw[:14].hex(),'engine_sha256':g['engine_sha256'],'trace_sha256':hashlib.sha256(blob).hexdigest(),'trace_bytes':len(blob),'rounds':len(g['rounds']),'owner_turns':len(g['turns']),'commands':len(g['actions']),'damage_frames':len(g['damage']),'deaths':len(g['deaths']),'api_checks':api_checks,'decoder_api_checks':g.get('apiFinalChecks'),'apiFinalErrors':g['apiFinalErrors'],'errors':errs})
        errors.extend({'id':mid,'kind':e}for e in errs)
        if ix%25==0:print(json.dumps({'worker':a.worker,'processed':ix+1,'id':mid,'errors':len(errors)}),flush=True)
    except Exception as e:errors.append({'id':r['id'],'exception':repr(e)});raise
jsonwrite(a.out_dir/'parts'/f'worker-{a.worker}.json',{'games':games,'bodies':bodies,'audit':audit,'errors':errors,'candidates':dict(candidates)})
