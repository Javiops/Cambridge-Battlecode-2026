# Descriptive combat trace findings

Current ladder16Oct2026 11:39UTC / full history patch-stratified / cutoff16Oct11:41UTC

This pass covers **2,498 exact raw-SHA-deduplicated trajectories**. The primary slice is top-four head-to-head under this pass's frozen ladder; the word “top” does not establish later live ranking. Native command order and stable HP-loss recipient IDs are observed. The data does not reveal a private primary target, rejected calls, owner-turn action permissions, exact personal visibility, or counterfactual outcomes. No bot execution or new replay decoding was performed.

Primary tables below use **92 current-ladder head-to-head trajectories on patch 0.0.2**. All-patch current-ranked H2H contains 893 streams in this pass; that wider history is shown as sensitivity, not silently treated as one mechanics version. Observed patch counts: `{'0.0.2': 730, '0.0.1': 1768}`. Full API champion damage counters are reported only when present; public-summary round/score/draft checks and native-final death-counter checks have separate availability.

Validation coverage: 2498/2498 API round checks; 2126/4996 available side-score checks; 2126/4996 available side-draft checks; 3296 external API champion-counter checks; 25443 native final-body death-counter checks. Missing public fields are not counted as validated.

## Contact exposure, recorded actions and recipient persistence

Each fraction below prints its numerator and denominator. Contact means an alive field owner-turn start with an enemy alive outside its own spawn within Chebyshev six. A recorded cast or ordinary displacement during that turn is not proof that it targeted that enemy. The enemy-HP-loss column uses direct native attack/cast-frame associations; a secondary effect can be among the recipients. These denominators are geometric exposures, not available-action opportunities.

| Team | Streams | Body appearances | Cast/contact starts | Move/contact starts | Enemy HP loss/contact starts | Recipient overlap/consecutive PvP actor-round pairs | Shared recipient/multi-attacker team-rounds |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Fish | 41 | 219 | 4,445/29,481 (15.08%) | 19,537/29,481 (66.27%) | 4,589/29,481 (15.57%) | 1,610/1,724 (93.39%) | 599/713 (84.01%) |
| Sneaky | 47 | 241 | 4,126/30,925 (13.34%) | 18,964/30,925 (61.32%) | 4,382/30,925 (14.17%) | 1,467/1,589 (92.32%) | 341/480 (71.04%) |
| Univardisty | 45 | 242 | 3,936/29,544 (13.32%) | 22,320/29,544 (75.55%) | 3,448/29,544 (11.67%) | 1,126/1,172 (96.08%) | 364/441 (82.54%) |
| procless | 51 | 272 | 3,355/22,501 (14.91%) | 13,555/22,501 (60.24%) | 3,330/22,501 (14.80%) | 1,367/1,433 (95.39%) | 217/299 (72.58%) |

All-ten context:

| Team | Streams | Body appearances | Cast/contact starts | Move/contact starts | Enemy HP loss/contact starts | Recipient overlap/consecutive PvP actor-round pairs | Shared recipient/multi-attacker team-rounds |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Fish | 135 | 715 | 13,121/84,365 (15.55%) | 56,364/84,365 (66.81%) | 13,736/84,365 (16.28%) | 4,983/5,412 (92.07%) | 1,907/2,272 (83.93%) |
| Sneaky | 151 | 779 | 12,298/88,982 (13.82%) | 55,506/88,982 (62.38%) | 13,645/88,982 (15.33%) | 4,687/5,032 (93.14%) | 1,270/1,668 (76.14%) |
| Univardisty | 138 | 738 | 12,439/90,882 (13.69%) | 66,828/90,882 (73.53%) | 11,398/90,882 (12.54%) | 3,858/4,052 (95.21%) | 1,256/1,535 (81.82%) |
| procless | 131 | 698 | 9,397/63,561 (14.78%) | 37,360/63,561 (58.78%) | 9,822/63,561 (15.45%) | 4,630/4,837 (95.72%) | 746/1,007 (74.08%) |
| Mite | 163 | 873 | 13,514/93,041 (14.52%) | 59,244/93,041 (63.68%) | 12,284/93,041 (13.20%) | 4,391/4,723 (92.97%) | 1,388/1,677 (82.77%) |
| hello | 118 | 628 | 13,810/96,970 (14.24%) | 64,632/96,970 (66.65%) | 17,540/96,970 (18.09%) | 8,780/9,563 (91.81%) | 2,815/3,358 (83.83%) |
| Shawn | 173 | 895 | 16,467/128,196 (12.85%) | 81,255/128,196 (63.38%) | 19,494/128,196 (15.21%) | 7,464/8,067 (92.53%) | 2,803/3,360 (83.42%) |
| VeryGood | 222 | 1200 | 19,078/157,417 (12.12%) | 94,945/157,417 (60.31%) | 18,272/157,417 (11.61%) | 6,352/6,757 (94.01%) | 2,487/2,871 (86.62%) |
| ❤️Quantom❤️ | 106 | 519 | 7,655/52,686 (14.53%) | 33,996/52,686 (64.53%) | 8,958/52,686 (17.00%) | 4,615/4,860 (94.96%) | 829/1,099 (75.43%) |
| geese geese go | 123 | 637 | 9,421/69,267 (13.60%) | 45,139/69,267 (65.17%) | 11,656/69,267 (16.83%) | 5,948/6,324 (94.05%) | 1,731/2,159 (80.18%) |

Cast roles during the same geometric contact denominator (ability classes, not recovered intended targets):

| Team | Damage/control-class cast/contact | Damage-class2/3 cast/contact | CC-class4 cast/contact | Dash cast/contact | Reset cast/contact | Heal / shield cast turns |
| --- | --- | --- | --- | --- | --- | --- |
| Fish | 3,070/29,481 (10.41%) | 1,824/29,481 (6.19%) | 1,246/29,481 (4.23%) | 681/29,481 (2.31%) | 519/29,481 (1.76%) | 0 / 175 |
| Sneaky | 2,639/30,925 (8.53%) | 1,599/30,925 (5.17%) | 1,040/30,925 (3.36%) | 536/30,925 (1.73%) | 671/30,925 (2.17%) | 61 / 219 |
| Univardisty | 2,505/29,544 (8.48%) | 1,236/29,544 (4.18%) | 1,269/29,544 (4.30%) | 516/29,544 (1.75%) | 531/29,544 (1.80%) | 0 / 384 |
| procless | 1,844/22,501 (8.20%) | 1,265/22,501 (5.62%) | 579/22,501 (2.57%) | 711/22,501 (3.16%) | 499/22,501 (2.22%) | 0 / 301 |

Native numeric ability types are retained:1attack reset,2targeted damage,3ground damage,4CC,5heal,6dash,7shield. Type4 can itself damage; its counts are not all control effects because Marcella enhanced reset is type1 and its next basic stuns. A damage/CC-class spell while geometric enemy contact exists can still target a camp; target intent is absent. Cast classes overlap within a turn, so their turn counts must not be added as mutually exclusive shares.

Persistence requires the same actor to have opposing HP-loss recipients in consecutive world rounds and the sets to intersect. Shared recipients require at least two same-team actors to have a common opposing recipient in one world round. Neither statistic proves shared intention; commands are sequential and recipient sets can contain AoE/splash effects.

Conservative linked-life sensitivity:

| Team | Linked-pair terminal HP loss / all opposing command-frame HP loss | Recipient overlap excluding paired terminal events | Shared recipient excluding paired terminal events | Actor self-HP loss in own attack/cast frames |
| --- | --- | --- | --- | --- |
| Fish | 118,579.45/902,907.72 (13.13%) | 1,588/1,699 (93.47%) | 589/700 (84.14%) | 50549.4 |
| Sneaky | 104,722.17/876,233.48 (11.95%) | 1,445/1,562 (92.51%) | 330/467 (70.66%) | 44539.3 |
| Univardisty | 75,500.25/694,756.92 (10.87%) | 1,109/1,154 (96.10%) | 358/433 (82.68%) | 32440.45 |
| procless | 36,635.88/490,602.20 (7.47%) | 1,355/1,420 (95.42%) | 213/295 (72.20%) | 39471.3 |

When Cassi and Issac both die at exactly one native seq, both paired terminal recipients are removed from the strict recipient analysis. This intentionally also removes the directly struck body because these compressed frames do not always identify which one it was. It does not remove ordinary nonlethal damage to either body. Actor self-loss during an own attack/cast can include Ren retaliation, including shielded/lethal exchanges; it is excluded from outgoing opposing-recipient totals and is not attributed to an intended outgoing target.

## Action order by range role

| Team / role | Body appearances | Move before first attack / field turns with both | Move before first cast / field turns with both | Move before enemy HP loss / field turns with move + enemy loss | Multiple attack-command turns |
| --- | --- | --- | --- | --- | --- |
| Fish / melee | 126 | 2,774/3,336 (83.15%) | 1,037/4,011 (25.85%) | 895/1,303 (68.69%) | 1565 |
| Fish / ranged | 93 | 174/174 (100.00%) | 543/843 (64.41%) | 47/47 (100.00%) | 130 |
| Sneaky / melee | 115 | 2,585/3,019 (85.62%) | 1,200/3,684 (32.57%) | 662/1,062 (62.34%) | 1623 |
| Sneaky / ranged | 126 | 0/0 (NA) | 102/175 (58.29%) | 0/0 (NA) | 775 |
| Univardisty / melee | 109 | 1,980/3,199 (61.89%) | 1,139/3,791 (30.04%) | 462/1,012 (45.65%) | 1299 |
| Univardisty / ranged | 133 | 416/416 (100.00%) | 997/1,305 (76.40%) | 120/120 (100.00%) | 524 |
| procless / melee | 164 | 2,610/4,298 (60.73%) | 1,498/4,920 (30.45%) | 621/1,155 (53.77%) | 2326 |
| procless / ranged | 108 | 44/44 (100.00%) | 44/140 (31.43%) | 5/5 (100.00%) | 54 |

| Team / role | Move before first damage/control cast / field turns with both | Multiple attack commands with reset cast / multiple attack-command turns |
| --- | --- | --- |
| Fish / melee | 0/0 (NA) | 1,565/1,565 (100.00%) |
| Fish / ranged | 369/669 (55.16%) | 130/130 (100.00%) |
| Sneaky / melee | 0/0 (NA) | 1,623/1,623 (100.00%) |
| Sneaky / ranged | 12/85 (14.12%) | 775/775 (100.00%) |
| Univardisty / melee | 0/0 (NA) | 1,299/1,299 (100.00%) |
| Univardisty / ranged | 579/887 (65.28%) | 524/524 (100.00%) |
| procless / melee | 0/0 (NA) | 2,326/2,326 (100.00%) |
| procless / ranged | 0/96 (0.00%) | 54/54 (100.00%) |

Ordering rows condition on a body alive outside spawn at its owner-turn start and on the listed actions actually being retained. They are not measures of optimal sequencing. A move before an HP-loss frame demonstrates access in that observed sequence, without showing whether standing still could have achieved the same result. Multiple attacks can involve resets, targets or native effects; selected source-bound episodes distinguish them.

## HP-loss associations and death context

| Team | Attack/cast-frame opposing HP loss | Spell-owned other-frame opposing HP loss | API champion damage done / taken | Death preceded by nearby ally / recent prior-field contexts | Death preceded outnumbered / recent prior-field contexts |
| --- | --- | --- | --- | --- | --- |
| Fish | 902907.72 | 0 | unavailable (0/219 bodies) | 201/312 (64.42%) | 81/312 (25.96%) |
| Sneaky | 876233.48 | 0 | unavailable (0/241 bodies) | 235/325 (72.31%) | 71/325 (21.85%) |
| Univardisty | 694756.92 | 0 | unavailable (0/242 bodies) | 267/401 (66.58%) | 124/401 (30.92%) |
| procless | 490602.2 | 0 | unavailable (0/272 bodies) | 169/361 (46.81%) | 152/361 (42.11%) |

Direct and spell-owned categories describe the native frame/source association, not direct-versus-splash damage. API damage counts may include shield or uncapped damage; frame HP loss is separately measured. Death context uses the latest own turn start at/before the death input, only in the same or previous world round. Nearby allies may be unable to act and may not see the enemy; a death with help nearby is not proof of a failed coordinated plan.

## Bounded contact exits

| Team | Alive field / no enemy≤6 at third future own start | Death within three starts | Spawn at third start | Right-censored candidates |
| --- | --- | --- | --- | --- |
| Fish | 3,976/18,126 (21.94%) | 355/18,126 (1.96%) | 26/18,126 (0.14%) | 61 |
| Sneaky | 4,121/17,845 (23.09%) | 438/17,845 (2.45%) | 33/17,845 (0.18%) | 57 |
| Univardisty | 3,726/21,104 (17.66%) | 644/21,104 (3.05%) | 60/21,104 (0.28%) | 84 |
| procless | 2,956/12,350 (23.94%) | 477/12,350 (3.86%) | 78/12,350 (0.63%) | 45 |

The anchor is a contact-six owner-turn with ordinary displacement and no direct enemy-HP-loss association. Follow-up requires all three consecutive future owner starts and the endpoint inside the window. Counts can overlap when several adjacent turns qualify. These are geometric continuations, not a retreat-success rate, escape intent, or proof that the original pursuer stopped following.

## Recent and early-window sensitivity

All recorded patches, frozen-rank H2H:

| Team | Streams | Contact owner starts | Cast/contact | Move/contact | Enemy HP loss/contact | Recipient overlap/consecutive PvP pairs |
| --- | --- | --- | --- | --- | --- | --- |
| Fish | 452 | 230506 | 33,391/230,506 (14.49%) | 160,744/230,506 (69.74%) | 35,385/230,506 (15.35%) | 13,501/14,375 (93.92%) |
| Sneaky | 362 | 173649 | 22,906/173,649 (13.19%) | 110,543/173,649 (63.66%) | 24,285/173,649 (13.99%) | 8,089/8,687 (93.12%) |
| Univardisty | 444 | 215542 | 30,825/215,542 (14.30%) | 155,707/215,542 (72.24%) | 33,115/215,542 (15.36%) | 13,047/13,667 (95.46%) |
| procless | 528 | 204921 | 29,085/204,921 (14.19%) | 123,963/204,921 (60.49%) | 30,515/204,921 (14.89%) | 12,991/13,628 (95.33%) |

Latest-two-per-pair/map/kind H2H, all recorded patches:

| Team | Streams | Contact owner starts | Cast/contact | Move/contact | Enemy HP loss/contact | Recipient overlap/consecutive PvP pairs |
| --- | --- | --- | --- | --- | --- | --- |
| Fish | 112 | 63503 | 9,417/63,503 (14.83%) | 43,363/63,503 (68.28%) | 9,601/63,503 (15.12%) | 3,471/3,679 (94.35%) |
| Sneaky | 128 | 67438 | 9,294/67,438 (13.78%) | 42,801/67,438 (63.47%) | 10,027/67,438 (14.87%) | 3,337/3,593 (92.88%) |
| Univardisty | 122 | 82310 | 11,260/82,310 (13.68%) | 60,976/82,310 (74.08%) | 10,551/82,310 (12.82%) | 3,712/3,882 (95.62%) |
| procless | 142 | 65740 | 9,670/65,740 (14.71%) | 39,891/65,740 (60.68%) | 9,796/65,740 (14.90%) | 4,091/4,271 (95.79%) |

Latest-two H2H restricted to patch0.0.2:

| Team | Streams | Contact owner starts | Cast/contact | Move/contact | Enemy HP loss/contact | Recipient overlap/consecutive PvP pairs |
| --- | --- | --- | --- | --- | --- | --- |
| Fish | 40 | 26814 | 4,061/26,814 (15.15%) | 17,647/26,814 (65.81%) | 4,232/26,814 (15.78%) | 1,506/1,613 (93.37%) |
| Sneaky | 46 | 28281 | 3,837/28,281 (13.57%) | 17,371/28,281 (61.42%) | 4,109/28,281 (14.53%) | 1,381/1,496 (92.31%) |
| Univardisty | 45 | 29544 | 3,936/29,544 (13.32%) | 22,320/29,544 (75.55%) | 3,448/29,544 (11.67%) | 1,126/1,172 (96.08%) |
| procless | 51 | 22501 | 3,355/22,501 (14.91%) | 13,555/22,501 (60.24%) | 3,330/22,501 (14.80%) | 1,367/1,433 (95.39%) |

Primary H2H, available R25–150:

| Team | Streams | Contact owner starts | Cast/contact | Move/contact | Enemy HP loss/contact | Recipient overlap/consecutive PvP pairs |
| --- | --- | --- | --- | --- | --- | --- |
| Fish | 41 | 5026 | 818/5,026 (16.28%) | 3,174/5,026 (63.15%) | 866/5,026 (17.23%) | 326/348 (93.68%) |
| Sneaky | 47 | 4663 | 697/4,663 (14.95%) | 2,757/4,663 (59.13%) | 782/4,663 (16.77%) | 275/315 (87.30%) |
| Univardisty | 45 | 5042 | 723/5,042 (14.34%) | 3,785/5,042 (75.07%) | 666/5,042 (13.21%) | 211/225 (93.78%) |
| procless | 51 | 4015 | 629/4,015 (15.67%) | 2,327/4,015 (57.96%) | 622/4,015 (15.49%) | 260/277 (93.86%) |

Latest H2H, available R25–150:

| Team | Streams | Contact owner starts | Cast/contact | Move/contact | Enemy HP loss/contact | Recipient overlap/consecutive PvP pairs |
| --- | --- | --- | --- | --- | --- | --- |
| Fish | 112 | 12997 | 2,047/12,997 (15.75%) | 8,558/12,997 (65.85%) | 2,153/12,997 (16.57%) | 839/888 (94.48%) |
| Sneaky | 128 | 12267 | 1,857/12,267 (15.14%) | 7,622/12,267 (62.13%) | 2,080/12,267 (16.96%) | 726/815 (89.08%) |
| Univardisty | 122 | 15892 | 2,287/15,892 (14.39%) | 11,533/15,892 (72.57%) | 2,285/15,892 (14.38%) | 841/892 (94.28%) |
| procless | 142 | 12487 | 1,921/12,487 (15.38%) | 7,563/12,487 (60.57%) | 1,981/12,487 (15.86%) | 835/881 (94.78%) |

Latest selection is outcome-independent, using the latest two source IDs in each unordered pair/map/kind stratum before raw deduplication. It is a chronology sensitivity, not a verified bot-version comparison. Available early windows are right-censored by game end; complete126-round streams are separately counted in summary/CSV.

## Map and champion conditional tables

| Map / team | Streams | Contact owner starts | Cast/contact | Move/contact | Enemy HP loss/contact |
| --- | --- | --- | --- | --- | --- |
| ambush / Fish | 2 | 129 | 9/129 (6.98%) | 97/129 (75.19%) | 5/129 (3.88%) |
| ambush / Sneaky | 3 | 144 | 20/144 (13.89%) | 68/144 (47.22%) | 12/144 (8.33%) |
| ambush / Univardisty | 4 | 269 | 25/269 (9.29%) | 136/269 (50.56%) | 24/269 (8.92%) |
| ambush / procless | 5 | 124 | 17/124 (13.71%) | 73/124 (58.87%) | 17/124 (13.71%) |
| collision / Fish | 2 | 1324 | 203/1,324 (15.33%) | 847/1,324 (63.97%) | 241/1,324 (18.20%) |
| collision / Sneaky | 2 | 1057 | 140/1,057 (13.25%) | 698/1,057 (66.04%) | 189/1,057 (17.88%) |
| collision / procless | 2 | 1107 | 172/1,107 (15.54%) | 690/1,107 (62.33%) | 177/1,107 (15.99%) |
| contest / Fish | 4 | 10214 | 1,572/10,214 (15.39%) | 6,426/10,214 (62.91%) | 1,646/10,214 (16.12%) |
| contest / Sneaky | 4 | 11229 | 1,412/11,229 (12.57%) | 6,997/11,229 (62.31%) | 1,454/11,229 (12.95%) |
| contest / Univardisty | 3 | 8419 | 1,076/8,419 (12.78%) | 6,627/8,419 (78.71%) | 871/8,419 (10.35%) |
| contest / procless | 1 | 2101 | 315/2,101 (14.99%) | 1,320/2,101 (62.83%) | 304/2,101 (14.47%) |
| corners / Fish | 3 | 3979 | 500/3,979 (12.57%) | 3,057/3,979 (76.83%) | 452/3,979 (11.36%) |
| corners / Sneaky | 4 | 4360 | 448/4,360 (10.28%) | 2,365/4,360 (54.24%) | 309/4,360 (7.09%) |
| corners / Univardisty | 4 | 3042 | 368/3,042 (12.10%) | 2,580/3,042 (84.81%) | 226/3,042 (7.43%) |
| corners / procless | 3 | 1234 | 169/1,234 (13.70%) | 703/1,234 (56.97%) | 188/1,234 (15.24%) |
| eight / Fish | 1 | 944 | 149/944 (15.78%) | 702/944 (74.36%) | 126/944 (13.35%) |
| eight / Sneaky | 1 | 1301 | 183/1,301 (14.07%) | 847/1,301 (65.10%) | 195/1,301 (14.99%) |
| eight / Univardisty | 2 | 1908 | 248/1,908 (13.00%) | 1,477/1,908 (77.41%) | 184/1,908 (9.64%) |
| eight / procless | 2 | 1943 | 297/1,943 (15.29%) | 1,101/1,943 (56.66%) | 264/1,943 (13.59%) |
| elkring / Fish | 1 | 623 | 114/623 (18.30%) | 416/623 (66.77%) | 147/623 (23.60%) |
| elkring / Sneaky | 1 | 499 | 71/499 (14.23%) | 322/499 (64.53%) | 79/499 (15.83%) |
| elkring / Univardisty | 2 | 1773 | 232/1,773 (13.09%) | 1,461/1,773 (82.40%) | 185/1,773 (10.43%) |
| elkring / procless | 4 | 2545 | 349/2,545 (13.71%) | 1,559/2,545 (61.26%) | 248/2,545 (9.74%) |
| expanse / Fish | 3 | 0 | 0/0 (NA) | 0/0 (NA) | 0/0 (NA) |
| expanse / Sneaky | 1 | 0 | 0/0 (NA) | 0/0 (NA) | 0/0 (NA) |
| expanse / Univardisty | 2 | 0 | 0/0 (NA) | 0/0 (NA) | 0/0 (NA) |
| expanse / procless | 2 | 0 | 0/0 (NA) | 0/0 (NA) | 0/0 (NA) |
| fragment / Fish | 1 | 756 | 122/756 (16.14%) | 538/756 (71.16%) | 127/756 (16.80%) |
| fragment / Sneaky | 3 | 2111 | 322/2,111 (15.25%) | 1,286/2,111 (60.92%) | 394/2,111 (18.66%) |
| fragment / Univardisty | 4 | 2749 | 358/2,749 (13.02%) | 1,818/2,749 (66.13%) | 306/2,749 (11.13%) |
| fragment / procless | 4 | 3047 | 493/3,047 (16.18%) | 1,836/3,047 (60.26%) | 491/3,047 (16.11%) |
| interlock / Fish | 3 | 2048 | 314/2,048 (15.33%) | 1,355/2,048 (66.16%) | 397/2,048 (19.38%) |
| interlock / Sneaky | 3 | 2262 | 363/2,262 (16.05%) | 1,380/2,262 (61.01%) | 430/2,262 (19.01%) |
| interlock / Univardisty | 3 | 2411 | 304/2,411 (12.61%) | 1,657/2,411 (68.73%) | 248/2,411 (10.29%) |
| interlock / procless | 3 | 1852 | 265/1,852 (14.31%) | 1,095/1,852 (59.13%) | 289/1,852 (15.60%) |
| lanes / Fish | 2 | 493 | 70/493 (14.20%) | 336/493 (68.15%) | 65/493 (13.18%) |
| lanes / Sneaky | 3 | 801 | 109/801 (13.61%) | 499/801 (62.30%) | 119/801 (14.86%) |
| lanes / Univardisty | 2 | 213 | 23/213 (10.80%) | 156/213 (73.24%) | 27/213 (12.68%) |
| lanes / procless | 5 | 983 | 139/983 (14.14%) | 561/983 (57.07%) | 132/983 (13.43%) |
| monolith / Fish | 3 | 1369 | 185/1,369 (13.51%) | 920/1,369 (67.20%) | 184/1,369 (13.44%) |
| monolith / Sneaky | 2 | 758 | 97/758 (12.80%) | 524/758 (69.13%) | 83/758 (10.95%) |
| monolith / Univardisty | 3 | 696 | 108/696 (15.52%) | 542/696 (77.87%) | 120/696 (17.24%) |
| monolith / procless | 2 | 676 | 101/676 (14.94%) | 464/676 (68.64%) | 123/676 (18.20%) |
| packs / Fish | 2 | 289 | 51/289 (17.65%) | 191/289 (66.09%) | 59/289 (20.42%) |
| packs / Sneaky | 5 | 1157 | 194/1,157 (16.77%) | 603/1,157 (52.12%) | 202/1,157 (17.46%) |
| packs / Univardisty | 2 | 578 | 86/578 (14.88%) | 387/578 (66.96%) | 80/578 (13.84%) |
| packs / procless | 3 | 975 | 162/975 (16.62%) | 459/975 (47.08%) | 138/975 (14.15%) |
| pilgrimage / Fish | 3 | 1239 | 182/1,239 (14.69%) | 945/1,239 (76.27%) | 199/1,239 (16.06%) |
| pilgrimage / Sneaky | 3 | 892 | 125/892 (14.01%) | 618/892 (69.28%) | 176/892 (19.73%) |
| pilgrimage / Univardisty | 2 | 1718 | 281/1,718 (16.36%) | 1,346/1,718 (78.35%) | 337/1,718 (19.62%) |
| pilgrimage / procless | 4 | 2274 | 346/2,274 (15.22%) | 1,476/2,274 (64.91%) | 332/2,274 (14.60%) |
| rows / Fish | 3 | 0 | 0/0 (NA) | 0/0 (NA) | 0/0 (NA) |
| rows / Sneaky | 4 | 0 | 0/0 (NA) | 0/0 (NA) | 0/0 (NA) |
| rows / Univardisty | 5 | 0 | 0/0 (NA) | 0/0 (NA) | 0/0 (NA) |
| rows / procless | 4 | 0 | 0/0 (NA) | 0/0 (NA) | 0/0 (NA) |
| rushbait_v2 / Fish | 1 | 290 | 42/290 (14.48%) | 191/290 (65.86%) | 33/290 (11.38%) |
| rushbait_v2 / Sneaky | 2 | 956 | 119/956 (12.45%) | 605/956 (63.28%) | 91/956 (9.52%) |
| rushbait_v2 / Univardisty | 3 | 1361 | 163/1,361 (11.98%) | 1,015/1,361 (74.58%) | 124/1,361 (9.11%) |
| rushbait_v2 / procless | 2 | 737 | 85/737 (11.53%) | 468/737 (63.50%) | 82/737 (11.13%) |
| stampede / Fish | 3 | 2345 | 382/2,345 (16.29%) | 1,609/2,345 (68.61%) | 419/2,345 (17.87%) |
| stampede / Sneaky | 4 | 2153 | 332/2,153 (15.42%) | 1,391/2,153 (64.61%) | 416/2,153 (19.32%) |
| stampede / Univardisty | 3 | 3444 | 532/3,444 (15.45%) | 2,562/3,444 (74.39%) | 591/3,444 (17.16%) |
| stampede / procless | 4 | 1893 | 296/1,893 (15.64%) | 1,222/1,893 (64.55%) | 340/1,893 (17.96%) |
| swirl / Fish | 4 | 3439 | 550/3,439 (15.99%) | 1,907/3,439 (55.45%) | 489/3,439 (14.22%) |
| swirl / Sneaky | 2 | 1245 | 191/1,245 (15.34%) | 761/1,245 (61.12%) | 233/1,245 (18.71%) |
| swirl / Univardisty | 1 | 963 | 132/963 (13.71%) | 556/963 (57.74%) | 125/963 (12.98%) |
| swirl / procless | 1 | 1010 | 149/1,010 (14.75%) | 528/1,010 (52.28%) | 205/1,010 (20.30%) |

Full champion/team/map and draft-slot/physical-roster tables accompany this report. Different spell kits, drafts, roles, match duration, opponents and chronology can produce map averages without map-adaptive private logic. Within-team/champion comparisons still have chronology/opponent/role confounding and sparse cells. Do not rank maps from cells with little or no contact.

## Evidence and limits

Summary SHA256: `d975253d16e9005ab7c058da3be36b4669b8557414554acca9f8a61b85ceff15`. `audit.json` binds each compressed trace and original raw replay, its engine identity, roster/final API checks and exact death counts. `case-candidates.json` identifies illustrative source-bound mechanisms; selection scores are not performance scores. Full numerator/denominator CSVs are named by window/cohort/table; body/team game CSV and compressed JSONL preserve recomputation rows.

These repeated observations are not independent trials. No association with winning is used to claim a causal benefit. Missing visibility, readiness and rejected calls prevent missed-opportunity or optimal-target judgments; omitted shield/positive-HP trajectories prevent a complete effective-HP trade model.

