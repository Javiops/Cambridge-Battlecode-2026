// Read-only pure helpers transcribed from official CLI2.2.2 viewer view-index.js.
// Bh byteoffset791627, Vh/Hh792067. No engine/native state or bot execution.
const arrayBuffer = value => value instanceof ArrayBuffer ? value : value.buffer.slice(value.byteOffset,value.byteOffset+value.byteLength);
export function replayHeader(value) {
  const buffer=arrayBuffer(value);
  if(buffer.byteLength<11)throw Error('File header is truncated.');
  const d=new DataView(buffer),magic=d.getBigUint64(0,true),version=offset=>`v${d.getUint8(offset)}_${d.getUint8(offset+1)}_${d.getUint8(offset+2)}`;
  if(magic===120265261594231n)return{kind:'map',formatVersion:version(8)};
  if(magic!==125779999602273n)throw Error('Unrecognized map or replay file.');
  if(buffer.byteLength<14)throw Error('Replay header is truncated.');
  return{kind:'replay',engineVersion:version(8),formatVersion:version(11)};
}
// Call ONLY after official v0_0_2 loader returns replayParseError and its
// MapBuilder_FromFileBytes(raw.slice(14)).encodeBytes() matches the raw map prefix.
// Caller preserves original raw SHA and records normalized SHA if this is used.
export function normalizeLegacyV002(value,embeddedMapLength) {
  const buffer=arrayBuffer(value),h=replayHeader(buffer);
  if(h.kind!=='replay'||h.engineVersion!=='v0_0_2'||h.formatVersion!=='v0_0_2')throw Error('Not a legacy v0_0_2 replay.');
  const r=new Uint8Array(buffer),d=new DataView(buffer),a=14+embeddedMapLength;
  if(!Number.isSafeInteger(embeddedMapLength)||embeddedMapLength<11||a+4>buffer.byteLength)throw Error('Invalid embedded replay map.');
  const records=d.getUint32(a,true),start=a+4;
  if(records>buffer.byteLength-start)throw Error('Invalid legacy replay record count.');
  const payloadSizes=[4,8,9,17,0,8,8,0,8,9,8,4],bad=()=>{throw Error('Malformed legacy replay actions.');};
  function pass(out) {
    let read=start,write=start;
    for(let k=0;k<records;k++) {
      if(read>=r.length)bad();
      const begin=read,type=r[read++];
      if(type===4) {
        if(read+5>r.length||r[read]!==0)bad();read+=5;
        out?.set(r.subarray(begin,read),write);write+=6;if(out)out[write]=255;write++;continue;
      }
      if(type===3) {
        if(read+5>r.length||(r[read]&127)>1)bad();
        if(out){out[write]=type;out[write+1]=r[read]&127;}read+=5;write+=2;continue;
      }
      if(type===0||type===2) {
        if(read>=r.length)bad();const subtype=r[read++],length=type===0?payloadSizes[subtype]:subtype===0?9:subtype<=8?30:undefined;
        if(length===undefined||read+length>r.length)bad();read+=length;
      } else if(type!==5)bad();
      out?.set(r.subarray(begin,read),write);write+=read-begin;
    }
    if(read!==r.length)bad();return write;
  }
  const result=new Uint8Array(pass());result.set(r.subarray(0,start));pass(result);return result;
}
