# Coordination research evidence — 16 October 2026

Research evidence only; this ZIP is not a Battlecode bot submission.

Start with publication/coordination-research-2026-10-16.md and publication/06-team-coordination.md. The former is research; the latter is an unimplemented Planned specification. No new bot competitive games or implementation changes were performed.

matches/ contains the complete grouped summaries and compact CSV ledgers for the same3,766 API IDs /2,119 distinct raw replay streams as the ward/shopping study, including all1,078 top-four head-to-head streams. Core and early-window summaries are frozen. Case files contain exact source bindings and selected sequence windows; they illustrate mechanisms rather than representative success rates. Native world-round samples, owner-turn boundaries, recorded commands, HP-loss recipients, capture receipts and real submitted score have distinct definitions. Geometry is not available help or personal knowledge; private opponent intent/versions are unavailable.

The full native output tree (~621.7MB gzip), original raw replays/bundles, duplicate JSONL ledgers, runtime/vendor binaries, credentials and private opponent code are excluded. The internal payload manifest lists every included byte sequence. matches/evidence-index.json also binds excluded full native traces and vendor engine source; an entry there is not a promise that the corresponding large/executable source is redistributed. source-index.json maps original source paths to archive paths and explicitly records the excluded WASM.

Reproduction is source-backed but not one-command portable. Public bundle URLs/raw hashes and match/API metadata are retained in support/ward-research/acquisition/manifest-native.json and support/ward-research/matches/manifest-current-unique.json. Obtain the official WASM with SHA ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc and retain the original helper dependency layout under work/ when running the supplied sources. Native decoding uses Node; aggregation/audits use Python, and figures use matplotlib/numpy. Configure the local paths in the provided runners/helpers for your environment. The saved scripts and runtime source hashes, not an assertion of current-server binary identity, define the reconstruction.

Support files preserve the earlier rule/probe and map-helper context. Six-source-file hashes and the pinned own-bot commit identify the source audit; the bot code itself remains in the team repository. The artifact does not assert that audited revision is the active Battlecode upload or latest main.

The independent summary/publication/episode reviews verify the stated reconstructions and bounded prose, not a causal strategy improvement. The final external ZIP audit is intentionally kept outside the ZIP to avoid recursive hashing/repacking. The external archive manifest contains its final SHA-256 and size; the internal payload manifest contains each payload SHA-256 and size.
