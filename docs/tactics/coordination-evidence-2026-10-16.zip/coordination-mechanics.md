# Coordination mechanics audit — 16 October 2026

These are mechanics checks, not strategy matches or competitive comparisons. The pinned official visualiser engine has SHA-256 `ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc`. The live handbook was read in the browser on 16 October 2026. No claim is made that the saved executable is byte-identical to the current match server.

## Current official sources

- [Shared memory](https://2026a.battlecode.co.uk/game/docs/shared-memory): per-body bot instances, eight writable team bytes, 1,024 draft bytes that become read-only in play.
- [A champion turn](https://2026a.battlecode.co.uk/game/docs/your-first-turn), expanded exact-turn-order panel: alternating teams, starting team flips each round, higher priority before draft order within a team, priority changes apply next round and persist. Dead bodies keep an input turn. Ranged ordinary movement and basic attack share an allowance.
- [Vision and wards](https://2026a.battlecode.co.uk/game/docs/vision), prior ward source audit and fixtures: personal observation, including the observer's own ward, is not automatic shared vision.
- [Camps and capture](https://2026a.battlecode.co.uk/game/docs/camps), prior shopping mechanics fixtures: fixed capture phases, uninterrupted uncontested occupancy, rewards allocated to qualifying bodies. Extra holders do not accelerate the capture timer.

The latter two remain bound to the earlier ward/shopping source audits and native fixtures. This audit adds new direct tests of personal views, memory and scheduling rather than re-running unrelated mechanics.

## New native cases

`probe-coordination.mjs` produces `coordination-mechanics.json`: **seven cases, 22 asserted checks, all passing**.

| Case | Observed result | Design implication |
| --- | --- | --- |
| Team memory lifecycle, isolation and bounds | Capacity 8; initial zeros in this fresh game. An own-team write is immediately readable and is visible to a later ally input in the same round. A one-byte update preserves the other bytes; values persist through round 4. Opponent storage is separate. Wrong-team input-boundary access is rejected. An overrun write is rejected without changing the buffer. | Messages can support later teammates, but are not automatically fresh. A plan may be read later in the same round or after an intervening enemy action. |
| Draft memory during play | Capacity 1,024, readable; attempted write rejected without mutation. | Static map/role tables may be prepared during draft; this is not a 1,024-byte live team blackboard. The fixture does not test every draft-write or guest-restart edge case. |
| Default order | With two bodies per side, world rounds 1–3 act `[A0,B0,A1,B1]`, `[B0,A0,B1,A1]`, `[A0,B0,A1,B1]`. | A round snapshot cannot substitute for an individual owner's exact action boundary. |
| Priority | Giving A1 priority7 in round1 leaves that round unchanged; rounds2/3 reorder A1 before A0 while preserving team alternation. The priority persists in round4. | An initiator/follow-up order can be planned for a later round, but cannot remove intervening enemy responses or reorder actions already taken. |
| Dead actor | Killing A1 from an enemy source still leaves A1 an input boundary in the current order, with alive=false. | A scheduled input is not available combat power. |
| Occupied tiles: ally and enemy | A normal move from(10,10) to an ally/enemy at(11,10) is rejected and leaves the actor in place. | Chokes can queue bodies. This does not establish projectile interception, universal body-blocking protection, dash rules, or the value of a blocking sacrifice. |
| Personal observation | A0 at(10,10) cannot see its remote ally A1 at(24,24): personal snapshot position is(-1,-1), while the host view contains its true position. B0 at(25,24) is visible to A1 but absent from A0's live view. | Neither an ally's remote position nor its enemy pixels may be treated as globally available. Hidden live HP is not zero actual HP. Public identity/alive metadata is a separate API issue. |

## Deliberate limits

The tests establish host API behavior at sequential input boundaries. They do **not** prove a multi-call read–modify–write transaction is atomic across guest fuel suspension, nor test arbitrary guest restart, serialization, corruption, wrap-around protocols or all legal priorities. They do not reveal any opponent's private shared-memory schema or decision code.

The existing source allocation already uses all eight bytes: claims0–4, camp lifecycle5–6, danger alert7 when help is disabled. A new mission/ack/expiry protocol needs an explicit migration and bit budget; it cannot simply append a rich object. A shared report also does not grant a recipient vision or legal attack/cast range.

Use the exact world-round and actor-turn schedule when estimating first useful contribution, arrival and enemy response. A nearby body that has already spent its action, is channeling, is hidden from the observer, or cannot traverse the route in time is not confirmed ready support. These are policy constraints inferred from the mechanics, not measured improvements.
