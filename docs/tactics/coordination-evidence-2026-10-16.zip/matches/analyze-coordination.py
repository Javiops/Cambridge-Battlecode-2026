"""Bounded per-game reconstruction/aggregation of native coordination traces."""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timezone
import json,gzip,csv,hashlib,statistics,math,argparse
ROOT=Path(__file__).resolve().parent;WARD=ROOT.parents[1]/'ward-research'
parser=argparse.ArgumentParser();parser.add_argument('--limit',type=int);parser.add_argument('--stride',type=int,default=1);parser.add_argument('--index',type=int,default=0);parser.add_argument('--merge-parts',type=Path);parser.add_argument('--input-dir',type=Path,default=ROOT/'current');parser.add_argument('--out-dir',type=Path,default=ROOT);args=parser.parse_args();OUTPUT=args.out_dir;OUTPUT.mkdir(parents=True,exist_ok=True)
unique=json.loads((WARD/'matches/manifest-current-unique.json').read_bytes());full=json.loads((WARD/'acquisition/manifest-native.json').read_bytes());ladder=json.loads((WARD/'acquisition/api/ladder.json').read_bytes())
rank={t['teamId']:t for t in ladder['teams']};requests={r['id']:r for r in unique['requests']};strata=Counter();latest={}
for r in sorted(full['requests'],key=lambda r:(r['created_at'],r['id']),reverse=True):
 key=(tuple(sorted(t['teamId']for t in r['teams'].values())),r['map'],r['kind'])
 if strata[key]<2:latest.setdefault(r['raw_sha256'],r);strata[key]+=1
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def distance(a,b):return max(abs(a[1]-b[1]),abs(a[2]-b[2]))
def atspawn(c,b):return b[0]<=c[1]<b[2]and b[1]<=c[2]<b[3]
def dist(v):
 v=sorted(v)
 def q(p):
  if not v:return None
  x=(len(v)-1)*p;i=int(x);return v[i]+(v[min(i+1,len(v)-1)]-v[i])*(x-i)
 return{'n':len(v),'mean':statistics.mean(v)if v else None,'median':q(.5),'p25':q(.25),'p75':q(.75),'min':v[0]if v else None,'max':v[-1]if v else None}
def components(cs,radius=6):
 todo={c[0]:c for c in cs};groups=[]
 while todo:
  _,c=todo.popitem();group=[c];i=0
  while i<len(group):
   a=group[i];i+=1
   for key,b in list(todo.items()):
    if distance(a,b)<=radius:group.append(b);del todo[key]
  groups.append(group)
 return groups
def meta(r,side,g):
 t=r['teams']['a'if side==0 else'b'];rr=rank[t['teamId']];ranks=[rank[t['teamId']]['rank']for t in r['teams'].values()]
 return{'match_id':r['id'],'raw_sha256':r['raw_sha256'],'map':r['map'],'kind':r['kind'],'created_at':r['created_at'],'side':side,'teamId':t['teamId'],'team':rr['name'],'rank':rr['rank'],'top4_h2h':max(ranks)<=4,'latest_slice':r['raw_sha256']in latest,'draftSlots':g['draftCounts'][side],'rosterBodies':sum(c['team']==side for c in g['roster']),'rounds':g['final']['round']}
games=[];bodies=[];audit=[];errors=[];candidates=defaultdict(list);totals=Counter();captures_out=[];submissions_out=[];focus_out=[]
def check(ok,mid,kind,**extra):
 if not ok:errors.append({'id':mid,'kind':kind,**extra})
def candidate(kind,score,data):
 rr=requests[data['match_id']];ranks=[rank[t['teamId']]['rank']for t in rr['teams'].values()];score+=10000 if max(ranks)<=4 else 1000 if min(ranks)<=4 else 0
 if rr['raw_sha256']in latest:score+=100
 rows=candidates[kind];old=next((x for x in rows if(x[1]['match_id'],x[1]['side'])==(data['match_id'],data['side'])),None)
 if old:
  if old[0]>=score:return
  rows.remove(old)
 rows.append((score,data));rows.sort(key=lambda x:x[0],reverse=True);del rows[24:]
selected=[]if args.merge_parts else list(requests.items())[args.index::args.stride][:args.limit]
for ix,(mid,r)in enumerate(selected):
 file=args.input_dir/f'{mid}.coord.json.gz'
 if not file.exists():errors.append({'id':mid,'kind':'missing'});continue
 g=json.loads(gzip.decompress(file.read_bytes()));check(g['id']==mid and g['raw_sha256']==r['raw_sha256'],mid,'source_binding');check(not g['apiFinalErrors'],mid,'api_final',errors=g['apiFinalErrors']);check(sha(Path(r['raw']))==r['raw_sha256'],mid,'raw_sha');check(g['final']['round']==r['game']['statistics']['round'],mid,'round')
 roster={c['id']:c for c in g['roster']};team=lambda id:roster[id]['team'];pick=lambda id:('duo'if roster[id]['type']in[3,4]else str(id));spawns=g['geometry']['spawn'];rs={r['r']:r for r in g['rounds']};roundkeys=list(rs)
 check(roundkeys==sorted(set(roundkeys)),mid,'round_sample_unique_sorted');check(all(len(w['c'])==len(roster)for w in rs.values()),mid,'complete_round_roster');check(len(roster)==len(r['game']['statistics']['champions']),mid,'roster_count')
 bybody={id:Counter()for id in roster};bybodydist={id:defaultdict(list)for id in roster};ts=[Counter(),Counter()];hist=[defaultdict(Counter),defaultdict(Counter)];nearcache={};paircache={};fieldcache={}
 for rnd,w in rs.items():
  alive=[c for c in w['c']if c[5]];field=[c for c in alive if not atspawn(c,spawns[team(c[0])])];fieldcache[rnd]=field
  for id,b in bybody.items():
   c=next(c for c in w['c']if c[0]==id);b['worldRoundSamples']+=1
   if c[5]:b['aliveBodyRounds']+=1
   else:b['deadBodyRounds']+=1
   if c[5]and atspawn(c,spawns[team(id)]):b['aliveSpawnBodyRounds']+=1
   if c[5]and c[9]:b['aliveChannelBodyRounds']+=1
  for side in [0,1]:
   cs=[c for c in field if team(c[0])==side];en=[c for c in field if team(c[0])!=side];t=ts[side];t['worldRoundSamples']+=1;t['fieldBodyRounds']+=len(cs);t['aliveBodyRounds']+=sum(team(c[0])==side for c in alive);hist[side]['fieldBodies'][len(cs)]+=1
   if cs:t['roundsWithFieldBodies']+=1
   if len(cs)>=2:t['roundsWithAtLeast2FieldBodies']+=1
   if len(cs)>=3:t['roundsWithAtLeast3FieldBodies']+=1
   groups=components(cs);largest=max(map(len,groups),default=0);hist[side]['largestComponent6'][largest]+=1
   distinct=max((len({pick(c[0])for c in group})for group in groups),default=0);hist[side]['largestComponentDistinctPicks6'][distinct]+=1
   if largest>=2:t['roundsWithComponentAtLeast2']+=1
   if largest>=3:t['roundsWithComponentAtLeast3']+=1
   if distinct>=2:t['roundsWithComponentAtLeast2Picks']+=1
   if len(groups)>=2:t['splitComponentRounds']+=1
   for c in cs:
    id=c[0];b=bybody[id];b['fieldBodyRounds']+=1
    if c[9]:b['fieldChannelBodyRounds']+=1
    else:b['fieldNonChannelBodyRounds']+=1
    nearest=min((distance(c,e)for e in en),default=None)
    if nearest is not None:bybodydist[id]['nearestEnemy'].append(nearest)
    for radius in [3,6,8]:
     allies=[a for a in cs if distance(a,c)<=radius];enemies=[e for e in en if distance(e,c)<=radius];a=len(allies);e=len(enemies);p=len({pick(x[0])for x in allies});hist[side][f'support{radius}'][a]+=1;hist[side][f'contactBalance{radius}'][f'{a}:{e}']+=1;b[f'support{radius}Sum']+=a
     if a>=2:b[f'withAlly{radius}BodyRounds']+=1
     if p>=2:b[f'withOtherPick{radius}BodyRounds']+=1
     if e:
      b[f'contact{radius}BodyRounds']+=1
      if a>=2:b[f'groupedContact{radius}BodyRounds']+=1
      if a>e:b[f'advantageContact{radius}BodyRounds']+=1
      if a<e:b[f'outnumberedContact{radius}BodyRounds']+=1
      if a==e:b[f'evenContact{radius}BodyRounds']+=1
      if a==1 and e==1:b[f'oneVsOne{radius}BodyRounds']+=1
      if a>=2 and e==1:b[f'twoPlusVsOne{radius}BodyRounds']+=1
     if radius==6:nearcache[(rnd,id)]=(allies,enemies)
   for j,a in enumerate(cs):
    for b in cs[j+1:]:
     if distance(a,b)<=6:paircache[(rnd,a[0],b[0])]=(a,b)
 # Pair persistence/co-movement between identical fixed-stage world snapshots.
 for (rnd,aid,bid),(a,b)in paircache.items():
  nxt=rs.get(rnd+1)
  if not nxt:continue
  nextfield={c[0]:c for c in fieldcache[rnd+1]};aa=nextfield.get(aid);bb=nextfield.get(bid)
  if aa is None or bb is None:continue
  t=ts[team(aid)];t['nearPairRoundTransitions']+=1
  if distance(aa,bb)<=6:t['nearPairRetainedTransitions']+=1
  da=(aa[1]-a[1],aa[2]-a[2]);db=(bb[1]-b[1],bb[2]-b[2]);la=math.hypot(*da);lb=math.hypot(*db)
  if la and lb:
   t['nearPairBothMovedTransitions']+=1
   if distance(aa,bb)<=6 and sum(x*y for x,y in zip(da,db))/(la*lb)>=.8:t['nearPairSimilarHeadingTransitions']+=1
 # All sampled owner turns, including unavailable/dead/spawn; separate from world-round metrics.
 for v in g['turns']:
  b=bybody[v[2]];b['ownerTurnStarts']+=1
  if not v[3]:b['deadOwnerTurnStarts']+=1
  elif v[4]:b['spawnOwnerTurnStarts']+=1
  else:b['fieldOwnerTurnStarts']+=1
 # Stable actual HP-loss recipient IDs, restricted direct native champion attack/cast frames.
 pvp=defaultdict(lambda:defaultdict(lambda:defaultdict(set)));pve=defaultdict(lambda:defaultdict(lambda:defaultdict(set)));actorpvp=defaultdict(lambda:defaultdict(set));actordamage=defaultdict(lambda:defaultdict(float));campDamage=[]
 for d in g['damage']:
  source=d['source'];direct=source and source['id']in roster and d['step'][0]==10 and d['step'][1]in[5,6]and d['step'][2]==1 and d['step'][4]==0
  if not direct:continue
  actor=source['id'];side=team(actor)
  for loss in d['losses']:
   kind,target,sideTarget,amount=loss[:4]
   if kind==1 and sideTarget!=side:
    pvp[side][d['r']][target].add(actor);actorpvp[actor][d['r']].add(target);actordamage[actor]['pvpHealthLossDuringOwnAttackCast']+=amount;bybody[actor]['pvpRecipientHits']+=1
   elif kind==2:
    camp=next(c for c in g['camps']if c['id']==target);pve[side][d['r']][camp['group']].add(actor);campDamage.append((d['seq'],d['r'],camp['group'],actor));actordamage[actor]['pveHealthLossDuringOwnAttackCast']+=amount;bybody[actor]['pveRecipientHits']+=1
 for side in [0,1]:
  t=ts[side]
  for rnd,targetActors in pvp[side].items():
   actors=set().union(*targetActors.values());t['pvpTeamRounds']+=1;t['pvpDamagingActorRounds']+=len(actors)
   if len(actors)>=2:t['multiAttackerPvpTeamRounds']+=1
   shared=[id for id,actors in targetActors.items()if len(actors)>=2]
   if shared:t['sharedRecipientPvpTeamRounds']+=1
   t['sharedRecipientTargetRounds']+=len(shared)
   for target in shared:
    row={**meta(r,side,g),'round':rnd,'target':target,'actors':sorted(targetActors[target])};focus_out.append(row)
    if len(targetActors[target])>=3:candidate('larger_joint_attack',len(targetActors[target])*100+max(ranks:=[rank[x['teamId']]['rank']for x in r['teams'].values()])*-1,{'match_id':mid,'map':r['map'],'side':side,'round':rnd,'target':target,'actors':sorted(targetActors[target]),'category':'direct enemy HP-loss recipient shared in same world round'})
   prev=pvp[side].get(rnd-1,{})
   if shared and any(target in prev and len(prev[target])>=2 for target in shared):t['persistentSharedRecipientPvpTeamRounds']+=1
  for rnd,groups in pve[side].items():
   t['pveTeamRounds']+=1;t['pveCampGroupRounds']+=len(groups)
   if len(groups)>=2:
    t['multiCampWorkTeamRounds']+=1;actorGroups=defaultdict(set)
    for group,actors in groups.items():
     for actor in actors:actorGroups[actor].add(group)
    if all(len(x)==1 for x in actorGroups.values()):t['disjointMultiCampWorkTeamRounds']+=1
    if len(groups)>=3:candidate('split_camp_work',len(groups)*100-len(actorGroups),{'match_id':mid,'map':r['map'],'side':side,'round':rnd,'groups':{str(k):sorted(v)for k,v in groups.items()},'category':'direct camp HP losses on distinct groups in same world round'})
   if any(len(actors)>=2 for actors in groups.values()):t['sharedCampGroupWorkTeamRounds']+=1
  for rnd in pvp[side]:
   union=defaultdict(set)
   for rr in range(rnd-2,rnd+1):
    for target,actors in pvp[side].get(rr,{}).items():union[target].update(actors)
   t['pvpAnchorRoundsFor3RoundWindow']+=1
   if any(len(v)>=2 for v in union.values()):t['sharedRecipientWithin3RoundWindows']+=1
 for actor,rnds in actorpvp.items():
  b=bybody[actor];b['pvpDamagingActorRounds']=len(rnds)
  for rnd,targets in rnds.items():
   if rnd+1 in rnds:
    b['consecutivePvpActorRoundPairs']+=1
    if targets&rnds[rnd+1]:b['persistentRecipientPvpActorRoundPairs']+=1
 for actor in roster:
  bybody[actor]['pveDamagingActorRounds']=sum(actor in set().union(*groups.values())for groups in pve[team(actor)].values())
 # Confirmed resource-resolution captures and contributors since prior reward in same group.
 lastReward=defaultdict(lambda:-1)
 for e in g['captures']:
  if not e['recipients']:continue
  recipientTeams={x['team']for x in e['recipients']};check(len(recipientTeams)==1,mid,'capture_recipient_teams',seq=e['seq']);side=next(iter(recipientTeams));t=ts[side];recipients={x['id']for x in e['recipients']};contributors={actor for seq,rnd,group,actor in campDamage if group==e['group']and lastReward[e['group']]<seq<e['seq']and team(actor)==side};t['confirmedCampRewards']+=1;t['campRewardRecipientBodies']+=len(recipients);t['captureRecipientNotObservedDamagerBodies']+=len(recipients-contributors);hist[side]['campRewardRecipientCounts'][len(recipients)]+=1;hist[side]['campObservedDirectDamagerCounts'][len(contributors)]+=1
  for id in recipients:bybody[id]['campRewardEvents']+=1;bybody[id]['campRewardGold']+=sum(x['gold']for x in e['recipients']if x['id']==id);bybody[id]['campRewardGems']+=sum(x['gems']for x in e['recipients']if x['id']==id)
  if recipients-contributors:t['campRewardsWithRecipientNotObservedDamager']+=1
  row={**meta(r,side,g),'round':e['r'],'seq':e['seq'],'group':e['group'],'recipients':sorted(recipients),'observedDirectDamagers':sorted(contributors),'rewardGold':sum(x['gold']for x in e['recipients']),'rewardGems':sum(x['gems']for x in e['recipients'])};captures_out.append(row)
  if contributors and recipients-contributors:candidate('capture_handoff',len(recipients-contributors)*100+len(contributors),{'match_id':mid,'map':r['map'],'side':side,'round':e['r'],'seq':e['seq'],'group':e['group'],'recipients':sorted(recipients),'observedDirectDamagers':sorted(contributors),'category':'reward recipient not among observed direct same-team camp damagers since prior reward'})
  lastReward[e['group']]=e['seq']
 # Actual submitted score, exact submitter gem decrement, geometric escort.
 for e in g['submissions']:
  for side in [0,1]:
   if e['delta'][side]<=0:continue
   donors=[(c,next(a for a in e['after']if a[0]==c[0]))for c in e['c']if team(c[0])==side and c[7]>next(a for a in e['after']if a[0]==c[0])[7]];check(len(donors)==1,mid,'submit_single_donor',seq=e['seq']);
   if len(donors)!=1:continue
   c,a=donors[0];t=ts[side];t['confirmedSubmissions']+=1;t['submittedScore']+=e['delta'][side];bybody[c[0]]['confirmedSubmissions']+=1;bybody[c[0]]['submittedScore']+=e['delta'][side];f=[x for x in e['c']if x[5]and not atspawn(x,spawns[team(x[0])])];allies=[x for x in f if team(x[0])==side and distance(x,c)<=6];enemies=[x for x in f if team(x[0])!=side and distance(x,c)<=6];hist[side]['submissionAllies6InclSubmitter'][len(allies)]+=1;hist[side]['submissionEnemies6'][len(enemies)]+=1
   if len(allies)>=2:t['submissionsWithGeometricAlly6']+=1
   if enemies:t['submissionsWithGeometricEnemy6']+=1
   row={**meta(r,side,g),'round':e['r'],'seq':e['seq'],'submitter':c[0],'score':e['delta'][side],'gemsDecrement':c[7]-a[7],'allies6':len(allies),'enemies6':len(enemies)};submissions_out.append(row)
   if len(allies)>=3 and enemies:candidate('contested_group_submission',len(allies)*100+len(enemies),{'match_id':mid,'map':r['map'],'side':side,'round':e['r'],'seq':e['seq'],'submitter':c[0],'allies':list(x[0]for x in allies),'enemies':list(x[0]for x in enemies),'category':'actual score submission with geometric local allies and enemies'})
 # Commands and confirmed ordinary displacement; no failed-command interpretation.
 for a in g['actions']:
  b=bybody[a['actor']];b['recordedActions']+=1
  if a['kind']==4:
   b['moveCommands']+=1
   if a['before'][1:3]!=a['after'][1:3]:b['actualOrdinaryDisplacements']+=1
  if a['kind']==5:b['basicAttackCommands']+=1
  if a['kind']==6:b['castCommands']+=1
  if a['kind']==11:b['recallCommands']+=1
  if a['kind']==12:b['submitCommands']+=1
 # Repeated 1:1 geometric contact anchors and bounded reinforcement after <=3 snapshots.
 for (rnd,id),(allies,enemies)in nearcache.items():
  if len(allies)!=1 or len(enemies)!=1:continue
  b=bybody[id];b['oneVsOne6Anchors']+=1;target=enemies[0][0]
  for rr in range(rnd+1,rnd+4):
   q=nearcache.get((rr,id))
   if not q:break
   aa,ee=q
   if len(aa)>=2 and len(ee)==1 and ee[0][0]==target:
    helpers={c[0]for c in aa if c[0]!=id};b['reinforcedWithin3Anchors']+=1;actual={actor for rd in range(rnd,rr+2)for actor in pvp[team(id)].get(rd,{}).get(target,set())};both=id in actual and bool(helpers&actual)
    if both:b['reinforcedThenSharedRecipientAnchors']+=1;candidate('one_to_two_vs_one',1000-(rr-rnd)*10-rank[r['teams']['a'if team(id)==0 else'b']['teamId']]['rank'],{'match_id':mid,'map':r['map'],'side':team(id),'round':rnd,'afterRound':rr,'focal':id,'target':target,'helpers':sorted(helpers),'actorsWithRecipientHPChange':sorted(actual),'category':'1:1 geometric contact becomes >=2:1 with same enemy; focal and helper have observed HP-loss attack/cast frames at that recipient'})
    break
 # Geometric contact exit against enemy positions held fixed at prior snapshot.
 for rnd,w in rs.items():
  if rnd+1 not in rs:continue
  nxt={c[0]:c for c in fieldcache[rnd+1]}
  for c in fieldcache[rnd]:
   id=c[0];aa,ee=nearcache[(rnd,id)]
   if not ee or id not in nxt:continue
   b=bybody[id];b['contact6NextAliveFieldTransitions']+=1;post=nxt[id];before=min(distance(c,e)for e in ee);after=min(distance(post,e)for e in ee)
   if after>=7 and after-before>=2:
    b['geometricContactExitTransitions']+=1
    if c[3]/c[4]<.5:b['lowHealthGeometricContactExitTransitions']+=1
    if len(aa)>=2:candidate('geometric_disengagement',int(1000*(1-c[3]/c[4]))+len(aa)*10,{'match_id':mid,'map':r['map'],'side':team(id),'round':rnd,'afterRound':rnd+1,'focal':id,'allies':[x[0]for x in aa],'enemies':[x[0]for x in ee],'healthFraction':c[3]/c[4],'category':'focal moves >=2 farther from prior enemy positions, exits radius6 next snapshot while alive on-field; no intent claim'})
 for id,c in roster.items():
  m=meta(r,c['team'],g);b={**m,'body':id,'champion':c['name'],'type':c['type'],**dict(bybody[id]),**dict(actordamage[id]),'nearestEnemy':dist(bybodydist[id]['nearestEnemy'])};bodies.append(b)
 for side in [0,1]:
  bsum=Counter()
  for id,b in bybody.items():
   if team(id)==side:bsum.update(b);bsum.update(actordamage[id])
  # Body fields duplicate explicit team fields only for alive/field exposure; same values required.
  for key in ['aliveBodyRounds','fieldBodyRounds']:check(bsum[key]==ts[side][key],mid,'exposure_sum_'+key,side=side)
  row={**meta(r,side,g),**dict(bsum),**dict(ts[side]),'histograms':{k:dict(v)for k,v in hist[side].items()}};games.append(row)
 totals.update({'streams':1,'roundSnapshots':len(g['rounds']),'ownerTurnStarts':len(g['turns']),'commands':len(g['actions']),'damageFrames':len(g['damage']),'deaths':len(g['deaths']),'captureTransitions':len(g['captures']),'scoreTransitions':len(g['submissions']),'bodies':len(roster)})
 audit.append({'id':mid,'raw_sha256':r['raw_sha256'],'trace_sha256':sha(file),'rounds':len(g['rounds']),'frames':g['frames'],'apiFinalErrors':g['apiFinalErrors']})
 if(ix+1)%200==0:print('Aggregated',ix+1,flush=True)
if args.merge_parts:
 for part in sorted(args.merge_parts.glob('part-*')):
  for name,dest in [('team-game-metrics',games),('body-game-metrics',bodies)]:
   with gzip.open(part/(name+'.jsonl.gz'),'rt',encoding='utf8')as f:dest.extend(json.loads(line)for line in f)
  partaudit=json.loads((part/'current-audit.json').read_bytes());audit.extend(partaudit['records']);errors.extend(partaudit['errors']);totals.update(partaudit['counts'])
  for kind,rows in json.loads((part/'case-candidates.json').read_bytes()).items():
   for data in rows:candidate(kind,0,data)
def write(name,rows):
 with gzip.open(OUTPUT/(name+'.jsonl.gz'),'wt',encoding='utf8',compresslevel=1)as f:
  for r in rows:f.write(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n')
 fields=list(dict.fromkeys(k for r in rows for k in r))
 numeric={k for r in rows for k,v in r.items()if isinstance(v,(int,float))and not isinstance(v,bool)}
 with(OUTPUT/(name+'.csv')).open('w',newline='',encoding='utf8')as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  for r in rows:
   filled={**{k:0 for k in numeric},**r};w.writerow({k:json.dumps(v,ensure_ascii=False,separators=(',',':'))if isinstance(v,(dict,list))else v for k,v in filled.items()})
def summarize(rows):
 out={'streams':len({r['match_id']for r in rows}),'bodyAppearances':sum(1 if 'body'in r else r['rosterBodies']for r in rows)};keys={k for r in rows for k,v in r.items()if isinstance(v,(int,float))and not isinstance(v,bool)and k not in ['rank','side','draftSlots','rosterBodies','rounds','body','type']}
 for k in keys:out[k]=sum(r.get(k,0)for r in rows)
 hs=defaultdict(Counter)
 for r in rows:
  for name,values in r.get('histograms',{}).items():hs[name].update(values)
 out['histograms']={k:dict(v)for k,v in hs.items()};out['gameDistributions']={k:dist([r.get(k,0)for r in rows])for k in ['rounds','fieldBodyRounds','contact6BodyRounds','sharedRecipientPvpTeamRounds','confirmedCampRewards','confirmedSubmissions']};return out
def group(rows,keys):
 buckets=defaultdict(list)
 for r in rows:buckets[tuple(r[k]for k in keys)].append(r)
 return[{**dict(zip(keys,key)),**summarize(v)}for key,v in sorted(buckets.items())]
write('team-game-metrics',games);write('body-game-metrics',bodies)
for name,rows in [('camp-rewards',captures_out),('submissions',submissions_out),('shared-recipient-rounds',focus_out)]:
 if not args.merge_parts:write(name,rows);continue
 with(OUTPUT/(name+'.jsonl.gz')).open('wb')as gzout,(OUTPUT/(name+'.csv')).open('w',newline='',encoding='utf8')as csvout:
  first=True
  for part in sorted(args.merge_parts.glob('part-*')):
   gzout.write((part/(name+'.jsonl.gz')).read_bytes())
   with(part/(name+'.csv')).open('r',newline='',encoding='utf8')as f:
    header=next(f)
    if first:csvout.write(header);first=False
    for line in f:csvout.write(line)
summary={'generated_at_utc':datetime.now(timezone.utc).isoformat(),'counts':dict(totals),'expectedIDs':3766,'expectedRawStreams':2119,'latestRawStreams':len(latest),'latestH2hRawStreams':len({r['raw_sha256']for r in games if r['latest_slice']and r['top4_h2h']}),'cohorts':{}}
for name,predicate in [('unique',lambda r:True),('top4_h2h',lambda r:r['top4_h2h']),('latest',lambda r:r['latest_slice']),('latest_h2h',lambda r:r['latest_slice']and r['top4_h2h'])]:
 gs=[r for r in games if predicate(r)];bs=[r for r in bodies if predicate(r)];summary['cohorts'][name]={'per_team':group(gs,['rank','teamId','team']),'per_map_team':group(gs,['rank','team','map']),'per_roster_size_team':group(gs,['rank','team','draftSlots','rosterBodies']),'per_champion_team':group(bs,['rank','team','champion']),'per_map_champion_team':group(bs,['rank','team','champion','map'])}
summary['definitions']={'field':'Alive at fixed first phase10 complete-roster snapshot of world round, outside own spawn rectangle. All proximity counts exclude own-spawn/dead bodies on both sides.','support':'Chebyshev geometry radius3/6/8, includes focal body. Does not imply walkable reach, readiness, line of sight, personal visibility, action or intent. Connected groups can chain far beyond radius. Distinct-pick support collapses Cassi/Issac pair.','sharedRecipient':'At least two distinct same-team actors whose native phase10 kind5/6 actorKind1 substep0 frames coincide with positive HP loss at the same stable enemy body ID in one world round. No nearest-target guess or private targeting policy inferred. Delayed spell/environment effects excluded from primary focus.','capture':'Phase7 group transition with exact positive gold/gem recipient changes. Contributor count is observed direct attack/cast camp HP loss since previous reward, same team; absence from contributor set is not proof of no contribution via delayed effects.','submission':'Actual positive submitted score change and unique personal gem decrement; local counts from exact preceding native frame. Geometric escort does not prove deliberate escort.','reinforcement':'Overlapping body-round 1:1 contact anchors; within next3 fixed snapshots same focal and same enemy observed again, becomes>=2:1. Intermediate contact may lapse; continuity is not required. HP-loss co-occurrence requires focal and a helper present at reinforcement to appear in the recipient frame union from anchor through reinforcement+1; it need not occur after joining or in one round. Anchors are not independent episodes.','movement':'Pair direction is cosine>=0.8 between net displacements across fixed snapshots and remains within6. Contact exit moves >=2 farther from prior enemy positions and beyond6 next snapshot while alive/on-field; enemy motion frozen for calculation. No retreat intent/indecision claim.','availability':'World-round and owner-turn-start denominators are separate. Death/spawn/channel exposure retained, on-field can include channeling. Actions sequential within rounds, never assumed simultaneous.','inference':'Descriptive outcomes only. Draft/physical body count, map, chronology, private versions, opponents, roles, health, items and duration confound comparisons.'}
(OUTPUT/'current-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8');(OUTPUT/'case-candidates.json').write_text(json.dumps({k:[d for score,d in v]for k,v in candidates.items()},ensure_ascii=False,indent=2)+'\n',encoding='utf8');result={'passed':not errors and totals['streams']==(2119 if args.merge_parts else len(selected)),'counts':dict(totals),'errors':errors,'source_unique_manifest_sha256':sha(WARD/'matches/manifest-current-unique.json'),'source_all_manifest_sha256':sha(WARD/'acquisition/manifest-native.json'),'scanner_sha256':sha(ROOT/'scan-coordination.mjs'),'engine_sha256':'ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc','records':audit};(OUTPUT/'current-audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps({'passed':result['passed'],'counts':dict(totals),'errors':len(errors),'latestH2hRaw':summary['latestH2hRawStreams']},indent=2),flush=True)
