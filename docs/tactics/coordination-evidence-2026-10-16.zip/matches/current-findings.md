# Team coordination and grouping: frozen elite replay cohort

The replay evidence supports a mixture of nearby formations, shared combat and split economic work. Across the top-four head-to-head games, an on-field body has another ally within six tiles in 68.71–77.72% of sampled body-rounds; when geometric enemy contact exists, the corresponding grouped-contact share is 76.67–84.58%. These are spatial facts, not proof that another body could act, saw the same information, or received a shared assignment. Actual native attack/cast frames separately show shared enemy HP-loss recipients. Camp rewards usually go to one body, even when the team performs camp work in several locations during the same world round.

## Cohort, source and denominators

The cohort is exactly the prior ward/shopping freeze: 3,766 API match IDs, 2,119 distinct raw SHA-256 streams, 4,238 team/game observations and 21,312 champion-body/game appearances. The additional 1,647 IDs alias raw streams already counted. Top-four head-to-head includes 2,460 IDs / 1,078 raw streams. Fixed ladder ranks come from 2026-10-15 22:51:52 UTC; selected matches span October 13–15. No outcome filter was used, and raw-distinct games are not asserted to be independent bot versions or experiments. Private submission/version identifiers are unavailable.

All 2,119 official native trajectories were decoded sequentially with WASM SHA `ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc`. The extraction contains 1,047,385 fixed-stage world-round snapshots, 10,442,536 separately identified owner-turn starts, 8,942,482 retained actor commands and 3,779,432 HP-loss frames, including neutral/environment frames. The canonical round snapshot is the first phase10 frame with the complete roster, after that round’s environmental phases. It is one sequential world state; actions within a world round are never assumed simultaneous.

“On field” means alive and outside that body’s own embedded spawn rectangle. Proximity excludes dead and own-spawn bodies on both sides. The principal denominator is on-field champion-body × sampled world round. Channeling bodies remain included and have separate exposure counters; proximity does not establish readiness. Radius6 is Chebyshev distance, includes the focal body in allied counts, and is supplemented by radii3/8 and a distinct-pick measure collapsing Cassi/Issac. Connected components can form chains; they are secondary descriptors, not a cohesion or reachability test. Omniscient coordinates are not proof of the information available to either bot; remote allied GPS/team sight are not assumed.

## All ten teams

| Team | Streams / body appearances | On-field body-rounds | Another ally≤6 | Enemy-contact body-rounds | Grouped contact≤6 | Shared recipient / multi-attacker PvP rounds |
| --- | --- | --- | --- | --- | --- | --- |
| Fish | 567 / 2,938 | 1,276,308 | 75.66% | 267,093 | 80.95% | 5,770/6,863 (84.07%) |
| Sneaky | 380 / 1,876 | 739,541 | 68.87% | 164,095 | 77.44% | 2,544/3,129 (81.30%) |
| Mite | 1011 / 5,295 | 2,231,062 | 77.64% | 494,904 | 84.47% | 9,173/11,500 (79.77%) |
| Univardisty | 821 / 4,037 | 1,751,563 | 70.96% | 411,312 | 78.17% | 9,778/11,926 (81.99%) |
| VeryGood | 227 / 1,176 | 497,965 | 77.82% | 114,917 | 82.32% | 1,763/2,125 (82.96%) |
| Quantom | 264 / 1,233 | 496,700 | 59.59% | 102,846 | 65.63% | 1,608/2,181 (73.73%) |
| hello | 264 / 1,321 | 585,758 | 71.51% | 143,585 | 81.18% | 4,062/4,923 (82.51%) |
| Nyxius | 243 / 1,196 | 468,629 | 65.53% | 111,948 | 72.67% | 1,400/1,551 (90.26%) |
| geese geese go | 221 / 1,087 | 441,993 | 68.05% | 89,614 | 77.96% | 2,025/2,494 (81.19%) |
| Full Damage | 240 / 1,153 | 481,116 | 68.03% | 101,209 | 74.04% | 964/1,297 (74.33%) |

The last column conditions on world rounds with at least two distinct actors whose native direct attack/cast frames contain enemy HP loss. A shared recipient means the same stable enemy body ID loses HP during frames associated with at least two of those actors in that round. This avoids nearest-target guessing. It does not identify a chosen primary target, a common private objective, or causal damage from every secondary effect. The primary measure excludes delayed spell/environment frames; those frames remain in the trace. An AoE frame may have several recipients.

## Top-four head-to-head: local numbers, persistence and shared attacks

| Team | Contact grouped / contact body-rounds | Local ally count > enemy count | Local ally count < enemy count | Shared recipient / all PvP team-rounds | Shared recipient / multi-attacker rounds |
| --- | --- | --- | --- | --- | --- |
| Fish | 165,712/204,405 (81.07%) | 127,888/204,405 (62.57%) | 27,380/204,405 (13.39%) | 4,208/24,093 (17.47%) | 4,208/4,986 (84.40%) |
| Sneaky | 70,496/91,944 (76.67%) | 53,476/91,944 (58.16%) | 11,800/91,944 (12.83%) | 1,208/9,949 (12.14%) | 1,208/1,522 (79.37%) |
| Mite | 354,612/419,273 (84.58%) | 275,789/419,273 (65.78%) | 50,402/419,273 (12.02%) | 7,804/54,805 (14.24%) | 7,804/9,833 (79.37%) |
| Univardisty | 257,752/329,594 (78.20%) | 186,444/329,594 (56.57%) | 51,329/329,594 (15.57%) | 8,315/48,101 (17.29%) | 8,315/10,034 (82.87%) |

Local numbers are centered on each focal body. Radius overlap, terrain, range, cooldowns, health, items, turn order and personal vision can make a numerical edge unusable. The same engagement may contribute several body-rounds and both sides. These percentages are exposure-weighted descriptions, not independent engagements or causal win estimates.

| Team | Local ally count1 /2 /≥3 (field body-rounds) | Other draft pick≤6 | Recipient overlap in consecutive own PvP rounds | Similar pair heading / nearby pair transitions with both moving |
| --- | --- | --- | --- | --- |
| Fish | 238,378 / 258,803 / 489,604 | 72.48% | 10,822/11,934 (90.68%) | 149,356/342,739 (43.58%) |
| Sneaky | 127,658 / 112,780 / 167,507 | 65.98% | 3,523/3,809 (92.49%) | 51,367/108,965 (47.14%) |
| Mite | 414,337 / 458,091 / 986,952 | 74.00% | 26,331/28,245 (93.22%) | 264,186/596,460 (44.29%) |
| Univardisty | 406,952 / 405,039 / 588,243 | 68.36% | 23,457/25,101 (93.45%) | 149,939/382,735 (39.18%) |

Recipient overlap counts consecutive world-round pairs in which the same actor has enemy HP-loss recipients in both; the recipient sets intersect. It is a narrow observed persistence proxy, not proof of a target lease, deliberate commitment or good target selection. Similar heading requires both members of a previously nearby pair to move between consecutive fixed snapshots, cosine≥0.8 and continued separation≤6; it does not establish a shared route plan. Raw zigzags/reversals are not labeled indecision because obstacles, threat, ability timing and deadlines are not counterfactually observed.

The broad reinforcement counter is kept as a diagnostic only: a 1:1 geometric contact anchor is followed within three snapshots by the same focal and enemy with at least two allies versus one enemy. Intermediate contact may lapse. Its HP-loss co-occurrence window runs from anchor through reinforcement+1 and does not require post-arrival or same-round action; anchors overlap. The two curated reinforcement episodes below satisfy stricter continuous-contact, actual approach and post-join same-round evidence.

## Economic splitting, rewards and banking

| Team | Disjoint multi-camp work / any camp-work rounds | Single recipient / confirmed camp rewards | Reward has recipient absent from observed direct damagers | Submission with nearby ally / all submissions | Submission with nearby enemy / all submissions |
| --- | --- | --- | --- | --- | --- |
| Fish | 21,333/113,504 (18.79%) | 11,614/11,738 (98.94%) | 712/11,738 (6.07%) | 4,344/7,824 (55.52%) | 1,115/7,824 (14.25%) |
| Sneaky | 13,573/54,130 (25.07%) | 4,322/4,483 (96.41%) | 397/4,483 (8.86%) | 2,044/3,480 (58.74%) | 571/3,480 (16.41%) |
| Mite | 47,299/226,433 (20.89%) | 20,993/21,383 (98.18%) | 1,901/21,383 (8.89%) | 11,174/18,461 (60.53%) | 3,031/18,461 (16.42%) |
| Univardisty | 34,133/162,230 (21.04%) | 15,474/16,049 (96.42%) | 1,092/16,049 (6.80%) | 6,843/11,648 (58.75%) | 1,551/11,648 (13.32%) |

Multi-camp work means distinct camp-group IDs suffer HP loss during direct same-team attack/cast frames in one world round, with each actor observed on only one of those groups that round. The commands remain sequential. “Single recipient” comes from exact positive gold/gem changes at native capture resolution, not inferred proximity. A recipient outside the observed direct damager set may reflect role splitting, delayed effects or other unmeasured contribution; it is not automatic proof of a planned handoff. A submission is a positive score change with a unique personal gem decrement. Nearby bodies are geometric context, not verified escorts or attackers.

## Nine maps, fixed roster sizes and champion conditioning

The following top-four head-to-head table shows field-support percentages per team, followed by total recorded direct PvP team-rounds for those four appearances. Full per-map numerators/denominators are in `map-team-summary.csv`; one game contributes to each participating team, so the final column is a count of team-rounds, not unique engagements.

| Map | Fish ally≤6 | Sneaky ally≤6 | Mite ally≤6 | Univardisty ally≤6 | Top4 PvP team-rounds |
| --- | --- | --- | --- | --- | --- |
| collision | 75.73% | 64.42% | 79.00% | 66.62% | 12,216 |
| corners | 81.42% | 84.97% | 86.62% | 78.55% | 56,339 |
| elkring | 85.25% | 80.85% | 80.89% | 73.47% | 20,376 |
| expanse | 49.86% | 25.86% | 64.84% | 36.36% | 16 |
| interlock | 78.90% | 69.98% | 76.78% | 77.59% | 15,448 |
| lanes | 73.35% | 69.38% | 75.12% | 73.65% | 13,570 |
| monolith | 67.20% | 55.98% | 61.09% | 59.90% | 5,149 |
| packs | 68.88% | 61.46% | 71.62% | 62.61% | 13,817 |
| rows | 80.70% | 80.43% | 80.16% | 79.29% | 17 |

Rows is a useful counterexample to “grouped means attacking”: field support is about79–81%, while the top-four appearances contain only17 direct PvP team-rounds there. Expanse has only16 such team-rounds across the top-four head-to-head cohort; Fish and Sneaky have none. Corners has much more enemy-contact/combat exposure. These observed map patterns do not establish geometric causes or adaptive code: map, draft, chronology, opponent, private versions and game duration remain entangled.

Draft slots and physical bodies differ when Cassi/Issac occupies one pick but two bodies. The h2h strata are explicitly exported in `roster-size-summary.csv`; Fish and Mite use3/4,4/5 and5/6 slot/body combinations, while Sneaky and Univardisty also have some rosters without the pair. The primary radius6 support pattern remains when the pair is collapsed to one draft pick; body support and other-pick support are both shown above. No team-wide ranking is interpreted as a causal effect of grouping.

| Team / champion | Body appearances | Field body-rounds | Another ally≤6 | Own PvP-damaging actor-rounds | Own camp-damaging actor-rounds | Actual submission events |
| --- | --- | --- | --- | --- | --- | --- |
| Fish / Issac | 437 | 184,143 | 72.62% | 3,485 | 39,098 | 1,810 |
| Fish / Stellar | 376 | 170,983 | 78.83% | 6,575 | 38,717 | 1,217 |
| Sneaky / Issac | 189 | 62,651 | 66.99% | 791 | 15,250 | 669 |
| Sneaky / Stellar | 220 | 83,757 | 70.46% | 3,104 | 19,800 | 647 |
| Mite / Issac | 839 | 345,388 | 80.77% | 7,605 | 89,328 | 3,873 |
| Mite / Stellar | 594 | 247,111 | 80.18% | 12,453 | 46,564 | 2,367 |
| Univardisty / Issac | 454 | 183,213 | 70.44% | 3,246 | 41,439 | 1,610 |
| Univardisty / Stellar | 557 | 243,307 | 73.24% | 12,263 | 47,049 | 2,036 |

These action counts describe what each champion did. They do not assign hidden fighter/farmer/escort roles from position alone. Some bodies perform more than one task within a round. All team×champion×map tables are exported, with explicit sample counts; even those comparisons retain chronology/opponent/build confounding. Spawn, dead, channel and owner-turn counters remain available in the body/game ledgers, rather than being treated as ordinary combat availability.

## Recent and early-game sensitivity

The latest slice selects the newest two API IDs per unordered pair×map×game kind by timestamp then ID, before raw deduplication:1,513 IDs / 1,174 raw streams. Its top-four head-to-head intersection is 133 raw streams, with Fish 62/Sneaky 64/Mite 84/Univardisty 56 team appearances. “Latest” is a relative stratified slice, not a single known private code version.

| Team | All h2h field support≤6 | Latest h2h field support≤6 | All h2h grouped contact | Latest h2h grouped contact | Early R25–150 field support: all h2h → latest h2h |
| --- | --- | --- | --- | --- | --- |
| Fish | 75.84% | 74.55% | 81.07% | 80.38% | 79.60% → 77.29% |
| Sneaky | 68.71% | 68.37% | 76.67% | 77.28% | 68.74% → 67.99% |
| Mite | 77.72% | 77.16% | 84.58% | 84.51% | 78.33% → 77.60% |
| Univardisty | 70.94% | 72.17% | 78.20% | 80.41% | 75.52% → 76.63% |

Every one of the 2,119 streams has all 126 fixed-stage snapshots R25–150; available/full-window subsets therefore coincide. The early comparison reduces differences arising solely from late-game duration. The main proximity patterns persist, but exact rates and combat exposures move; no invariance or current-policy identity is claimed. Complete early counts and direct-focus denominators are in `early-window-summary.json` and its team/body CSVs. Radius3/8 results are retained in the main summary; the six-tile threshold is a descriptive scale, not a universal assistance range.

## Thirteen episodes, including an adverse continuation

All cases in `cases/index.json` bind raw, compressed bundle and native trace hashes, source URL and same-raw aliases. They include terrain buffers plus printable map rows, champion types, exact HP/positions, sequential input/seq actions, actual displacement routes, captures/submissions/deaths and context snapshots. Selection illustrates mechanisms and counterexamples; it is not a representative success-rate sample.

| Case | Match / map / round | Observed mechanism |
| --- | --- | --- |
| 01 one_to_two_vs_one | `d44a2517-49ab-42f3-bb62-c791cf1d46a3` / packs / R131 | continuous contact; actual helper approach; post-join same-round recipient HP loss |
| 02 one_to_two_vs_one | `781a2be6-bfc5-4f00-a0fe-5dd53c33c798` / interlock / R578 | continuous contact; actual helper approach; post-join same-round recipient HP loss |
| 03 larger_joint_attack | `9c830c09-e7bf-4032-ad35-4cadfac6c49f` / corners / R40 | larger joint attack |
| 04 larger_joint_attack | `aa1d9761-7dfe-474d-a25c-8b32ca0d0d60` / corners / R92 | larger joint attack |
| 05 split_camp_work | `d0ec9528-2d31-4fc8-9ba4-aaad9dbc2be9` / corners / R22 | split camp work |
| 06 capture_handoff | `d869ea34-1654-4d9a-beed-65612cb56f43` / collision / R70 | recipient absent from observed direct damagers; planned handoff unproved |
| 07 contested_group_submission | `fb3e09a7-5bd4-4f27-8a67-1bff71093f7c` / corners / R43 | contested group submission |
| 08 geometric_disengagement | `3660dd73-c053-40cf-90b0-7b79dc4a4bfc` / packs / R219 | separation from prior enemy positions; actual contact persists |
| 09 shared_attack_adverse_continuation | `8bc79c59-04bf-4e79-bd5b-75314eade848` / interlock / R273 | recipient survives two snapshots; an attacker dies in the continuation |
| 10 larger_joint_attack | `f9f576b4-c0a0-42d0-b864-c160bf7e48ea` / corners / R26 | larger joint attack |
| 11 larger_joint_attack | `c58b2e34-29f8-47ef-8e18-a0edc1dd6317` / corners / R32 | larger joint attack |
| 12 split_camp_work | `9f57b5a5-2065-4bb5-b134-70eceb78aee6` / lanes / R34 | split camp work |
| 13 collective_geometric_withdrawal | `8dfb72d3-26f3-422a-ba5a-5311b4f3aa71` / corners / R380 | two allies separate from actual enemies and stay connected; intent unproved |

Case 01, Fish versus Sneaky on packs, is a concrete stronger sequence. At the first R131 snapshot, Fish Ren 4 at (15,4) is in radius6 contact with Sneaky Varg 3 at (16,3); Fish Stellar 5 at (22,9) is outside Ren’s support radius. During R131, Stellar’s actual move is input 2064/seq 13464, (22,9)→(21,8). The first R132 snapshot now has both Fish bodies within radius6 of Ren while the same enemy remains. During R132, input 2074/seq 13537 Ren’s basic-attack frame records Varg HP 832→829.5, then input 2077/seq 13555 Stellar’s cast frame records 829.5→689.5. These are distinct draft picks with a real approach and shared recipient after joining; private coordination intent and immediate prior visibility are not established. R132 snapshot HP precedes those R132 actions; R133 reflects the resulting 689.5 HP.

Case 09 prevents an overly positive reading. In Fish versus Sneaky on interlock, three Fish actors share an enemy HP-loss recipient during R273. That enemy is still alive with 102 HP at the first R275 snapshot; Fish attacker 7 then dies during R275 with 22 gems. Joint damage did not guarantee a kill or safety over that interval. This does not prove the group decision was wrong or caused the death. Case 06 separately preserves all observed camp HP-loss frames since the prior reward to examine the timing behind a handoff-like recipient change.

Case 07 shows different actual tasks within a nearby formation. In Fish versus Sneaky on corners, Fish Stellar 7 remains at (34,33), channeling with 48 gems at the R42/R43 snapshots while Ren 6, Cassi 8 and Issac 9 have attack frames reducing Sneaky Willow 4 HP 185→75 during R42. During R43, Ren’s input 1080 reduces 75→35; Stellar’s native channel completion at input 1083/seq 6971 submits 48 score, then its input 1084 basic-attack frame records Willow 35→0. Ryth 10’s input 1094 cast has a different recipient, Sneaky Stellar 2, HP 750→650. These are observed banking, attacks and a second combat recipient in sequential frames; a common private role assignment is not established.

Case 08 is only separation from prior enemy positions, not verified contact breaking: the enemy can follow, and actual radius6 contact persists in that episode. The stronger Case 13 adds actual-current-enemy separation. Univardisty versus Sneaky on corners, `8dfb72d3-26f3-422a-ba5a-5311b4f3aa71`: during R380, Stellar 6 moves (35,37)→(36,36), input 10251/seq 63799, and Tavi 9 moves (36,37)→(35,36), input 10265/seq 63857. For both, nearest actual enemy distance increases 5→7 at the R381 snapshot; their own displacement also increases distance from prior enemy positions 5→6. They remain alive and within radius6 of one another through R382, at (37,35)/(34,35). Stellar is 205/750 HP at departure and receives 48 gems by R381, so the continuation also contains an economic reward; it cannot be attributed solely to a deliberate retreat. This case came from a bounded search of existing candidate traces, not a full-cohort retreat-frequency estimate.

## Audit and limitations

`current-audit.json` passes with zero errors across 2,119 source-bound traces and 21,312 final body appearances. All raw hashes, complete sampled rosters, unique/sorted round samples and final native–API roster/type/team/gold/gems/earned gold/KDA/score/round checks pass. Six native workers finished in 388.94 seconds; cached aggregation used six workers and bounded per-game parsing. No bot simulation, bot modification or new cohort acquisition occurred.

The evidence measures observed formations, motion, damage-recipient associations and resource resolution. It cannot recover a private grouping/role algorithm, a target lease, intention, unobserved rejected commands, opportunity cost, or a causal effect on winning. Geometry is not line of sight, walkable reach or readiness. Actual movement paths establish only observed traversal; no hypothetical shortest-path model is substituted. Sparse fixed-stage world snapshots can miss intra-round regrouping; native action/HP frames remain exact and sequential. Overlapping body-rounds, repeated maps/opponents, chronology and unavailable private versions prevent treating rows as independent trials.

Core summary SHA256: `a396b2b4107d43a23bd683d6acfb569aedec21ead6f0e246f9604ca53b5e8856`. Early summary SHA256: `a905b830619228f726929d6d85a036d0e7bfc7e3c971fcf372f6e52cae9e48c5`. Full tables: `team-summary.csv`, `map-team-summary.csv`, `roster-size-summary.csv`, `conditional-role-summary.csv`, `team-game-metrics.{csv,jsonl.gz}`, `body-game-metrics.{csv,jsonl.gz}`, `camp-rewards.{csv,jsonl.gz}`, `submissions.{csv,jsonl.gz}`, `shared-recipient-rounds.{csv,jsonl.gz}`, `early-window-summary.json`, early team/body CSVs, and `cases/index.json`.
