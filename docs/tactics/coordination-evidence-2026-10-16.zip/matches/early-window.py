"""Cached round/action supplement. No native replay or bot execution."""
from pathlib import Path
from collections import Counter,defaultdict
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,json,gzip,csv,subprocess,sys,hashlib
ROOT=Path(__file__).resolve().parent;WARD=ROOT.parents[1]/'ward-research'
p=argparse.ArgumentParser();p.add_argument('--worker',type=int);p.add_argument('--workers',type=int,default=6);a=p.parse_args()
def writecsv(path,rows):
 fields=list(dict.fromkeys(k for r in rows for k in r))
 numeric={k for r in rows for k,v in r.items()if isinstance(v,(int,float))and not isinstance(v,bool)}
 with path.open('w',newline='',encoding='utf8')as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows({**{k:0 for k in numeric},**r}for r in rows)
def summarize(rows,keys):
 buckets=defaultdict(list)
 for row in rows:buckets[tuple(row[k]for k in keys)].append(row)
 result=[]
 for key,values in sorted(buckets.items()):
  sums=Counter()
  for row in values:
   sums.update({k:v for k,v in row.items()if isinstance(v,(float,int))and not isinstance(v,bool)and k not in ['rank','side','body','rosterBodies','draftSlots']})
  result.append({**dict(zip(keys,key)),'streams':len({r['match_id']for r in values}),'fullWindowStreams':len({r['match_id']for r in values if r['fullWindow']}),**dict(sums)})
 return result
if a.worker is None:
 def run(i):
  with(ROOT/'parts'/f'early-{i}.log').open('w',encoding='utf8')as f:r=subprocess.run([sys.executable,__file__,'--worker',str(i),'--workers',str(a.workers)],stdout=f,stderr=subprocess.STDOUT)
  return r.returncode
 with ThreadPoolExecutor(max_workers=a.workers)as pool:codes=list(pool.map(run,range(a.workers)))
 if any(codes):raise SystemExit('early-window worker failed')
 games=[];bodies=[]
 for i in range(a.workers):
  d=json.loads((ROOT/'parts'/f'early-{i}.json').read_bytes());games.extend(d['games']);bodies.extend(d['bodies'])
 writecsv(ROOT/'early-window-team-games.csv',games);writecsv(ROOT/'early-window-body-games.csv',bodies)
 summary={'range':[25,150],'definition':'First phase10 complete-roster snapshot for each available world round R25–150 inclusive. Full-window sensitivity requires all126 snapshots. Available-window rows right-censored by game duration. Proximity excludes dead/own-spawn on both sides; channels separately counted. Focus uses exact direct attack/cast-frame enemy HP-loss recipients, not intent.','sourceUniqueManifestSha256':hashlib.sha256((WARD/'matches/manifest-current-unique.json').read_bytes()).hexdigest(),'rawStreams':len({r['raw_sha256']for r in games}),'fullWindowRawStreams':len({r['raw_sha256']for r in games if r['fullWindow']}),'cohorts':{}}
 for name,pred in [('unique',lambda r:True),('top4_h2h',lambda r:r['top4_h2h']),('latest',lambda r:r['latest_slice']),('latest_h2h',lambda r:r['latest_slice']and r['top4_h2h'])]:
  gs=[r for r in games if pred(r)];bs=[r for r in bodies if pred(r)];summary['cohorts'][name]={'per_team':summarize(gs,['rank','team']),'full_window_per_team':summarize([r for r in gs if r['fullWindow']],['rank','team']),'per_map_team':summarize(gs,['rank','team','map']),'per_roster_size_team':summarize(gs,['rank','team','draftSlots','rosterBodies']),'per_champion_team':summarize(bs,['rank','team','champion'])}
 (ROOT/'early-window-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps({'rawStreams':summary['rawStreams'],'fullWindowRawStreams':summary['fullWindowRawStreams'],'games':len(games),'bodies':len(bodies)}));raise SystemExit
manifest=json.loads((WARD/'matches/manifest-current-unique.json').read_bytes());ladder=json.loads((WARD/'acquisition/api/ladder.json').read_bytes());rank={t['teamId']:t for t in ladder['teams']};full=json.loads((WARD/'acquisition/manifest-native.json').read_bytes());strata=Counter();latest=set()
for r in sorted(full['requests'],key=lambda r:(r['created_at'],r['id']),reverse=True):
 key=(tuple(sorted(t['teamId']for t in r['teams'].values())),r['map'],r['kind'])
 if strata[key]<2:latest.add(r['raw_sha256']);strata[key]+=1
games=[];bodies=[]
for ix,r in enumerate(manifest['requests'][a.worker::a.workers]):
 g=json.loads(gzip.decompress((ROOT/'current'/f"{r['id']}.coord.json.gz").read_bytes()));roster={c['id']:c for c in g['roster']};teams={id:c['team']for id,c in roster.items()};bs={id:Counter()for id in roster};ts=[Counter(),Counter()];window=[w for w in g['rounds']if 25<=w['r']<=150];complete=len(window)==126
 def distance(x,y):return max(abs(x[1]-y[1]),abs(x[2]-y[2]))
 def inside(c,b):return b[0]<=c[1]<b[2]and b[1]<=c[2]<b[3]
 for w in window:
  field=[c for c in w['c']if c[5]and not inside(c,g['geometry']['spawn'][teams[c[0]]])]
  for side in [0,1]:ts[side]['sampledRounds']+=1
  for c in field:
   side=teams[c[0]];b=bs[c[0]];b['fieldBodyRounds']+=1
   if c[9]:b['fieldChannelBodyRounds']+=1
   allies=[x for x in field if teams[x[0]]==side and distance(c,x)<=6];enemies=[x for x in field if teams[x[0]]!=side and distance(c,x)<=6];picks={('duo'if roster[x[0]]['type']in[3,4]else str(x[0]))for x in allies}
   if len(allies)>=2:b['withAlly6BodyRounds']+=1
   if len(picks)>=2:b['withOtherPick6BodyRounds']+=1
   if enemies:
    b['contact6BodyRounds']+=1
    if len(allies)>=2:b['groupedContact6BodyRounds']+=1
    if len(allies)>len(enemies):b['advantageContact6BodyRounds']+=1
    if len(allies)<len(enemies):b['outnumberedContact6BodyRounds']+=1
 pvp=defaultdict(lambda:defaultdict(lambda:defaultdict(set)))
 for d in g['damage']:
  if not(25<=d['r']<=150 and d['source']and d['source']['id']in roster and d['step'][0]==10 and d['step'][1]in[5,6]and d['step'][2]==1 and d['step'][4]==0):continue
  actor=d['source']['id'];side=teams[actor]
  for loss in d['losses']:
   if loss[0]==1 and loss[2]!=side:pvp[side][d['r']][loss[1]].add(actor)
 for side in [0,1]:
  for rnd,targets in pvp[side].items():
   ts[side]['pvpTeamRounds']+=1
   if len(set().union(*targets.values()))>=2:ts[side]['multiAttackerPvpTeamRounds']+=1
   if any(len(x)>=2 for x in targets.values()):ts[side]['sharedRecipientPvpTeamRounds']+=1
 ranks=[rank[t['teamId']]['rank']for t in r['teams'].values()]
 for side in [0,1]:
  rr=rank[r['teams']['a'if side==0 else'b']['teamId']];meta={'match_id':r['id'],'raw_sha256':r['raw_sha256'],'map':r['map'],'rank':rr['rank'],'team':rr['name'],'side':side,'draftSlots':g['draftCounts'][side],'rosterBodies':sum(t==side for t in teams.values()),'top4_h2h':max(ranks)<=4,'latest_slice':r['raw_sha256']in latest,'fullWindow':complete};total=Counter()
  for id,b in bs.items():
   if teams[id]!=side:continue
   total.update(b);bodies.append({**meta,'body':id,'champion':roster[id]['name'],**dict(b)})
  games.append({**meta,**dict(total),**dict(ts[side])})
 if(ix+1)%200==0:print('Window',a.worker,ix+1,flush=True)
(ROOT/'parts'/f'early-{a.worker}.json').write_text(json.dumps({'games':games,'bodies':bodies},ensure_ascii=False,separators=(',',':')),encoding='utf8')
