"""Curate source-bound mechanisms from compact traces, not match outcomes."""
from pathlib import Path
from collections import defaultdict
from functools import lru_cache
import json,gzip,hashlib,base64
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'cases';OUT.mkdir(exist_ok=True);WARD=ROOT.parents[1]/'ward-research'
manifest=json.loads((WARD/'matches/manifest-current-unique.json').read_bytes());requests={r['id']:r for r in manifest['requests']};ladder=json.loads((WARD/'acquisition/api/ladder.json').read_bytes());rank={t['teamId']:t for t in ladder['teams']};allrequests=json.loads((WARD/'acquisition/manifest-native.json').read_bytes())['requests'];aliases=defaultdict(list)
for r in allrequests:aliases[r['raw_sha256']].append(r['id'])
pool=defaultdict(list)
for file in [ROOT/'case-candidates.json',*sorted((ROOT/'parts').glob('part-*/case-candidates.json'))]:
 for kind,rows in json.loads(file.read_bytes()).items():
  for row in rows:
   if row not in pool[kind]:pool[kind].append(row)
def priority(c):
 r=requests[c['match_id']];rr=[rank[t['teamId']]['rank']for t in r['teams'].values()];return(max(rr)>4,min(rr)>4,max(rr),c['round'])
for kind in pool:pool[kind].sort(key=priority)
@lru_cache(maxsize=8)
def load(mid):return json.loads(gzip.decompress((ROOT/'current'/f'{mid}.coord.json.gz').read_bytes()))
def distance(a,b):return max(abs(a[1]-b[1]),abs(a[2]-b[2]))
def inside(c,b):return b[0]<=c[1]<b[2]and b[1]<=c[2]<b[3]
def dmg(g,r,target):
 result=set()
 for e in g['damage']:
  if e['r']==r and e['source']and e['step'][0]==10 and e['step'][1]in[5,6]and e['step'][2]==1 and e['step'][4]==0 and any(x[0]==1 and x[1]==target for x in e['losses']):result.add(e['source']['id'])
 return result
def strong(c):
 g=load(c['match_id']);rs={w['r']:w for w in g['rounds']};roster={x['id']:x for x in g['roster']};focal=c['focal'];target=c['target'];start=c['round'];end=c['afterRound'];continuous=True
 for rnd in range(start,end+1):
  cs={x[0]:x for x in rs.get(rnd,{}).get('c',[])};a=cs.get(focal);b=cs.get(target)
  if not(a and b and a[5]and b[5]and distance(a,b)<=6):continuous=False
 if not continuous:return None
 for rnd in range(end,end+2):
  actors=dmg(g,rnd,target);helpers=set(c['helpers'])&actors
  helpers={id for id in helpers if not(roster[id]['type']in[3,4]and roster[focal]['type']in[3,4])}
  moved={a['actor']for a in g['actions']if start<=a['r']<end and a['kind']==4 and a['before'][1:3]!=a['after'][1:3]}
  helpers&=moved
  if focal in actors and helpers:return{'continuousFocalEnemyRadius6Contact':True,'sameRoundPostJoinRecipientHPFrames':rnd,'focal':focal,'postJoinHelpersWithActualApproachMovement':sorted(helpers),'postJoinDamagingActors':sorted(actors),'distinctDraftPickHelpers':True}
 return None
selected=[];used=set()
def choose(kind,count=1,validator=None):
 picked=0;sides=set()
 for c in pool[kind]:
  g=load(c['match_id']);r=requests[c['match_id']];teamid=r['teams']['a'if c['side']==0 else'b']['teamId']
  if c['match_id']in used or teamid in sides:continue
  facts=validator(c)if validator else{}
  if facts is None:continue
  selected.append({'kind':kind,'candidate':c,'facts':facts});used.add(c['match_id']);sides.add(teamid);picked+=1
  if picked>=count:break
choose('one_to_two_vs_one',2,strong);choose('larger_joint_attack',2);choose('split_camp_work',1);choose('capture_handoff',1);choose('contested_group_submission',1);choose('geometric_disengagement',1)
# Deliberately retain an observed adverse local continuation without blaming grouping.
negative=None
for c in pool['larger_joint_attack']:
 g=load(c['match_id']);start=c['round'];target=c['target'];rs={w['r']:w for w in g['rounds']};after=rs.get(start+2);targetAfter=next((x for x in after['c']if x[0]==target),None)if after else None;deaths=[d for d in g['deaths']if start<=d['r']<=start+2 and d['id']in c['actors']]
 if targetAfter and targetAfter[5]and deaths:
  negative={'kind':'shared_attack_adverse_continuation','candidate':{**c,'afterRound':start+2},'facts':{'enemyRecipientAliveTwoSnapshotsLater':True,'recipientHPAfter2':targetAfter[3],'attackerDeathsWithin2WorldRounds':deaths,'inference':'Joint HP-loss frames and geometric grouping do not guarantee a kill or safety. This continuation does not establish that the group decision was wrong or caused deaths.'}};break
if negative:selected.append(negative)
# Retain examples from both other top-four teams as well as the top-two duel.
for wanted in [3,4]:
 for c in pool['larger_joint_attack']:
  rr=requests[c['match_id']];acting=rank[rr['teams']['a'if c['side']==0 else'b']['teamId']]['rank'];ranks=[rank[t['teamId']]['rank']for t in rr['teams'].values()]
  if acting==wanted and max(ranks)<=4 and c['match_id']not in used:selected.append({'kind':'larger_joint_attack','candidate':c,'facts':{}});used.add(c['match_id']);break
for c in sorted(pool['split_camp_work'],key=lambda c:-len(c['groups'])):
 rr=requests[c['match_id']];ranks={rank[t['teamId']]['rank']for t in rr['teams'].values()}
 if ranks=={3,4}and c['match_id']not in used:selected.append({'kind':'split_camp_work','candidate':c,'facts':{}});break
if(ROOT/'extra-case-candidates.json').exists():selected.extend(json.loads((ROOT/'extra-case-candidates.json').read_bytes()))
index=[]
for i,entry in enumerate(selected):
 c=entry['candidate'];g=load(c['match_id']);r=requests[c['match_id']];start=max(1,c['round']-3);end=max(c.get('afterRound',c['round'])+4,c['round']+4);roster={x['id']:x for x in g['roster']};campids={x['id']for x in g['camps']if x['group']==c.get('group')};contributorFrames=[]
 if entry['kind']=='capture_handoff':
  prior=max((x['seq']for x in g['captures']if x['group']==c['group']and x['seq']<c['seq']and x['recipients']),default=-1)
  contributorFrames=[e for e in g['damage']if prior<e['seq']<c['seq']and any(x[0]==2 and x[1]in campids for x in e['losses'])];start=max(1,min((e['r']for e in contributorFrames),default=start)-1)
 frames=[w for w in g['rounds']if start<=w['r']<=end];actions=[a for a in g['actions']if start<=a['r']<=end];damage=[e for e in g['damage']if start<=e['r']<=end];paths=defaultdict(list)
 for a in actions:
  if a['before'][1:3]!=a['after'][1:3]:paths[a['actor']].append({'r':a['r'],'input':a['input'],'seq':a['seq'],'kind':a['kind'],'before':a['before'][1:3],'after':a['after'][1:3]})
 geometry=g['geometry'];width,height,stride=geometry['width'],geometry['height'],geometry['stride'];planes={k:base64.b64decode(v)for k,v in geometry['planes'].items()}
 def has(name,x,y):return bool(planes[name][((y>>3)*stride+(x>>3))*8+(y&7)]&(1<<(x&7)))
 rows=[''.join('#'if has('Wall',x,y)else'O'if has('Hole',x,y)else'A'if has('Altar',x,y)else'B'if has('Bush',x,y)else'.'for x in range(width))for y in range(height)]
 output={'case':entry['kind'],'match_id':r['id'],'map':r['map'],'created_at':r['created_at'],'representativeSourceRawSha256':r['raw_sha256'],'sourceTraceSha256':hashlib.sha256((ROOT/'current'/f"{r['id']}.coord.json.gz").read_bytes()).hexdigest(),'sourceBundleSha256':r['bundle_sha256'],'sourceBundleURL':r['bundle_url'],'sameRawMatchAliases':aliases[r['raw_sha256']],'engineSha256':g['engine_sha256'],'teams':[{**t,'rank':rank[t['teamId']]['rank'],'name':rank[t['teamId']]['name'],'side':0 if side=='a' else 1}for side,t in r['teams'].items()],'candidate':c,'episodeFacts':entry['facts'],'range':[start,end],'geometry':geometry,'mapRows':rows,'mapLegend':{'.':'floor','B':'bush','#':'wall','O':'hole','A':'altar'},'roster':g['roster'],'draftCounts':g['draftCounts'],'camps':g['camps'],'columns':g['columns'],'roundSnapshots':frames,'actions':actions,'hpLossFrames':damage,'deaths':[d for d in g['deaths']if start<=d['r']<=end],'captureTransitions':[e for e in g['captures']if start<=e['r']<=end],'submissions':[e for e in g['submissions']if start<=e['r']<=end],'observedDisplacementPaths':dict(paths),'allObservedCampHPFramesSincePriorReward':contributorFrames,'nativeFinal':g['final'],'limitations':['Omniscient reconstruction; personal/team observation or private intent is not established.','Actual ordinary movement and displacements provide observed routes; no shortest walkable route or immediate help availability is inferred.','HP-loss recipient associations can include secondary effects; they do not establish chosen primary targets.','Round snapshots have fixed native phase10 stage; action frames remain sequential and carry exact input/seq.','Episodes selected for mechanisms and counterexamples, not representative frequency or causal win effects.']}
 filename=f'{i+1:02}-{entry["kind"]}-{r["id"]}.json';p=OUT/filename;p.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf8');index.append({'file':filename,'case':entry['kind'],'match_id':r['id'],'map':r['map'],'round':c['round'],'afterRound':c.get('afterRound'),'side':c['side'],'teams':[(t['rank'],t['name'])for t in output['teams']],'episodeFacts':entry['facts'],'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(OUT/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(index,ensure_ascii=True,indent=2))
