"""Bounded search of existing episode-candidate traces for collective separation."""
from pathlib import Path
from collections import defaultdict
import json,gzip
ROOT=Path(__file__).resolve().parent;WARD=ROOT.parents[1]/'ward-research';m=json.loads((WARD/'matches/manifest-current-unique.json').read_bytes());requests={r['id']:r for r in m['requests']};ladder=json.loads((WARD/'acquisition/api/ladder.json').read_bytes());rank={t['teamId']:t['rank']for t in ladder['teams']};ids=[]
for p in [ROOT/'case-candidates.json',*sorted((ROOT/'parts').glob('part-*/case-candidates.json'))]:
 for c in json.loads(p.read_bytes()).get('geometric_disengagement',[]):
  if c['match_id']not in ids and max(rank[t['teamId']]for t in requests[c['match_id']]['teams'].values())<=4:ids.append(c['match_id'])
def distance(a,b):return max(abs(a[1]-b[1]),abs(a[2]-b[2]))
def inside(c,b):return b[0]<=c[1]<b[2]and b[1]<=c[2]<b[3]
found=[];examined=0
for mid in ids[:60]:
 g=json.loads(gzip.decompress((ROOT/'current'/f'{mid}.coord.json.gz').read_bytes()));ro={c['id']:c for c in g['roster']};rs={w['r']:w for w in g['rounds']};moves=defaultdict(set)
 for a in g['actions']:
  if a['kind']==4 and a['before'][1:3]!=a['after'][1:3]:moves[a['r']].add(a['actor'])
 examined+=1
 for rnd,w in rs.items():
  if rnd+1 not in rs:continue
  field=[c for c in w['c']if c[5]and not inside(c,g['geometry']['spawn'][ro[c[0]]['team']])];nextfield=[c for c in rs[rnd+1]['c']if c[5]and not inside(c,g['geometry']['spawn'][ro[c[0]]['team']])];nxt={c[0]:c for c in nextfield};eligible=[]
  for c in field:
   id=c[0];side=ro[id]['team'];en=[x for x in field if ro[x[0]]['team']!=side];enafter=[x for x in nextfield if ro[x[0]]['team']!=side]
   if id not in nxt or id not in moves[rnd]or not en or not enafter:continue
   a=nxt[id];before=min(distance(c,e)for e in en);after=min(distance(a,e)for e in enafter);frozen=min(distance(a,e)for e in en)
   if before<=6 and after>=7 and after>=before+2 and frozen>before:eligible.append((c,a,before,after,frozen))
  for i,x in enumerate(eligible):
   for y in eligible[i+1:]:
    aid,bid=x[0][0],y[0][0]
    if ro[aid]['team']!=ro[bid]['team']or distance(x[0],y[0])>6 or distance(x[1],y[1])>6 or(ro[aid]['type']in[3,4]and ro[bid]['type']in[3,4]):continue
    if any(d['id']in[aid,bid]and rnd<=d['r']<=rnd+2 for d in g['deaths']):continue
    later={c[0]:c for c in rs.get(rnd+2,{}).get('c',[])if c[5]}
    if aid not in later or bid not in later or distance(later[aid],later[bid])>6:continue
    found.append({'kind':'collective_geometric_withdrawal','candidate':{'match_id':mid,'map':g['map'],'side':ro[aid]['team'],'round':rnd,'afterRound':rnd+1,'actors':[aid,bid],'category':'two distinct-pick allies move away from prior enemies, actual nearest enemy distances also grow and exceed6, remain alive and connected'},'facts':{'actors':[{'id':c[0],'name':ro[c[0]]['name'],'before':c[1:3],'after':a[1:3],'nearestEnemyDistanceBefore':b,'nearestEnemyDistanceAfter':e,'nearestPriorEnemyPositionDistanceAfter':f}for c,a,b,e,f in[x,y]],'ordinaryDisplacementsDuringRound':rnd,'connectedRadius6BeforeAndThroughSnapshot':rnd+2,'positionsTwoSnapshotsLater':{str(id):later[id][1:3]for id in[aid,bid]},'noActorDeathThroughRound':rnd+2,'inference':'Observed collective separation; a deliberate retreat/regroup command, shared threat knowledge, optimality and causality are not established.'}})
    break
   if found:break
  if found:break
 if found:break
report={'candidateTraceLimit':60,'eligibleCandidateTraces':len(ids),'examinedTraces':examined,'found':found};(ROOT/'withdrawal-search.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
if found:(ROOT/'extra-case-candidates.json').write_text(json.dumps(found,indent=2)+'\n',encoding='utf8')
print(json.dumps(report,indent=2))
