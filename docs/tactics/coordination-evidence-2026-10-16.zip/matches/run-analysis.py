from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import subprocess,json,time,sys,hashlib
ROOT=Path(__file__).resolve().parent;parts=ROOT/'parts';parts.mkdir(exist_ok=True);workers=6
def worker(i):
 dest=parts/f'part-{i}';dest.mkdir(exist_ok=True)
 with(dest/'run.log').open('w',encoding='utf8')as f:r=subprocess.run([sys.executable,str(ROOT/'analyze-coordination.py'),'--stride',str(workers),'--index',str(i),'--out-dir',str(dest)],stdout=f,stderr=subprocess.STDOUT)
 return{'worker':i,'exit_code':r.returncode}
start=time.time();results=[]
with ThreadPoolExecutor(max_workers=workers)as pool:
 for future in as_completed([pool.submit(worker,i)for i in range(workers)]):results.append(future.result());print(json.dumps(results[-1]),flush=True)
if any(r['exit_code']for r in results):raise SystemExit('Part worker failed; read parts/part-*/run.log')
with(ROOT/'merge-analysis.log').open('w',encoding='utf8')as f:r=subprocess.run([sys.executable,str(ROOT/'analyze-coordination.py'),'--merge-parts',str(parts)],stdout=f,stderr=subprocess.STDOUT)
result={'finished_at_utc':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.time()-start,'workers':results,'merge_exit_code':r.returncode,'analyzer_sha256':hashlib.sha256((ROOT/'analyze-coordination.py').read_bytes()).hexdigest()};(ROOT/'analysis-run-report.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result),flush=True)
