from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import subprocess,json,time,argparse,hashlib
ROOT=Path(__file__).resolve().parent
NODE=Path(r'C:\Users\frans\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe')
p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--out-dir',required=True);p.add_argument('--workers',type=int,default=6);a=p.parse_args();assert 1<=a.workers<=8
out=Path(a.out_dir).resolve();out.mkdir(parents=True,exist_ok=True);logs=out/'logs';logs.mkdir(exist_ok=True)
def worker(i):
 with(logs/f'worker-{i:02}.log').open('w',encoding='utf8')as f:r=subprocess.run([str(NODE),str(ROOT/'scan-coordination.mjs'),'--manifest',str(Path(a.manifest).resolve()),'--out-dir',str(out),'--stride',str(a.workers),'--index',str(i),'--resume'],stdout=f,stderr=subprocess.STDOUT)
 return{'worker':i,'exit_code':r.returncode}
start=time.time();results=[]
with ThreadPoolExecutor(max_workers=a.workers)as pool:
 for future in as_completed([pool.submit(worker,i)for i in range(a.workers)]):results.append(future.result());print(json.dumps(results[-1]),flush=True)
result={'finished_at_utc':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.time()-start,'workers':results,'completed_matches':len(list(out.glob('*.coord.json.gz'))),'manifest':str(Path(a.manifest).resolve()),'manifest_sha256':hashlib.sha256(Path(a.manifest).read_bytes()).hexdigest(),'scanner_sha256':hashlib.sha256((ROOT/'scan-coordination.mjs').read_bytes()).hexdigest()}
(out/'run-report.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result),flush=True)
