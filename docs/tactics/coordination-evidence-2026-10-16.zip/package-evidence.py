from pathlib import Path
import hashlib,json,zipfile,datetime
ROOT=Path(__file__).resolve().parent
PUB=ROOT/'publication';OUT=Path('outputs')
sha=lambda b:hashlib.sha256(b).hexdigest()
idx=json.loads((ROOT/'matches/evidence-index.json').read_bytes())
files={};sources=[]
def add(path,name=None):
 path=Path(path)
 if not path.is_file():raise FileNotFoundError(path)
 if name is None:name=str(path.relative_to(ROOT)).replace('\\','/')
 if name in files:raise ValueError('duplicate '+name)
 files[name]=path
for item in idx['files']:
 original_path=Path(item['path']);path=original_path.resolve();raw=path.read_bytes()
 assert sha(raw)==item['sha256'] and len(raw)==item['size_bytes'],str(path)
 if path.suffix=='.wasm':
  sources.append({**item,'included':False,'reason':'pinned official vendor executable is not redistributed'})
  continue
 try:name=path.relative_to(ROOT).as_posix()
 except ValueError:
  name='support/'+original_path.as_posix().removeprefix('work/')
 add(path,name);sources.append({**item,'archive_path':name,'included':True})
for name in ['matches/evidence-index.json','coordination-mechanics.md','coordination-mechanics.json','probe-coordination.mjs','our-policy-review.md','our-policy-notes.json','lol-research.md','lol-sources.json','methods-review.md','summary-review.json','chapter-review.json','episode-review.json','publication-review.json','report-source-bindings.json','write-report.py','plot-coordination.py','plot-overload-case.py','package-evidence.py','repository/06-team-coordination.original.md']:
 add(ROOT/name)
for name in ['06-team-coordination.md','coordination-research-2026-10-16.md','coordination-map-patterns.png','coordination-map-patterns.svg','coordination-local-overload.png','coordination-local-overload.svg','coordination-figure-data.json','coordination-overload-figure-data.json']:
 add(PUB/name,'publication/'+name)
for rel in ['work/ward-research/mechanics-harness.mjs','work/ward-research/probe-grid.mjs','work/ward-research/mechanics.md','work/shopping-research/mechanics.md','work/ward-research/repository/EDITING.md','work/study27-economy-v2/baseline-manifest.json']:
 add(rel,'support/'+rel.removeprefix('work/'))
readme='''# Coordination research evidence — 16 October 2026

Research evidence only; this ZIP is not a Battlecode bot submission.

Start with publication/coordination-research-2026-10-16.md and publication/06-team-coordination.md. The former is research; the latter is an unimplemented Planned specification. No new bot competitive games or implementation changes were performed.

matches/ contains the complete grouped summaries and compact CSV ledgers for the same3,766 API IDs /2,119 distinct raw replay streams as the ward/shopping study, including all1,078 top-four head-to-head streams. Core and early-window summaries are frozen. Case files contain exact source bindings and selected sequence windows; they illustrate mechanisms rather than representative success rates. Native world-round samples, owner-turn boundaries, recorded commands, HP-loss recipients, capture receipts and real submitted score have distinct definitions. Geometry is not available help or personal knowledge; private opponent intent/versions are unavailable.

The full native output tree (~621.7MB gzip), original raw replays/bundles, duplicate JSONL ledgers, runtime/vendor binaries, credentials and private opponent code are excluded. The internal payload manifest lists every included byte sequence. matches/evidence-index.json also binds excluded full native traces and vendor engine source; an entry there is not a promise that the corresponding large/executable source is redistributed. source-index.json maps original source paths to archive paths and explicitly records the excluded WASM.

Reproduction is source-backed but not one-command portable. Public bundle URLs/raw hashes and match/API metadata are retained in support/ward-research/acquisition/manifest-native.json and support/ward-research/matches/manifest-current-unique.json. Obtain the official WASM with SHA ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc and retain the original helper dependency layout under work/ when running the supplied sources. Native decoding uses Node; aggregation/audits use Python, and figures use matplotlib/numpy. Configure the local paths in the provided runners/helpers for your environment. The saved scripts and runtime source hashes, not an assertion of current-server binary identity, define the reconstruction.

Support files preserve the earlier rule/probe and map-helper context. Six-source-file hashes and the pinned own-bot commit identify the source audit; the bot code itself remains in the team repository. The artifact does not assert that audited revision is the active Battlecode upload or latest main.

The independent summary/publication/episode reviews verify the stated reconstructions and bounded prose, not a causal strategy improvement. The final external ZIP audit is intentionally kept outside the ZIP to avoid recursive hashing/repacking. The external archive manifest contains its final SHA-256 and size; the internal payload manifest contains each payload SHA-256 and size.
'''
for name,data in [('README.md',readme.encode()),('source-index.json',json.dumps(sources,indent=2).encode())]:files[name]=data
payload=[]
for name,path in sorted(files.items()):
 data=path if isinstance(path,bytes)else path.read_bytes()
 payload.append({'path':name,'size_bytes':len(data),'sha256':sha(data)})
manifest={'schema':1,'scope':'Curated coordination research evidence; excluded native/raw/vendor sources are identified separately','payloads':payload}
manifest_bytes=json.dumps(manifest,indent=2).encode()
zip_path=PUB/'coordination-evidence-2026-10-16.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,path in sorted(files.items()):
  data=path if isinstance(path,bytes)else path.read_bytes()
  z.writestr(name,data)
 z.writestr('payload-manifest.json',manifest_bytes)
with zipfile.ZipFile(zip_path)as z:
 assert z.testzip()is None
 assert len(z.namelist())==len(set(z.namelist()))==len(payload)+1
 for x in payload:
  data=z.read(x['path']);assert len(data)==x['size_bytes']and sha(data)==x['sha256'],x['path']
 for name,path in files.items():
  assert z.read(name)==(path if isinstance(path,bytes)else path.read_bytes()),name
external={'filename':zip_path.name,'size_bytes':zip_path.stat().st_size,'sha256':sha(zip_path.read_bytes()),'entries':len(payload)+1,'payload_manifest_sha256':sha(manifest_bytes),'root_publication_sha256':sha((PUB/'coordination-research-2026-10-16.md').read_bytes()),'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(PUB/'coordination-evidence-2026-10-16.manifest.json').write_text(json.dumps(external,indent=2),encoding='utf8')
print(json.dumps(external,indent=2))
