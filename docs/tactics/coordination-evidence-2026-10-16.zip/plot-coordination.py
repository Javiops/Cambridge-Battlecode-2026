from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,str(Path('work/battlecode-match-analysis/pythonlib').resolve()))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parent
data_path=ROOT/'matches/current-summary.json'
data=json.loads(data_path.read_bytes())
rows=data['cohorts']['top4_h2h']['per_map_team']
maps=sorted({r['map']for r in rows})
teams=['Intercontinental Fish','Sneaky Bush Campers','Mite','Univardisty of Shingtonwash']
short=['Fish','Sneaky','Mite','Univardisty']
metrics=[('groupedContact6BodyRounds','contact6BodyRounds','Nearby support during enemy contact','Alive/off-spawn body-rounds with an enemy within6;\nshare with at least one ally within6.'),('sharedRecipientPvpTeamRounds','multiAttackerPvpTeamRounds','Shared damaged recipient in the same round','Team-rounds with at least two damaging actors;\nshare with a common enemy HP-loss recipient.')]
fig,axes=plt.subplots(1,2,figsize=(12.8,7.3))
source=[]
for ax,(num,den,title,subtitle)in zip(axes,metrics):
 arr=np.full((len(maps),len(teams)),np.nan);denoms=np.zeros((len(maps),len(teams)),dtype=int)
 for i,m in enumerate(maps):
  for k,t in enumerate(teams):
   r=next(x for x in rows if x['map']==m and x['team']==t)
   n,d=r.get(num,0),r.get(den,0)
   denoms[i,k]=d
   if d:arr[i,k]=100*n/d
   source.append({'metric':num,'denominator':den,'map':m,'team':t,'n':n,'d':d})
 im=ax.imshow(arr,vmin=0,vmax=100,cmap='Blues',aspect='auto')
 ax.set_xticks(range(4),short,fontsize=11)
 ax.set_yticks(range(len(maps)),maps,fontsize=11)
 ax.set_title(title,loc='left',fontsize=13,fontweight='bold',pad=43)
 ax.text(0,1.025,subtitle,transform=ax.transAxes,fontsize=9.4,va='bottom',color='#374151')
 for i in range(len(maps)):
  for k in range(4):
   v=arr[i,k]
   color='white'if v>=65 else'#172554'
   ax.text(k,i-.12,'—'if np.isnan(v)else f'{v:.0f}%',ha='center',va='center',fontsize=12,color=color,fontweight='bold')
   ax.text(k,i+.21,f'n={denoms[i,k]:,}',ha='center',va='center',fontsize=7.7,color=color)
 ax.tick_params(length=0)
 for s in ax.spines.values():s.set_visible(False)
fig.suptitle('Different coordination styles across the nine maps',x=.06,y=.97,ha='left',fontsize=19,fontweight='bold')
fig.text(.06,.91,'Frozen top-four head-to-head cohort:1,078 distinct replay streams • descriptive, not causal',fontsize=10.5,color='#374151')
fig.text(.06,.075,'n is the denominator (correlated samples, not independent games). Radius is geometry, not reachable/ready help.\nHP loss can include area/secondary effects. Map, draft, champion, opponent, timing and version remain confounded; exact n/d in the archive.',fontsize=9.5,color='#374151')
fig.subplots_adjust(left=.14,right=.97,bottom=.15,top=.77,wspace=.43)
pub=ROOT/'publication';pub.mkdir(exist_ok=True)
fig.savefig(pub/'coordination-map-patterns.png',dpi=160,facecolor='white')
fig.savefig(pub/'coordination-map-patterns.svg',facecolor='white')
(pub/'coordination-figure-data.json').write_text(json.dumps({'summary_sha256':hashlib.sha256(data_path.read_bytes()).hexdigest(),'cells':source},indent=2),encoding='utf8')
print(json.dumps({'cells':len(source),'png_bytes':(pub/'coordination-map-patterns.png').stat().st_size}))
