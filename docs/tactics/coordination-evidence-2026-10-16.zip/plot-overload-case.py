from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,str(Path('work/battlecode-match-analysis/pythonlib').resolve()))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
ROOT=Path(__file__).resolve().parent
casepath=next((ROOT/'matches/cases').glob('01-*.json'));case=json.loads(casepath.read_bytes())
snapshots={s['r']:s for s in case['roundSnapshots']}
prior={x[0]:x for x in snapshots[131]['c']};after={x[0]:x for x in snapshots[132]['c']}
move=next(x for x in case['actions']if x['actor']==5 and x['r']==131 and x['kind']==4)
hits=[(d,loss)for d in case['hpLossFrames']if d['r']==132 and d.get('source',{}).get('id')in[4,5]for loss in d['losses']if loss[0]==1 and loss[1]==3]
assert len(hits)==2
assert [loss[6]for d,loss in hits]==[832,829.5]
assert [loss[7]for d,loss in hits]==[829.5,689.5]
fig,(ax,hp)=plt.subplots(1,2,figsize=(12.6,6.5),gridspec_kw={'width_ratios':[1.2,1]})
for y,row in enumerate(case['mapRows']):
 for x,tile in enumerate(row):
  if tile!='.'and 8<=x<=25 and 0<=y<=12:
   ax.add_patch(Rectangle((x-.5,y-.5),1,1,facecolor={'B':'#d5ead5','#':'#444444','O':'#d4d4d8','A':'#facc15'}[tile],edgecolor='none'))
ren=after[4];varg=after[3];old=prior[5];stellar=after[5]
ax.add_patch(Rectangle((ren[1]-6,ren[2]-6),12,12,fill=False,edgecolor='#94a3b8',linestyle='--',lw=1.4))
ax.scatter([ren[1]],[ren[2]],s=240,c='#2563eb',edgecolors='white',zorder=5)
ax.scatter([varg[1]],[varg[2]],s=240,c='#dc2626',edgecolors='white',zorder=5)
ax.scatter([old[1]],[old[2]],s=180,facecolors='none',edgecolors='#7c3aed',lw=2,zorder=5)
ax.scatter([stellar[1]],[stellar[2]],s=220,c='#7c3aed',edgecolors='white',zorder=5)
ax.annotate('',xy=move['to'],xytext=move['from'],arrowprops={'arrowstyle':'->','lw':2.5,'color':'#7c3aed'})
ax.text(ren[1]-.3,ren[2]+1.15,'Fish Ren4\n(15,4)',ha='right',fontsize=10,color='#1d4ed8')
ax.text(varg[1]+.65,varg[2]-.5,'Sneaky Varg3\n(16,3)',ha='left',fontsize=10,color='#991b1b')
ax.text(old[1]+.6,old[2]+.4,'Stellar5 at R131 start\n(22,9)',ha='left',fontsize=9,color='#6d28d9')
ax.text(stellar[1]-.7,stellar[2]-.85,'R131 move → (21,8)\nR132 start: within6 of Ren',ha='right',fontsize=9,color='#6d28d9')
ax.set(xlim=(8.5,26.5),ylim=(12,-.5),aspect='equal',xlabel='Map x',ylabel='Map y')
ax.set_xticks(range(9,27,2));ax.set_yticks(range(0,13,2));ax.grid(alpha=.18)
ax.set_title('Observed approach, then shared damage',loc='left',fontweight='bold',fontsize=12,pad=13)
hp.plot([0,1,2],[832,829.5,689.5],color='#334155',marker='o',lw=2.4,markersize=7)
for x,y,txt in [(0,832,'832'),(1,829.5,'829.5'),(2,689.5,'689.5')]:hp.annotate(txt,(x,y),xytext=(0,13 if x!=1 else -24),textcoords='offset points',ha='center',fontweight='bold',fontsize=11)
hp.set_xticks([0,1,2],['Before\nRen frame','After Ren\ninput2074','After Stellar\ninput2077'],fontsize=10)
hp.set(xlim=(-.3,2.3),ylim=(630,890),ylabel='Varg current HP')
hp.grid(axis='y',alpha=.2);hp.set_title('Exact sequential frames during R132',loc='left',fontweight='bold',fontsize=12,pad=13)
hp.text(.03,.1,'Ren basic frame: −2.5 HP\nStellar cast frame: −140 HP',transform=hp.transAxes,fontsize=10,color='#334155')
for a in [ax,hp]:
 a.spines['top'].set_visible(False);a.spines['right'].set_visible(False)
fig.suptitle('A local 1v1 becomes a two-body attack',x=.06,y=.97,ha='left',fontsize=19,fontweight='bold')
fig.text(.06,.905,'Fish vs Sneaky • packs • game d44a2517… • three draft picks / four physical bodies per team',fontsize=10.5,color='#374151')
fig.text(.06,.075,'Host reconstruction, not either actor’s complete knowledge. Dashed square is radius6 geometry, not an ability range.\nThe approach happens during R131; R132 snapshot shows its result. This is not proof the help was necessary, optimal or secured a kill.',fontsize=9.3,color='#374151')
fig.subplots_adjust(left=.08,right=.97,top=.79,bottom=.21,wspace=.33)
pub=ROOT/'publication'
fig.savefig(pub/'coordination-local-overload.png',dpi=160,facecolor='white')
fig.savefig(pub/'coordination-local-overload.svg',facecolor='white')
(pub/'coordination-overload-figure-data.json').write_text(json.dumps({'case_file':casepath.name,'case_sha256':hashlib.sha256(casepath.read_bytes()).hexdigest(),'rounds':[131,132],'move':move,'hits':[{'round':d['r'],'input':d['input'],'seq':d['seq'],'actor':d['source']['id'],'loss':loss}for d,loss in hits]},indent=2),encoding='utf8')
print(json.dumps({'hits':len(hits),'png_bytes':(pub/'coordination-local-overload.png').stat().st_size}))
