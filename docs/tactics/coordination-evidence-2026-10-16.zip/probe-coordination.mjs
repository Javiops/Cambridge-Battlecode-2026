import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {E,out,checked,v,entity,state,cstring} from '../ward-research/mechanics-harness.mjs';
import {createGame,finish,teleport} from '../ward-research/probe-grid.mjs';
const records=[],checks=[];
const buf=E.Engine_Malloc(1024);
const bytes=(n=8)=>Array.from(new Uint8Array(E.memory.buffer,buf,n));
function read(g,team,draft=false,offset=0,count=8){const code=E[draft?'Game_API_ReadDraftMemory':'Game_API_ReadSharedMemory'](g,team,offset,buf,count);return{code,error:code?cstring(E.GetLastErrorMsg()):null,bytes:!code?bytes(count):null};}
function write(g,team,data,draft=false,offset=0){new Uint8Array(E.memory.buffer,buf,data.length).set(data);const code=E[draft?'Game_API_WriteDraftMemory':'Game_API_WriteSharedMemory'](g,team,offset,buf,data.length);return{code,error:code?cstring(E.GetLastErrorMsg()):null};}
function check(name,condition){checks.push({name,pass:!!condition});assert(condition,name);}
function turn(g){const s=state(g);return{round:s.round,team:s.team,current:s.current,alive:s.champs.find(c=>c.id===s.current)?.alive};}
function test(name,fn){const g=createGame();try{records.push({name,...fn(g)});}finally{checked('Game_Destroy',g);}}
test('shared_memory_bounds_isolation_persistence',g=>{
 checked('Game_API_GetSharedMemorySize',g,out);const sharedSize=v().getUint32(out,true);
 checked('Game_API_GetDraftMemorySize',g,out);const draftSize=v().getUint32(out,true);
 check('memory_sizes_8_and_1024',sharedSize===8&&draftSize===1024);
 const first=turn(g),initial=read(g,0),pattern=[11,22,33,44,55,66,77,88],written=write(g,0,pattern),immediate=read(g,0),denied=read(g,1);
 check('own_write_immediate_read',written.code===0&&JSON.stringify(immediate.bytes)===JSON.stringify(pattern));
 check('opponent_api_memory_denied_from_wrong_boundary',denied.code!==0);
 const overrun=write(g,0,[1,2],false,7),afterFailed=read(g,0);
 check('out_of_range_write_rejected_without_mutation',overrun.code!==0&&JSON.stringify(afterFailed.bytes)===JSON.stringify(pattern));
 const draftRead=read(g,0,true),draftWrite=write(g,0,[99],true),draftAfter=read(g,0,true);
 check('draft_memory_readable_and_readonly_in_play',draftRead.code===0&&draftWrite.code!==0&&JSON.stringify(draftRead.bytes)===JSON.stringify(draftAfter.bytes));
 finish(g);const opponentTurn=turn(g),enemyInitial=read(g,1),enemyWrite=write(g,1,[200],false,0),enemyAfter=read(g,1);
 check('separate_team_buffers',enemyInitial.bytes?.every(x=>x===0)&&enemyWrite.code===0&&enemyAfter.bytes[0]===200);
 finish(g);const allyTurn=turn(g),laterAlly=read(g,0),update=write(g,0,[99],false,7),updated=read(g,0);
 check('later_ally_sees_prior_own_team_write',allyTurn.current===1&&JSON.stringify(laterAlly.bytes)===JSON.stringify(pattern));
 check('partial_write_preserves_other_bytes',update.code===0&&JSON.stringify(updated.bytes)===JSON.stringify([...pattern.slice(0,7),99]));
 const observed=[];for(let i=0;i<12;i++){finish(g);const now=turn(g);if(now.team===0)observed.push({turn:now,memory:read(g,0)});}
 check('shared_bytes_persist_across_rounds',observed.every(x=>x.memory.bytes[0]===11&&x.memory.bytes[7]===99));
 return{sharedSize,draftSize,first,initial,written,immediate,denied,overrun,afterFailed,draftRead,draftWrite,draftAfter,opponentTurn,enemyInitial,enemyWrite,enemyAfter,allyTurn,laterAlly,updated,observed};
});
test('alternating_order_and_starter_flip',g=>{
 const turns=[];for(let i=0;i<12;i++){turns.push(turn(g));finish(g);}
 const r1=turns.filter(t=>t.round===1).map(t=>t.current),r2=turns.filter(t=>t.round===2).map(t=>t.current),r3=turns.filter(t=>t.round===3).map(t=>t.current);
 check('initial_round_team_alternation',JSON.stringify(r1)===JSON.stringify([0,2,1,3]));
 check('next_round_starter_flip',JSON.stringify(r2)===JSON.stringify([2,0,3,1]));
 check('third_round_starter_returns',JSON.stringify(r3)===JSON.stringify(r1));return{turns};
});
test('priority_next_round_persistent_not_consecutive_ally_actions',g=>{
 const turns=[];for(let i=0;i<16;i++){const t=turn(g);if(t.round===1&&t.current===1){const code=E.Game_Action_SetPriority(g,7);check('set_priority_accepted',code===0);t.setPriority=7;}turns.push(t);finish(g);}
 const r1=turns.filter(t=>t.round===1).map(t=>t.current),r2=turns.filter(t=>t.round===2).map(t=>t.current),r3=turns.filter(t=>t.round===3).map(t=>t.current);
 check('priority_does_not_reorder_current_round',JSON.stringify(r1)===JSON.stringify([0,2,1,3]));
 check('higher_priority_first_within_team_next_round',JSON.stringify(r2)===JSON.stringify([2,1,3,0]));
 check('priority_persists_round3',JSON.stringify(r3)===JSON.stringify([1,2,0,3]));
 check('team_alternation_survives_priority',turns.every((t,i)=>!i||t.round!==turns[i-1].round||t.team!==turns[i-1].team));return{turns};
});
test('dead_body_still_has_input_turn',g=>{
 checked('Game_Sandbox_Damage',g,entity(1,2),entity(1,1,24),100000);
 const turns=[];for(let i=0;i<4;i++){turns.push(turn(g));finish(g);}
 check('dead_body_retains_scheduled_turn',turns.some(t=>t.current===1&&!t.alive));return{turns};
});
for(const [label,other] of [['ally',1],['enemy',2]])test('movement_into_occupied_'+label,g=>{
 teleport(g,0,10,10);teleport(g,other,11,10);
 const before=state(g).champs.map(c=>({id:c.id,x:c.x,y:c.y}));
 const code=E.Game_Action_Move(g,11,10,out),error=code?cstring(E.GetLastErrorMsg()):null,success=!code&&!!v().getInt32(out,true),after=state(g).champs.map(c=>({id:c.id,x:c.x,y:c.y}));
 check('ordinary_move_into_'+label+'_occupied_tile_rejected',code!==0&&!success&&after.find(c=>c.id===0).x===10);
 return{other,before,code,success,error,after};
});
test('remote_ally_state_personal_perspective',g=>{
 teleport(g,0,10,10);teleport(g,1,24,24);teleport(g,2,25,24);
 const observer=state(g,0,0),allyObserver=state(g,0,1),all=state(g);
 check('remote_ally_live_position_hidden_in_personal_view',observer.champs.find(c=>c.id===1).x===-1&&all.champs.find(c=>c.id===1).x===24);
 check('ally_sight_does_not_reveal_its_enemy_to_other_observer',observer.champs.find(c=>c.id===2).x===-1&&allyObserver.champs.find(c=>c.id===2).x===25);
 return{observer:observer.champs,allyObserver:allyObserver.champs,all:all.champs};
});
E.Engine_Free(buf);
const sourcePath='work/battlecode-bot-v1/r2-research/v0_0_1-ctH8uuEb.wasm';
fs.writeFileSync('work/coordination-research/coordination-mechanics.json',JSON.stringify({schema:1,engine:{path:sourcePath,sha256:crypto.createHash('sha256').update(fs.readFileSync(sourcePath)).digest('hex')},records,checks},null,2));
console.log(JSON.stringify({cases:records.length,checks:checks.length,failed:checks.filter(c=>!c.pass),records},null,2));
