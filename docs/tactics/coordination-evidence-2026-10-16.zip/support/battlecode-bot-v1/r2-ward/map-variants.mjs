// Pure local map utility using the official editor's WebAssembly exports.
// It reads source maps and writes new files; it never edits the source pool.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const taskRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const wasmPath = path.join(taskRoot, 'r2-research', 'v0_0_1-ctH8uuEb.wasm');
const mapDir = path.join(taskRoot, 'arena', 'maps');
const outDir = path.join(taskRoot, 'arena', 'r2maps-exact');
let instance;
const view = () => new DataView(instance.exports.memory.buffer);
const bytes = (p, n) => new Uint8Array(instance.exports.memory.buffer, p, n);
const cstring = p => {
  const buffer = new Uint8Array(instance.exports.memory.buffer);
  let end = p;
  while (end < buffer.length && buffer[end] !== 0) ++end;
  return new TextDecoder().decode(buffer.subarray(p, end));
};
const wasi = {
  environ_get: () => 0,
  environ_sizes_get: (p, n) => { view().setUint32(p, 0, true); view().setUint32(n, 0, true); return 0; },
  fd_close: fd => fd <= 2 ? 0 : 8,
  fd_fdstat_get: (fd, p) => {
    if (fd > 2) return 8;
    bytes(p, 24).fill(0); view().setUint8(p, 2); return 0;
  },
  fd_prestat_get: () => 8,
  fd_prestat_dir_name: () => 8,
  fd_read: (fd, p, n, result) => { if (fd !== 0) return 8; view().setUint32(result, 0, true); return 0; },
  fd_seek: fd => fd <= 2 ? 70 : 8,
  fd_write: (fd, p, n, result) => {
    if (fd !== 1 && fd !== 2) return 8;
    let written = 0;
    for (let i = 0; i < n; ++i) {
      const begin = view().getUint32(p + i * 8, true);
      const len = view().getUint32(p + i * 8 + 4, true);
      process.stderr.write(Buffer.from(bytes(begin, len))); written += len;
    }
    view().setUint32(result, written, true); return 0;
  },
  random_get: (p, n) => { crypto.randomFillSync(bytes(p, n)); return 0; },
  proc_exit: code => { throw new Error(`Official editor engine exited: ${code}`); },
};
const module = new WebAssembly.Module(fs.readFileSync(wasmPath));
instance = new WebAssembly.Instance(module, { wasi_snapshot_preview1: wasi });
const E = instance.exports;
E._initialize();
const out = E.Engine_Malloc(64);
function checked(name, ...args) {
  const error = E[name](...args);
  if (error !== 0) throw new Error(`${name}: engine error ${error}: ${cstring(E.GetLastErrorMsg())}`);
}
function scalar(handle, suffix) {
  checked(`MapBuilder_Get${suffix}`, handle, out);
  return view().getInt32(out, true);
}
function load(buffer) {
  const p = E.Engine_Malloc(buffer.length);
  try {
    bytes(p, buffer.length).set(buffer);
    checked('MapBuilder_FromFileBytes', p, buffer.length, out);
    return view().getBigUint64(out, true);
  } finally { E.Engine_Free(p); }
}
const terrainNames = ['Bush', 'Wall', 'Hole', 'Altar'];
const colorNames = ['GroundGrassColor', 'GroundDirtColor', 'GroundGrassHighlightColor',
  'GroundGrassShadeColor', 'GroundGrassWallColor', 'GroundDirtDarkColor', 'GroundDirtDustyColor',
  'GroundDirtMossColor', 'GroundPebbleColor', 'GroundSlabColor', 'GroundFlowerColorA',
  'GroundFlowerColorB', 'GroundFlowersEnabled', 'BushBaseColor'];
function decode(handle) {
  checked('MapBuilder_GetBitboardMetadata', handle, out);
  const width = view().getInt32(out, true), height = view().getInt32(out + 4, true);
  const stride = view().getUint32(out + 16, true);
  const terrain = {};
  for (const name of terrainNames) {
    checked(`MapBuilder_Get${name}Buffer`, handle, out);
    const p = view().getUint32(out, true), tiles = [];
    const data = view();
    for (let y = 0; y < height; ++y) for (let x = 0; x < width; ++x) {
      const word = data.getBigUint64(p + ((y >> 3) * stride + (x >> 3)) * 8, true);
      if ((word & (1n << BigInt(((y & 7) << 3) + (x & 7)))) !== 0n) tiles.push([x, y]);
    }
    terrain[name] = tiles;
  }
  checked('MapBuilder_GetTeamASpawnArea', handle, out);
  const spawn = [0, 4, 8, 12].map(offset => view().getInt32(out + offset, true));
  const camps = [];
  for (let i = 0, n = scalar(handle, 'NumCamps'); i < n; ++i) {
    checked('MapBuilder_GetCampHandle', handle, i, out);
    const campHandle = view().getBigUint64(out, true);
    checked('MapBuilder_GetCamp', handle, campHandle, out);
    camps.push({ type: view().getInt32(out, true), x: view().getInt32(out + 4, true), y: view().getInt32(out + 8, true) });
  }
  const colors = Object.fromEntries(colorNames.map(name => [name, scalar(handle, name)]));
  checked('MapBuilder_GetBushTintRange', handle, out, out + 4);
  colors.BushTintRange = [view().getUint32(out, true), view().getUint32(out + 4, true)];
  return { width, height, symmetry: scalar(handle, 'Symmetry'), champions: scalar(handle, 'NumChampsPerTeam'),
    spawn, terrain, camps, colors, groups: scalar(handle, 'NumCampGroups') };
}
function encode(handle) {
  checked('MapBuilder_VerifyIntegrity', handle);
  checked('MapBuilder_Encode', handle, out, out + 4);
  const p = view().getUint32(out, true), n = view().getUint32(out + 4, true);
  return Buffer.from(bytes(p, n));
}
function transform(source, kind) {
  const W = source.width, H = source.height;
  const T = kind === 'rot90' ? ([x, y]) => [H - 1 - y, x] : ([x, y]) => [x, H - 1 - y];
  const width = kind === 'rot90' ? H : W, height = kind === 'rot90' ? W : H;
  const symmetry = kind === 'rot90' && source.symmetry !== 2 ? 1 - source.symmetry : source.symmetry;
  const [minX, minY, maxX, maxY] = source.spawn;
  // Spawn bounds are half-open [min,max), not inclusive tile coordinates.
  const spawn = kind === 'rot90' ? [H - maxY, minX, H - minY, maxX] :
    [minX, H - maxY, maxX, H - minY];
  return { ...source, width, height, symmetry,
    spawn,
    terrain: Object.fromEntries(terrainNames.map(name => [name, source.terrain[name].map(T)])),
    camps: source.camps.map(c => { const [x, y] = T([c.x, c.y]); return { type: c.type, x, y }; }) };
}
function create(source) {
  checked('MapBuilder_Create', source.width, source.height, source.symmetry, out);
  const handle = view().getBigUint64(out, true);
  try {
    const initial = decode(handle);
    for (const name of terrainNames) for (const [x, y] of initial.terrain[name])
      checked(`MapBuilder_Remove${name}`, handle, x, y);
    if (initial.camps.length !== 0) throw new Error('Unexpected camps in a blank official builder');
    checked('MapBuilder_SetNumChampsPerTeam', handle, source.champions);
    for (let i = 0; i < 4; ++i) view().setInt32(out + i * 4, source.spawn[i], true);
    checked('MapBuilder_SetTeamASpawnArea', handle, out);
    for (const name of colorNames) checked(`MapBuilder_Set${name}`, handle, source.colors[name]);
    checked('MapBuilder_SetBushTintRange', handle, ...source.colors.BushTintRange);
    for (const name of ['Hole', 'Wall', 'Altar', 'Bush']) for (const [x, y] of source.terrain[name])
      checked(`MapBuilder_Add${name}`, handle, x, y);
    for (const camp of source.camps) checked('MapBuilder_AddCamp', handle, camp.type, camp.x, camp.y, out);
    return handle;
  } catch (error) { checked('MapBuilder_Destroy', handle); throw error; }
}
function verifyGame(buffer) {
  const p = E.Engine_Malloc(buffer.length);
  let game;
  try {
    bytes(p, buffer.length).set(buffer);
    checked('Game_FromMapFileBytes', p, buffer.length, out, 0);
    game = view().getBigUint64(out, true);
  } finally {
    if (game !== undefined) checked('Game_Destroy', game);
    E.Engine_Free(p);
  }
}
const hash = buffer => crypto.createHash('sha256').update(buffer).digest('hex');
const canonical = source => JSON.stringify({ width: source.width, height: source.height, symmetry: source.symmetry,
  champions: source.champions, spawn: source.spawn,
  terrain: Object.fromEntries(terrainNames.map(n => [n, [...source.terrain[n]].sort((a, b) => a[1] - b[1] || a[0] - b[0])])),
  camps: source.camps.map(c => [c.type, c.x, c.y]).sort((a, b) => a[0] - b[0] || a[1] - b[1] || a[2] - b[2]) });

export { taskRoot, E, out, checked, load, decode, encode, verifyGame, hash, canonical, terrainNames };

function generateTransforms() {
fs.mkdirSync(outDir, { recursive: true });
const manifest = [];
for (const name of fs.readdirSync(mapDir).filter(n => n.endsWith('.map26a')).sort()) {
  const original = fs.readFileSync(path.join(mapDir, name));
  const originalHandle = load(original);
  let source;
  try { checked('MapBuilder_VerifyIntegrity', originalHandle); source = decode(originalHandle); }
  finally { checked('MapBuilder_Destroy', originalHandle); }
  fs.writeFileSync(path.join(taskRoot, 'r2-ward', name.replace('.map26a', '-decoded.json')), JSON.stringify(source, null, 2));
  for (const kind of ['rot90', 'mirrorY']) {
    const target = transform(source, kind), handle = create(target);
    let buffer, decoded;
    try { buffer = encode(handle); decoded = decode(handle); }
    finally { checked('MapBuilder_Destroy', handle); }
    if (canonical(decoded) !== canonical(target)) throw new Error(`Round-trip mismatch: ${name} ${kind}`);
    verifyGame(buffer);
    const filename = name.replace('.map26a', `-${kind}.map26a`), destination = path.join(outDir, filename);
    if (fs.existsSync(destination)) throw new Error(`Refusing to overwrite ${destination}`);
    fs.writeFileSync(destination, buffer);
    manifest.push({ source: name, transform: kind, file: filename, source_sha256: hash(original), sha256: hash(buffer),
      width: decoded.width, height: decoded.height, symmetry: decoded.symmetry, champions: decoded.champions,
      stored_camps: decoded.camps.length, stored_groups: decoded.groups,
      terrain_counts: Object.fromEntries(terrainNames.map(n => [n, decoded.terrain[n].length])), verified: true });
    console.log(`Verified ${filename}: ${buffer.length} bytes, ${decoded.width}x${decoded.height}, ${decoded.camps.length} stored camps`);
  }
}
E.Engine_Free(out);
fs.writeFileSync(path.join(outDir, 'manifest.json'), JSON.stringify({
  engine_asset: path.basename(wasmPath), engine_sha256: hash(fs.readFileSync(wasmPath)),
  generation: 'Official MapBuilder encode, integrity check, structural round-trip, Game_FromMapFileBytes validation',
  note: 'Transformed maps are additional deterministic scenarios, not independent new game distributions.', maps: manifest,
}, null, 2));
console.log(`Created ${manifest.length} new valid local test maps; original pool untouched.`);
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) generateTransforms();
