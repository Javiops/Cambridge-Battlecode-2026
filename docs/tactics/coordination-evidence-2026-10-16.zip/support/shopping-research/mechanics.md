# Shopping and investment mechanics: verified rules and useful consequences

Audit: 2026-10-16, Europe/Zagreb. Official sources: the freshly read [Items & gold](https://2026a.battlecode.co.uk/game/docs/items) article, saved as `live-items-rules.txt`, the [official API](https://2026a.battlecode.co.uk/game/api), the cached official GameRules handbook, SDK/CLI 2.1.6, and controlled public-editor WASM experiments. This research changes no bot and is not a competitive strategy experiment.

Exact executable: `v0_0_1-ctH8uuEb.wasm`, SHA-256 `ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc`. The live article agrees with the main purchase and passive rules. Exact edge cases below are pinned to this executable; this does not prove that the currently deployed server binary is byte-identical. `mechanics-evidence.json` records hashes, all 51 controlled cases, and 35 passing consistency checks. The fixture outputs include complete before/after resources rather than successful-looking command names alone.

## Resources belong to a body, not a team bank

- Each champion body starts with **0 gold**. The tested `passive_gold` setting is **0**, independently confirmed by 30 idle champion turns with no income. There is no elapsed-time allowance that makes Treasure profitable without future captures or kills.
- Gold, equipment, consumable inventory and carried gems belong to the individual body. **Cassi and Issac have separate gold and equipment**, despite their linked deaths and one draft selection. Giving Cassi 300 gold and buying her an emblem leaves Issac at zero gold and zero equipment.
- Capture gold is divided among qualifying champions on the camp region when capture completes. The lowest ID gets an integer remainder. **Each recipient's own gold bonus is then applied to that recipient's share.** In a 125-gold, two-capturer fixture, the shares are 63 and 62; Treasure on only the first body changes their receipts to 75 and 62. It does not increase the other body’s income or the camp’s gem reward.
- A champion kill gives its credited killer **50 base gold**; the tested assist gives **0 gold**. Treasure changes the killer's receipt to 60. Camps grant no direct kill gold before capture; defeating monsters and leaving the reward region unclaimed earns no reward.
- Death preserves gold, equipment and carried consumables. It loses carried gems according to the kill rules and costs the normal respawn absence; dying is therefore not a good general way to obtain shopping access.
- The 2,000-round gold tiebreak uses **lifetime gold earned**, not unspent cash. Buying does not lower this tiebreak. Tavi refunds are not counted as newly earned gold, so selling and repurchasing cannot inflate it.
- There is **no separate XP/level investment system** in the audited equipment interface. A shard adds champion-specific growth for its stat; it is not an automatic level gained by killing a monster.

Evidence: `initial_and_idle_income`, `gold_and_items_personal_cassi_issac`, `capture_split_bonus_false/true`, `kill_assist_income_false/true`, `dead_shop_gold_persistence`, `tavi_field_and_sale`; settings `kill_gold=50`, `assist_gold=0`, `passive_gold=0`. Cached official rules lines 274–323, 359–375, 418–428.

## Catalogue and the completion threshold

The public shop has **42 equipment types**, representing seven families × three stats × shard/emblem. Every family has Strength, Focus and Health versions.

- Every shard costs **30 gold**, including later copies. There is no escalating level price.
- **Five shards of the same exact item type automatically combine**, with no extra combination fee. Shards of different families or different stats do not jointly complete an emblem. A completed emblem has purchase/refund value 150 gold but cannot be bought directly.
- Loose shards already grant stats. Only a completed emblem grants a family passive or extra completion stats. Buying four scattered families is not equivalent to completing one family.
- Equipment stats stack through duplicate emblems. This is not a six-slot LoL inventory: the controlled fixture successfully holds 22 same-type emblems. The API still has integer/overflow validity checks; this is not a promise of mathematically unlimited counts.
- For a family with an active passive, **only one passive of that family applies across all three stat versions and all duplicates**. A Monster Strength emblem plus a Monster Focus emblem does not grant 20% monster damage.

| Family | Final stats from five bought shards | Passive once per body |
| --- | --- | --- |
| Monster | 5 growth points of chosen stat | +10% damage to camps, for basic attacks **and damaging spells** |
| Power | **6** growth points of chosen stat | No passive; completion supplies one extra growth point |
| Durability | 5 chosen | Incoming damage ×0.9 |
| Treasure | 5 chosen | +20 percentage points of base gold income |
| Jungle | 5 chosen | Incoming **camp-source** damage ×0.7 |
| Home | 5 chosen | Recall duration `ceil(5 × 0.5) = 3` owner turn ends |
| Bruiser | 5 chosen **plus 1 of each other stat** | No passive |

The fifth Power shard is particularly discontinuous: four shards supply four points, then the fifth changes the total to six. Bruiser similarly unlocks both off-stat points only on completion. Monster/Durability/Treasure/Jungle/Home unlock their entire passive on completion. This makes the **remaining price to the next useful completion** more relevant than a generic percentage of gold spent.

## What a growth point actually buys

For integer equipment point totals `h`, `s`, `f`, the ordinary item contributions are `h × health_growth`, `s × strength_growth`, and `f × focus_growth`, added to the champion's base stats. Dynamic kit passives add their separate bonuses. Strength powers basic attacks; Focus changes only those kit effects whose magnitude uses Focus. The current catalogue does not buy armor, attack speed, movement speed, range, mana, cooldown reduction or longer stuns.

| Body | Base HP / Strength / Focus | HP / Strength / Focus per point | Investment-relevant kit caveat |
| --- | --- | --- | --- |
| Ryth | 1,200 / 50 / 100 | 100 / 5 / 10 | Adds Strength equal to 1% of bonus health from items; one health point also gives 1 Strength |
| Vesper Vale | 900 / 45 / 100 | 100 / 5 / 10 | +20% base gold; reset/dash abilities do not scale with Focus |
| Vendetta | 800 / 70 / 100 | 100 / 5 / 10 | Reset/dash abilities do not scale with Focus; cooldown resets on kills are kit behavior |
| Cassi | 700 / 30 / 70 | 71.25 / 3.5 / 15 | Damage spell has 2 × Focus; nondamaging stun gains no duration from Focus |
| Issac | 900 / 40 / 100 | 95 / 4.75 / 10 | Reset/dash abilities do not scale with Focus |
| Stellar | 750 / 35 / 100 | 75 / 3.5 / 10 | Spells scale with Focus: 2× single target, 1.4× area |
| Prism | 700 / 35 / 80 | 75 / 3.5 / 10 | Also receives 0.2 Focus per carried gem; that bonus disappears when those gems leave the bag |
| Marcella | 1,200 / 45 / 50 | 100 / 5 / 10 | Damage spell 2 × Focus; Focus does not lengthen the reset's stun |
| Willow | 700 / 45 / 105 | 50 / 3 / 5 | Healing 3 × Focus to another ally; one point means up to 15 additional heal per successful useful cast |
| Ren | 900 / 40 / 100 | 100 / 5 / 10 | Spell 1.25 × Focus and retaliatory passive 0.2 × Focus per qualifying hit |
| Varg | 1,000 / 50 / 100 | 100 / 5 / 10 | Strength also powers splash on other valid targets; Focus powers the 2.5× shield |
| Tavi | 750 / 35 / 100 | 75 / 5 / 10 | Field equipment purchases and 2.2 × Focus stunning damage spell |

Heart of Ruin has a design record in the engine but is marked unreleased in the official presentation; it is excluded from current build recommendations. All audited kit cooldowns are 8 owner turn ends. Equipment does not change those cooldowns or the one-successful-cast-per-turn allowance. Repeated cast potential depends on remaining cooldown, target availability, walking exclusions and the actual fight duration, not just damage/8.

Numerical table source: exact `Game_API_Champion_Design` and `Game_API_GetChampionPassiveInfo` output in `mechanics-metadata.json`; official cached champion specifications. Full payloads retain kinds, modifiers, radii, target masks and movement attributes.

## Stacking, damage and diminishing returns

Controlled combat checks:

| Incoming 100 raw damage | From champion | From camp |
| --- | --- | --- |
| No passive | 100 | 100 |
| Durability | 90 | 90 |
| Two Durability emblems of different stats | 90 | 90 |
| Jungle | 100 | 70 |
| Two Jungle emblems of different stats | 100 | 70 |
| Durability + Jungle | 90 | **63** |

Different damage-reduction families therefore **multiply**, rather than subtracting 10%+30%=40%. At a fixed HP total, Durability gives about 11.1% more effective HP against affected damage, Jungle about 42.9% against camps, and both about 58.7% against camps. This does not heal current damage, prevent stuns, prevent loss of position, or make a camp contested by opponents safe.

Ryth's actual camp attack/spell fixture produces: bare 50/100 damage; Monster Strength emblem 82.5/110; Monster Focus emblem 55/165; both Monster emblems 82.5/165; Power Strength emblem 80/100. Monster's single 10% multiplier scales all applicable current damage, including later bought stats; it is not confined to the five points contained in that emblem.

There are several different phenomena that should not all be called “diminishing returns”:

1. **No price inflation or weaker absolute ordinary stat growth:** another same-stat shard is still 30 gold and the same growth amount. Power/Bruiser have periodic completion bonuses.
2. **Smaller relative stat increase:** +5 Strength is +10% from 50, but +5% from 100. This is a ratio effect, not a hidden debuff.
3. **A real zero marginal passive on duplicate family completion:** a second Treasure/Monster/etc. still gives its listed stats, but no second family effect. After acquiring a useful unique passive, Power or Bruiser can be a better repeat stat source; choose the relevant stat and actual next threshold.
4. **Discrete action breakpoints:** `ceil(remaining target HP / actual hit damage)` may stay unchanged after a purchase. A 1,350-HP wolf needs 17 bare basic attacks at 80 damage and also 17 at 82.5; those builds can still differ in spell damage, overkill, retaliation, multiple targets and the next stat purchase. Raw percentage DPS is not the whole result.
5. **Complementarity:** health and mitigation multiply; more damage can reduce monster attacks taken and complete a capture before enemy arrival. Healing/shield Focus is worth zero when no useful cast or absorption occurs. Team role and map access determine realized value.

No observed item effect grants LoL-style armor penetration, attack-speed scaling, purchased ability haste or permanent XP leveling. Import the idea of timing a power spike, not those absent systems.

## Treasure: income timing and the correct opportunity cost

Treasure and Vesper add: 20%+20%=**40%** base bonus, not 1.2×1.2. The engine retains fractional bonus credit across grants: after buying Treasure, successive base grants `1,1,1,2` yield `1,1,1,3`. Do not floor each capture's 20% separately when reconstructing the ledger. A second Treasure emblem, even a different stat, gives the same bonus sequence as the first alone.

An extra 150 gold from an extra 20% bonus requires roughly **750 future base personal earned gold**, ignoring fractional timing. This is a useful cash-generation horizon but **not the actual break-even versus another emblem**. Treasure already provides five points of the selected stat. Compared with Power, its immediate equipment opportunity cost is one growth point; compared with Monster, Home or Durability it gives up the relevant unique effect. Those alternatives can generate income indirectly through quicker captures, safe contests, shorter absence and fewer deaths. Treasure needs new income before the match ends, a useful place to spend it, and enough time for the new purchase to affect secured gems.

Its income bonus is personal, so who captures matters. Selecting a Treasure carrier to remain on a camp can concentrate future purchasing power, but removes that body from another task and does not increase camp gems. More champions waiting dilute the nominal personal share without accelerating capture. A policy must compare the group's upcoming useful purchases, not just maximize one champion's gold counter.

Evidence: `gold_bonus_base/treasure/treasure_double/vesper/vesper_treasure`, real `capture_split_bonus_true`, `kill_assist_income_true`; metadata and lifetime `treasureGold` ledger.

## When shopping is legal and what it costs in turns

| Situation | Equipment | Consumables | Equipment sales |
| --- | --- | --- | --- |
| Ordinary living champion on own spawn | Yes | Yes | No |
| Ordinary living champion in field | No | No | No |
| Dead ordinary champion, during its turn | Yes | Yes | No |
| Living Tavi in field | Yes | No | No |
| Living Tavi on own spawn | Yes | Yes | Yes, full value |
| Dead Tavi, during its turn | Yes | Yes | **Yes in the pinned engine fixture** |
| Stunned, or channeling recall/tribute/TP | Blocked by action restrictions | Blocked | Respect engine permission/restriction queries |

The live article abbreviates Tavi sales as “on spawn.” The tested native `CanSell` and sale action also allow dead Tavi (position −1,−1), giving a full refund. Treat this as a pinned executable edge rather than silently broadening the article. Selling can remove an emblem passive immediately, including Home or mitigation. Health sales cap current HP to the new maximum if needed; they do not preserve HP percentage. Refunds do not grow earned-gold/treasure ledgers.

Shopping itself does not spend ordinary movement, attack or the spell allowance, and multiple purchases/batches can occur in one turn. A purchase→cast→purchase fixture succeeds. Ordinary ranged/melee movement and spell walking exclusions still apply independently. Buy and re-read stats before choosing attacks or spells whose threshold changes.

Buying Health **on spawn** raises current HP by exactly the maximum-HP gain, including Power/Bruiser completion gains. Ryth damaged to 900/1,200 becomes 1,500/1,800 after completing Power Health for 150 gold, with his additional Strength also updated. Tavi field Health raises only max HP: 650/750 becomes 650/1,200 after Power Health. A dead Health purchase leaves current HP zero; it equips the future respawn rather than resurrecting the body. Spawn turn-end recovery is a separate full heal.

Failures include zero batch count, insufficient gold, directly buying an emblem, invalid current location, full consumable inventory, stun and channel restrictions. Insufficient funds for a two-shard batch rejects the entire batch without charging for one shard. Check the actual API and action result rather than assuming all requested purchases occurred.

### Tavi's health buy/sell cycle is real immediate healing

The interaction between spawn Health purchase healing and full-value sales has a meaningful same-turn use. In the pinned executable, living Tavi on his own spawn can buy one Treasure Health shard for 30 gold, immediately gain 75 maximum **and current** HP, then sell that shard for 30. Maximum HP returns to its old value; current HP is retained, capped at the new maximum. The gold and equipment round trip is therefore net zero while current HP rises by up to 75.

The fresh fixture `tavi_bounded_health_shard_buy_sell_healing` exactly reproduces the replay-observed starting state: **210/750 HP and 160 gold**. Eight buy/sell cycles produce current HP `285,360,435,510,585,660,735,750`, with **750 max HP, 160 gold, unchanged equipment and unchanged earned-gold ledger** at the end. All 16 purchase/sale actions succeed in the same owner turn, ordinary action flags are unchanged, and Tavi successfully casts his damaging spell afterward. This is not merely meaningless transaction churn. The root native replay audit independently found Mite Tavi doing eight such cycles in lanes replay `17a5c872-dd06-4e5d-b6af-13c0dfaec889`, round 139, inputs 4292–4307.

This advantage must be scoped correctly. Spawn already heals to full at turn end if Tavi stays there. Immediate cycling is useful when he can act or leave **before** that automatic heal, not as a reason to add a shopping detour. It gives no gold profit and does not raise final maximum HP. Field Health purchases do not heal and field sales are forbidden; other champions cannot sell. A dead body stays at zero HP rather than reviving from a purchase.

Any proposed implementation should be a **bounded** operation: living Tavi, own spawn, enough temporary gold for one shard, legal shopping/selling permissions, missing HP, and a chosen Health shard whose existing loose count will not auto-combine on the purchase. A loose count at most three is a simple safe condition before buying one; with four, the purchase creates an emblem and blindly selling the shard fails. Re-query HP and inventory after each completed pair, stop at full HP or any failed action, and bound cycles by `ceil(missing HP / 75)` for Tavi's ordinary Health shard. Keep the pre-existing inventory unchanged and verify the cash refund. Eight cycles mean 16 host actions, not an infinite loop; this unmetered editor fixture does not establish their exact Wasmtime fuel cost. Source-bot implementation and fuel validation remain future work.

## Home is two saved recall ticks, with an important capture interaction

Normal recall starts with timer five; Home starts with three. A second Home does not shorten it further. The starting turn end ticks the timer, and arrival occurs at the owner's next turn start after zero. Home changes the channel, not the walk back to the next camp, tribute duration or the five-round capture process.

**Do not start recall at the same capture timer after buying Home.** In a controlled solo wolf fixture, the first capture phase at round 2 starts capture timer five. Starting normal recall then awards 90 gold/22 gems at round 7 before the owner arrives on spawn. Starting Home recall at that identical moment arrives at round 5, leaves the region empty, resets capture and earns nothing. Delay the shorter recall until capture will finish before departure, or preserve an actual ally handoff. The two “saved” channel ticks cannot be claimed as productive time while losing the entire capture.

Evidence: `home_recall_duration_0/1/2`, `capture_and_recall_false/true`. This is a mechanics fact, not evidence that Home is generally good or bad.

## Consumables: small cash price, situational action value

- **TP crystal:** 10 gold, carry at most one; raw engine ID 0. Starts a three-turn-end channel to a reserved legal destination within Chebyshev range three. It ignores terrain in between, but landing legality/occupancy still applies. The channel is not manually cancelable and stun can interrupt it. This is not a normal zero-time LoL Flash or a cross-map teleport. Use only when terrain bypass, avoiding a longer route, reaching a necessary tile, or tactical relocation justifies the channel and risk; carrying one unused indefinitely is not itself value.
- **Altar lock:** 10 gold, carry at most one; raw engine ID 2. Place on an altar within two tiles. Blocks opposing tribute and cancels enemy tribute channels there; own team can still tribute. Removal requires three successful basic attacks, and a blocked tribute attempt is converted into an attack. It can buy important time, but no scenario-independent gem value follows from spending 10 gold.
- **Free ordinary wards are not purchased consumables.** Legacy raw IDs 1/control ward and 3/ward teleport remain in frontend metadata but are unpurchasable with carry limit zero in the tested engine. The public SDK exposes only TP crystal and altar lock as consumable types.

Both usable consumables cost one third of a shard. Buying one can delay a 30-gold shard or a fifth-shard passive; include that threshold cost, especially early. The player may buy both (20 gold) and carry one of each, not two of either. Tavi cannot replenish consumables remotely. The engine does not require a consumable purchase every base visit.

## Strategy boundaries for the handbook

The verified mechanics support an original policy based on **the next useful threshold before the next objective**, with explicit personal budget, family passive already owned, current loose shards, expected useful casts/hits, available income and remaining game horizon. Evaluate a return together with healing, capture handoff and walking absence; compare field Tavi upgrades with their actual no-heal state. Preserve a small consumable reserve only for a named likely use, not as a universal tax.

For replay extraction, both equipment and consumable purchases emit native snapshot step kind **13**; a confirmed Tavi equipment sale emits kind **25** in this pinned engine. The fixture `shop_and_sale_step_kinds` checks both purchases and an actual owned-emblem sale. Use inventory/gold changes to classify transactions; a command kind alone is not a purchase-success or item-type proof.

These are policy-design constraints and analytic examples. They do not establish one universal best build, causal purchase-to-win effects from elite replays, or a measured win-rate gain. Elite choice frequencies, timing, map differences and observed spending behavior must be supplied separately by the matched native replay audit.
