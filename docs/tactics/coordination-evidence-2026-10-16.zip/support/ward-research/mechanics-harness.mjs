import fs from 'node:fs';
import {E,out,checked} from '../battlecode-bot-v1/r2-ward/map-variants.mjs';
export {E,out,checked};
export const v=()=>new DataView(E.memory.buffer);
export const scratch=E.Engine_Malloc(256), snap=E.Engine_Malloc(184696);
export function pos(x,y){v().setInt32(scratch,x,true);v().setInt32(scratch+4,y,true);return scratch;}
export function entity(kind,index,offset=8){v().setUint32(scratch+offset,kind,true);v().setUint32(scratch+offset+4,index,true);return scratch+offset;}
export function perspective(team=2,champ=4294967295){v().setUint32(scratch+16,team,true);v().setUint32(scratch+20,champ,true);return scratch+16;}
export function state(g,team=2,champ=4294967295){checked('Game_Visualiser_ReadState',g,perspective(team,champ),snap); const d=v(),r=n=>d.getUint32(snap+n,true),i=n=>d.getInt32(snap+n,true),a=n=>d.getFloat32(snap+n,true);return {round:r(8),turn:r(12),team:r(16),input:!!r(20),phase:r(24),current:r(60),champs:Array.from({length:r(120)},(_,k)=>{const n=140+k*456;return {id:r(n+4),team:r(n+8),type:r(n+12),known:r(n+16),x:i(n+20),y:i(n+24),hp:a(n+28),flags:r(n+36),buff:r(n+40),alive:!!r(n+224),hasWard:!!r(n+408),charges:r(n+428),recharge:i(n+432),channel:i(n+436),channelType:r(n+440)};}),wards:Array.from({length:r(132)},(_,k)=>{const n=133436+k*40;return {id:r(n+4),owner:r(n+12),team:r(n+16),x:i(n+20),y:i(n+24),timer:i(n+28),radius:a(n+32),disabled:!!r(n+36)}})};}
export function loadGame(file='work/battlecode-bot-v1/arena/maps/expanse.map26a') {const b=fs.readFileSync(file),p=E.Engine_Malloc(b.length); new Uint8Array(E.memory.buffer,p,b.length).set(b);checked('Game_FromMapFileBytes',p,b.length,out,0);const g=v().getBigUint64(out,true);E.Engine_Free(p); return g;}
export function ward(g,x,y){const code=E.Game_Action_PlaceWard(g,pos(x,y),out);return {code,success:code===0&&!!v().getInt32(out,true),error:code?cstring(E.GetLastErrorMsg()):null};}
export function cstring(p){const b=new Uint8Array(E.memory.buffer);let n=p;while(b[n])n++;return new TextDecoder().decode(b.subarray(p,n));}

