# Ward mechanics: verified rules, executable checks, and tactical consequences

Audit date: 2026-10-16 (Europe/Zagreb). This is documentation and mechanics research. It changes no bot and runs no bot match. Sources are the live official [Vision & wards](https://2026a.battlecode.co.uk/game/docs/vision) article saved in `live-vision-rules.txt`, local official rules/API/SDK 2.1.6, and controlled calls to the official editor WASM. Machine-readable claims, source hashes, exact paths/lines, and probe names are in `mechanics-evidence.json`.

The tested WASM is `v0_0_1-ctH8uuEb.wasm`, SHA-256 `ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc`. The installed CLI reports `cambc 2.1.6`. The live article independently confirms the high-level rules. Its current frontend shell alone does not identify whether every internal executable edge case uses this identical binary; retain the executable hash when citing the sandbox results.

## Exact resource and geometry rules

| Property | Verified value or behavior | Evidence |
| --- | --- | --- |
| Gold/inventory cost | Free ordinary ward trinket; not a purchased consumable. | Live article; rules 104, 346; settings probe. |
| Maximum active ordinary wards | One per champion **body**. A successful placement at a different tile removes that owner's previous ward immediately. | Live article; `ward_recharge_and_replace`. |
| Initial/max charges | One. | `Game_API_GetSettings`, ABI fields at byte offsets 60 and 64; settings probe. |
| Recharge setting | One owner turn-end tick. Successful placement changes charge 1→0 and timer 0→1; timer reaches zero at that owner's turn end; charge restores at that owner's next turn start. | Rules 122; `ward_recharge_and_replace`. |
| Placement frequency | At most one successful deployment per owner turn/round. Failures that consume no charge can be retried. | Live article; recharge/hidden-allied-ward probes. |
| Placement reach | Chebyshev distance ≤2 from the champion's **current** position: max(abs(dx),abs(dy))≤2. The geometric window has at most 25 tiles including self. | SDK 3532–3547; diagonal (2,2) succeeds; distance 3 rejects 65. |
| Vision reach | Chebyshev radius 6, terrain aware. A wholly unobstructed interior ward sees a 13×13 square, 169 tiles. | Settings probe; `ward_masks.open`. |
| Lifetime | Unlimited (`ward_lifetime=-1`, exposed as empty optional remaining time). | Live article; settings; SDK 143–144, 4010–4011. |
| Health/destruction | Wards take no damage and have no attackable HP in the public API. A direct ordinary-ward basic-attack target is rejected. | Live article; `attack_ordinary_ward`; public entity types SDK 2457–2463. |
| Recall/death | Existing ward and its sight survive both. A dead owner still receives its ward vision and recharge, but cannot deploy while dead. | `kill_owner_preserves_ward`, `recall_preserves_remote_ward`, `dead_owner_ward_action`. |
| Team/body exception | Cassi and Issac each have their own ward charge and active ward. The pair can maintain two wards, with separate personal sight. | Rules 424–428; `cassi_issac_separate_wards`. |
| Other champion exceptions | All queried current design IDs 0–12 have ordinary vision type 0 and base vision radius 8. No champion-specific ordinary ward range/charge exception was found. | `champion_design_0` through `_12`. |

A cooldown value of zero is not sufficient to promise placement at every instant: between end and next start, the timer can be zero while the charge remains zero. Bots act after their start-of-turn restoration, so this normally matters when interpreting engine traces rather than in their regular turn entry. Channel, death, restriction, destination, and range checks still apply.

## Sight: walls, bushes, holes, allies, and hidden units

Vision uses symmetric shadowcasting based on Albert Ford's algorithm. The live rules confirm that champions normally see eight tiles in every direction including diagonals; walls and bushes occlude; holes do not occlude. A ward has the same terrain-sensitive style of vision at its smaller radius.

A ward in a bush sees the connected bush cluster containing its origin and can see out of that cluster, subject to radius and walls. It does not see into a separate bush cluster. A ward outside a bush cannot see the bush interior or through it. Exact corners are an engine-mask question, not a straight-line or radius-only approximation. The fixture verifies sight into the origin cluster, exclusion of a separate cluster, a wall shadow, and sight over a hole.

The observer receives **its own champion sight + its own ward sight + applicable temporary tile reveals**. A teammate's ward does not contribute its pixels. The live article's shorthand “nor their wards” should not be interpreted as making allied ward objects globally invisible: an allied ward object can be observed when its tile lies inside the observer's own effective sight. Conversely, a remote allied ward or one hidden by a bush may be unobserved.

There is no separate current champion invisibility mechanic identified in the public kit/API audit. Bush/fog concealment is enough to hide a champion. A ward inside the relevant bush immediately reveals an enemy there, including when the enemy occupies the ward's own tile. The fixture first rejects an attack on the hidden enemy, places the ward, requeries the enemy's now visible state, and then successfully moves and attacks within the **same turn**.

A report from another champion is information, not an extra personal visibility mask. It does not by itself make a unit a legal visible target for the recipient's basic attack or unit-targeted ability. Enemy absence is evidence only for the actually visible tiles at the observation time; it does not make unobserved route branches safe.

## Placement legality and failure behavior

These are executable ordinary-ward facts, not the more conservative candidate filters in our dormant bot.

| Destination or condition | Result in controlled engine fixture |
| --- | --- |
| Ordinary floor or bush | Legal. |
| Current champion tile | Legal. |
| Allied or enemy champion on the tile | Legal, including an enemy hidden in a bush. |
| Live monster/camp on the tile | Legal. |
| Active TP-crystal reserved destination | Legal for a different champion's ward. |
| Own spawn | Legal. |
| Enemy spawn | Illegal: 64 (`bad_destination`). |
| Wall, hole, altar, out of bounds | Illegal: 64. |
| Valid tile beyond Chebyshev distance 2 | Illegal: 65 (`out_of_range`). |
| Tile obscured behind an intervening wall | Legal if destination itself is legal and within range; placement needs no direct sight/path across that wall. |
| Already visible allied ordinary ward | Illegal: 117 (`ally_ward_present`). |
| Own current ward on that same tile | Same 117; retaining it requires no placement call. |
| Hidden allied ordinary ward in a bush | Returns `false`, reveals that destination tile for the rest of the round, retains the charge; a different tile can then succeed. A repeated now-known collision should be treated as known invalid. |
| Enemy ordinary ward | Legal to overlap. Both ward records remain; the enemy ward is not removed. |

The SDK's `place_ward` returns a success boolean; known invalid placement throws `cambc::error`, while an otherwise legal placement blocked by a newly discovered hidden allied ward returns false. In the fixture, hidden-allied-ward failure expands current vision by exactly one tile (210→211), restores no extra ward vision, and consumes no charge. This is the important hidden obstruction for ordinary wards; hidden champion/camp occupancy does not obstruct their placement.

Wards do not block champion movement: walking onto an enemy ward succeeds when no other physical blocker occupies the tile. They do not count as a champion occupying a camp region. A ward placed on a cleared camp tile leaves that camp unclaimed with capture team unset and timer zero after eight rounds without a champion present.

## Action ordering and channels

Ward placement uses its trinket charge. It does not spend the ordinary move, basic attack, or successful ability-cast allowance. Controlled probes establish ward→move→melee basic attack, ward→ranged basic attack, ward→ability cast, move→ward, and ward→recall. Existing ranged move/attack sharing and movement-exclusive spell rules still operate normally: a Ryth movement-exclusive cast after walking is rejected for having moved, not because of the ward.

Movement before placement changes the reach origin. Placement before a decision can expose information that the same turn's movement, targeting, or commitment uses, provided the bot requeries the changed observation. A final end-of-turn placement can inform later turns, but cannot change decisions that have already executed.

| Owner state | Deployment result |
| --- | --- |
| Dead | 63 (`cant_place`), even if recharge has restored a charge. |
| Stunned / ward restriction active | 63. |
| Recalling | 34; cancel recall before acting. |
| Tributing | 35; cancel gem submission before acting. |
| TP-crystal channel | 123; teleport channel blocks deployment and cannot be manually cancelled. |
| Before starting recall | Ward then recall succeeds on the same turn. |

Do not turn these into an invented multi-round ward budget: the normal resource returns on the next owner turn. The meaningful replacement cost is loss of the previous permanent remote observer, computation, and choosing the right point in the action order. A champion cannot repeatedly relocate its single ward within one turn to scan many directions.

## Counterwarding and legacy interfaces

Current ordinary wards cannot be destroyed by basic attacks or damaged. Seeing an enemy ward does not allow ordinary denial: the enemy may keep it indefinitely until its owner replaces it. The current public SDK's attack entity categories are champion, camp, and altar lock; ordinary wards are not target entities.

The engine/frontend retain internal **control ward** names, a disabled flag, and legacy tooltip/ABI fields. Those are not sufficient evidence of an available current counterward tool. The public SDK exposes only TP crystal and altar lock consumables. The internal control-ward shop entry has `purchasable=false`, carry limit zero, and purchase fails with error 58. Do not import LoL sweepers, ward HP, expiry refresh, purchased control wards, or denial rewards into current Battlecode strategy. Altar locks are a separate attackable object with a different job.

## What the bot can actually query and remember

| API | Exact role and caveat |
| --- | --- |
| `self.ward_positions()` | Owning list of the authenticated champion's ordinary ward positions, including remote own ward. Self-only, not a way to inspect allies' private resources. |
| `self.ward_cooldown()` | Current own resource recharge timer; this is a live query. |
| `self.ward_placement_tiles[_into]()` | Range-only Chebyshev mask. It does not check terrain, enemy spawn, allied ward collision, readiness, or channels. |
| `ward::visible_tiles_from[_into](position)` | Actual terrain-aware hypothetical ordinary-ward vision at that origin. No visibility gain estimate or placement legality guarantee is implied. |
| `ward.visible_tiles()` | Recomputes hypothetical sight at the saved ward position, ignoring current observer visibility; the ward object itself is an immutable snapshot. |
| `vision::wards([team])` | Fresh visible ordinary-ward observations. Overlapping records remain distinct. |
| `vision::ward_tiles([team])` | Visible ordinary-ward occupancy. A bitboard cannot distinguish overlapping records. |
| `vision::ward_at(position[,team])` | Visible ward lookup; use team filtering when opposing wards overlap. |
| `vision::has_ward(position[,team])` | False means hidden **or** absent. It is not a global absence oracle. |
| Ward snapshot fields | Position, team relative to observer, optional remaining time. No public owner identity, HP, or entire team ward network. |
| Camp-group live state | The public SDK exposes current lifecycle state only while an original camp spawn tile is in effective vision. A ward can provide that visibility. |
| Champion roster handles | Handles/immutable designs exist outside vision, but do not imply permission to inspect a hidden live position or state. |

The team has **eight writable shared-memory bytes** in this runtime. The 1024-byte draft-memory buffer freezes after drafting. Team sharing requires deliberate writes and reads using an agreed layout; the engine does not broadcast ward pixels. Private bot memory can retain previously seen data, but those records become historical observations when the tile leaves sight. Store observation time and uncertainty; do not present memory as current engine vision. A dead champion still gets turns and can in principle read its surviving ward and publish a compact report; that is a strategy opportunity, not a tested bot feature.

## Tactical implications derived from these facts

1. **A fresh open-field ward adds zero immediate geometric sight.** For champion `p`, legal ward `w`, and ward-visible tile `t`, Chebyshev distance obeys `d(p,t) ≤ d(p,w)+d(w,t) ≤ 2+6 = 8`. Without wall/bush occlusion, all of the ward's mask is inside the champion's current radius-8 mask. Immediate gain comes from seeing around a corner or inside a bush; open-field value comes from persistent observation after departure.
2. **Score a job and a horizon.** A pre-move bush check, a rear watcher after departure, a remote camp-status watcher during a bank trip, and a post-recall watcher have different values. Requiring positive current new-area gain would reject every open-field deployment, even a valuable future watcher.
3. **Replacement is a counterfactual comparison.** Compare keeping the old remote observer against the new observer under the same mission/future owner route. Counting `new mask - current effective vision` alone ignores the useful old sight that replacement erases.
4. **Coordinate owners, not an imaginary team mask.** Distinct wards with overlapping areas can be justified when both owners need direct visibility. Different jobs may reduce redundant reports; an ally's ward is not a substitute for this champion's tactical sight.
5. **Visibility must affect decisions to have value.** Requery after an early ward; consume sightings in path safety, targeting, camp choice, channel decisions, or measured reports. A large number of new pixels or wards does not demonstrate an improved strategy.
6. **Enemy wards are persistent information sources, not destructible objectives.** Treat visible opposing wards as evidence of possible enemy observation, with unknown owner in the public snapshot. Bypass or route choice may matter; a ward-clear routine does not.
7. **Do not overfilter legal deployment.** Units, live camps, self spawn, and teleport reservations are legal ward tiles. Excluding them is a policy choice that can suppress useful bush checks; exact allied ward cells are a real legality exclusion.

These are hypotheses for later policy design and evaluation, not evidence of a win-rate improvement. The mechanics probes use a fixed controlled fixture and verify action/observation contracts; they are not strategy match tests.

## Reproducibility and remaining boundary

`probe-mechanics.mjs` reads settings; `probe-grid.mjs` creates the controlled symmetric fixture; `probe-scenarios.mjs`, `probe-supplement.mjs`, `probe-exceptions.mjs`, `probe-camp.mjs`, and `probe-teleport-reservation.mjs` exercise the cases above. Each fresh case initializes a separate official-engine game, uses sandbox functions only for setup, and checks actual game actions/current observations. JSON outputs retain successful values, error codes, before/after resources, and visibility samples.

The live article has been verified directly at its public URL. Exact runtime edges additionally depend on the recorded executable snapshot; a later engine release requires rerunning these probes and comparing SDK/asset hashes. No claim here requires reading elite/private bot code, implementing a bot change, or treating spectator replay omniscience as bot-visible information.
