from pathlib import Path
import json,hashlib,re
ROOT=Path(__file__).resolve().parent
PUB=ROOT/'publication'
summary=json.loads((ROOT/'matches/current-summary.json').read_bytes())
manifest=json.loads(Path('work/ward-research/matches/manifest-current-unique.json').read_bytes())
requests={r['id']:r for r in manifest['requests']}
cases=json.loads((ROOT/'matches/cases/index.json').read_bytes())
intro='''# Team coordination research — 16 October 2026

[Operational tactics: Chapter06](06-team-coordination.md)

Our proposed starting point is **temporary cooperation around a specific job, with timely useful actions and an explicit end**. A team can look coordinated because its members approach compatible positions, damage a shared reachable enemy, leave one body to collect a reward, and convert a short advantage into a bank. It does not need to move as one permanent blob.

The question “why do they look decisive?” has two answers with different evidence. We can measure repeated recipient choices and shared action sequences. We cannot see their private planner, role assignments, memory protocol or rejected alternatives. Similar local rules and observations could also produce coherent-looking behavior without a centralized shotcaller. Our proposed commitment/abort protocol is an original hypothesis, not a reverse-engineered opponent algorithm.

The top four in the unchanged ward/shopping snapshot are **Intercontinental Fish, Sneaky Bush Campers, Mite and Univardisty of Shingtonwash**. All ten frozen teams are retained. This is research and documentation only: no bot code was changed or new competitive bot simulations run. The eight practical topics remain **Planned**.

## How to read the evidence

- **Confirmed mechanics** come from official rules, SDK/source checks and seven new native cases with22 passing assertions.
- **Observed behavior** is source-bound native position/action/HP/resource evidence, reconstructed sequentially from the frozen replay cohort.
- **Interpretation** explains a plausible mechanism while preserving alternatives. A spatial group is not automatically ready help, and an HP-loss recipient is not necessarily the actor's chosen primary target.
- **Planned strategy** turns those observations and LoL lessons into conditions our bot can implement and test. It is not a demonstrated win-rate improvement.

## Main practical findings

**Their cooperation is selective.** In top-four head-to-head games, nearby ally support occurs in about69–78% of off-spawn living body-rounds, rising to77–85% during geometric enemy contact. Yet disjoint work on multiple camp groups also occurs in about19–25% of camp-work team-rounds. A useful team alternates concentration with productive division of work.

**They often keep damaging the same reachable opponent.** When at least two teammates have direct attack/cast frames with enemy HP loss in one world round, about79–84% of those rounds include a shared enemy recipient. In consecutive own PvP-damaging rounds, recipient sets overlap about91–93% of the time. These are conditional descriptions; a lone available enemy, area damage or continued necessity can explain persistence without a private target lease.

**Clearing, collecting and banking are different jobs.** About96–99% of confirmed top-four head-to-head camp rewards have one recipient. Multiple bodies may help before that boundary, but extra holders do not accelerate capture. Exact episode evidence below includes productive split farming and a champion finishing a48-point bank amid nearby fighting before resuming combat.

**More grouping is not automatically better.** Mite groups more frequently by several spatial measures; Fish is not always the most grouped team, and rank8 Nyxius has the highest all-cohort conditional shared-recipient percentage in the ten-team table. Ranks, compositions, opponents and chronology confound these comparisons. Neither a larger group nor a higher focus percentage is an objective by itself.

![Coordination patterns across maps](coordination-map-patterns.png)

The figure shows different denominators in its two panels. Zero-denominator cells are missing observations, not0% coordination; the rows100% value has only three qualifying multi-attacker team-rounds. Exact table and figure numerators/denominators are included in the evidence archive.

'''
findings=(ROOT/'matches/current-findings.md').read_text(encoding='utf8')
findings=findings.split('\n',1)[1].lstrip()
# Presentation labels are narrower than historical machine category names.
findings=findings.replace('| capture handoff |','| recipient outside observed direct damagers; timing requires qualification |')
findings=findings.replace('| geometric disengagement |','| displacement away from prior enemy positions; not necessarily broken contact |')
for c in cases:
 r=requests[c['match_id']]
 findings=findings.replace('`'+c['match_id']+'`','['+c['match_id'][:8]+'…]('+r['series_url']+')')
details='''
## What the concrete episodes teach

### A real local overload, without assuming it was necessary

![Actual approach and shared damage](coordination-local-overload.png)

The packs example demonstrates the difference between “a second body is going there” and “a second body can contribute now.” Stellar approaches during R131, is present in the R132 fixed snapshot, and has a real damaging cast frame during R132 after Ren's frame. The cast's area can hit a recipient other than its center. This proves a timely two-actor recipient sequence, not an optimal gank, a saved Ren, a necessary intervention or a secured kill. The bodies' personal knowledge and private communication are not reconstructed.

### Larger groups and actual split work

The larger-attack cases cover all four leaders. In case03, five Fish actors—Ren6, Stellar7, Cassi8, Issac9 and Ryth10—have native frames with HP loss at Sneaky Issac1 in R40 on corners. Case04 has Sneaky Stellar2, Prism3 and Willow4 sharing Fish Varg11 as a damaged recipient in R92. Case10 has Mite Varg0, Stellar1 and Ryth4 sharing Fish Ren6 in R26. Case11 has Univardisty Cassi0, Issac1, Marcella2, Tavi4 and Varg5 sharing Mite Varg6 in R32. These are physical actor counts; Cassi/Issac is one draft pick. Area/secondary effects and other recipients mean this is not proof every actor selected one common primary target.

Contrast case12: during R34 on lanes, all six Univardisty bodies have observed camp HP-loss frames on six distinct groups—Ren0→8, Ryth1→10, Cassi2→12, Issac3→36, Varg4→38, Tavi5→40. Case05 gives another multi-location farming example for Sneaky. A team can divide work deliberately or through compatible local priorities; the output proves the work, not the hidden assignment process. A future group should release members when their additional presence has little value.

### A bank is a team objective even while combat continues

In case07, Fish Stellar7 completes a48-point submission during R43, input1083/seq6971, on corners. Exact personal gems fall48→0 and score rises48. Five other Fish bodies and two enemies are within six tiles at that resolution; this is geometric context, not proof of a planned escort.

The sequential actions show useful division of work: Fish Ren6 attacks Sneaky Willow4 at input1080, reducing HP75→35. Stellar finishes the bank at1083, then its own basic-attack frame at1084 reduces Willow35→0. During R42, an enemy Stellar cast had reduced the banking Stellar550→410. Thus “everyone must attack now” would not describe the observed sequence. Do not infer that allies guaranteed the bank, or that proximity itself supplied protection.

### Role separation and the limits of a handoff proxy

Case06's historical machine label is `capture_handoff`, but the evidence is narrower. Fish Stellar4 and Cassi5 have observed direct HP-loss frames at gold-cluster camp9; the last such Cassi frame is R56. Issac6 reaches its region in R64, capture starts R65, and Issac receives35 gold/0 gems in R70 before leaving. The delay does not establish an immediate holder-to-holder handoff or an explicit capture contract. The full earlier camp HP history is preserved, and absence from direct damagers does not exclude delayed/other contributions. Our planned safe handoff requires stronger actual region/phase overlap.

### Continuing together is not the same as continuing correctly

Case09's enemy Ren2 remains alive at102HP at the first R275 snapshot after shared Fish recipient frames in R273. Fish Issac7 then dies during R275 with22 gems, and linked Cassi6 dies at the same input4797. Ren2 subsequently dies in R276. This is not “the group never got the kill”; it demonstrates that joint damage did not ensure an immediate kill or preserve the actors through the intermediate boundary. No causal claim is made that grouping caused their losses.

Case08 is also deliberately limited: Issac moves farther from the *prior* enemy positions, but the enemy Ren follows; Issac is still within four tiles of the current Ren in the R220 snapshot. This is not proof of a safe exit, contact break or coordinated retreat. Our collective-retreat design is a proposal, not an inferred universal doctrine of the top teams.

Case13 provides a stronger observed collective separation. During R380 on corners, Univardisty Stellar6 moves(35,37)→(36,36), while Tavi9 moves(36,37)→(35,36). At the first R381 snapshot, each body's distance to the nearest actual enemy increases5→7; their own moves also increase distance from the previous enemy positions5→6. Both remain alive and within six tiles of each other through R382. Stellar has205/750HP and receives48 gems at R381, so the movement can have an economic purpose as well as threat separation. It does not prove an explicit retreat command, shared knowledge, optimal safety or a causal benefit. This case was found by a bounded look at one existing candidate trace, not a cohort-wide retreat-frequency search.

## Why they can look more decisive

The evidence supports three visible ingredients: persistent useful engagement, actual overlapping action contributions, and conversion into captures or submitted score. The recipient-persistence and exact post-arrival cases substantiate those appearances. They do not reveal whether the implementation uses a leader, identical local scores, long-lived targets, shared memory or hardcoded routines. We also have not measured rejected plans or established that every pause/reversal is indecision.

For our design, **decisiveness means executing one still-valid intent long enough for follow-up**, with a clear abort when its premise breaks. It does not mean never retreating or never reconsidering. An entry/stay margin can suppress small score noise; a dead required ally, missed deadline, illegal target, imminent lethal risk or meaningful enemy reinforcement must override persistence. Lease lengths and advantage margins remain experiment parameters. No fixed number is claimed optimal from these replays.

## LoL lessons that transfer, and those that do not

The research uses primary interviews, original team-published guidance and official analyst commentary. Professional-organization publication does not make every paragraph direct pro testimony. Historical sources provide mechanisms, not current-patch build advice; embedded videos were not watched or used as evidence.

| Source principle | Battlecode adaptation to test | Necessary limit |
| --- | --- | --- |
| Biofrost evaluates current power, cooldowns and nearby numbers in his [support interview](https://dignitas.gg/articles/a-comprehensive-support-guide-with-dignitas-biofrost),18Nov2022 | A local overload counts first useful legal actions before the enemy response, not nearby names | Two allies separated by a wall or an action delay can still fight as two solo entries |
| The same interview separates engaging from protecting allied output; Dignitas's [original teamfight guide](https://dignitas.gg/articles/5-tips-to-improve-your-teamfighting-ft-team-dignitas),1Nov2017, discusses role-dependent positioning and cooldown answers | Assign initiation, follow-up, interrupt and protection according to the actual mission and kit | A melee champion need not dive; a low-damage actor may best enable another actor's action. An occupied tile can block walking, not all incoming projectiles |
| Biofrost's [warding interview](https://dignitas.gg/articles/pro-level-warding-guide-with-dignitas-biofrost),15May2022, discusses objective approaches; author guidance warns against unsafe/late setup | Prepare an approach, useful personal information and fallback before exposing a valuable carrier or starting a contest | Allied ward sight is not shared. Do not die assembling perfect vision or continue after the useful window passes |
| Dignitas's historical [composition guide](https://dignitas.gg/articles/how-should-your-team-composition-close-out-a-game),20Mar2014, relates grouping and concurrent split pressure to composition | A split body gets a concrete capture, bank, denial or interception job while the group exploits a real diversion | No minion wave/tower pressure,1–3–1 prescription, XP-level spike or Smite timing transfers |
| Its [macro guide](https://dignitas.gg/articles/macro-game-level-up-a-mid-to-late-game-league-of-legends-guide),26Mar2020, links reset, buying and objective arrival | Work backward from the latest useful arrival; synchronize readiness or use a verified staggered role handoff | Recall+return travel and lost capture phases matter. Do not reset every body simply because one needs shopping |
| [Jatt's official LCS analysis](https://lolesports.com/en-US/news/10-thoughts-going-into-lcs-spring-week-7),8Mar2023, critiques fight lines that prevent allied damage and unclear strategic direction | Choose positions that enable follow-up, and keep one coherent mission while its assumptions hold | This is original analyst interpretation, not a causal experiment or universal formation |
| [Yeon's firsthand interview](https://teamliquid.com/news/2023/01/25/yeon-no-pressure-for-the-rookie),25Jan2023, describes CoreJJ communicating intended play more freely | Communicate the minimum actionable intent and its validity rather than only a destination | Rich voice comms do not fit eight team bytes; no claim that one leader/language/protocol guarantees wins |

Our original policy is **separate useful tasks → rally if needed → establish ready positions → commit → convert or exit → recover/reassign**. A protection response and hard abort remain available throughout. This is a conceptual state machine, not an implemented global controller.

For a proposed extra participant, rank the additional secured objective or prevented loss against travel/absence, its best forgone task, congestion and risk. Count the expected reward once while retaining who personally receives it. First compare only a solo, pair and available larger group. A pair can exploit an isolated enemy if both contribute before escape/reinforcement and the first survives; four bodies can secure an important contested objective when all four add relevant timely capability. Four is not a default goal.

Give the group an explicit conversion task after pressure: finish the capture, let the chosen carrier bank, deny an imminent tribute, take another feasible reward or exit. Bound pursuit by the conversion/escape window. LoL's useful lesson is coordinated timing and division of work; Battlecode must supply its own path, phase, personal-information and reward model.

## Our existing bot

The source audit pins the cleaned study27 combat derivative at [e72cec84391cf0623d15c2eb3f2f864e2b0bddea](https://github.com/Javiops/Cambridge-Battlecode-2026/commit/e72cec84391cf0623d15c2eb3f2f864e2b0bddea), matching six source hashes recorded in the evidence. This is the same reference used by the shopping study, not a claim about the current active upload or latest main code.

| Source fact | Consequence to investigate |
| --- | --- |
| Camp claims encode intention without age, ETA, accepted role or readiness; channel/recall/tribute paths do not always clear them | “Coming” can include an unavailable body. Replacing intent counts with ready contribution could change exposed openings |
| Initial camp assembly counts living visible allies within7 and all matching claims; the squad estimate assumes identical owner DPS/equal tanking | Radius/claim counts can overstate the first volley or hide serial arrivals; actual kits, paths, cooldowns and HP matter |
| Current capture helper can nominate a still-claimed ally within4 rather than requiring actual region presence | A promised handoff can precede arrival; verify continuous occupancy and phase overlap |
| Pre-sweep, ranged kite and melee front-line select locally, with different rankings; early casts may already be spent | A later common focus cannot recover an earlier committed cast. Align the earliest relevant action, preserving interrupts/peel/AoE exceptions |
| Explicit group/ball/help/twin/fight-state routines are disabled in this configuration; no `set_priority` occurs | Dormant code comments are not implemented team movement. Similar-looking local behavior is not a shared contract |
| Five ordinary claim slots; six packed claims only when group count≤63 | The sixth body cannot publish a normal claim on larger unseen group sets; any replacement protocol needs a tested identity/capacity design |

Detailed source line ranges, active flags and six hashes are retained in `our-policy-review.md` and `our-policy-notes.json` inside the archive. These are specific source-derived failure mechanisms, not proof they caused any top-team replay outcome. The current source already has useful target persistence; new group coordination should not discard it blindly.

## Mechanics that bound an implementable plan

Seven new cases contain22 passing assertions. Host team writes are visible to later allied input boundaries in the same world round and persist across later rounds. Team buffers are separate, range overruns are rejected, and draft memory is readable but not writable during play. The test does not establish multi-call atomicity across guest fuel suspension or arbitrary restart.

Teams alternate, the starting side swaps each world round, and priority changes reorder only the owner's team from the next round onward. A higher-priority initiator does not remove intervening enemy responses. Dead bodies still receive input turns, which is not ready fighting power. Ordinary movement into an ally/enemy occupied tile is rejected; route capacity and crossing order can matter.

Personal visualiser perspectives hide a remote ally's live coordinates/HP and do not inherit that ally's enemy view. Thus an omniscient replay metric cannot be copied into the bot as if it were a legal query. Public identity/alive metadata is distinct from hidden live state. Shared reports can support movement but do not grant targeting permission.

Official sources: [Shared memory](https://2026a.battlecode.co.uk/game/docs/shared-memory), [A champion turn](https://2026a.battlecode.co.uk/game/docs/your-first-turn), [Vision](https://2026a.battlecode.co.uk/game/docs/vision), [Camps](https://2026a.battlecode.co.uk/game/docs/camps). The earlier [ward](ward-research-2026-10-16.md) and [shopping](shopping-research-2026-10-16.md) audits bind the unchanged observation/capture/economy mechanics. The new executable fixtures use the pinned engine, not an assertion of byte identity with the current server.

The reference byte layout already uses claims0–4, camp lifecycle5–6 and active danger7. There is no spare rich mission object. Begin with local readiness, finite assembly and verified handoff; specify an explicit compatible bit budget, writer ownership, freshness/wrap and failure semantics before adding a remote contract. Intent, acceptance, readiness and execution are separate facts.

## Implementation and evaluation order

1. **Readiness and finite assembly:** preserve draft, navigation, builds and useful target stickiness. Compare a radius/claim count with visible, role-relevant first-action timing. Reject unavailable promised help; stop waiting at the mission deadline.
2. **Capture role transfer:** compare proximity-based nomination with actual region/phase overlap and confirmed reward receipt. Release excess bodies after clear, with protection exceptions.
3. **Focus and commit/abort/reset:** align the earliest useful action with a deterministic local target/window, preserving legal observation, survival, peel and interrupt exceptions. Use a stable intent with hard aborts, not irrevocable chasing.
4. **One remote mission:** only after the eight-byte migration is explicit, add bounded membership/expiry/arbitration. Test it against the local-only design. Global allocation and general movement optimization are separate later experiments.

Test components individually and together so complementary changes are not discarded solely because one loses in isolation. Use several opponents, paired map/side comparisons and unseen maps, with draft/body/champion/time strata. Inspect contribution delay, exposure before help, missed captures/banks, useful split work forgone, actual focus conditional on legal shared observations, overkill, stale travel, serial re-entry and fuel. Successful policy means secured value with acceptable cost, not maximum proximity, maximum kills or resemblance to the leader. No comparative win-rate claim is made here.

## Evidence package and reproduction limits

The [research evidence ZIP](coordination-evidence-2026-10-16.zip) and [external checksum manifest](coordination-evidence-2026-10-16.manifest.json) contain the cohort replay index, native source/trace hashes, complete grouped summaries and compact ledgers, early-window data, source-bound cases, mechanics fixtures, independent reviews, figure inputs and analysis source. Paths mentioned in backticks refer to matching archive paths or its source index. This is a research archive, not a bot submission ZIP.

The621.7MB compressed full native trace tree, raw replay/bundle copies, credentials and vendor executable/runtime binaries are excluded. Public bundle URLs and hashes bind the underlying games; executable regeneration requires the pinned official WASM, Node/Python and the documented local helper/path setup. The archive is not a one-command portable runner. Source audits identify hashes and behavior without publishing another team's private code.

The frozen selection, correlated exposures, hidden private versions/intent, geometry-versus-action distinction and limited delayed-effect attribution remain material limits after accounting checks pass. Confirmed before/after events support mechanisms; neither a replay association nor a mechanics fixture establishes a stronger competitive policy.
'''
# The native findings retain machine labels; this section explicitly bounds them.
report=intro+findings+'\n'+details
report=report.replace('Chapter06','Chapter 06').replace('with22','with 22').replace('cases contain22','cases contain 22').replace('The621.7MB','The 621.7 MB')
report=report.replace('metrics.{csv,jsonl.gz}','metrics.csv').replace('rewards.{csv,jsonl.gz}','rewards.csv').replace('submissions.{csv,jsonl.gz}','submissions.csv').replace('rounds.{csv,jsonl.gz}','rounds.csv')
(PUB/'coordination-research-2026-10-16.md').write_text(report,encoding='utf8')
(ROOT/'report-source-bindings.json').write_text(json.dumps({'coreSummarySha256':hashlib.sha256((ROOT/'matches/current-summary.json').read_bytes()).hexdigest(),'earlySummarySha256':hashlib.sha256((ROOT/'matches/early-window-summary.json').read_bytes()).hexdigest(),'findingsSha256':hashlib.sha256((ROOT/'matches/current-findings.md').read_bytes()).hexdigest(),'casesIndexSha256':hashlib.sha256((ROOT/'matches/cases/index.json').read_bytes()).hexdigest(),'reportSha256':hashlib.sha256((PUB/'coordination-research-2026-10-16.md').read_bytes()).hexdigest()},indent=2),encoding='utf8')
print(json.dumps({'words':len(report.split()),'bytes':len(report.encode()),'cases':len(cases)}))
