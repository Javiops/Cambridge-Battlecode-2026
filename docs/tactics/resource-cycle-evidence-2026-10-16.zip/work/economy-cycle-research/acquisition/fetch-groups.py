"""Read-only public group statistics and outcome-independent combat replay selection."""
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import Counter, defaultdict
import json, hashlib, urllib.request, time

ROOT = Path(__file__).parent
CACHES = [ROOT.parents[1]/'combat-research/acquisition',ROOT.parents[1]/'ward-research/acquisition']
BASE = 'https://2026a.battlecode.co.uk'
history = json.loads((ROOT / 'history-index.json').read_bytes())
ladder = json.loads((ROOT / 'ladder-snapshot.json').read_bytes())
assert history['history_complete']
ranks = {t['teamId']: t for t in ladder['teams']}
top4 = {t['teamId'] for t in ladder['teams'][:4]}
sha = lambda b: hashlib.sha256(b).hexdigest()

def one(g):
    local = ROOT / 'api/groups' / (g['id'] + '.json')
    cached = next((c/'api/groups'/(g['id']+'.json')for c in CACHES if(c/'api/groups'/(g['id']+'.json')).exists()),ROOT/'missing-cache'/g['id'])
    if local.exists() or cached.exists():
        file = local if local.exists() else cached
        raw = file.read_bytes()
    else:
        for attempt in range(3):
            try:
                raw = urllib.request.urlopen(BASE + '/api/v1/match-groups/' + g['id'], timeout=40).read()
                break
            except Exception:
                if attempt == 2:
                    raise
                time.sleep(1 + attempt)
        local.parent.mkdir(parents=True, exist_ok=True)
        local.write_bytes(raw)
        file = local
    data = json.loads(raw)
    assert data['group']['id'] == g['id']
    assert {s['teamId'] for s in data['group']['sides']} == {s['teamId'] for s in g['sides']}
    return g, data, {'url': BASE + '/api/v1/match-groups/' + g['id'], 'path': str(file), 'sha256': sha(raw), 'cached': file != local}

rows, errors = [], []
with ThreadPoolExecutor(max_workers=6) as pool:
    pending = {pool.submit(one, g): g for g in history['groups']}
    for future in as_completed(pending):
        try:
            rows.append(future.result())
        except Exception as exc:
            errors.append({'id': pending[future]['id'], 'error': repr(exc)})
        if len(rows) % 400 == 0:
            print(json.dumps({'groups': len(rows), 'total': len(pending), 'errors': len(errors)}), flush=True)

requests = {}
series = []
for g, data, ref in sorted(rows, key=lambda x: (x[0]['createdAt'], x[0]['id']), reverse=True):
    series.append({'id': g['id'], 'created_at': g['createdAt'], 'api_reference': ref, 'game_ids': [m['id'] for m in data['matches']]})
    for game in data['matches']:
        if game['status'] != 'finished':
            continue
        teams = {s['side']: {'teamId': s['teamId'], 'name': s['teamName'], 'rank': ranks[s['teamId']]['rank'],
                             'version': s.get('version'), 'submissionId': s.get('submissionId')} for s in game['sides']}
        requests[game['id']] = {'id': game['id'], 'map': game.get('mapName') or game.get('map'), 'series_id': g['id'],
                                'kind': g['kind'], 'created_at': game['createdAt'], 'teams': teams, 'game': game,
                                'series_url': BASE + '/game/match-groups/' + g['id'], 'group_api_reference': ref}

strata = defaultdict(list)
selected = {}
for r in requests.values():
    ids = {t['teamId'] for t in r['teams'].values()}
    if ids <= top4:
        selected[r['id']] = {**r, 'selection_reason': 'ALL_current_top4_head_to_head'}
    else:
        strata[(tuple(sorted(ids)), r['map'], r['kind'])].append(r)
for key, group in strata.items():
    for r in sorted(group, key=lambda x: (x['created_at'], x['id']), reverse=True)[:2]:
        selected[r['id']] = {**r, 'selection_reason': 'latest_two_other_top10_pair_map_kind'}

record = {'created_at_utc': datetime.now(timezone.utc).isoformat(), 'data_cutoff_utc': history['data_cutoff_utc'],
          'ladder_snapshot': history['ladder_snapshot'], 'history_complete': history['history_complete'],
          'selection': 'All finished current top4 head-to-head game IDs, plus latest two IDs in every other current-top10 unordered pair/map/match-kind stratum. No result, champion, combat or statistics fingerprint filter. Exact raw dedup only after retrieval.',
          'source_history_sha256': sha((ROOT / 'history-index.json').read_bytes()), 'selected_series': len(rows),
          'all_finished_top10_game_ids': len(requests), 'errors': errors,
          'series': series, 'requests': sorted(selected.values(), key=lambda r: (r['created_at'], r['id']), reverse=True)}
(ROOT / 'manifest-selected.json').write_text(json.dumps(record, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
print(json.dumps({'acquired_groups': len(rows), 'all_top10_finished_ids': len(requests), 'selected_ids': len(selected),
                  'all_top4_h2h_ids': sum(r['selection_reason'].startswith('ALL') for r in selected.values()),
                  'maps': dict(Counter(r['map'] for r in selected.values())), 'errors': errors}), flush=True)
if errors:
    raise SystemExit(1)
