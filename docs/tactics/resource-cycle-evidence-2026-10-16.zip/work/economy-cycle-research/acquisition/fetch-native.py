"""Public replay acquisition, CRC/hash checks and identity-preserving exact deduplication."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from collections import defaultdict, Counter
import json, hashlib, urllib.request, urllib.error, zipfile, io, time

ROOT = Path(__file__).parent
CACHES = [ROOT.parents[1]/'combat-research/acquisition',ROOT.parents[1]/'ward-research/acquisition']
manifest = json.loads((ROOT / 'manifest-selected.json').read_bytes())
sha = lambda b: hashlib.sha256(b).hexdigest()

def one(r):
    mid = r['id']
    dest = ROOT / 'native-metadata' / (mid + '.json')
    if dest.exists():
        old = json.loads(dest.read_bytes())
        assert old['id'] == mid
        return old
    oldmeta = next((c/'native-metadata'/(mid+'.json')for c in CACHES if(c/'native-metadata'/(mid+'.json')).exists()),ROOT/'missing-cache'/mid)
    if oldmeta.exists():
        old = json.loads(oldmeta.read_bytes())
        bundle, rawpath = Path(old['bundle']), Path(old['raw'])
        data, raw = bundle.read_bytes(), rawpath.read_bytes()
        assert sha(data) == old['bundle_sha256'] and sha(raw) == old['raw_sha256']
        cached = {'metadata': str(oldmeta), 'sha256': sha(oldmeta.read_bytes())}
    else:
        url = f'https://2026a.battlecode.co.uk/api/v1/matches/{mid}/bundle'
        for attempt in range(5):
            try:
                with urllib.request.urlopen(url, timeout=50) as response:
                    data = response.read()
                    content_type = response.headers.get('Content-Type')
                with zipfile.ZipFile(io.BytesIO(data)) as z:
                    assert z.testzip() is None
                    raw = z.read('replay.repl26a')
                break
            except Exception as exc:
                if attempt == 4:
                    raise
                pause = min(30, 2 + attempt * 2)
                if isinstance(exc, urllib.error.HTTPError) and exc.code == 429:
                    try:
                        pause = min(30, max(pause, int(exc.headers.get('Retry-After', '5'))))
                    except ValueError:
                        pass
                if isinstance(exc, zipfile.BadZipFile):
                    diag = ROOT / 'format-retries' / f'{mid}-{attempt}.json'
                    diag.parent.mkdir(exist_ok=True)
                    diag.write_text(json.dumps({'id': mid, 'bytes': len(data), 'sha256': sha(data), 'content_type': content_type,
                                                'prefix_hex': data[:64].hex(), 'attempt': attempt}), encoding='utf-8')
                time.sleep(pause)
        bundle, rawpath = ROOT / 'bundles' / (mid + '.zip'), ROOT / 'raw' / (mid + '.repl26a')
        bundle.parent.mkdir(exist_ok=True)
        rawpath.parent.mkdir(exist_ok=True)
        bundle.write_bytes(data)
        rawpath.write_bytes(raw)
        cached = None
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        assert z.testzip() is None and z.read('replay.repl26a') == raw
        members = z.namelist()
    record = {**r, 'raw': str(rawpath), 'bundle': str(bundle),
              'bundle_url': f'https://2026a.battlecode.co.uk/api/v1/matches/{mid}/bundle',
              'raw_sha256': sha(raw), 'bundle_sha256': sha(data), 'bundle_members': members,
              'crc_verified': True, 'downloaded_at_utc': datetime.now(timezone.utc).isoformat(), 'cache_reuse': cached}
    dest.parent.mkdir(exist_ok=True)
    dest.write_text(json.dumps(record, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    return record

results, errors = [], []
with ThreadPoolExecutor(max_workers=4) as pool:
    pending = {pool.submit(one, r): r for r in manifest['requests']}
    for future in as_completed(pending):
        try:
            results.append(future.result())
        except Exception as exc:
            errors.append({'id': pending[future]['id'], 'error': repr(exc)})
        if len(results) % 250 == 0:
            print(json.dumps({'bundles': len(results), 'total': len(pending), 'errors': len(errors)}), flush=True)

record = {k: v for k, v in manifest.items() if k != 'requests'}
record['requests'] = sorted(results, key=lambda r: (r['created_at'], r['id']), reverse=True)
record['bundle_errors'] = errors
(ROOT / 'manifest-native.json').write_text(json.dumps(record, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
byraw = defaultdict(list)
byidentity = defaultdict(list)
for r in record['requests']:
    byraw[r['raw_sha256']].append(r['id'])
    byidentity[(r['raw_sha256'], tuple(r['teams'][s]['teamId'] for s in ('a', 'b')))].append(r)
unique = {k: v for k, v in record.items() if k != 'requests'}
unique['requests'] = [rs[0] for rs in byidentity.values()]
unique['raw_aliases'] = dict(byraw)
unique['identity_aliases'] = {rs[0]['id']: [r['id'] for r in rs] for rs in byidentity.values()}
unique['deduplication'] = 'One row per exact raw replay SHA and ordered external team identities; duplicate IDs do not add independent trajectories. Raw hashes shared across different external pairings remain separate attribution units, not independent trajectories.'
(ROOT / 'manifest-unique.json').write_text(json.dumps(unique, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
report = {'downloaded_ids': len(results), 'unique_raw_streams': len(byraw), 'unique_attribution_units': len(byidentity),
          'top4_h2h_ids': sum(r['selection_reason'].startswith('ALL') for r in results),
          'top4_h2h_attribution_units': sum(r['selection_reason'].startswith('ALL') for r in unique['requests']),
          'cached_id_bundles': sum(r['cache_reuse'] is not None for r in results),
          'maps': dict(Counter(r['map'] for r in unique['requests'])), 'errors': errors}
(ROOT / 'acquisition-report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps({**report, 'errors': len(errors)}), flush=True)
if errors:
    raise SystemExit(1)
