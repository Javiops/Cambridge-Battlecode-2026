import urllib.request,json,zipfile,io
u='https://2026a.battlecode.co.uk/api/v1/matches/fc6e7cad-86bd-4b6c-94f1-72d4156261ad/bundle'
with urllib.request.urlopen(u,timeout=30)as r:
 b=r.read();print({'type':r.headers.get('Content-Type'),'status':r.status,'bytes':len(b),'data':json.loads(b)if b[:1]==b'{'else'ZIP'if zipfile.is_zipfile(io.BytesIO(b))else'other'})
