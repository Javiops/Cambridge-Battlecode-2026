from pathlib import Path
p=Path('work/economy-cycle-research/acquisition');s=Path('work/combat-research/acquisition/fetch_groups.py').read_text()
s=s.replace("OLD = ROOT.parents[1] / 'ward-research/acquisition'", "CACHES = [ROOT.parents[1]/'combat-research/acquisition',ROOT.parents[1]/'ward-research/acquisition']")
s=s.replace("cached = OLD / 'api/groups' / (g['id'] + '.json')", "cached = next((c/'api/groups'/(g['id']+'.json')for c in CACHES if(c/'api/groups'/(g['id']+'.json')).exists()),ROOT/'missing-cache'/g['id'])")
s=s.replace('max_workers=8','max_workers=6')
(p/'fetch-groups.py').write_text(s,encoding='utf8')
