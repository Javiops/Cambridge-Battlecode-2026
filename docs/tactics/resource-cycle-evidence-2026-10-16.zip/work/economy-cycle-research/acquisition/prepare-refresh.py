from pathlib import Path
p=Path('work/economy-cycle-research/acquisition');s=Path('work/combat-research/acquisition/refresh_histories.py').read_text()
s=s.replace("OLD = ROOT.parents[1] / 'ward-research/acquisition'", "CACHES = [ROOT.parents[1] / 'combat-research/acquisition', ROOT.parents[1] / 'ward-research/acquisition']")
s=s.replace("old_cutoff = json.loads((OLD / 'history-index.json').read_bytes())['data_cutoff_utc']",'')
s=s.replace("old_file = OLD / 'api/histories' / tid / 'index.json'", "cache = next((c for c in CACHES if (c/'api/histories'/tid/'index.json').exists()),None)\n    old_file = cache/'api/histories'/tid/'index.json' if cache else ROOT/'missing-cache'/tid\n    old_cutoff = json.loads((cache/'history-index.json').read_bytes())['data_cutoff_utc'] if cache else None")
(p/'refresh-histories.py').write_text(s,encoding='utf8')
