from pathlib import Path
import json
r=Path('work/economy-cycle-research/acquisition');p=list((r/'format-retries').glob('*.json'));print('cachedmetadata',len(list((r/'native-metadata').glob('*.json'))),'retryfiles',len(p));print([json.load(open(x))for x in p[-2:]])
