from pathlib import Path
from datetime import datetime,timezone
import urllib.request,hashlib,json
r=Path('work/economy-cycle-research/acquisition');u='https://2026a.battlecode.co.uk/api/v1/ladder';b=urllib.request.urlopen(u,timeout=35).read();(r/'ladder.json').write_bytes(b);x=json.loads(b);s={'url':u,'fetched_at_utc':datetime.now(timezone.utc).isoformat(),'sha256':hashlib.sha256(b).hexdigest(),'updatedAt':x.get('updatedAt'),'teams':[{k:t[k]for k in ['teamId','name','rank','rating']if k in t}for t in x['teams'][:10]]};(r/'ladder-snapshot.json').write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(s,ensure_ascii=True))
