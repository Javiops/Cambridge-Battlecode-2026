"""Timestamped public history refresh, reusing complete previously acquired history."""
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
import json, hashlib, urllib.request, urllib.parse, time

ROOT = Path(__file__).parent
CACHES = [ROOT.parents[1] / 'combat-research/acquisition', ROOT.parents[1] / 'ward-research/acquisition']
BASE = 'https://2026a.battlecode.co.uk'
snapshot = json.loads((ROOT / 'ladder-snapshot.json').read_bytes())
teams = snapshot['teams']
cutoff = datetime.now(timezone.utc).isoformat()

sha = lambda b: hashlib.sha256(b).hexdigest()

def fetch(url, path):
    for attempt in range(3):
        try:
            raw = urllib.request.urlopen(url, timeout=40).read()
            break
        except Exception:
            if attempt == 2:
                raise
            time.sleep(1 + attempt)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    return json.loads(raw), {'url': url, 'path': str(path), 'sha256': sha(raw), 'fetched_at_utc': datetime.now(timezone.utc).isoformat()}

def one(team):
    tid = team['teamId']
    cache = next((c for c in CACHES if (c/'api/histories'/tid/'index.json').exists()),None)
    old_file = cache/'api/histories'/tid/'index.json' if cache else ROOT/'missing-cache'/tid
    old_cutoff = json.loads((cache/'history-index.json').read_bytes())['data_cutoff_utc'] if cache else None
    old = json.loads(old_file.read_bytes()) if old_file.exists() else None
    assert old is None or old['complete']
    groups = {g['id']: g for g in old['groups']} if old else {}
    pages = []
    before = None
    seen = set()
    complete = False
    stop = None
    for index in range(500):
        query = {'team': tid}
        if before:
            query['before'] = before
        data, ref = fetch(BASE + '/api/v1/match-groups?' + urllib.parse.urlencode(query), ROOT / 'api/histories' / tid / f'page-{index:04}.json')
        rows = data['groups']
        pages.append({**ref, 'count': len(rows), 'more': data['more'], 'before': before,
                      'newest': rows[0]['createdAt'] if rows else None, 'oldest': rows[-1]['createdAt'] if rows else None})
        for g in rows:
            assert tid in {s['teamId'] for s in g['sides']}
            assert g['id'] not in seen, 'pagination duplicate'
            seen.add(g['id'])
            if g['createdAt'] <= cutoff:
                groups[g['id']] = g
        if not data['more'] or not rows:
            complete, stop = True, 'end_of_public_history'
            break
        if old and rows[-1]['createdAt'] < old_cutoff:
            complete, stop = True, 'overlap_with_complete_cached_history'
            break
        before = rows[-1]['createdAt'] + '_' + rows[-1]['id']
    result = {'team': {k: team[k] for k in ('rank', 'teamId', 'name', 'rating')}, 'complete': complete, 'stop': stop,
              'pages': pages, 'cached_history': {'path': str(old_file), 'sha256': sha(old_file.read_bytes()), 'cutoff': old_cutoff} if old else None,
              'groups': sorted(groups.values(), key=lambda g: (g['createdAt'], g['id']), reverse=True)}
    dest = ROOT / 'api/histories' / tid / 'index.json'
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(result, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    print(json.dumps({'team': team['name'], 'new_pages': len(pages), 'groups': len(groups), 'complete': complete, 'stop': stop}), flush=True)
    return result

histories, errors = [], []
with ThreadPoolExecutor(max_workers=5) as pool:
    pending = {pool.submit(one, t): t for t in teams}
    for future in as_completed(pending):
        try:
            histories.append(future.result())
        except Exception as exc:
            errors.append({'team': pending[future]['name'], 'error': repr(exc)})

teamids = {t['teamId'] for t in teams}
top4 = {t['teamId'] for t in teams[:4]}
allgroups = {}
for h in histories:
    for g in h['groups']:
        ids = {s['teamId'] for s in g['sides']}
        if len(ids) == 2 and ids <= teamids and g['status'] == 'finished':
            allgroups[g['id']] = g
record = {'created_at_utc': datetime.now(timezone.utc).isoformat(), 'data_cutoff_utc': cutoff,
          'ladder_snapshot': {'path': str(ROOT / 'ladder-snapshot.json'), 'sha256': sha((ROOT / 'ladder-snapshot.json').read_bytes())},
          'selection': 'All finished distinct current-top10 internal series before fixed cutoff; complete histories with hashed cached overlap where available.',
          'history_complete': not errors and len(histories) == 10 and all(h['complete'] for h in histories), 'errors': errors,
          'histories': [{k: h[k] for k in ('team', 'complete', 'stop', 'cached_history', 'pages')} for h in histories],
          'groups': sorted(allgroups.values(), key=lambda g: (g['createdAt'], g['id']), reverse=True)}
(ROOT / 'history-index.json').write_text(json.dumps(record, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
print(json.dumps({'histories': len(histories), 'complete': record['history_complete'], 'finished_current_top10_series': len(allgroups),
                  'current_top4_series': sum({s['teamId'] for s in g['sides']} <= top4 for g in allgroups.values()),
                  'errors': errors, 'cutoff': cutoff}), flush=True)
if not record['history_complete']:
    raise SystemExit(1)
