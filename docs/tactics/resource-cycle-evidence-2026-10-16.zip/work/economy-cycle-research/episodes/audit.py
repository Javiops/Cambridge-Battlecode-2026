import json,gzip,pathlib,collections
HERE=pathlib.Path(__file__).resolve().parent
for p in sorted(HERE.glob('*.native-frames.json.gz')):
 d=json.loads(gzip.decompress(p.read_bytes()));prev={};gp={};events=[]
 print('\n###',d['key'],d['id'],d['map'])
 for f in d['frames']:
  for c in f['c']:
   b=prev.get(c[0]);diff=[]
   if b:
    if b[10:12]!=c[10:12] and (b[10]!=c[10] or c[11]==0):diff+=['channel '+str(b[10:12])+'→'+str(c[10:12])]
    if c[9]!=b[9]:diff+=['bag '+str(b[9])+'→'+str(c[9])]
    if c[5]>b[5]+1:diff+=['heal '+str(b[5])+'→'+str(c[5])]
    if max(abs(c[3]-b[3]),abs(c[4]-b[4]))>3:diff+=['jump '+str(b[3:5])+'→'+str(c[3:5])]
    if b[7]!=c[7]:diff+=['alive '+str(b[7])+'→'+str(c[7])]
   if diff:
    row={'r':f['r'],'seq':f['seq'],'step':f['step'],'actor':c[0],'c':c,'changes':diff};events.append(row);print(json.dumps(row))
   prev[c[0]]=c
  for g,a in f['groups'].items():
   b=gp.get(g)
   if b and a!=b and (a[1]!=b[1] or a[2]!=b[2] or a[3]>b[3] or a[3]==0):
    row={'r':f['r'],'seq':f['seq'],'step':f['step'],'group':g,'before':b,'after':a};events.append(row);print(json.dumps(row))
   gp[g]=a
 ext=json.loads((HERE/(d['key']+'.trace-extract.json')).read_text(encoding='utf8'))
 # first productive source-owned damage after each exact arrival and/or submission, with source position at preceding native frame
 for label,seq in [('submit',x['seq']) for x in ext['submissions']]+[('arrival',x['seq']) for x in events if 'actor'in x and any(z.startswith('jump') for z in x['changes']) and any(box[0]<=x['c'][3]<box[2] and box[1]<=x['c'][4]<box[3] for box in ext['spawn'])]:
  for actor in d['actors']:
   found=next((x for x in ext['damage'] if x['seq']>seq and x['source'] and x['source']['id']==actor and any(l[0]==2 or l[0]==1 and l[2]!=next(c['team'] for c in ext['roster'] if c['id']==actor) for l in x['losses'])),None)
   if found:
    prevf=next((f for f in reversed(d['frames']) if f['seq']<=found['seq']),None);print('PRODUCTIVE',label,actor,found, 'state',prevf['c'] if prevf else None)
 (HERE/(d['key']+'.native-audit.json')).write_text(json.dumps(events,indent=2),encoding='utf8')
