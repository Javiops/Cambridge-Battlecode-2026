import json,gzip,pathlib,hashlib
HERE=pathlib.Path(__file__).resolve().parent
index=json.loads((HERE/'selected-index.json').read_text(encoding='utf8'))
manifest=json.loads((HERE.parents[1]/'combat-research/matches/manifest-bound.json').read_text(encoding='utf8'))
requests={r['id']:r for r in manifest['requests']}
specs={
 'sneaky-packs-overlap':dict(status='complete',focus=[1],seq=[8246,8299,8341,8833,8887,8892,9319,9826,11012],observations=[
  'Sneaky Issac1 cleared group2 on r80, stood through capture start r81, and began a five-tick recall that same round at 670/995 HP with no gems.',
  'At r86 capture phase7, the holder received 70 gold and 48 gems while recall timer was already zero. Recall relocation happened later in the same world round at phase14, followed by full 1185/1185 HP at phase13 after purchases increased maximum HP.',
  'The 48-gem tribute started r90 and actually completed r95; bag48→0 and side0 score+48 agree. At r106 Issac directly dealt 68.5 camp HP loss, establishing productive return rather than arrival alone.',
  'This body also dealt direct enemy damage during r54–57 in the bounded lead-in; this observed fighting precedes the capture/recall sequence and does not prove a priority rule.'
 ]),
 'uni-fragment-return':dict(status='complete',focus=[6],seq=[31670,31724,31762,32213,32259,32266,33247,33833,34039],observations=[
  'Univardisty Issac6 killed the last camp in group1 r325; capture started r326 phase7 and recall started r326 phase10 at 295.4499816894531/1375 HP with an empty bag.',
  'On r331, payout58 at phase7 preceded recall relocation at phase14 and full spawn recovery at phase13. The sampled next-round spawn arrival r332 is a one-round-late observation; exact native arrival is r331.',
  'Tribute began r341 for six owner turn ends and completed r347: bag58→0, side1 score+58. Direct basic attack r349 input6309 dealt121.5 to enemy Ren1, from Issac position14,19 outside its spawn.'
 ]),
 'procless-fragment-recovery':dict(status='complete',focus=[3],seq=[75013,75092,75523,75734,76242,76267,76718,76733,76743,77912,78480,79351],observations=[
  'Procless had already made group1 reward available r771. Allied Issac1 left its capture region r776 with timer1, resetting to neutral; Stellar3 later became holder and capture restarted r784.',
  'Stellar3 dealt518 direct enemy HP loss r778. At r784 it recalled on the capture region at83.70001220703125/1125 HP with zero gems.',
  'At r789 phase7 it received250 gold and58 gems; later phase14 it relocated to spawn, and phase13 healed to1125. No death or inferred rescue is needed to establish this completed recovery.',
  'Tribute801 completed807 with score+58; at816 direct cast input13581 caused1116 HP loss to opposing Issac6. The immediately adjacent prior tribute775 belongs to an earlier bag and must not be attributed to payout789.'
 ]),
 'fish-swirl-bank-first':dict(status='complete',focus=[0],seq=[18320,18391,19317,20718,22334,22336,23228,23589],observations=[
  'Fish Ren0 received360 gold and88 gems at group18 payout106, after ally Stellar1 made the camp reward available100.',
  'Ren started tribute113 and completed122: bag88→0, side0 score+88. On the very next native action in the same round it began recall with430 gold, zero gems, and1000/1000 HP.',
  'Recall completed127, purchases changed HP/maxHP, and Ren dealt212.5 camp HP loss by cast129. Full-HP recall here is observable; shopping/repositioning intent is not directly observed.',
  'A Ren-owned spell step r98 caused two enemy HP losses while Ren was approaching the camp sequence; remote spell ownership is not proof of its personal vision of either recipient.'
 ]),
 'sneaky-swirl-split':dict(status='complete-two-carriers',focus=[1,2],seq=[64681,65645,65767,66296,66544,66674,66680,67190,67196,67404,67919,68295,68828,71758,73894],observations=[
  'Sneaky Stellar1 made group18 reward available353; capture began359. Cassi2 began recall359 at359/700 HP, Stellar1 began recall362 at1074.60009765625/1125 HP.',
  'Payout364 divided the camp into two actual personal receipts:180 gold+44 gems each. Cassi recall timer0 and Stellar timer3 were visible at payout; the two bodies did not accelerate the capture countdown.',
  'Cassi relocated home later364 and healed700; Stellar relocated367 and healed1125. Separate tribute starts368/371 completed373/376 with two independent bag44→0 and side0 score+44 events.',
  'Both bodies later caused camp HP loss, Cassi392 and Stellar404. This establishes two delivered shares and two returns, not a causal claim that sharing beat a single carrier.'
 ]),
 'procless-rows-cycle':dict(status='complete',focus=[8],seq=[3027,3057,3228,3710,3872,3879,5697,6633,9210,10745],observations=[
  'On rows, procless Varg8 recalled25 after group1 capture had started24. Payout29 supplied270 gold+66 gems with one recall tick still remaining.',
  'Recall relocated30 and full recovery followed at turn end. Tribute started43 at35,34 targeting altar34,33 and completed50, with bag66→0 and side1 score+66.',
  'Actual next work was r69 direct basic-attack HP loss95 to each of three group1 camps after their respawn; the next clear80 is also in the bounded trace. Body8 is procless, not Univardisty.'
 ]),
 'fish-pilgrimage-long-return':dict(status='complete-long-cycle',focus=[11],seq=[109634,109656,110475,110618,111448,111458,120872,123339,126009],observations=[
  'Fish Varg11 cleared group12 r662, collected780 gold+144 gems r668 at770/1200 HP, and began recall later668.',
  'Recall arrived673 at48,1; purchases changed maxHP to1500, followed by full recovery at turn end. The first next-round spawn sample674 is later than native arrival.',
  'Tribute did not start until730, and its15-countdown channel completed745 with side1 score+144. At762 direct basic attack dealt220 enemy HP loss from26,49.',
  'This successful path still occupies94 world rounds from receipt668 to recorded productive return762. It is an example of travel/channel cost to measure, not proof that recall was the fastest route.'
 ]),
 'uni-fragment-adverse':dict(status='adverse-no-delivery-or-recovery',focus=[4],seq=[6774,7090,7356,7685,7750,8117,8178,8711],observations=[
  'Univardisty Stellar4 left group1 capture at75 with timer3; it restarted79 and began recall at510/750 HP.',
  'An enemy cast r83 input1676 interrupted recall at timer1; native channel1→0 and HP loss are visible. This recall command did not reach spawn.',
  'Stellar nevertheless collected250 gold+58 gems r84 at220/750 HP. It died r89 carrying58 before any tribute completion. Payout and recall command do not establish secured score or recovery.'
 ]),
 'sneaky-eight-adverse':dict(status='adverse-combat-continuation',focus=[5],seq=[19622,19656,20353,20466,20747,20895],observations=[
  'On eight, an opposing Tavi11 cast made camp3 reward available141. Sneaky Varg5 held the capture begun142 and collected180 gold+44 gems147 at542.5/1000 HP.',
  'Varg basic attacks continued147,149,150, each causing65 enemy HP loss. It died in its own r150 basic-attack frame carrying44, with no tribute completion.',
  'The step actor is Varg5 even though Varg dies in that step. Secondary/retaliation loss means actor identity must not be called the killer. This bounds an economic capture followed by adverse combat continuation without asserting why either bot chose it.'
 ]),
 'sneaky-lanes-parallel':dict(status='parallel-work-and-delivery',focus=[0,1,2,3,5],seq=[5616,5634,5836,6235,6445,6661,6989,7153,7651,7821,7895,8591,8808,8912,8932,9228,9619,10353,11627,12213],observations=[
  'Sneaky distributed five bodies across distinct lanes camps. Issac1/Stellar2/Tavi5/Cassi0/Willow3 each individually received24 gems from groups10/12/38/8/36 at rounds43/45/46/49/50 respectively.',
  'All five actually completed their own24-gem tributes at rounds50/54/55/58/60. These are five separate score+24 and personal bag24→0 events, totaling120 permanent score, rather than five queued tribute commands.',
  'Issac and Stellar were already doing actual camp HP loss again at56; Issac got a second24-gem camp receipt65 and banked it72; Tavi caused camp HP loss75. No recall was issued by these five in this bounded20–85 window.',
  'Parallel participation is observed. The trace alone does not establish a central assignment algorithm or that each bot had full teammate position/vision information.'
 ]),
 'sneaky-corners-concession':dict(status='adverse-capture-concession-with-enemy-carrier-death',focus=[6,7,10,3],seq=[45271,45899,45951,46238,46472,47090,47660,48298,48877,50004,50854,51293],observations=[
  'Sneaky Cassi6 made group2 reward available266. Side1 capture starts270,272,277,284 repeatedly reset when that same holder moves off the region at270,273,280,287; later two resets occurred with capture timer2.',
  'The r287 move34,37→35,38 reset team1,timer2 to neutral,timer0. This is a direct same-step capture state transition, not an inference from another body recalling.',
  'Univardisty Tavi3 began side0 capture294 and received48 gems299. Tavi died carrying48 at301 before delivering, so enemy receipt was not permanent enemy score.',
  'Sneaky Willow/Issac recalls277/285 occurred at37,33 and35,28 and are not the capture-holder departures. They must not be described as causing group2 loss merely because they co-occurred.'
 ])
}
episodes=[];checks=[]
for it in index:
 key=it['key'];sp=specs[key];native_path=HERE/(key+'.native-frames.json.gz');nb=native_path.read_bytes();native=json.loads(gzip.decompress(nb));ext_path=HERE/(key+'.trace-extract.json');ext=json.loads(ext_path.read_text(encoding='utf8'));native_byseq={f['seq']:f for f in native['frames']}
 assert it['raw_sha256']==native['raw_sha256']==ext['raw_sha256']
 assert it['trace_sha256']==hashlib.sha256(pathlib.Path(it['trace_path']).read_bytes()).hexdigest()
 assert hashlib.sha256(pathlib.Path(native['raw_path']).read_bytes()).hexdigest()==it['raw_sha256']
 assert native['raw_header_patch']==native['raw_header_format']=='0.0.2'
 assert native['engine_sha256']==ext['engine_sha256']=='e123b59d9dea198762ab7a04db9b3cb6d06dfa991088e41c24750fc4cb88b947'
 exact_native=[];exact_damage=[]
 for seq in sp['seq']:
  if seq in native_byseq:exact_native.append(native_byseq[seq])
  damage=next((a for a in ext['damage'] if a['seq']==seq),None)
  if damage:exact_damage.append(damage)
  assert seq in native_byseq or damage,(key,seq)
 # Compare independently saved native event states with the coordination trace's event states.
 verified=0
 for event in ext['submissions']+ext['captures']:
  if event['seq'] not in native_byseq:continue
  frame=native_byseq[event['seq']];assert frame['r']==event['r'] and frame['step'][1]==event['input']
  if 'after'in event and 'delta'in event:
   for c in frame['c']:
    a=next(x for x in event['after'] if x[0]==c[0]);assert [c[3],c[4],c[5],c[6],c[7],c[8],c[9]]==[a[1],a[2],a[3],a[4],a[5],a[6],a[7]]
  verified+=1
 req=requests[it['id']]
 body={**it,'teams':ext['teams'],'actors':sp['focus'],'roster':ext['roster'],'status':sp['status'],'observations':sp['observations'],'native_path':str(native_path),'native_sha256':hashlib.sha256(nb).hexdigest(),'native_columns':native['columns'],'trace_extract_path':str(ext_path),'trace_extract_sha256':hashlib.sha256(ext_path.read_bytes()).hexdigest(),'raw_path':native['raw_path'],'raw_header_patch':native['raw_header_patch'],'raw_header_format':native['raw_header_format'],'series_url':req['series_url'],'series_id':req['series_id'],'created_at':req['created_at'],'group_api_reference':req['group_api_reference'],'phase_events':exact_native,'damage_events':exact_damage,'submissions':ext['submissions'],'captures':ext['captures'],'deaths':ext['deaths']}
 episodes.append(body);checks.append({'key':key,'raw_and_trace_sha256_verified':True,'raw_header_patch_format_verified':True,'engine_pin_verified':True,'native_events':len(exact_native),'damage_events':len(exact_damage),'crosschecked_capture_submission_events':verified})
out={'scope':'Purposively selected bounded examples from 92 deduplicated patch0.0.2 top4-v-top4 attribution units in the 2026-10-16 11:41:43 UTC acquisition cutoff; descriptive case evidence only, no population or causal estimates. Rank numbers within source teams belong to that frozen ladder, not a later live rank. Parent research may bind current rank to a refreshed snapshot.','historical_examples_included':False,'interpretation_limits':['Host coordinates are omniscient geometry and do not establish personal visibility, path reachability or intended decisions.','Same native step actor can cause retaliation/secondary HP losses; a death step actor is not automatically its killer.','Exact phase14 recall relocation and phase13 recovery can occur before the first next-round phase10 spawn sample.','A tribute command is not completion; complete deliveries require native bag decrease and team score increase.','Exact camp clear means group state1→2/rewardAvailable0→1 in its actual native frame. Existing coordination scanner only records phase7 capture transitions and would miss this phase10/phase9 start.','Parallel collectors and recall overlap observed here do not prove central role assignment or strategy optimality.'],'episodes':episodes,'validation':checks}
(HERE/'audited-episodes.json').write_text(json.dumps(out,indent=2),encoding='utf8')
artifact_index={'primary':str(HERE/'audited-episodes.json'),'primary_sha256':hashlib.sha256((HERE/'audited-episodes.json').read_bytes()).hexdigest(),'entries':[{k:e[k] for k in ['key','id','map','status','bounds','trace_path','trace_sha256','raw_path','raw_sha256','engine_sha256','native_path','native_sha256','trace_extract_path','trace_extract_sha256']} for e in episodes],'screening_only':['candidate-cycles.json','concession-candidates.json'],'scripts':['mine.py','select.py','native-frames.mjs','audit.py','curate.py']}
(HERE/'artifact-index.json').write_text(json.dumps(artifact_index,indent=2),encoding='utf8')
print(json.dumps({'episodes':len(episodes),'checks':checks,'primary_sha256':artifact_index['primary_sha256']},indent=2))
