import json,gzip,pathlib
HERE=pathlib.Path(__file__).resolve().parent;MATCH=HERE.parents[1]/'combat-research/matches';m=json.loads((MATCH/'manifest-bound.json').read_text(encoding='utf8'))
result=[]
for req in m['requests']:
 if req['replay_patch']!='0.0.2' or not all(t['rank']<=4 for t in req['teams'].values()):continue
 p=MATCH/'current'/f"{req['id']}.coord.json.gz";d=json.loads(gzip.decompress(p.read_bytes()));ro={c['id']:c for c in d['roster']};rs={s['r']:s for s in d['rounds']}
 for recall in (a for a in d['actions'] if a['kind']==11):
  actor=recall['actor'];team=recall['team'];rr=recall['r'];s=rs.get(rr+1)
  if not s:continue
  for g,b in enumerate(s['groups']):
   if b[1]!=1 or b[2]!=team:continue
   later=next((cap for cap in d['captures'] if cap['group']==g and rr<cap['r']<=rr+24 and cap['before'][0]==1 and cap['after'][0]==0),None)
   if not later or not any(rec['team']!=team for rec in later['recipients']):continue
   arrival=next(((q['r'],c) for q in d['rounds'] if rr<q['r']<=rr+8 for c in q['c'] if c[0]==actor and c[5] and d['geometry']['spawn'][team][0]<=c[1]<d['geometry']['spawn'][team][2] and d['geometry']['spawn'][team][1]<=c[2]<d['geometry']['spawn'][team][3]),None)
   if not arrival:continue
   beforec=next(c for c in s['c'] if c[0]==actor)
   if abs(beforec[1]-arrival[1][1])<=3 and abs(beforec[2]-arrival[1][2])<=3:continue
   result.append(dict(id=d['id'],map=d['map'],team=d['teams']['ab'[team]]['name'],actor=actor,champion=ro[actor]['name'],group=g,recall=recall,waiting=s['groups'][g],arrival=arrival,enemy_payout=later,group_samples=[[q['r'],q['groups'][g]] for q in d['rounds'] if rr-2<=q['r']<=later['r']]))
(HERE/'concession-candidates.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print('candidates',len(result))
for row in result[:18]:print(json.dumps({k:row[k] for k in ['id','map','team','actor','champion','group','waiting','arrival']}), 'recall',row['recall']['r'],'enemy',row['enemy_payout']['r'],row['enemy_payout']['recipients'])
