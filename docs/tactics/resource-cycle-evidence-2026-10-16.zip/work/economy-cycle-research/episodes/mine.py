import json,gzip,pathlib,hashlib,collections,bisect
ROOT=pathlib.Path(__file__).resolve().parents[2]
MATCH=ROOT/'combat-research/matches'
OUT=pathlib.Path(__file__).resolve().parent
manifest=json.loads((MATCH/'manifest-bound.json').read_text(encoding='utf8'))
requests=[r for r in manifest['requests'] if r['replay_patch']=='0.0.2' and all(t['rank']<=4 for t in r['teams'].values())]
def inside(c,box):return box[0]<=c[1]<box[2] and box[1]<=c[2]<box[3]
allcycles=[]; adverse=[]; overlaps=[]; split=[]
for r in requests:
 p=MATCH/'current'/f"{r['id']}.coord.json.gz"
 if not p.exists():continue
 d=json.loads(gzip.decompress(p.read_bytes()));ro={c['id']:c for c in d['roster']};rg={s['r']:s for s in d['rounds']};camps={c['id']:c for c in d['camps']}
 actions=collections.defaultdict(list);deaths=collections.defaultdict(list);payouts=collections.defaultdict(list);submits=collections.defaultdict(list);prods=collections.defaultdict(list)
 for a in d['actions']:actions[a['actor']].append(a)
 for a in d['deaths']:deaths[a['id']].append(a)
 for a in d['submissions']:
  for pre,post in zip(a['c'],a['after']):
   if pre[7]>post[7] and a['delta'][ro[pre[0]]['team']]>0:submits[pre[0]].append(a)
 for a in d['damage']:
  if a['source'] and a['source']['kind']==1:
   actor=a['source']['id']
   if any(l[2]!=ro[actor]['team'] or l[0]==2 for l in a['losses']):prods[actor].append(a)
 for cap in d['captures']:
  if cap['before'][0]==1 and cap['after'][0]==0:
   for rec in cap['recipients']:
    payouts[rec['id']].append(cap);prods[rec['id']].append(cap)
 for actor,caps in payouts.items():
  team=ro[actor]['team'];name=d['teams']['ab'[team]]['name'];spawn=d['geometry']['spawn'][team]
  for cap in caps:
   seq=cap['seq'];cr=cap['r'];group=cap['group'];rec=next(x for x in cap['recipients'] if x['id']==actor);pre=next(x for x in cap['c'] if x[0]==actor)
   nextdeath=next((x for x in deaths[actor] if x['seq']>seq),None);endseq=nextdeath['seq'] if nextdeath else 10**9
   sub=next((x for x in submits[actor] if seq<x['seq']<endseq),None)
   recall=next((a for a in actions[actor] if a['kind']==11 and cr-5<=a['r'] and a['seq']<endseq),None)
   # nearest pre-payout recall if any; otherwise first later recall
   nearrec=[a for a in actions[actor] if a['kind']==11 and cr-5<=a['r']<=cr and a['seq']<seq]
   if nearrec:recall=nearrec[-1]
   postrec=next((a for a in actions[actor] if a['kind']==11 and seq<a['seq']<endseq),None)
   if not nearrec:recall=postrec
   arrivals=[]
   if recall:
    arrivals=[(s['r'],c) for s in d['rounds'] if recall['r']<s['r']<=recall['r']+12 for c in s['c'] if c[0]==actor and c[5] and inside(c,spawn)]
   arr=arrivals[0] if arrivals else None
   prod=next((a for a in sorted(prods[actor],key=lambda x:x['seq']) if arr and a['seq']>rg[arr[0]]['seq'] and a['seq']<endseq and a['r']>arr[0]),None)
   # prior actual camp work limited to previous payout of this group / 35 rounds
   prior=[a for a in d['damage'] if cr-35<=a['r']<=cr and a['seq']<seq and any(l[0]==2 and camps.get(l[1],{}).get('group')==group for l in a['losses'])]
   start=prior[0]['r'] if prior else cr
   gseq=[(s['r'],s['groups'][group]) for s in d['rounds'] if start<=s['r']<=cr]
   waiting=[(rr,g) for rr,g in gseq if g[1]==1]
   competing=[a for a in d['damage'] if start<=a['r']<=cr and a['source'] and a['source']['id']==actor and any(l[0]==1 and l[2]!=team for l in a['losses'])]
   row=dict(id=r['id'],map=r['map'],team=name,actor=actor,champion=ro[actor]['name'],group=group,start=start,capture_r=cr,capture_seq=seq,capture_input=cap['input'],reward=rec,hp=pre[3],maxhp=pre[4],bag_before=pre[7],waiting_first=waiting[0] if waiting else None,camp_work_sources=sorted(set(a['source']['id'] for a in prior if a['source'])),camp_work_rounds=[prior[0]['r'],prior[-1]['r']] if prior else None,recall_r=recall['r'] if recall else None,recall_input=recall['input'] if recall else None,recall_hp=recall['before'][3] if recall else None,recall_bag=recall['before'][7] if recall else None,arrival=arr,submit_r=sub['r'] if sub else None,submit_input=sub['input'] if sub else None,submit_delta=sub['delta'][team] if sub else None,return_prod_r=prod['r'] if prod else None,return_prod_seq=prod['seq'] if prod else None,return_kind=('capture' if prod and 'group'in prod else 'damage') if prod else None,nextdeath_r=nextdeath['r'] if nextdeath else None,competing_combat_count=len(competing),split=len(cap['recipients'])>1)
   allcycles.append(row)
   if recall and recall['seq']<seq:overlaps.append(row)
   if row['split']:split.append(row)
   if not sub and nextdeath and nextdeath['r']-cr<=30:adverse.append(row)
summary={'requests':len(requests),'cycles':allcycles,'adverse':adverse,'overlaps':overlaps,'split':split}
(OUT/'candidate-cycles.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
print('requests',len(requests),'cycles',len(allcycles),'overlaps',len(overlaps),'split',len(split),'adverse',len(adverse))
for category,rows in [('complete',[c for c in allcycles if c['submit_r'] and c['arrival'] and c['return_prod_r']]),('overlap',[c for c in overlaps if c['submit_r'] and c['arrival'] and c['return_prod_r']]),('split',split),('adverse',adverse)]:
 print('\n'+category)
 chosen=sorted(rows,key=lambda x:(-(x['competing_combat_count']>0),-x['reward']['gems'],x['capture_r']))[:20]
 for c in chosen:print(json.dumps({k:c[k] for k in ['id','map','team','actor','champion','group','start','capture_r','reward','hp','recall_r','arrival','submit_r','submit_delta','return_prod_r','nextdeath_r','competing_combat_count','split']},ensure_ascii=True))
