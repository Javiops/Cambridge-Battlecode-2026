// Read-only reconstruction of selected windows from already validated raw replays.
// No bot execution, simulation, game creation or replay mutation.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import zlib from 'node:zlib';
import {E,out,checked} from '../../combat-research/matches/engine.mjs';
const here=path.dirname(new URL(import.meta.url).pathname).replace(/^\/(.:)/,'$1');
const selected=JSON.parse(fs.readFileSync(path.join(here,'selected-index.json'))),manifest=JSON.parse(fs.readFileSync(path.join(here,'../../combat-research/matches/manifest-bound.json')));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),engineSha=sha(fs.readFileSync(process.env.COMBAT_ENGINE_PATH));
if(engineSha!=='e123b59d9dea198762ab7a04db9b3cb6d06dfa991088e41c24750fc4cb88b947')throw Error('Wrong patch2 engine');
const snap=E.Engine_Malloc(40152),full=E.Engine_Malloc(184696),pp=E.Engine_Malloc(8),v=()=>new DataView(E.memory.buffer);
v().setUint32(pp,2,true);v().setUint32(pp+4,0xffffffff,true);
const gameIds=[...new Set(selected.map(s=>s.id))];
for(const gid of gameIds){
 const picks=selected.filter(s=>s.id===gid),req=manifest.requests.find(r=>r.id===gid),raw=fs.readFileSync(req.raw);
 const rawPatch=[...raw.subarray(8,11)].join('.'),rawFormat=[...raw.subarray(11,14)].join('.');
 if(raw.readBigUInt64LE(0)!==125779999602273n||rawPatch!=='0.0.2'||rawFormat!=='0.0.2'||req.replay_patch!==rawPatch||sha(raw)!==req.raw_sha256)throw Error('Invalid raw header/version/hash binding');
 const p=E.Engine_Malloc(raw.length);new Uint8Array(E.memory.buffer,p,raw.length).set(raw);checked('Game_FromReplayFileBytes',p,raw.length,out);const game=v().getBigUint64(out,true);E.Engine_Free(p);
 try{
  checked('Game_Visualiser_Timeline_GetMain',game,out);const timeline=v().getBigUint64(out,true);checked('Game_Visualiser_Timeline_Seek',game,timeline,0,0);
  const outputs=new Map(picks.map(s=>[s.key,{...s,raw_path:req.raw,raw_sha256:req.raw_sha256,raw_header_patch:rawPatch,raw_header_format:rawFormat,engine_path:process.env.COMBAT_ENGINE_PATH,engine_sha256:engineSha,columns:{champion:['id','team','type','x','y','hp','maxHP','alive','gold','gems','channelType','channelTimer','cooldown0','cooldown1','attackRange'],group:['state','rewardAvailable','captureTeam','captureTimer','respawnRounds'],step:['phase','input','owner','kind','actorKind','actor','fromX','fromY','toX','toY','sub','slot','abilityType']},frames:[]}]))
  const last=new Map();let max=Math.max(...picks.map(s=>s.bounds[1]));
  for(let seq=0;seq<500000;seq++){
   checked('Game_Visualiser_ReadTimelineState',game,snap);let d=v(),u=n=>d.getUint32(snap+n,true),i=n=>d.getInt32(snap+n,true),round=u(8),phase=u(24);
   if(round>max||phase===11)break;
   const active=picks.filter(s=>s.bounds[0]<=round&&round<=s.bounds[1]);
   if(active.length){
    const step=[u(24),u(56),u(60),u(68),u(72),u(76),i(80),i(84),i(88),i(92),u(104),u(108),u(112)],score=[Number(d.getBigUint64(snap+32,true)),Number(d.getBigUint64(snap+40,true))];
    const lean=Array.from({length:u(172)},(_,k)=>{const q=196+k*252;return [u(q+4),u(q+8),u(q+12),i(q+16),i(q+20),d.getFloat32(snap+q+24,true),d.getFloat32(snap+q+28,true),u(q+32),u(q+36),u(q+40)];});
    checked('Game_Visualiser_ReadState',game,pp,full);d=v();const fu=n=>d.getUint32(full+n,true),fi=n=>d.getInt32(full+n,true),ff=n=>d.getFloat32(full+n,true);
    const all=Array.from({length:fu(120)},(_,k)=>{const q=140+k*456;return [fu(q+4),fu(q+8),fu(q+12),fi(q+20),fi(q+24),ff(q+28),ff(q+32),fu(q+224),fu(q+232),fu(q+236),fu(q+440),fi(q+436),fu(q+92),fu(q+96),ff(q+112)];});
    const groups=Array.from({length:fu(128)},(_,k)=>{const q=123436+k*20;return [fu(q),fu(q+4),fu(q+8),fi(q+12),fi(q+16)];});
    for(const s of active){
     const c=all.filter(c=>s.actors.includes(c[0])),g=Object.fromEntries(s.group_ids.map(k=>[k,groups[k]])),signature=JSON.stringify([c,g,score]);
     if(last.get(s.key)!==signature||step[4]===1&&s.actors.includes(step[5])&&step[10]===0){outputs.get(s.key).frames.push({seq,r:round,step,score,c,groups:g,world:lean});last.set(s.key,signature);}
    }
   }
   checked('Game_Visualiser_Timeline_ReplayNext',game,1);
  }
  for(const o of outputs.values()){
   const file=path.join(here,o.key+'.native-frames.json.gz');fs.writeFileSync(file,zlib.gzipSync(JSON.stringify(o),{level:6}));console.log(JSON.stringify({key:o.key,frames:o.frames.length,file,sha256:sha(fs.readFileSync(file))}));
  }
 }finally{checked('Game_Destroy',game);}
}
