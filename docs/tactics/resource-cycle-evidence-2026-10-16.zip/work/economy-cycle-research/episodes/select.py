import json,gzip,pathlib,hashlib,collections
HERE=pathlib.Path(__file__).resolve().parent
MATCH=HERE.parents[1]/'combat-research/matches'
selections=[
 ('sneaky-packs-overlap','c55af396-08ca-4128-a37c-968ebd6e451d',50,110,[1],[2]),
 ('uni-fragment-return','9702e344-a397-4e37-a9ab-3310c000264a',308,353,[6],[1]),
 ('procless-fragment-recovery','9702e344-a397-4e37-a9ab-3310c000264a',762,820,[3],[1]),
 ('fish-swirl-bank-first','24d776a8-2b1b-4703-b01b-5cdff42fb40f',72,133,[0],[18]),
 ('sneaky-swirl-split','ce6d20c1-3694-402c-b2e9-70a0aeb71f03',338,408,[1,2],[18]),
 ('procless-rows-cycle','d2f8eca2-f754-48f1-9615-068507e064f9',1,90,[8],[]),
 ('fish-pilgrimage-long-return','839b0f80-95e0-472b-9cd9-db592ebe09a2',633,765,[11],[12]),
 ('uni-fragment-adverse','9702e344-a397-4e37-a9ab-3310c000264a',49,92,[4],[1]),
 ('sneaky-eight-adverse','00971df3-7cb0-46de-9f7d-d4cb383b4613',115,153,[5],[3]),
 ('sneaky-lanes-parallel','a9e180f9-905b-46b4-b3be-0b6b6e845bc9',20,85,[0,1,2,3,4,5],[8,10,12,36,38]),
 ('sneaky-corners-concession','953c804b-a2eb-49a0-bc9e-5b792eddce9a',260,315,[6,7,10,3],[2]),
]
index=[]
for key,gid,lo,hi,actors,groups in selections:
 p=MATCH/'current'/f'{gid}.coord.json.gz';d=json.loads(gzip.decompress(p.read_bytes()));ro={c['id']:c for c in d['roster']};cm={c['id']:c for c in d['camps']}
 captures=[a for a in d['captures'] if lo<=a['r']<=hi and (a['group'] in groups or any(c['id'] in actors for c in a['recipients']))]
 if not groups:groups=sorted(set(a['group'] for a in captures))
 actions=[a for a in d['actions'] if lo<=a['r']<=hi and a['actor'] in actors]
 events={
 'key':key,'id':gid,'map':d['map'],'teams':d['teams'],'actors':actors,'actor_roster':[ro[a] for a in actors], 'group_ids':groups,'bounds':[lo,hi],
 'trace_path':str(p),'trace_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'raw_sha256':d['raw_sha256'],'engine_sha256':d['engine_sha256'],'patch':d['patch'],
 'roster':d['roster'],'spawn':d['geometry']['spawn'],'camps':[c for c in d['camps'] if c['group'] in groups],
 'captures':captures,'submissions':[a for a in d['submissions'] if lo<=a['r']<=hi and any(x[0] in actors and x[7]>next(y[7] for y in a['after'] if y[0]==x[0]) for x in a['c'])],
 'actions':actions,'damage':[a for a in d['damage'] if lo<=a['r']<=hi and (a['source'] and a['source']['id'] in actors or any(l[0]==1 and l[1] in actors or l[0]==2 and cm.get(l[1],{}).get('group') in groups for l in a['losses']))],
 'deaths':[a for a in d['deaths'] if lo<=a['r']<=hi and a['id'] in actors],
 'rounds':[dict(r=s['r'],seq=s['seq'],input=s['input'],c=[c for c in s['c'] if c[0] in actors],groups={g:s['groups'][g] for g in groups},score=s['score']) for s in d['rounds'] if lo<=s['r']<=hi]
 }
 (HERE/(key+'.trace-extract.json')).write_text(json.dumps(events,indent=2),encoding='utf8')
 index.append({k:events[k] for k in ['key','id','map','actors','group_ids','bounds','trace_path','trace_sha256','raw_sha256','engine_sha256','patch']})
 print('\n',key,d['map'], [(a,ro[a]['name'],d['teams']['ab'[ro[a]['team']]]['name']) for a in actors])
 print('commands',[(a['r'],a['input'],a['kind'],a['actor'],a['before'][3],a['before'][7],a['from'],a['to']) for a in actions if a['kind'] not in [4,5,6]])
 print('captures',[(a['r'],a['input'],a['group'],a['before'],a['after'],a['recipients']) for a in captures])
 print('submits',[(a['r'],a['input'],a['delta'],[(x[0],x[7]) for x in a['c'] if x[0] in actors]) for a in events['submissions']])
 print('deaths',events['deaths'])
(HERE/'selected-index.json').write_text(json.dumps(index,indent=2),encoding='utf8')
