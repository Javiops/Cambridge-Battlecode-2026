import json
x=json.load(open('work/economy-cycle-research/geometry/inputs.json'))
for a in x:
 if a['map']in['rushbait_v2','pilgrimage','swirl']:print(a['map'],a['geometry']['spawn'],a['geometry']['symmetry'],a['source_id'])
