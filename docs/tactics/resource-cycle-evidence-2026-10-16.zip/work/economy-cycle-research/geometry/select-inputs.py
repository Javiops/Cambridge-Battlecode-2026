from pathlib import Path
import json,gzip,hashlib
r=Path('work/economy-cycle-research/geometry');m=json.load(open('work/combat-research/matches/manifest-bound.json'));a={}
for x in m['requests']:
 if x['replay_patch']!='0.0.2' or x['map']in a:continue
 p=Path('work/combat-research/matches/current')/(x['id']+'.coord.json.gz');b=p.read_bytes();g=json.loads(gzip.decompress(b));a[x['map']]={'map':x['map'],'source_id':x['id'],'raw_sha256':x['raw_sha256'],'trace_sha256':hashlib.sha256(b).hexdigest(),'engine_sha256':g['engine_sha256'],'geometry':g['geometry'],'camps':g['camps']}
(r/'inputs.json').write_text(json.dumps(list(a.values())));print('maps',len(a))

