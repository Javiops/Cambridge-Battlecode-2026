from pathlib import Path
import os,json,concurrent.futures,subprocess,time
r=Path('work/economy-cycle-research/matches').resolve();o=r/'current';o.mkdir(exist_ok=True);(o/'logs').mkdir(exist_ok=True)
node=r'C:/Users/frans/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe';scanner=Path('work/combat-research/matches/scan-coordination.mjs').resolve();eng=Path('work/combat-research/acquisition/runtime').resolve()
def job(ver,i):
 env={**os.environ,'COMBAT_ENGINE_PATH':str(eng/('v0_0_2-DFj19m76.wasm'if ver=='0.0.2'else'v0_0_1-ctH8uuEb.wasm'))}
 with(o/'logs'/f'{ver}-{i}.log').open('w',encoding='utf8')as f:p=subprocess.run([node,str(scanner),'--manifest',str(r/f'missing-{ver}.json'),'--out-dir',str(o),'--stride','4','--index',str(i),'--resume'],env=env,stdout=f,stderr=subprocess.STDOUT)
 return{'patch':ver,'worker':i,'exit_code':p.returncode}
t=time.time();result=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
 for f in concurrent.futures.as_completed([pool.submit(job,v,i)for v in ['0.0.2','0.0.1']for i in range(4)]):result.append(f.result());print(json.dumps(result[-1]),flush=True)
x={'jobs':result,'seconds':time.time()-t,'completed':len(list(o.glob('*.coord.json.gz')))};(o/'run-report.json').write_text(json.dumps(x,indent=2));print(json.dumps(x),flush=True)
