from pathlib import Path
import json,hashlib,zipfile,gzip,io,collections
R=Path(__file__).resolve().parent;W=R.parent;P=R/'publication';S=R/'evidence-staging';S.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
def add(p,name=None):
    p=Path(p)
    if not p.is_file():raise FileNotFoundError(p)
    name=name or p.relative_to(W.parent).as_posix()
    if name in files and files[name]!=p.read_bytes():raise ValueError('Duplicate '+name)
    files[name]=p.read_bytes()
def add_text(name,s):files[name]=s.encode('utf8')
for folder in ['acquisition','quant','geometry','policy','episodes']:
    for p in (R/folder).glob('*'):
        if p.is_file() and p.suffix in ['.py','.mjs']:add(p)
for n in ['ladder-snapshot.json','history-index.json','manifest-selected.json','manifest-native.json','manifest-unique.json','acquisition-report.json']:add(R/'acquisition'/n)
add(R/'matches/manifest-bound.json');add(R/'matches/decode-missing.py');add(R/'matches/current/run-report.json')
for n in ['source-reference.json']:add(R/'repository'/n)
for n in ['definitions.md']:add(R/'quant'/n)
for n in ['summary.json','source-audit.json','denominator-audit.json','validation.json','findings.md','findings.json','aggregates.json','run-report.json','top10-primary-team-summary.json','top10-primary-team-summary.csv','champion-role-summary.json','geometry-bins.json','geometry-bins.csv','geometry-findings.md','joined-cycle-stages-summary.json','historical-sensitivity.json']:
    add(R/'quant/current'/n)
# Filter a compact but complete current-top4 event projection. Population aggregates/audits above cover all2588.
primary_rows={}
for p in (R/'quant/current').glob('*.jsonl.gz'):
    kept=[]
    with gzip.open(p,'rt',encoding='utf8') as f:
        for line in f:
            x=json.loads(line)
            if x.get('patch')=='0.0.2' and x.get('cohort')=='top4_h2h':kept.append(line)
    if kept:
        data=gzip.compress(''.join(kept).encode('utf8'),compresslevel=9,mtime=0)
        name='primary-event-ledgers/'+p.name;files[name]=data;primary_rows[p.name]=len(kept)
for p in (R/'quant/native-gems-current').glob('*'):
    if p.is_file():add(p)
for n in ['inputs.json','static-route-features.json','native-distance-fixture.json']:add(R/'geometry'/n)
for n in ['native-cycle-timing-current.json','native-cycle-timing-summary.json','native-cycle-timing-manifest.json','policy-validation.json','FINAL-HANDOFF.txt','cycle-timing-current-002.md','cycle-decision-contract.md']:add(R/'policy'/n)
for n in ['audited-episodes.json','artifact-index.json','validation.json','publication-review.json']:add(R/'episodes'/n)
episodes=json.loads((R/'episodes/audited-episodes.json').read_bytes())['episodes']
seen_raw=set();seen_api=set()
for e in episodes:
    for k in ['native_path','trace_extract_path']:add(e[k])
    if e['raw_sha256'] not in seen_raw:
        add(e['raw_path'],'selected-raw/'+Path(e['raw_path']).name);seen_raw.add(e['raw_sha256'])
    api=e['group_api_reference']
    if api['sha256'] not in seen_api:
        add(api['path'],'selected-public-series/'+Path(api['path']).name);seen_api.add(api['sha256'])
for n in ['matches/engine.mjs','matches/scan-coordination.mjs','policy/native-harness.mjs']:
    add(W/'combat-research'/n)
for n in ['prepare-publication.py','write-research.py','package-evidence.py']:add(R/n)
for p in sorted(P.glob('*.md')):add(p,'published-docs/'+p.name)
repro='''# Reproduction and scope

This archive is resource-cycle documentation evidence, not a submission bot.
Extract it at a chosen workspace root; scripts retain `work/economy-cycle-research/` and supporting `work/combat-research/` relative locations. Python3 and Node22 were used. The original absolute paths are provenance, not a requirement to use that user's folder. Rebind them to the extracted/reacquired bytes, preserving hashes and ordered external team IDs; never bypass a hash mismatch.

## Population and acquisition

Use acquisition/manifest-selected.json's fixed3580 source IDs, not a live re-selection if reproducing this cohort. `fetch-native.py` can reacquire public ZIP bundles and validate CRC/raw SHA. HTTP202 pending JSON is not a ZIP and must be retried at the same bundle URL. Existing hashed caches are optional. Manifest native/bound records include original public bundle URLs, raw/bundle SHA, patch header, ordered teams and series API references. There are2588 distinct raw trajectories,952patch2 and1636patch1. The history/rank snapshot fixes current-top10 identities; raw ladder profile extras are intentionally excluded.

Exact full-population trace caches and full-population event JSONL ledgers are omitted to bound this archive. All-population aggregates, source/denominator/conservation audits and compact primary150-H2H event ledgers are included. Eleven audited episodes have selected exact raw streams, independent native windows and trace extracts. All150 current-H2H thin personal-gem/group ledgers are included. Native replay observations require the correct official engine and ABI, not a new competitive match.

## Engines and decode

Obtain the official cambc2.2.2 embedded viewer assets from the official PyPI package. Engine0.0.2 file `v0_0_2-DFj19m76.wasm` SHA256e123b59d9dea198762ab7a04db9b3cb6d06dfa991088e41c24750fc4cb88b947; engine0.0.1 `v0_0_1-ctH8uuEb.wasm` SHA256ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc. Binaries are not redistributed. Set COMBAT_ENGINE_PATH to the correct file for each header patch, and COMBAT_ROOT when the scanner requires an output root. The wrapper refuses a full/timeline ABI other than184696/40152. Never decode both patches under an assumed common engine.

`work/combat-research/matches/scan-coordination.mjs --manifest <matching-patch-manifest> --out-dir <trace-dir>` reconstructs command, first-world-snapshot, damage, payout, bank and terminal observations. Run separate patch jobs. Rebind the canonical manifest's trace_path to validated outputs and source raw paths to reacquired raw bytes. Preserve aliases rather than count identical hashes repeatedly. The parent decoder runner shows the original parallel patch jobs and completed530 missing traces;2058 others were exact raw/team-matched cache reuse.

## Metrics

`python work/economy-cycle-research/quant/run-cycles.py --workers 4 --out-dir <directory> --manifest <bound-manifest> --trace-dir <trace-dir> --ladder <ladder-snapshot> --gem-dir <native-gems-current-directory>` performs sharded analysis and merges event ledgers. See `analyze-cycles.py --help` for supported options. Run `validate-cycles.py <directory>` and `write-findings.py <directory>` afterward. `definitions.md` distinguishes exact payouts, ordered mixed-gem followup, clean full-ledger receipt→bank, strict sampled recall boundary and observed productive return. Missing completion is not automatically failure. Both sides/bodies/events in a stream are correlated.

For exact primary personal-gem/group coverage, `scan-gem-ledger.mjs` and its runner retain every native frame's relevant changes under the same header/engine binding, verify bag conservation, then independently match captures and bank completions. See scripts' argument parsing, native-gems-current/run-report and audits for retained IDs/hashes. This supplement is available on150current-top4H2H streams only.

## Geometry, episodes and mechanics

Geometry `inputs.json` binds each exemplar to terrain/camp/source hashes. `build-features.mjs` calls official managed distance fields and stores dense static routes. Group layouts can vary under a label: `geometry-bins.py` verifies exact terrain/dimensions/spawns and queries each source's actual camp tiles, never assuming label+group index defines a layout. Static fields omit camps/champions/locks/readiness and are route lower bounds, not action ETAs. The four native distance/connectivity fixtures and per-stream join audit state coverage and missingness.

Episode reports preserve sequence, world round, input/phase, body/group identity and bags/scores. Current ranks may differ from the earlier frozen labels inside an original trace; use external team identity and the refreshed ladder. A death-step actor can cause retaliation/secondary effects and is not automatically the killer.

Set COMBAT_ENGINE_PATH to the0.0.2 asset and run `node work/economy-cycle-research/policy/probe-cycle-timing-current.mjs`. The script imports the preserved harness/wrapper, verifies engineSHA, constructs bounded native fixtures and writes full/compact observations. Twelve cases,97assertions cover recall durations, real occupied movement/second-tile contest, real basic interruption, public query limitations and reward joining active tribute. No guest bot executes; unmetered native mechanics cannot prove fuel safety or strategy strength.

## Integrity and interpretation

`member-manifest.json` lists included bytes/SHA for every other member. The external published manifest binds this ZIP; it is excluded from the ZIP to avoid circular self-hashing. Published documentation copy may differ only in packaging links from the policy draft hashed by the native timing manifest; that manifest identifies its exact original draft, not an altered claim.

No authentication material, private opponent code, generated test-map outcomes or new ladder challenges are included. New tactics are Planned, and the private live upload is not identified as byte-equal to the pinned source. Event distributions and selected examples are descriptive, not causal policy improvement.
'''
add_text('REPRODUCTION.md',repro)
manifest={'scope':'Curated source/replay/mechanics evidence; no bot implementation or competitive experiment. Paths under work retain original layout. Full-population trace and event caches omitted; primary current-top4 event/ledger projection included.','primary_event_projection_rows':primary_rows,'selected_raw_streams':len(seen_raw),'files':[{'path':n,'bytes':len(b),'sha256':sha(b)}for n,b in sorted(files.items())]}
add_text('member-manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
z=P/'resource-cycle-evidence-2026-10-16.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as arc:
    for n,b in sorted(files.items()):arc.writestr(n,b)
external={'artifact':{'file':z.name,'bytes':z.stat().st_size,'sha256':sha(z.read_bytes())},'scope':manifest['scope'],'members':len(files),'selected_raw_streams':len(seen_raw),'primary_event_projection_rows':primary_rows,'engines':{'0.0.2':'e123b59d9dea198762ab7a04db9b3cb6d06dfa991088e41c24750fc4cb88b947','0.0.1':'ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc'},'source_main':'ba93427c94c344b0fade0757208c5e0eeeb88c41'}
(P/'resource-cycle-evidence-manifest-2026-10-16.json').write_text(json.dumps(external,indent=2)+'\n',encoding='utf8')
print(json.dumps(external,indent=2))
