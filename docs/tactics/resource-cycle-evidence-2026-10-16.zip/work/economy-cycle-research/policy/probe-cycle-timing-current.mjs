import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {E,out,scratch,snap,checked,v,state,entity,pos,perspective,teleport,enginePath,cstring} from '../../combat-research/policy/native-harness.mjs';

const expectedHash='e123b59d9dea198762ab7a04db9b3cb6d06dfa991088e41c24750fc4cb88b947';
const engineHash=crypto.createHash('sha256').update(fs.readFileSync(enginePath)).digest('hex');
assert.equal(engineHash,expectedHash,'These cases must use the pinned current0.0.2 engine');
const records=[],checks=[];
let active;

function query(name,...args){const code=E[name](...args,out);return{code,error:code?cstring(E.GetLastErrorMsg()):null,value:code?null:v().getInt32(out,true)};}
function observe(g,label){
  const base=state(g),d=v(),u=n=>d.getUint32(snap+n,true),i=n=>d.getInt32(snap+n,true),f=n=>d.getFloat32(snap+n,true);
  const champs=Array.from({length:u(120)},(_,k)=>{const p=140+k*456;return{id:u(p+4),team:u(p+8),type:u(p+12),x:i(p+20),y:i(p+24),hp:f(p+28),alive:!!u(p+224),gold:u(p+232),gems:u(p+236),channelTimer:i(p+436),channelType:u(p+440),flags:u(p+36)};});
  const groups=Array.from({length:u(128)},(_,k)=>{const p=123436+k*20;return{group:k,state:u(p),available:!!u(p+4),captureTeam:u(p+8),captureTimer:i(p+12),respawnTimer:i(p+16)};});
  const publicState=query('Game_API_CampGroup_GetState',g,perspective(0,0),0);
  const publicCooldown=query('Game_API_CampGroup_GetCooldown',g,perspective(0,0),0);
  const publicChannel=query('Game_API_Champion_GetChannelTime',g,perspective(0,0),0);
  const scoreA=query('Game_API_GetSubmittedGemCount',g,0),scoreB=query('Game_API_GetSubmittedGemCount',g,1);
  const result={label,...base,champs,groups,public:{groupState:publicState,groupCooldown:publicCooldown,selfChannel:publicChannel,scoreA,scoreB}};
  active?.trace.push(result);return result;
}
function action(g,name,...args){const before=observe(g,'before:'+name),code=E[name](g,...args),result={name,code,error:code?cstring(E.GetLastErrorMsg()):null,...(name==='Game_Action_Move'?{successful:code?null:!!v().getInt32(out,true)}:{})};const after=observe(g,'after:'+name);active.actions.push({result,beforeIndex:active.trace.indexOf(before),afterIndex:active.trace.indexOf(after)});return result;}
function advance(g){checked('Game_Runner_EndTurn',g,0);observe(g,'owner-end');for(let k=0;k<1000;k++){let s=state(g);if(s.input&&s.phase===10)return s;checked('Game_Runner_Step',g);observe(g,'runner-step');}throw Error('advance bound');}
function toSelf(g){for(let k=0;k<100;k++){const s=state(g);if(s.input&&s.phase===10&&s.current===0)return s;advance(g);}throw Error('toSelf bound');}
function nextSelf(g){advance(g);return toSelf(g);}
function toActor(g,id){for(let k=0;k<30;k++){const s=state(g);if(s.input&&s.phase===10&&s.current===id)return s;advance(g);}throw Error('toActor bound');}
function create({singleTile=false}={}){
  checked('MapBuilder_Create',32,32,0,out);const m=v().getBigUint64(out,true);
  checked('MapBuilder_SetNumChampsPerTeam',m,2);
  [1,1,4,4].forEach((x,k)=>v().setInt32(scratch+k*4,x,true));checked('MapBuilder_SetTeamASpawnArea',m,scratch);
  checked('MapBuilder_AddAltar',m,13,15);
  checked('MapBuilder_AddCamp',m,0,13,14,out);if(!singleTile)checked('MapBuilder_AddCamp',m,3,14,14,out);
  checked('MapBuilder_VerifyIntegrity',m);checked('MapBuilder_Encode',m,out,out+4);const p=v().getUint32(out,true),n=v().getUint32(out+4,true);
  checked('Game_FromMapFileBytes',p,n,out,0);const g=v().getBigUint64(out,true);checked('MapBuilder_Destroy',m);checked('Game_Runner_Init',g);
  let j=0;for(let k=0;k<1000;k++){const s=state(g);if(s.input&&s.phase===12)checked('Game_Runner_DraftChampion',g,[0,1,4,5][j++],0);else if(s.input&&s.phase===10)return g;else checked('Game_Runner_Step',g);}throw Error('create bound');
}
function prepare(g,{home=false,other=false,singleTile=false}={}){
  assert.equal(state(g).current,0);
  if(home){checked('Game_Sandbox_GiveGold',g,0,150);action(g,'Game_Action_BuyItem',30,5);}
  // The two cardinally-connected camps form one two-tile capture region. Mirrored camps remain untouched.
  state(g);const d=v();const camps=Array.from({length:d.getUint32(snap+124,true)},(_,k)=>{const p=snap+7436+k*232;return{id:d.getUint32(p+4,true),x:d.getInt32(p+20,true),y:d.getInt32(p+24,true)};});
  active.setup={home,other,singleTile,camps};
  for(const c of camps.filter(x=>x.x===13||x.x===14))action(g,'Game_Sandbox_Damage',entity(1,0),entity(2,c.id,24),100000);
  teleport(g,0,13,14);if(other)teleport(g,1,14,14);
  observe(g,'prepared-new-waiting-reward');
}
function test(name,options,fn){const g=create(options);active={name,setup:null,trace:[],actions:[]};try{prepare(g,options);fn(g,active);active.final=observe(g,'final');records.push(active);}catch(e){active.error=String(e);active.stack=e.stack;records.push(active);}finally{active=null;checked('Game_Destroy',g);}}
function runUntil(g,round=11){for(let k=0;k<150;k++){const s=state(g);if(s.current===0&&s.round>=round)return;advance(g);}throw Error('run bound');}

for(const [name,home,hold] of [['normal_immediate',false,0],['normal_after_one_hold',false,1],['home_immediate',true,0],['home_after_one_hold',true,1],['home_after_three_holds',true,3]]){
  test(name,{home},(g,r)=>{for(let j=0;j<hold;j++)nextSelf(g);r.start=observe(g,'selected-recall-start');r.startResult=action(g,'Game_Action_Recall');runUntil(g);});
}
function contestRecall(g,r,hold){for(let j=0;j<hold;j++)nextSelf(g);r.start=observe(g,'selected-recall-start');r.startResult=action(g,'Game_Action_Recall');nextSelf(g);teleport(g,2,15,14);toActor(g,2);r.contestMove=action(g,'Game_Action_Move',14,14,out);r.enemyEntry=observe(g,'enemy-moves-onto-unoccupied-second-region-tile');nextSelf(g);r.contested=observe(g,'after-one-contested-capture-phase');teleport(g,2,28,28);observe(g,'enemy-leaves');runUntil(g);}
test('normal_after_one_hold_brief_enemy_contest',{},(g,r)=>contestRecall(g,r,1));
test('normal_immediate_actual_other_holder', {other:true},(g,r)=>{r.start=observe(g,'selected-recall-start');r.startResult=action(g,'Game_Action_Recall');runUntil(g);});
test('single_tile_normal_after_one_hold', {singleTile:true},(g,r)=>{nextSelf(g);r.start=observe(g,'selected-recall-start');r.startResult=action(g,'Game_Action_Recall');nextSelf(g);teleport(g,2,14,14);for(let k=0;k<10&&state(g).current!==2;k++)advance(g);assert.equal(state(g).current,2);r.entryAttempt=action(g,'Game_Action_Move',13,14,out);r.afterEntry=observe(g,'enemy-cannot-enter-occupied-single-region-tile');teleport(g,2,28,28);runUntil(g);});
test('home_after_three_holds_brief_enemy_contest',{home:true},(g,r)=>contestRecall(g,r,3));
test('normal_one_hold_basic_damage_interrupts_recall_but_hold_remains',{},(g,r)=>{nextSelf(g);r.start=observe(g,'selected-recall-start');r.startResult=action(g,'Game_Action_Recall');nextSelf(g);teleport(g,2,13,13);toActor(g,2);r.hit=action(g,'Game_Action_Attack',entity(1,0));r.afterHit=observe(g,'actual-basic-interrupts-recall-without-region-contest');teleport(g,2,28,28);runUntil(g);});
test('reward_during_active_four_tick_tribute',{},(g,r)=>{for(let j=0;j<3;j++)nextSelf(g);checked('Game_Sandbox_GiveGems',g,0,31);r.start=observe(g,'selected-tribute-start');r.startResult=action(g,'Game_Action_SubmitGems',pos(13,15));runUntil(g);});
test('capture_reward_before_pending_one_tick_tribute_completion',{},(g,r)=>{for(let j=0;j<5;j++)nextSelf(g);checked('Game_Sandbox_GiveGems',g,0,5);r.start=observe(g,'selected-tribute-start');r.startResult=action(g,'Game_Action_SubmitGems',pos(13,15));runUntil(g);});

function self(t,id=0){return t.champs.find(c=>c.id===id);}
for(const r of records){if(r.error)continue;
  const started=r.trace.find(t=>t.label==='after:Game_Action_Recall'||t.label==='after:Game_Action_SubmitGems');
  const firstAway=r.trace.find(t=>t!==r.trace[0]&&self(t).channelType===0&&self(t).x<5&&t.round>r.start.round);
  const firstReward=r.trace.find(t=>self(t).gems>(r.name.includes('tribute')?Number(r.name.includes('four_tick')?31:5):0));
  const receiptOther=r.trace.find(t=>self(t,1).gems>0);
  const bank=r.trace.find(t=>t.public.scoreA.value>0);
  const pending=r.trace.find(t=>self(t).channelType!==0&&self(t).channelTimer===0);
  r.summary={startRound:r.start.round,startGroup:r.start.groups[0],startPublic:r.start.public,accepted:r.startResult.code===0,initialChannel:started?{type:self(started).channelType,timer:self(started).channelTimer}:null,firstAway:firstAway?{round:firstAway.round,phase:firstAway.phase,turn:firstAway.turn}:null,firstReward:firstReward?{round:firstReward.round,phase:firstReward.phase,gems:self(firstReward).gems,channelType:self(firstReward).channelType,channelTimer:self(firstReward).channelTimer}:null,receiptOther:receiptOther?{round:receiptOther.round,gems:self(receiptOther,1).gems}:null,bank:bank?{round:bank.round,phase:bank.phase,score:bank.public.scoreA.value,bag:self(bank).gems}:null,pendingZero:pending?{round:pending.round,phase:pending.phase,input:pending.input,current:pending.current,channelType:self(pending).channelType}:null,final:{self:self(r.final),other:self(r.final,1),group:r.final.groups[0],score:r.final.public.scoreA.value}};
}
function check(name,pass,detail){checks.push({name,pass:!!pass,detail});}
for(const r of records){check(r.name+':no_setup_error',!r.error,r.error??null);if(r.error)continue;check(r.name+':start_accepted',r.startResult.code===0,r.startResult);}
const by=n=>records.find(r=>r.name===n);
for(const n of ['normal_immediate','normal_after_one_hold','home_immediate','home_after_one_hold','home_after_three_holds','normal_after_one_hold_brief_enemy_contest','normal_immediate_actual_other_holder','single_tile_normal_after_one_hold']){const r=by(n);if(!r.error){check(n+':numeric_recall_type1',r.summary.initialChannel.type===1,r.summary.initialChannel);check(n+':initial_timer',r.summary.initialChannel.timer===(r.setup.home?3:5),r.summary.initialChannel);check(n+':zero_pending_visible',!!r.summary.pendingZero,r.summary.pendingZero);}}
for(const n of ['reward_during_active_four_tick_tribute','capture_reward_before_pending_one_tick_tribute_completion']){const r=by(n);if(!r.error){check(n+':numeric_tribute_type2',r.summary.initialChannel.type===2,r.summary.initialChannel);check(n+':bank_includes_capture22',r.summary.final.score===(n.includes('four_tick')?53:27),r.summary);check(n+':zero_pending_visible',!!r.summary.pendingZero,r.summary.pendingZero);}}
for(const r of records){if(r.error)continue;const expected=r.summary.initialChannel.timer-1;const tick=r.trace.find(t=>t.round===r.start.round&&self(t).channelType===r.summary.initialChannel.type&&self(t).channelTimer===expected);check(r.name+':starting_owner_end_counts',!!tick,tick?{round:tick.round,phase:tick.phase,timer:self(tick).channelTimer}:null);if(!r.name.includes('basic_damage'))check(r.name+':public_pending_zero_matches_host',r.trace.some(t=>self(t).channelType!==0&&self(t).channelTimer===0&&t.public.selfChannel.code===0&&t.public.selfChannel.value===0),r.summary.pendingZero);}
for(const n of ['normal_immediate','home_immediate','home_after_one_hold']){const r=by(n);check(n+':leaves_before_payout_and_loses',!r.error&&r.summary.final.self.gems===0&&r.summary.final.group.state===2,r.summary);}
for(const [n,round] of [['normal_after_one_hold',7],['home_after_three_holds',7],['single_tile_normal_after_one_hold',7]]){const r=by(n);check(n+':collects22_before_departure',!r.error&&r.summary.firstReward?.round===round&&r.summary.firstAway?.round===round&&r.summary.firstReward.phase===7&&r.summary.final.self.gems===22,r.summary);}
const contest=by('normal_after_one_hold_brief_enemy_contest');check('contest_resets_host_progress_but_public_state_stays2',!contest.error&&contest.contested.groups[0].captureTimer===0&&contest.contested.groups[0].captureTeam===2&&contest.contested.public.groupState.value===2&&self(contest.contested).channelType===1,contest.contested?{group:contest.contested.groups[0],public:contest.contested.public.groupState,channel:self(contest.contested).channelType}:null);check('contest_case_uninterrupted_recall_loses_payout',!contest.error&&contest.summary.final.self.gems===0&&contest.summary.firstAway.round===7,contest.summary);
for(const n of ['normal_after_one_hold_brief_enemy_contest','home_after_three_holds_brief_enemy_contest']){const r=by(n);check(n+':actual_enemy_move_contests_other_spawn_tile',!r.error&&r.contestMove.code===0&&r.contestMove.successful&&self(r.enemyEntry,2).x===14&&self(r.enemyEntry,2).y===14,r.contestMove);check(n+':reset_despite_unchanged_public_reward_state',!r.error&&r.contested.groups[0].captureTimer===0&&r.contested.groups[0].captureTeam===2&&r.contested.public.groupState.value===2&&self(r.contested).channelType===1&&r.summary.final.self.gems===0,r.summary);}
const damaged=by('normal_one_hold_basic_damage_interrupts_recall_but_hold_remains');check('actual_basic_interrupts_recall_without_vacating_capture',!damaged.error&&damaged.hit.code===0&&self(damaged.afterHit).channelType===0&&self(damaged.afterHit).x===13&&self(damaged.afterHit).y===14&&self(damaged.afterHit).hp<self(damaged.start).hp,damaged.hit);check('interrupted_recall_holder_can_still_receive_capture22',!damaged.error&&damaged.summary.final.self.gems===22&&damaged.summary.final.self.x===13&&damaged.summary.firstAway===null,damaged.summary);
const holder=by('normal_immediate_actual_other_holder');check('actual_other_holder_preserves_payout22',!holder.error&&holder.summary.final.self.gems===0&&holder.summary.final.other.gems===22&&holder.summary.receiptOther.round===7,holder.summary);
const single=by('single_tile_normal_after_one_hold');check('single_tile_occupied_enemy_entry_rejected',!single.error&&single.entryAttempt.code!==0&&self(single.afterEntry,2).x===14&&self(single.afterEntry,2).y===14,single.entryAttempt);check('single_tile_entry_rejection_does_not_contest',!single.error&&single.afterEntry.groups[0].captureTeam===0&&single.afterEntry.groups[0].captureTimer>0,single.afterEntry?.groups[0]);
const long=by('reward_during_active_four_tick_tribute');check('tribute_capture_does_not_extend_remaining_timer',!long.error&&long.summary.firstReward.gems===53&&long.summary.firstReward.channelType===2&&long.summary.firstReward.channelTimer===1&&long.summary.bank.round===8,long.summary);
const short=by('capture_reward_before_pending_one_tick_tribute_completion');check('capture_phase_precedes_same_round_tribute_completion',!short.error&&short.summary.firstReward.round===7&&short.summary.firstReward.phase===7&&short.summary.firstReward.channelTimer===0&&short.summary.bank.round===7&&short.summary.bank.phase===14,short.summary);
check('public_reward_state_does_not_encode_capture_progress',by('normal_immediate').start.public.groupState.value===2&&by('normal_immediate').start.groups[0].captureTimer===0&&by('normal_after_one_hold').start.public.groupState.value===2&&by('normal_after_one_hold').start.groups[0].captureTimer===5&&by('home_after_three_holds').start.public.groupState.value===2&&by('home_after_three_holds').start.groups[0].captureTimer===3,{immediate:by('normal_immediate').start.groups[0],oneHold:by('normal_after_one_hold').start.groups[0],threeHolds:by('home_after_three_holds').start.groups[0]});
const result={engine:{path:enginePath,sha256:engineHash,snapshotBytes:E.Game_Visualiser_SnapshotSize(),timelineBytes:E.Game_Visualiser_TimelineSnapshotSize()},scope:'Twelve controlled current0.0.2 capture/channel timing cases; sandbox setup followed by real engine channel/phase actions. Enemy region entries and the recall-interrupting basic use actual game actions. Host capture progress is evidence only, not a bot-accessible API.',publicApiExports:Object.keys(E).filter(x=>x.startsWith('Game_API_CampGroup')||/GetChannelTime|GetSubmittedGemCount/.test(x)),hostCaptureConstant:E.Game_Visualiser_CaptureTime(),records,checks};
fs.writeFileSync('work/economy-cycle-research/policy/native-cycle-timing-current.json',JSON.stringify(result,null,2));
fs.writeFileSync('work/economy-cycle-research/policy/native-cycle-timing-summary.json',JSON.stringify({...result,records:records.map(({trace,actions,final,start,...r})=>r)},null,2));
console.log(JSON.stringify({engine:result.engine,summary:records.map(({name,error,summary})=>({name,error,summary})),checks:checks.filter(c=>!c.pass),counts:{cases:records.length,checks:checks.length,passed:checks.filter(c=>c.pass).length}},null,2));
assert(checks.every(c=>c.pass),'Some controlled timing assertions failed; inspect retained results');
