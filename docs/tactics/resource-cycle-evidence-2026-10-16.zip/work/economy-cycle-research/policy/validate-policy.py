from pathlib import Path
import re,json,hashlib
from urllib.parse import unquote

BASE=Path(r'C:/Users/frans/Documents/Codex/2026-10-14/v')
POL=BASE/'work/economy-cycle-research/policy'
REPO=BASE/'work/combat-research/repository/Cambridge-Battlecode-2026-main'
DOC=REPO/'docs/tactics'

# Correct only newly introduced prose spacing, retaining source quotations/code.
fixes={'using09.8':'using 09.8','under07':'under 07','under06':'under 06','under04/11':'under 04/11','Existing55%':'Existing 55%','Use95%':'Use 95%','requires55%':'requires 55%','chapter04':'chapter 04','chapter06':'chapter 06','chapter07':'chapter 07','chapter11':'chapter 11','under11':'under 11','round1850':'round 1850','reaching1000':'reaching 1000','the10-gold':'the 10-gold'}
for p in POL.glob('*.md'):
    text=p.read_text(encoding='utf-8-sig')
    for a,b in fixes.items():text=text.replace(a,b)
    # Make the safe implementable v1 default explicit where the earlier prose left an optimization open.
    if p.name=='10-recall-and-recovery.md':
        text=text.replace('Permit an elective capture recall only when our conservative personally verified remaining occupancy-phase bound ensures payout precedes departure, or an actually present replacement covers all required phases.','For v1 finish payout before an elective recall unless an actually present replacement covers the required hold. A later overlap optimization may use a conservative remaining occupancy-phase bound only after demonstrating how personal observations prove it; intermittent snapshots can miss a contest/reset.')
    p.write_text(text,encoding='utf-8')

issues=[];heading_checks={};source_links=0;relative_links=0
for fn in ['08-farming-and-capture.md','09-gems-and-objectives.md','10-recall-and-recovery.md','12-execution-and-validation.md']:
    text=(POL/fn).read_text(encoding='utf-8')
    original=(DOC/fn).read_text(encoding='utf-8-sig')
    headings=re.findall(r'^## [1-8]\. .+$',text,re.M)
    expected=re.findall(r'^## [1-8]\. .+$',original,re.M)
    heading_checks[fn]={'count':len(headings),'unchanged':headings==expected,'statuses':len(re.findall(r'^\*\*Status:\*\*',text,re.M))}
    if headings!=expected or len(headings)!=8:issues.append(f'{fn}: headings changed')

def anchors(text):
    return {re.sub(r'[^\w\- ]','',s.lower()).replace(' ','-') for s in re.findall(r'^#+ (.+)$',text,re.M)}

for p in POL.glob('*.md'):
    text=p.read_text(encoding='utf-8')
    links=re.findall(r'\]\(([^ )]+)(?:[^)]*)\)',text)
    links+=re.findall(r'^\[[^\]]+\]:\s+(\S+)',text,re.M)
    for target in links:
        if target.startswith('https://github.com/Javiops/Cambridge-Battlecode-2026/blob/'):
            m=re.search(r'/blob/([a-f0-9]+)/(.+?)(?:#L(\d+)(?:-L(\d+))?)?$',target)
            if not m:issues.append(f'{p.name}: malformed source {target}');continue
            source_links+=1;rev,rel,a,b=m.groups();path=REPO/unquote(rel)
            if not path.exists():issues.append(f'{p.name}: missing source {rel}');continue
            if a:
                n=len(path.read_text(encoding='utf-8-sig').splitlines())
                if not 1<=int(a)<=int(b or a)<=n:issues.append(f'{p.name}: source line bounds {target}')
        elif not re.match(r'^[a-z]+:',target):
            relative_links+=1;rel,_,anchor=target.partition('#')
            dest=(POL/rel) if rel else p
            if not dest.exists():dest=DOC/rel
            if not dest.exists():issues.append(f'{p.name}: relative target missing {target}');continue
            if anchor and dest.suffix=='.md' and anchor not in anchors(dest.read_text(encoding='utf-8-sig')):issues.append(f'{p.name}: anchor missing {target}')

manifest={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(POL.glob('*.md'))}
record={'scope':'Documentation draft checks only; no bot builds/matches or competitive validation','headings':heading_checks,'source_line_links_checked':source_links,'relative_links_checked_with_existing_handbook_fallback':relative_links,'issues':issues,'files':manifest}
(POL/'policy-validation.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in record.items() if k!='files'},indent=2))
assert not issues,issues
