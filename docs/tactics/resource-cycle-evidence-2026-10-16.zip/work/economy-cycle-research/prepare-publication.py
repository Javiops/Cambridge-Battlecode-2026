from pathlib import Path
import json,re,shutil,hashlib
R=Path(__file__).resolve().parent
O=R/'repository/Cambridge-Battlecode-2026-main/docs/tactics'
P=R/'publication';P.mkdir(exist_ok=True)
for n in ['08-farming-and-capture.md','09-gems-and-objectives.md','10-recall-and-recovery.md','12-execution-and-validation.md','cycle-decision-contract.md','cycle-source-audit.md','cycle-timing-current-002.md']:
    shutil.copyfile(R/'policy'/n,P/n)

def append_to_topic(text,num,addition):
    start=re.search(r'^## '+str(num)+r'\. .+$',text,re.M).end()
    end=re.search(r'^## [1-8]\. .+$',text[start:],re.M)
    end=start+end.start() if end else len(text)
    return text[:end].rstrip()+'\n\n'+addition.strip()+'\n\n'+text[end:]

s=(O/'01-overall-strategy.md').read_text(encoding='utf8')
s=append_to_topic(s,1,'**Unified decision:** [09.8](09-gems-and-objectives.md#8-finishing-and-deadlines) and the [resource-cycle contract](cycle-decision-contract.md) apply deciding-delivery and endgame timing before discretionary fights, camp expenditure, chain rewards and elective shopping. Public banked scores are observable; unseen enemy bags/routes and unavailable tiebreak statistics remain unknown. High-level score priority still requires legal actions and credible survival/interruption timing.')
s=append_to_topic(s,7,'**Unified cycle comparison:** Use the [bounded comparator](cycle-decision-contract.md#4-compare-complete-cycles-without-double-counting) for clear, collection, delivery and recovery/re-entry, preserving 04\'s information, 06\'s commitments, 07\'s legal sequences and 11\'s personal-purchase authority. Count each group reward once, retain personal allocation, and charge only incremental heal/shop time. This is a Planned local shortlist and explicit timing contract, not an omniscient global optimizer.')
(P/'01-overall-strategy.md').write_text(s,encoding='utf8')
s=(O/'02-map-understanding.md').read_text(encoding='utf8')
pos=s.index('\n## 1. Map connectivity')
note='''
**Unknown-map requirement:** Tournament maps may be unseen. Build decisions from walking times to legal contribution/capture/altar tiles, relative opposing arrival, camp damage/reward composition, capture-region tile count, choke/exit geometry, and recovery-to-work cost. Official map names remain descriptive evidence only; inherited named-map source overrides are not the new tactic. A new map is not automatically unsafe: retain unknown timing/vision explicitly and reduce it through useful reversible observation. Use the [geometry contract](cycle-decision-contract.md#3-geometry-and-bounded-candidate-construction); validate policy on untouched generated geometries, without tuning to their outcomes.
'''
s=s[:pos]+'\n'+note+s[pos:]
(P/'02-map-understanding.md').write_text(s,encoding='utf8')
s=(O/'README.md').read_text(encoding='utf8')
s=s.replace('Chapters 04 (vision), 06 (coordination), 07 (combat) and 11 (shopping) retain their detailed researched policies.','Chapters 04 (vision), 06 (coordination), 07 (combat), 08–10 (the resource cycle) and 11 (shopping) contain detailed researched policies.')
new='''## Resource-cycle research update — 16 October 2026

Read the [single decision contract](cycle-decision-contract.md) first: farming, collection, delivery, recovery, combat, wards and investment must share one action budget and one explicit next mission. [08](08-farming-and-capture.md), [09](09-gems-and-objectives.md) and [10](10-recall-and-recovery.md) now give the detailed transitions, continuity guards, endgame deadlines and return-to-work policy. Map adaptation uses route/resource/contest features, including capture-region geometry, rather than map-name rules.

The [research appendix](resource-cycle-research-2026-10-16.md) covers 2,588 unique replay streams, especially 150 current-patch games between the current top four, with completed resource flows, eleven bounded episodes and a [source audit](cycle-source-audit.md). [Twelve controlled current-engine cases](cycle-timing-current-002.md) verify capture/recall/tribute timing. All new decision policies remain **Planned**; replay descriptions and mechanics checks do not establish a stronger implemented bot.

'''
s=s.replace('## Keeping the specification current',new+'## Keeping the specification current')
(P/'README.md').write_text(s,encoding='utf8')

contract=P/'cycle-decision-contract.md'
s=contract.read_text(encoding='utf8')
diagram='''
```mermaid
flowchart TD
    OBS[Fresh self, channel, vision and mission state] --> CH{Active channel?}
    CH -->|yes| GUARD[Continue or legally cancel using remaining time and next response]
    CH -->|no| WIN{Deciding delivery or protection?}
    WIN -->|yes| DEC[Execute feasible finish or interruption]
    WIN -->|no| SAFE{Required survival action?}
    SAFE -->|yes| SURV[Escape, protect or retain timely channel]
    SAFE -->|no| JOB{Current job still useful and feasible?}
    JOB -->|yes| KEEP[Continue next useful action]
    JOB -->|no| CAND[Compare bounded complete-cycle candidates]
    CAND --> CLEAR[Travel, assemble and clear]
    CLEAR --> HOLD[Hold, collect and verify payout]
    HOLD --> BANK[Deliver and verify bank]
    BANK --> RE[Recover only if worthwhile, then productive re-entry]
    GUARD --> REF[Execute one legal action and refresh]
    DEC --> REF
    SURV --> REF
    KEEP --> REF
    RE --> REF
    REF --> OBS
```

The arrows describe mission transitions, not permission to spend several incompatible actions without refreshing state. A body can protect a collector while another clears, and an accepted channel can overlap capture only under section 6's continuity guard.
'''
s=s.replace('## 2. Local state and evidence that the API can support',diagram+'\n## 2. Local state and evidence that the API can support')
contract.write_text(s,encoding='utf8')
print(json.dumps({'staged_docs':[p.name for p in P.glob('*.md')]},indent=2))
