"""Read-only, source-bound aggregation of existing native sequential replay traces.

No bot invocation, game queue, guessed native offset, or inferred player intent.
Run with --limit for a pilot; --manifest/--trace-dir/--ladder allow refreshed cohorts.
"""
from pathlib import Path
from collections import Counter, defaultdict
from bisect import bisect_right
from datetime import datetime, timezone
import argparse, csv, gzip, hashlib, json, math, statistics, time

HERE = Path(__file__).resolve().parent
BASE = HERE.parents[2]
p = argparse.ArgumentParser()
p.add_argument('--manifest', type=Path, default=BASE/'work/combat-research/matches/manifest-bound.json')
p.add_argument('--trace-dir', type=Path, default=BASE/'work/combat-research/matches/current')
p.add_argument('--ladder', type=Path, default=BASE/'work/combat-research/acquisition/ladder-snapshot.json')
p.add_argument('--out-dir', type=Path, default=HERE/'current')
p.add_argument('--limit', type=int)
p.add_argument('--patch')
p.add_argument('--top4-only', action='store_true')
p.add_argument('--skip-raw-hash', action='store_true')
p.add_argument('--stride', type=int, default=1)
p.add_argument('--index', type=int, default=0)
p.add_argument('--merge-parts', type=Path)
p.add_argument('--gem-dir', type=Path)
a = p.parse_args()
a.out_dir.mkdir(parents=True, exist_ok=True)
sha = lambda b: hashlib.sha256(b).hexdigest()
ANALYZER_SHA = sha(Path(__file__).read_bytes())
ENGINE = {'0.0.1':'ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc',
          '0.0.2':'e123b59d9dea198762ab7a04db9b3cb6d06dfa991088e41c24750fc4cb88b947'}
manifest = json.loads(a.manifest.read_bytes())
ladder = json.loads(a.ladder.read_bytes())
rank = {x['teamId']:x for x in ladder['teams']}
current10 = {k for k,v in rank.items() if v['rank'] <= 10}
current4 = {k for k,v in rank.items() if v['rank'] <= 4}
started = time.time()

def writejson(name, obj):
    (a.out_dir/name).write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n', encoding='utf8')

def writecsv(name, rows):
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with (a.out_dir/name).open('w', newline='', encoding='utf8') as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for row in rows:
            w.writerow({k:json.dumps(v,separators=(',',':')) if isinstance(v,(list,dict)) else v for k,v in row.items()})

def dist(values):
    v = sorted(x for x in values if x is not None)
    def q(t):
        if not v:return None
        k=(len(v)-1)*t; i=int(k)
        return v[i]+(v[min(i+1,len(v)-1)]-v[i])*(k-i)
    return dict(n=len(v),sum=sum(v),mean=statistics.mean(v) if v else None,
                median=q(.5),p25=q(.25),p75=q(.75),p90=q(.9),min=v[0] if v else None,max=v[-1] if v else None)

def inside(c, rect):return rect[0]<=c[1]<rect[2] and rect[1]<=c[2]<rect[3]

allrequests=manifest['requests']
byraw=defaultdict(list)
for r in allrequests:byraw[r['raw_sha256']].append(r)
selected=[]; aliases=[]
for raw, rs in byraw.items():
    pairs={tuple(r['teams'][s]['teamId'] for s in ['a','b']) for r in rs}
    r=sorted(rs,key=lambda x:(x['created_at'],x['id']), reverse=True)[0]
    if a.patch and r['replay_patch']!=a.patch:continue
    if a.top4_only and not all(r['teams'][s]['teamId'] in current4 for s in ['a','b']):continue
    selected.append((r,len(pairs)>1))
    if len(rs)>1:aliases.append(dict(raw_sha256=raw,ids=[x['id'] for x in rs],ambiguous_external_identity=len(pairs)>1,ordered_pairs=[list(x) for x in pairs]))
if a.limit:selected=selected[:a.limit]
requested_count=len(selected)
selected=[] if a.merge_parts else selected[a.index::a.stride]

errors=[]; audits=[]; counts=Counter(); rows_by_type=defaultdict(list); game_rows=[]; case_rows=[]
files={name:gzip.open(a.out_dir/(name+'.jsonl.gz'),'wt',encoding='utf8') for name in
       ['capture-payouts','waiting-episodes','native-waiting-episodes','collection-followups','tribute-starts','tribute-completions','recall-followups','body-roles']}
def emit(kind, row):
    files[kind].write(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n')
    rows_by_type[kind].append(row)

def check(ok, mid, label, **detail):
    if not ok:errors.append(dict(match_id=mid,check=label,**detail))

for ix,(r,ambiguous) in enumerate(selected):
    mid=r['id']; path=Path(r.get('trace_path',a.trace_dir/(mid+'.coord.json.gz')))
    if not path.exists():errors.append(dict(match_id=mid,check='missing_trace',path=str(path)));continue
    compressed=path.read_bytes();g=json.loads(gzip.decompress(compressed))
    gemledger=None;gempath=a.gem_dir/(r['raw_sha256']+'.gems.json.gz') if a.gem_dir else None
    if gempath and not gempath.exists():gempath=a.gem_dir/(mid+'.gems.json.gz')
    if gempath and gempath.exists():
        gemledger=json.loads(gzip.decompress(gempath.read_bytes()))
        check(gemledger['raw_sha256']==r['raw_sha256'] and gemledger['trace_sha256']==sha(compressed) and gemledger.get('ordered_team_ids',[r['teams'][s]['teamId'] for s in ['a','b']])==[r['teams'][s]['teamId'] for s in ['a','b']],mid,'personal_gem_ledger_binding')
        check(not gemledger['errors'] and gemledger['frames']==g['frames'],mid,'personal_gem_ledger_native_validation')
    patch=r['replay_patch'];roster={c['id']:c for c in g['roster']};spawns=g['geometry']['spawn']
    check(g['raw_sha256']==r['raw_sha256'] and all(g['teams'][s]['teamId']==r['teams'][s]['teamId'] for s in ['a','b']),mid,'trace_raw_ordered_identity_binding')
    check(g.get('patch',patch)==patch and g['engine_sha256']==ENGINE.get(patch),mid,'patch_engine_binding',trace_patch_field=g.get('patch'))
    check(g['engine_sha256']==ENGINE.get(patch),mid,'native_engine_binding')
    check(not g['apiFinalErrors'],mid,'native_api_final_errors',errors=g['apiFinalErrors'])
    actualraw=None if a.skip_raw_hash else sha(Path(r['raw']).read_bytes())
    if actualraw is not None:check(actualraw==r['raw_sha256'],mid,'raw_sha256')
    checks=g.get('apiFinalChecks',{'scope':'not_recorded_in_legacy_trace'})
    api=r['game'].get('statistics')
    if api:
        for c in g['final']['c']:
            ac=next((x for x in api['champions'] if x['champion']==c['id']),None)
            check(ac is not None and ac['team']==c['team'] and ac['type']==c['type'] and ac['gold']==c['gold'] and ac['gems']==c['gems'] and ac['earnedGold']==c['earned'] and [ac['kills'],ac['deaths'],ac['assists']]==c['kda'],mid,'canonical_api_champion_counters',body=c['id'])
    api_round=api['round'] if api else r['game'].get('rounds')
    if api_round is not None:check(g['final']['round']==api_round,mid,'native_api_round')
    check([x['r'] for x in g['rounds']]==sorted(set(x['r'] for x in g['rounds'])),mid,'unique_sorted_rounds')
    check(all(len(x['c'])==len(roster) for x in g['rounds']),mid,'complete_round_rosters')
    check(all(x['id'] in roster for x in g['final']['c']),mid,'final_roster')
    teams=[r['teams'][s]['teamId'] for s in ['a','b']]
    cohort='top4_h2h' if set(teams)<=current4 else 'top4_vs_other_current_top10' if set(teams)<=current10 and set(teams)&current4 else 'other_current_top10' if set(teams)<=current10 else 'outside_current_top10_context'
    common=dict(match_id=mid,raw_sha256=r['raw_sha256'],patch=patch,map=r['map'],kind=r['kind'],created_at=r['created_at'],cohort=cohort,external_identity_ambiguous=ambiguous)
    def meta(side):
        tid=teams[side];rr=rank.get(tid)
        return dict(**common,side=side,teamId=tid,team=rr['name'] if rr else r['teams']['a' if side==0 else 'b']['name'],
                    rank=rr['rank'] if rr else None,current_top10=tid in current10,current_top4=tid in current4)
    def bm(bid):return dict(**meta(roster[bid]['team']),body=bid,champion=roster[bid]['name'],type=roster[bid]['type'])
    camps={c['id']:c for c in g['camps']};groupcamps=defaultdict(set)
    for c in camps.values():groupcamps[c['group']].add(c['id'])
    rounds=g['rounds']; endseq=g['frames']; endround=g['final']['round']
    bodysamples=defaultdict(list)
    groupsamples=defaultdict(list)
    for w in rounds:
        for c in w['c']:bodysamples[c[0]].append((w['seq'],w['r'],c))
        for group,v in enumerate(w['groups']):groupsamples[group].append((w['seq'],w['r'],v))
    deaths=defaultdict(list); commands=defaultdict(lambda:defaultdict(list)); productive=defaultdict(list); damagegroup=defaultdict(list)
    roles={bid:Counter() for bid in roster}
    for e in g['deaths']:deaths[e['id']].append(e)
    for e in g['actions']:
        bid=e['actor'];commands[bid][e['kind']].append(e)
        if e['kind'] in [5,6] and e['before'][5] and not inside(e['before'],spawns[e['team']]):
            valid=[x for x in e['losses'] if x[3]>0 and (x[0]==2 or x[0]==1 and x[2]!=e['team'])]
            if valid:productive[bid].append(dict(seq=e['seq'],r=e['r'],kind='direct_field_hp_loss',input=e['input'],position=e['before'][1:3],damages_camp=any(x[0]==2 for x in valid),damages_enemy=any(x[0]==1 for x in valid)))
    for e in g['damage']:
        bid=e.get('source',{}).get('id') if e.get('source') else None
        for loss in e['losses']:
            if loss[0]==2 and loss[1] in camps:
                group=camps[loss[1]]['group']
                damagegroup[group].append((e['seq'],e['r'],bid,loss[3],loss[1]))
                if bid in roster:roles[bid]['camp_hp_loss_dealt']+=loss[3];roles[bid]['sourced_camp_damage_frames']+=1
    def next_event(es, seq, stop=endseq):
        pos=bisect_right([x['seq'] for x in es],seq)
        return es[pos] if pos<len(es) and es[pos]['seq']<stop else None
    def next_death(bid,seq):return next_event(deaths[bid],seq)
    def samples_between(bid,lo,hi):return [x for x in bodysamples[bid] if lo<x[0]<hi]

    # Score changes are banked output. Attribute to a body only with exact same-frame bag loss.
    completions=defaultdict(list); matched_starts={}; perteam_score=[0,0]
    for e in g['submissions']:
        check(all(x>=0 for x in e['delta']),mid,'nonnegative_score_delta',seq=e['seq'])
        before={c[0]:c for c in e['c']}; after={c[0]:c for c in e['after']}
        for side,delta in enumerate(e['delta']):
            if not delta:continue
            perteam_score[side]+=delta
            changed=[bid for bid,c in before.items() if roster[bid]['team']==side and c[7]>after[bid][7]]
            exact=len(changed)==1 and before[changed[0]][7]-after[changed[0]][7]==delta
            check(exact,mid,'score_exact_bag_drop',seq=e['seq'],side=side,delta=delta,changed=changed)
            bid=changed[0] if exact else None
            row=dict(**(bm(bid) if bid is not None else meta(side)),round=e['r'],seq=e['seq'],input=e['input'],banked_gems=delta,
                     attribution='exact_single_body_bag_drop' if exact else 'unattributed_score_delta',native_step=e['step'])
            if bid is not None:
                starts=[x for x in commands[bid][12] if x['seq']<e['seq']]
                start=starts[-1] if starts else None
                previous_completion=completions[bid][-1] if completions[bid] else None
                if start and previous_completion and start['seq']<previous_completion['seq']:start=None
                if start and any(start['seq']<d['seq']<e['seq'] for d in deaths[bid]):start=None
                row.update(body=bid,bag_before_completion=before[bid][7],bag_after_completion=after[bid][7],position=before[bid][1:3],hp_fraction=before[bid][3]/before[bid][4] if before[bid][4] else None,
                           start_seq=start['seq'] if start else None,start_round=start['r'] if start else None,start_input=start['input'] if start else None,
                           bag_at_linked_start=start['before'][7] if start else None,start_to_completion_rounds=e['r']-start['r'] if start else None)
                if start:matched_starts[start['seq']]=row
                completions[bid].append(row);roles[bid]['tribute_completions']+=1;roles[bid]['banked_gems']+=delta
            emit('tribute-completions',row)
    initialscore=rounds[0]['score'] if rounds else [0,0]
    finalscore=rounds[-1]['score'] if rounds else [None,None]
    for side in [0,1]:
        # Native final score uses exact accumulated score changes; API missing remains unavailable.
        apiscore=next((x.get('submittedGems') for x in api['teams'] if x['team']==side),None) if api else next((x.get('score') for x in r['game'].get('sides',[]) if x['side']==('a' if side==0 else 'b')),None)
        if apiscore is not None:check(initialscore[side]+perteam_score[side]==apiscore,mid,'banked_sum_api_score',side=side)
        game_rows.append(dict(**meta(side),rounds=endround,roster_bodies=sum(c['team']==side for c in roster.values()),banked_score_from_deltas=perteam_score[side],api_score=apiscore,
                              api_scope=checks.get('scope'),api_full_body_counters_available=checks.get('championCounters',0)>0))

    for bid in roster:
        for j,e in enumerate(commands[bid][12]):
            nextstart=commands[bid][12][j+1] if j+1<len(commands[bid][12]) else None
            death=next_death(bid,e['seq']);done=matched_starts.get(e['seq'])
            stop=min(x for x in [nextstart['seq'] if nextstart else endseq,death['seq'] if death else endseq,done['seq']+1 if done else endseq])
            observed=any(c[9]==2 for _,_,c in samples_between(bid,e['seq'],stop))
            status='completed_exact_score' if done else 'death_before_completion' if death and death['seq']==stop else 'superseded_by_next_start' if nextstart and nextstart['seq']==stop else 'no_completion_before_trace_end'
            emit('tribute-starts',dict(**bm(bid),round=e['r'],seq=e['seq'],input=e['input'],bag_at_start=e['before'][7],gold_at_start=e['before'][6],hp_fraction=e['before'][3]/e['before'][4] if e['before'][4] else None,
                                      position=e['before'][1:3],observed_tribute_channel_sample=observed,outcome=status,
                                      completion_round=done['round'] if done else None,banked_gems=done['banked_gems'] if done else None))
            roles[bid]['tribute_start_commands']+=1

    # Waiting episodes use fixed-stage full snapshots, not an assumed exact kill timestamp.
    payouts=defaultdict(list)
    for e in g['captures']:
        if e['recipients']:
            check(e['before'][0]==1 and e['after'][0]==0,mid,'capture_payout_reward_transition',seq=e['seq'])
            check(len({x['team'] for x in e['recipients']})==1,mid,'capture_single_team',seq=e['seq'])
            payouts[e['group']].append(e)
            for rec in e['recipients']:
                bid=rec['id'];roles[bid]['capture_receipts']+=1;roles[bid]['capture_gems']+=rec['gems'];roles[bid]['capture_gold']+=rec['gold']
                if not (spawns[rec['team']][0]<=rec['position'][0]<spawns[rec['team']][2] and spawns[rec['team']][1]<=rec['position'][1]<spawns[rec['team']][3]):
                    productive[bid].append(dict(seq=e['seq'],r=e['r'],kind='capture_reward_receipt',input=e['input'],position=rec['position'],damages_camp=False,damages_enemy=False))
    nativewait={}
    if gemledger and 'groupEvents' in gemledger:
        ge=defaultdict(list)
        for event in gemledger['groupEvents']:ge[event['group']].append(event)
        for group,events in ge.items():
            active=None;changes=[]
            for e in events:
                if e['before'][0]==0 and e['after'][0]==1:active=e;changes=[]
                elif active and e['before'][0]==1 and e['after'][0]==1:changes.append(e)
                elif active and e['before'][0]==1 and e['after'][0]==0:
                    payout=next((x for x in payouts[group] if x['seq']==e['seq']),None)
                    check(payout is not None,mid,'native_wait_terminal_payout',group=group,seq=e['seq'])
                    row=dict(**common,group=group,exact_wait_start_round=active['r'],exact_wait_start_seq=active['seq'],exact_wait_start_step=active['step'],
                             completed=True,payout_round=e['r'],payout_seq=e['seq'],wait_to_payout_rounds_exact=e['r']-active['r'],
                             exact_control_to_neutral_transitions=sum(x['before'][1] in [0,1] and x['after'][1]==2 for x in changes),
                             exact_side_switches=sum(x['before'][1] in [0,1] and x['after'][1] in [0,1] and x['before'][1]!=x['after'][1] for x in changes),
                             payout_side=payout['recipients'][0]['team'] if payout else None,outcome='exact_payout_observed')
                    emit('native-waiting-episodes',row);nativewait[e['seq']]=row;active=None;changes=[]
            if active:
                emit('native-waiting-episodes',dict(**common,group=group,exact_wait_start_round=active['r'],exact_wait_start_seq=active['seq'],exact_wait_start_step=active['step'],completed=False,payout_round=None,payout_seq=None,wait_to_payout_rounds_exact=None,
                     exact_control_to_neutral_transitions=sum(x['before'][1] in [0,1] and x['after'][1]==2 for x in changes),
                     exact_side_switches=sum(x['before'][1] in [0,1] and x['after'][1] in [0,1] and x['before'][1]!=x['after'][1] for x in changes),
                     payout_side=None,outcome='right_censored_waiting_at_trace_end'))
    waitingrows={}
    for group,samples in groupsamples.items():
        segments=[];active=[]
        for x in samples:
            if x[2][1]:active.append(x)
            elif active:segments.append(active);active=[]
        if active:segments.append(active)
        for seg in segments:
            lo=seg[0][0]; hi=seg[-1][0]
            nextsample=next((x for x in samples if x[0]>hi),None)
            upper=nextsample[0] if nextsample else endseq
            payout=next((x for x in payouts[group] if lo<x['seq']<upper),None)
            # A phase7 payout precedes its same-round phase10 snapshot, hence upper includes it.
            eventhi=payout['seq'] if payout else upper
            changes=[x for x in g['captures'] if x['group']==group and lo<=x['seq']<=eventhi and x['before'][0]==1 and x['after'][0]==1]
            neutral=sum(x['before'][1] in [0,1] and x['after'][1]==2 for x in changes)
            switches=sum(x['before'][1] in [0,1] and x['after'][1] in [0,1] and x['before'][1]!=x['after'][1] for x in changes)
            resets=sum(b[2][1] and c[2][1] and c[2][3]>b[2][3] for b,c in zip(seg,seg[1:]))
            row=dict(**common,group=group,first_waiting_sample_round=seg[0][1],first_waiting_sample_seq=lo,last_waiting_sample_round=seg[-1][1],waiting_round_samples=len(seg),
                     completed=payout is not None,payout_round=payout['r'] if payout else None,payout_seq=payout['seq'] if payout else None,
                     observed_wait_to_payout_rounds=payout['r']-seg[0][1] if payout else None,
                     outcome='payout_observed' if payout else 'right_censored_waiting_at_trace_end' if nextsample is None else 'waiting_ended_without_trace_payout',
                     observed_control_to_neutral_transitions=neutral,observed_side_switches=switches,sampled_timer_increases=resets,
                     sampled_control_sides=sorted({x[2][2] for x in seg if x[2][2] in [0,1]}))
            emit('waiting-episodes',row)
            if payout:waitingrows[payout['seq']]=row

    for group,es in payouts.items():
        prev=0
        for e in es:
            side=e['recipients'][0]['team'];waiting=waitingrows.get(e['seq'])
            farm=[d for d in damagegroup[group] if prev<d[0]<e['seq']]
            farmers=sorted({d[2] for d in farm if d[2] in roster}); recipients=sorted(x['id'] for x in e['recipients'])
            gold=sum(x['gold'] for x in e['recipients']);gems=sum(x['gems'] for x in e['recipients'])
            row=dict(**meta(side),round=e['r'],seq=e['seq'],input=e['input'],group=group,recipient_count=len(recipients),recipient_bodies=recipients,
                     recipient_champions=[roster[x]['name'] for x in recipients],gold=gold,gems=gems,gold_split=[x['gold'] for x in e['recipients']],gem_split=[x['gems'] for x in e['recipients']],
                     equal_gold_split=len({x['gold'] for x in e['recipients']})==1,equal_gem_split=len({x['gems'] for x in e['recipients']})==1,
                     farming_bodies_since_previous_payout=farmers,unattributed_camp_hp_loss=sum(d[3] for d in farm if d[2] not in roster),
                     recipients_also_farmed=len(set(recipients)&set(farmers)),recipient_only_bodies=sorted(set(recipients)-set(farmers)),farmer_only_bodies=sorted(set(farmers)-set(recipients)),
                     opponent_farming_bodies=[x for x in farmers if roster[x]['team']!=side],
                     observed_wait_to_payout_rounds=waiting['observed_wait_to_payout_rounds'] if waiting else None,waiting_episode_linked=waiting is not None)
            nw=nativewait.get(e['seq']);row.update(wait_to_payout_rounds_exact=nw['wait_to_payout_rounds_exact'] if nw else None,exact_control_to_neutral_transitions=nw['exact_control_to_neutral_transitions'] if nw else None,exact_side_switches=nw['exact_side_switches'] if nw else None)
            emit('capture-payouts',row)
            if cohort=='top4_h2h' and patch=='0.0.2' and (row['recipient_only_bodies'] or row['opponent_farming_bodies'] or (waiting and waiting['observed_control_to_neutral_transitions'])):
                case_rows.append(row)
            before={c[0]:c for c in e['c']}
            for rec in e['recipients']:
                bid=rec['id'];death=next_death(bid,e['seq']);stop=death['seq'] if death else endseq
                tribute=next_event(commands[bid][12],e['seq'],stop);complete=next_event(completions[bid],e['seq'],stop);recall=next_event(commands[bid][11],e['seq'],stop)
                pastrecalls=[x for x in commands[bid][11] if x['seq']<e['seq']]
                priorrecall=pastrecalls[-1] if pastrecalls else None
                priorsamples=[x for x in bodysamples[bid] if x[0]<e['seq']]
                priorsample=priorsamples[-1] if priorsamples else None
                cleanstatus='complete_personal_gem_ledger_unavailable';intervening=None
                if gemledger:
                    pe=[x for x in gemledger['events'] if x['id']==bid]
                    receipt=next((x for x in pe if x['seq']==e['seq']),None)
                    terminal=next((x for x in pe if complete and x['seq']==complete['seq']),None)
                    intervening=[x for x in pe if complete and e['seq']<x['seq']<complete['seq']]
                    cleanstatus='no_next_exact_bank_before_death_or_end' if not complete else 'nonzero_bag_before_receipt' if before[bid][7]!=0 else 'intervening_personal_gem_deltas' if intervening else 'terminal_amount_differs_or_unlinked_start' if not terminal or not receipt or terminal['delta']!=-rec['gems'] or complete['banked_gems']!=rec['gems'] or complete.get('start_seq') is None else 'clean_exact_personal_gem_ledger'
                emit('collection-followups',dict(**bm(bid),round=e['r'],seq=e['seq'],input=e['input'],group=group,receipt_gold=rec['gold'],receipt_gems=rec['gems'],
                         bag_before=before[bid][7],bag_after=before[bid][7]+rec['gems'],
                         prior_recall_round=priorrecall['r'] if priorrecall else None,rounds_since_prior_recall= e['r']-priorrecall['r'] if priorrecall else None,
                         recall_command_0_to_5_rounds_before_receipt=bool(priorrecall and e['r']-priorrecall['r']<=5),
                         channel_in_last_sample_before_receipt=priorsample[2][9] if priorsample else None,last_sample_before_receipt_round=priorsample[1] if priorsample else None,
                         next_tribute_start_round=tribute['r'] if tribute else None,rounds_to_next_tribute_start=tribute['r']-e['r'] if tribute else None,
                         next_tribute_completion_round=complete['round'] if complete else None,rounds_to_next_tribute_completion=complete['round']-e['r'] if complete else None,
                         next_banked_amount=complete['banked_gems'] if complete else None,
                         clean_receipt_to_bank_status=cleanstatus,intervening_personal_gem_delta_events=len(intervening) if intervening is not None else None,
                         next_recall_round=recall['r'] if recall else None,rounds_to_next_recall=recall['r']-e['r'] if recall else None,
                         recall_within_0_rounds=bool(recall and recall['r']==e['r']),recall_within_3_rounds=bool(recall and recall['r']-e['r']<=3),
                         followup_stop='death' if death else 'trace_end',followup_available_rounds=(death['r'] if death else endround)-e['r']))
            prev=e['seq']

    for bid in roster:
        productive[bid].sort(key=lambda x:x['seq'])
        for j,e in enumerate(commands[bid][11]):
            death=next_death(bid,e['seq']);nextrecall=commands[bid][11][j+1] if j+1<len(commands[bid][11]) else None
            stop=min(death['seq'] if death else endseq,nextrecall['seq'] if nextrecall else endseq)
            samples=samples_between(bid,e['seq'],stop);side=roster[bid]['team'];atstart=inside(e['before'],spawns[side])
            home=next((x for x in samples if x[2][5] and inside(x[2],spawns[side])),None)
            observedchannel=any(x[2][9]==1 for x in samples)
            beforehome=[x for x in samples if home and x[0]<home[0]]
            boundary=bool(home and beforehome and beforehome[-1][2][9]==1 and home[2][9]!=1 and home[1]==beforehome[-1][1]+1)
            firstfield=next((x for x in samples if home and x[0]>home[0] and x[2][5] and not inside(x[2],spawns[side])),None)
            prod=next_event(productive[bid],home[0],stop) if home else None
            pve=next_event([x for x in productive[bid] if x['damages_camp']],home[0],stop) if home else None
            pvp=next_event([x for x in productive[bid] if x['damages_enemy']],home[0],stop) if home else None
            moves=[x for x in commands[bid][4] if home and prod and home[0]<x['seq']<prod['seq']]
            displacement=sum(max(abs(x['after'][1]-x['before'][1]),abs(x['after'][2]-x['before'][2])) for x in moves)
            status='sampled_spawn_then_field_productive_event' if home and prod else 'sampled_spawn_no_field_productive_event' if home else 'death_before_sampled_spawn' if death and death['seq']==stop else 'superseded_before_sampled_spawn' if nextrecall and nextrecall['seq']==stop else 'no_sampled_spawn_before_trace_end'
            emit('recall-followups',dict(**bm(bid),round=e['r'],seq=e['seq'],input=e['input'],bag_at_start=e['before'][7],gold_at_start=e['before'][6],
                         hp_fraction_at_start=e['before'][3]/e['before'][4] if e['before'][4] else None,position=e['before'][1:3],inside_own_spawn_at_start=atstart,
                         observed_recall_channel_sample=observedchannel,outcome=status,
                         recall_channel_to_alive_spawn_boundary_observed=boundary,
                         first_alive_spawn_sample_round=home[1] if home else None,rounds_to_first_alive_spawn_sample=home[1]-e['r'] if home else None,
                         first_spawn_sample_hp_fraction=home[2][3]/home[2][4] if home and home[2][4] else None,
                         first_field_sample_round=firstfield[1] if firstfield else None,spawn_to_first_field_sample_rounds=firstfield[1]-home[1] if firstfield else None,
                         first_field_sample_hp_fraction=firstfield[2][3]/firstfield[2][4] if firstfield and firstfield[2][4] else None,
                         first_productive_event_round=prod['r'] if prod else None,first_productive_event_kind=prod['kind'] if prod else None,first_productive_event_input=prod['input'] if prod else None,
                         spawn_to_first_productive_event_rounds=prod['r']-home[1] if prod else None,recall_to_first_productive_event_rounds=prod['r']-e['r'] if prod else None,
                         spawn_to_first_camp_hp_loss_rounds=pve['r']-home[1] if pve else None,spawn_to_first_enemy_hp_loss_rounds=pvp['r']-home[1] if pvp else None,
                         ordinary_move_commands_before_productive=len(moves) if prod else None,observed_ordinary_move_chebyshev_distance=displacement if prod else None,
                         followup_stop='death' if death and death['seq']==stop else 'next_recall' if nextrecall and nextrecall['seq']==stop else 'trace_end'))
            roles[bid]['recall_commands']+=1
    for bid,c in roles.items():
        samples=bodysamples[bid];alive=sum(x[2][5] for x in samples);spawn=sum(x[2][5] and inside(x[2],spawns[roster[bid]['team']]) for x in samples)
        emit('body-roles',dict(**bm(bid),world_round_samples=len(samples),alive_round_samples=alive,spawn_round_samples=spawn,field_round_samples=alive-spawn,
                              **{k:c.get(k,0) for k in ['camp_hp_loss_dealt','sourced_camp_damage_frames','capture_receipts','capture_gems','capture_gold','tribute_start_commands','tribute_completions','banked_gems','recall_commands']}))
    for side in [0,1]:
        cs=[v for bid,v in roles.items() if roster[bid]['team']==side]
        sums={k:sum(c[k] for c in cs) for k in ['camp_hp_loss_dealt','capture_receipts','capture_gems','capture_gold','tribute_start_commands','tribute_completions','banked_gems','recall_commands']}
        share=lambda k:max((c[k] for c in cs),default=0)/sums[k] if sums[k] else None
        game_rows[-2+side].update(**sums,farming_bodies=sum(c['camp_hp_loss_dealt']>0 for c in cs),capture_recipient_bodies=sum(c['capture_receipts']>0 for c in cs),tribute_completing_bodies=sum(c['tribute_completions']>0 for c in cs),
                                  largest_body_farming_damage_share=share('camp_hp_loss_dealt'),largest_body_capture_gem_share=share('capture_gems'),largest_body_banked_gem_share=share('banked_gems'))
    counts['raw_streams']+=1;counts['patch_'+patch]+=1;counts['cohort_'+cohort]+=1
    audits.append(dict(**common,source_trace_id=g['id'],trace_path=str(path.resolve()),trace_sha256=sha(compressed),raw_hash_checked=actualraw is not None,engine_sha256=g['engine_sha256'],
                       apiFinalChecks=checks,apiFinalErrors=g['apiFinalErrors'],native_rounds=endround,native_roster=len(roster),banked_score_from_deltas=perteam_score,
                       complete_personal_gem_ledger_available=gemledger is not None,personal_gem_ledger_sha256=sha(gempath.read_bytes()) if gemledger else None))
    if (ix+1)%50==0:print(json.dumps(dict(processed=ix+1,selected=len(selected),elapsed_seconds=round(time.time()-started,1))),flush=True)

for f in files.values():f.close()
if a.merge_parts:
    seen=set()
    for part in sorted(a.merge_parts.glob('part-*')):
        ps=json.loads((part/'summary.json').read_bytes());pa=json.loads((part/'source-audit.json').read_bytes())
        if ps['manifest_sha256']!=sha(a.manifest.read_bytes()) or ps['ladder_sha256']!=sha(a.ladder.read_bytes()) or ps['analyzer_sha256']!=ANALYZER_SHA:
            raise ValueError('Part source/analyzer binding differs: '+str(part))
        for entry in pa['checks']:
            if entry['raw_sha256'] in seen:raise ValueError('Duplicate trajectory across parts')
            seen.add(entry['raw_sha256'])
        audits+=pa['checks'];errors+=pa['errors'];counts.update(ps['counts'])
        case_rows+=json.loads((part/'case-candidates.json').read_bytes())
        with (part/'team-games.csv').open(newline='',encoding='utf8') as f:
            # Canonical types are retained separately; CSV is intended for readers.
            pass
        game_rows+=json.loads((part/'team-games.json').read_bytes())
        for kind in files:
            with gzip.open(part/(kind+'.jsonl.gz'),'rt',encoding='utf8') as f:rows_by_type[kind].extend(json.loads(line) for line in f)
    for kind,rows in rows_by_type.items():
        with gzip.open(a.out_dir/(kind+'.jsonl.gz'),'wt',encoding='utf8') as f:
            for row in rows:f.write(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n')
    check(len(seen)==requested_count,'merged','complete_requested_trajectory_count',expected=requested_count,actual=len(seen))
writecsv('team-games.csv',game_rows);writejson('source-audit.json',dict(errors=errors,checks=audits,raw_aliases=aliases))
writejson('team-games.json',game_rows)
writejson('case-candidates.json',case_rows)

NUMERIC={
 'team-games':['banked_score_from_deltas','rounds','roster_bodies','camp_hp_loss_dealt','capture_receipts','capture_gems','capture_gold','tribute_start_commands','tribute_completions','recall_commands','farming_bodies','capture_recipient_bodies','tribute_completing_bodies','largest_body_farming_damage_share','largest_body_capture_gem_share','largest_body_banked_gem_share'],
 'capture-payouts':['recipient_count','gold','gems','recipients_also_farmed','observed_wait_to_payout_rounds','wait_to_payout_rounds_exact','exact_control_to_neutral_transitions','exact_side_switches'],
 'waiting-episodes':['waiting_round_samples','observed_wait_to_payout_rounds','observed_control_to_neutral_transitions','observed_side_switches','sampled_timer_increases'],
 'native-waiting-episodes':['wait_to_payout_rounds_exact','exact_control_to_neutral_transitions','exact_side_switches'],
 'collection-followups':['receipt_gems','bag_after','rounds_since_prior_recall','rounds_to_next_tribute_start','rounds_to_next_tribute_completion','rounds_to_next_recall','next_banked_amount'],
 'tribute-starts':['bag_at_start','gold_at_start','hp_fraction','banked_gems'],
 'tribute-completions':['banked_gems','bag_before_completion','bag_at_linked_start','start_to_completion_rounds'],
 'recall-followups':['bag_at_start','gold_at_start','hp_fraction_at_start','rounds_to_first_alive_spawn_sample','first_spawn_sample_hp_fraction','spawn_to_first_field_sample_rounds','first_field_sample_hp_fraction','spawn_to_first_productive_event_rounds','recall_to_first_productive_event_rounds','spawn_to_first_camp_hp_loss_rounds','spawn_to_first_enemy_hp_loss_rounds','ordinary_move_commands_before_productive','observed_ordinary_move_chebyshev_distance'],
 'body-roles':['camp_hp_loss_dealt','capture_receipts','capture_gems','banked_gems','recall_commands','field_round_samples']}
def summarize(kind, rs, key):
    result=[];buckets=defaultdict(list)
    for row in rs:buckets[tuple(row.get(k) for k in key)].append(row)
    for values,group in buckets.items():
        out=dict(zip(key,values));out.update(events=len(group),streams=len({x['raw_sha256'] for x in group}),metrics={k:dist(x.get(k) for x in group) for k in NUMERIC[kind]})
        for k in ['outcome','recipient_count','bag_at_start','equal_gold_split','equal_gem_split','recall_within_0_rounds','recall_within_3_rounds','recall_command_0_to_5_rounds_before_receipt','channel_in_last_sample_before_receipt','clean_receipt_to_bank_status','followup_stop','completed','observed_tribute_channel_sample','observed_recall_channel_sample','inside_own_spawn_at_start','recall_channel_to_alive_spawn_boundary_observed']:
            if k in group[0]:out[k+'_counts']=dict(Counter(str(x[k]) for x in group))
        if kind=='capture-payouts':
            out['events_with_recipient_only_body']=sum(bool(x['recipient_only_bodies']) for x in group)
            out['events_with_farmer_only_body']=sum(bool(x['farmer_only_bodies']) for x in group)
            out['events_with_opponent_farmers']=sum(bool(x['opponent_farming_bodies']) for x in group)
        result.append(out)
    return result

aggregates={}
rows_by_type['team-games']=game_rows
for kind, rs in rows_by_type.items():
    clean=[x for x in rs if not x['external_identity_ambiguous']]
    aggregates[kind]={'cohort':summarize(kind,clean,['patch','cohort'])}
    if clean and 'side' in clean[0]:
        aggregates[kind]['team']=summarize(kind,clean,['patch','cohort','teamId','team','rank'])
        aggregates[kind]['map_team']=summarize(kind,clean,['patch','cohort','map','teamId','team','rank'])
        if 'champion' in clean[0]:aggregates[kind]['team_champion']=summarize(kind,clean,['patch','cohort','teamId','team','rank','champion'])
    if kind=='recall-followups':
        strict=[x for x in clean if x['recall_channel_to_alive_spawn_boundary_observed'] and not x['inside_own_spawn_at_start']]
        aggregates[kind]['recall_to_spawn_boundary_cohort']=summarize(kind,strict,['patch','cohort'])
        aggregates[kind]['recall_to_spawn_boundary_team']=summarize(kind,strict,['patch','cohort','teamId','team','rank'])
    if kind=='collection-followups':
        exact=[x for x in clean if x['clean_receipt_to_bank_status']=='clean_exact_personal_gem_ledger']
        aggregates[kind]['clean_exact_receipt_to_bank_cohort']=summarize(kind,exact,['patch','cohort'])
        aggregates[kind]['clean_exact_receipt_to_bank_team']=summarize(kind,exact,['patch','cohort','teamId','team','rank'])
writejson('aggregates.json',aggregates)
summary=dict(created_at_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.time()-started,counts=dict(counts),errors=len(errors),
             requested_streams=requested_count if a.merge_parts else len(selected),deduplication='One trajectory per exact raw SHA; any multiple external-identity attribution is recorded and excluded from grouped team/cohort analysis.',
             event_rows={k:len(v) for k,v in rows_by_type.items()},manifest_path=str(a.manifest.resolve()),manifest_sha256=sha(a.manifest.read_bytes()),
             trace_dir=str(a.trace_dir.resolve()),ladder_path=str(a.ladder.resolve()),ladder_sha256=sha(a.ladder.read_bytes()),
             ladder_fetched_at_utc=ladder.get('fetched_at_utc'),ladder_updated_at=ladder.get('updatedAt'),analyzer_sha256=ANALYZER_SHA,raw_hash_validation=not a.skip_raw_hash)
writejson('summary.json',summary)
print(json.dumps(summary,ensure_ascii=False),flush=True)
if errors:raise SystemExit('Source/audit errors; see source-audit.json')
