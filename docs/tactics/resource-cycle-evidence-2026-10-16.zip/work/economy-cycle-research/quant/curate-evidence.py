"""Small primary-cohort ledger set plus hashes for documentation evidence packaging."""
from pathlib import Path
import argparse,gzip,hashlib,json
p=argparse.ArgumentParser();p.add_argument('directory',type=Path);a=p.parse_args();d=a.directory
v=json.loads((d/'validation.json').read_bytes())
if v['errors']:raise SystemExit('Validation must pass before evidence is curated')
folder=d/'primary-top4';folder.mkdir(exist_ok=True);counts={}
names=['capture-payouts','native-waiting-episodes','collection-followups','tribute-starts','tribute-completions','recall-followups','body-roles']
for name in names:
    count=0
    with gzip.open(d/(name+'.jsonl.gz'),'rt',encoding='utf8')as source,gzip.open(folder/(name+'.jsonl.gz'),'wt',encoding='utf8')as dest:
        for line in source:
            x=json.loads(line)
            if x['patch']=='0.0.2'and x['cohort']=='top4_h2h':dest.write(line);count+=1
    counts[name]=count
audit=json.loads((d/'source-audit.json').read_bytes())
primary=dict(errors=[],checks=[x for x in audit['checks']if x['patch']=='0.0.2'and x['cohort']=='top4_h2h'],raw_aliases=[])
(folder/'source-audit.json').write_text(json.dumps(primary,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
selected=['summary.json','validation.json','denominator-audit.json','findings.md','findings.json','top10-primary-team-summary.csv','top10-primary-team-summary.json','geometry-bins.csv','geometry-bins.json','geometry-findings.md','joined-cycle-stages.jsonl.gz','joined-cycle-stages-summary.json','champion-role-summary.json','historical-sensitivity.json']
files=[d/x for x in selected if(d/x).exists()]+list(folder.glob('*'))
out=dict(scope='Validated primary patch2 current-top4 H2H event ledgers, with all-top10 comparative summary and denominator audit. Native replay sources remain in the source audit; no queued games or bot execution.',primary_event_counts=counts,files=[dict(path=str(x.resolve()),bytes=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest())for x in files])
(d/'curated-evidence-index.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(files=len(files),primary_event_counts=counts)))
