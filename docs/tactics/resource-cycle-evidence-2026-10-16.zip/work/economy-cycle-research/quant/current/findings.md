# Economy-cycle quantitative findings

Primary current-top4 H2H: 150 distinct raw trajectories, 8640 exact capture payouts and 9057 recipient observations. 365/8640 (4.2%) payouts had multiple recipients. 627/8640 (7.3%) payouts included a recipient with no source-mapped camp damage since the previous payout; this is a role observation, not evidence of deliberate delegation.

Exact reward-available→payout lag is available for 8640/8640 payouts: median 7, IQR 6–9, p90 10 world rounds. Fixed-stage sampled lag is separately retained (n=8640); the two definitions must not be pooled.

The complete native group ledger contains 8787 waiting episodes, of which 8640 end in payout and 147 remain right-censored. It records 1251 control-to-neutral transitions and 0 direct side switches. These transitions do not establish intentional abandonment or its cause.

There are 5199 tribute start commands and 4723 exact score/bag-drop completions, banking 242024 gems in total. Start bag median 44; actual completed bank median 44. Start outcomes: {'completed_exact_score': 4723, 'death_before_completion': 110, 'superseded_by_next_start': 301, 'no_completion_before_trace_end': 65}. Uncompleted commands are not automatically failures.

Collection followups cover 9057 recipient observations, stopping at the next personal death or trace end. A next exact bank exists for 6399; its latency median is 30 rounds. This is an ordered event relation, not attribution of those banked gems to the receipt.

The complete personal-gem ledger identifies 3382 clean receipt→bank sequences: pre-receipt bag zero, no intervening personal gem delta or death, and an exact equal terminal bank with a linked tribute start. Their bank latency median is 17 rounds (IQR 11–31). This selected subset is not a general conversion-rate estimate.

Strict sampled recall→alive-spawn boundaries number 8038 (distinct streams 150). Of these, 7367 have a subsequent trace-confirmed field productive event before death, next recall or trace end: median spawn→event 21 rounds. Camp HP loss and enemy HP loss followups are separately reported (n=6461 and n=3472). Delayed spell damage is outside this narrow command-confirmed return measure.

| Current rank / team | H2H streams | Payouts / shared | Exact wait median / p90 | Tribute bag median | Banked completions / gems | Strict recall boundaries / return median |
|---|---:|---:|---:|---:|---:|---:|
| 1. Sneaky Bush Campers | 82 | 2053 / 279 | 7 / 10 | 44 | 1386 / 64557 | 2186 / 24 |
| 2. Intercontinental Fish | 71 | 2372 / 42 | 7 / 12 | 48 | 1039 / 60896 | 1948 / 18 |
| 3. Univardisty of Shingtonwash | 73 | 1992 / 17 | 7 / 13 | 44 | 1008 / 56790 | 1805 / 20 |
| 4. procless | 74 | 2223 / 27 | 6 / 10 | 36 | 1290 / 59781 | 2099 / 20 |

Each team table row is an observed event distribution within its own H2H appearances. Opponent, side, map, duration, roster size and policy version differ; these are not matched or causal performance estimates. Current rank belongs to the timestamped supplied ladder and is not rank at play.

Corpus: {'raw_streams': 2588, 'patch_0.0.2': 952, 'cohort_top4_vs_other_current_top10': 996, 'cohort_other_current_top10': 641, 'cohort_top4_h2h': 951, 'patch_0.0.1': 1636}; exact raw SHA deduplication; source/audit errors 0; independent ledger validation errors 0. Event tables keep patch 0.0.1 separate as historical sensitivity and preserve missing native/API counters.

Manifest SHA256 `9a152a3943bef710e9c0d35041d438734fc8c50088ff2b3e8a918ca34106b69b`. Ladder SHA256 `9d6a0f6603cac9ca1c16c1bf0423d532c207bc0d7d1379a576188744513df984` fetched 2026-10-16T12:39:47.094054+00:00. Analyzer SHA256 `f7c35a2773ddd75449837226d8716bc33b78b5fe2ac01af61ffe69969dc0da3b`. Definitions: `../definitions.md`; complete source checks: `source-audit.json`; conservation checks: `validation.json`; distributions and denominators: `aggregates.json`; auditable event ledgers: `*.jsonl.gz`.
