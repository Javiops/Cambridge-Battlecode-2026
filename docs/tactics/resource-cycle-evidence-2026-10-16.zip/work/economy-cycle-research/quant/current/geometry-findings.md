# Descriptive geometry sensitivity, primary current-top4 H2H

All 150 primary raw trajectories pass exact terrain SHA, dimensions and spawn-rectangle comparison against the corresponding static-field exemplar. Initial camp membership differs in 34 streams. Distances were therefore queried from the validated dense fields at each stream's actual initial camp-group tiles; the join does not assume a map label or group index fixes a camp layout. No primary receipt or strict recall was excluded for a missing field after this correction. Per-stream variant hashes, source trace paths and checks are in `current/geometry-bins.json`.

The fields exclude dynamic camps/champions, locks, move permissions and readiness. They describe a lower-bound static walk, not complete action ETA. Bin cuts are reference quartiles of unique map/side/group slots in the 17 supplied exemplars. Samples are correlated and selected; no map-policy coefficient or causal distance effect is estimated.

| Original group tiles → nearest legal altar approach, static walk | Clean exact receipt→bank events | Distinct streams | Median receipt→bank rounds |
|---|---:|---:|---:|
| ≤8 | 1,509 | 102 | 11 |
| (8,13] | 1,160 | 107 | 19 |
| (13,20] | 338 | 68 | 30 |
| >20 | 375 | 54 | 40 |

All 3,382 rows above have a complete native personal-gem ledger: bag zero before receipt, no intervening personal gem delta/death, and an exact equal terminal bank with a linked tribute. This is a selected clean subset, not a general conversion-rate estimate. The feature describes original group tiles, not the exact recipient tile or an attack firing position. In the broader mixed-bag followup panel, next banks are observed for 2,237/3,124, 2,180/2,603, 1,086/1,610 and 896/1,720 recipient observations respectively; their medians are 14, 28, 52 and 54 rounds. Those broader banks cannot be attributed to the individual camp receipt.

| Recall command position → own spawn, static walk | Strict sampled recall→spawn boundaries | Distinct streams | Available productive returns | Median spawn→productive-event rounds |
|---|---:|---:|---:|---:|
| ≤22 | 5,014 | 128 | 4,617 | 17 |
| (22,33] | 1,446 | 126 | 1,336 | 25 |
| (33,46] | 805 | 76 | 731 | 42 |
| >46 | 773 | 45 | 683 | 50 |

The second feature describes the location left at recall start, not the next field objective. It is descriptive context for observed reset/return sequences. The productive-event measure is an actual field attack/cast with same-frame camp/enemy HP loss or a capture receipt, observed before the next death, recall or trace end. Missing followups are retained in the boundary denominator. Return to camp HP loss and enemy HP loss are separately available in `current/geometry-bins.csv`.

Exact source hashes, valid-match counts, camp variants, thresholds, all 48 table rows and missingness are in `current/geometry-bins.json`. The 87 initially uncovered `corners` recipient observations were resolved by actual per-stream camp-tile queries; no camp layout was guessed.
