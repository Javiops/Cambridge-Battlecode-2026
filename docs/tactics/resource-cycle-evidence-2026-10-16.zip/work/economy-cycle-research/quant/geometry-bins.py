"""Descriptive geometry joins; no fitted map/policy effects or action ETA claims."""
from pathlib import Path
from collections import defaultdict,Counter
import argparse,csv,gzip,hashlib,json,statistics
p=argparse.ArgumentParser();p.add_argument('directory',type=Path);p.add_argument('--features',type=Path,required=True);a=p.parse_args();d=a.directory
features=json.loads(a.features.read_bytes());maps={x['map']:x for x in features['maps']}
sourceaudit=json.loads((d/'source-audit.json').read_bytes());streamfeatures={};featurechecks=[]
summary=json.loads((d/'summary.json').read_bytes());bound=json.loads(Path(summary['manifest_path']).read_bytes());byraw={x['raw_sha256']:x for x in bound['requests']}
exemplars={}
for m in features['maps']:
    source=byraw.get(m['source_raw_sha256']);fallback=d.resolve().parents[3]/'work/combat-research/matches/current'/(m['source_id']+'.coord.json.gz')
    path=fallback if fallback.exists()else Path(source['trace_path'])
    data=path.read_bytes();g=json.loads(gzip.decompress(data))
    if hashlib.sha256(data).hexdigest()!=m['source_trace_sha256']:raise ValueError('Feature exemplar trace hash changed: '+m['map'])
    exemplars[m['map']]=g
def variant(g):
    members=sorted((x['group'],x['id'],x['type'],x['x'],x['y'],x['max'])for x in g['camps'])
    definition=dict(terrain_sha256=g['geometry']['sha256'],width=g['geometry']['width'],height=g['geometry']['height'],spawn=g['geometry']['spawn'],initial_camp_members=members)
    return hashlib.sha256(json.dumps(definition,sort_keys=True,separators=(',',':')).encode()).hexdigest(),definition
for entry in sourceaudit['checks']:
    if entry['patch']!='0.0.2'or entry['cohort']!='top4_h2h':continue
    data=Path(entry['trace_path']).read_bytes();g=json.loads(gzip.decompress(data));m=maps.get(entry['map'])
    eg=exemplars.get(entry['map']);terrain=bool(m and g['geometry']['sha256']==m['geometry_sha256']and g['geometry']['width']==m['width']and g['geometry']['height']==m['height'])
    spawn=bool(eg and g['geometry']['spawn']==eg['geometry']['spawn']);valid=terrain and spawn;vh,vd=variant(g);eh,ed=variant(eg)
    check=dict(raw_sha256=entry['raw_sha256'],match_id=entry['match_id'],map=entry['map'],trace_path=entry['trace_path'],trace_sha256=hashlib.sha256(data).hexdigest(),terrain_geometry_sha256=g['geometry']['sha256'],terrain_geometry_matches_feature_exemplar=terrain,spawn_rectangles_match_exemplar=spawn,initial_camp_members_match_exemplar=vd['initial_camp_members']==ed['initial_camp_members'],static_dense_field_valid=valid,variant_sha256=vh,exemplar_variant_sha256=eh,groups=len(g['rounds'][0]['groups']))
    if not valid:check['uncovered_variant_definition']=vd
    if valid:
        physical=defaultdict(list)
        for camp in g['camps']:physical[camp['group']].append([camp['x'],camp['y']])
        values={}
        for side in [0,1]:
            for group,tiles in physical.items():
                indices=[tile[1]*m['width']+tile[0]for tile in tiles]
                hw=[m['sides'][side]['home_distance_field'][i]for i in indices];aw=[m['sides'][side]['nearest_altar_approach_distance_field'][i]for i in indices]
                values[side,group]=dict(home_walk=min(hw)if hw else None,altar_walk=min(aw)if aw else None,tiles=tiles)
        streamfeatures[entry['raw_sha256']]=values
        check['physical_initial_groups']=len(physical)
        check['groups_absent_in_exemplar']=sorted(group for group in physical if not any(x['group']==group for x in m['sides'][0]['groups']))
    featurechecks.append(check)
def rows(name):
    with gzip.open(d/(name+'.jsonl.gz'),'rt',encoding='utf8')as f:
        for line in f:yield json.loads(line)
def quant(v,t):
    v=sorted(v);k=(len(v)-1)*t;i=int(k);return v[i]+(v[min(i+1,len(v)-1)]-v[i])*(k-i)
def distribution(v):
    v=[x for x in v if x is not None]
    return dict(n=len(v),median=quant(v,.5) if v else None,p25=quant(v,.25) if v else None,p75=quant(v,.75) if v else None)
thresholds={}
for feature in ['home_walk','altar_walk']:
    vals=[g[feature] for m in features['maps'] for side in m['sides'] for g in side['groups'] if g[feature] is not None and g[feature]!=65535]
    thresholds[feature]=[quant(vals,q)for q in [.25,.5,.75]]
def binvalue(v,feature):
    if v is None or v==65535:return 'unreachable_or_unavailable'
    limits=thresholds[feature]
    i=next((i for i,x in enumerate(limits)if v<=x),3)
    return (f'Q{i+1}: <= {limits[i]:g}' if i==0 else f'Q{i+1}: ({limits[i-1]:g}, {limits[i]:g}]' if i<3 else f'Q4: > {limits[2]:g}')
buckets=defaultdict(list);missing=Counter()
for x in rows('collection-followups'):
    if x['patch']!='0.0.2' or x['cohort']!='top4_h2h':continue
    g=streamfeatures.get(x['raw_sha256'],{}).get((x['side'],x['group']))
    if not g:missing['collection_group_feature']+=1;continue
    for feature in ['home_walk','altar_walk']:
        b=binvalue(g[feature],feature)
        buckets['collection_all',feature,b].append(x)
        if x['clean_receipt_to_bank_status']=='clean_exact_personal_gem_ledger':buckets['collection_clean_exact',feature,b].append(x)
for x in rows('recall-followups'):
    if x['patch']!='0.0.2' or x['cohort']!='top4_h2h' or not x['recall_channel_to_alive_spawn_boundary_observed']:continue
    m=maps.get(x['map']);pos=x['position']
    if x['raw_sha256']not in streamfeatures or not m or not(0<=pos[0]<m['width'] and 0<=pos[1]<m['height']):missing['recall_start_position_feature']+=1;continue
    v=m['sides'][x['side']]['home_distance_field'][pos[1]*m['width']+pos[0]]
    buckets['strict_recall','home_walk',binvalue(v,'home_walk')].append(x)
out=[]
for (kind,feature,b),rs in sorted(buckets.items()):
    metrics=['rounds_to_next_tribute_completion','rounds_to_next_recall']if kind.startswith('collection')else['rounds_to_first_alive_spawn_sample','spawn_to_first_productive_event_rounds','spawn_to_first_camp_hp_loss_rounds','spawn_to_first_enemy_hp_loss_rounds']
    for metric in metrics:out.append(dict(event_type=kind,feature=feature,feature_bin=b,events=len(rs),streams=len({x['raw_sha256']for x in rs}),metric=metric,**distribution(x[metric]for x in rs)))
with(d/'geometry-bins.csv').open('w',newline='',encoding='utf8')as f:
    w=csv.DictWriter(f,fieldnames=list(out[0])if out else[]);w.writeheader();w.writerows(out)
report=dict(scope=features['scope'],notes=[
    'Primary patch2 current-top4 H2H only. Static-feature quartile thresholds come from unique map/side/original-camp-group slots, not from observed outcomes.',
    'Every primary stream terrain SHA must match the exemplar before its dense fields are used. Collection distances are recomputed from that stream actual initial camp-group tiles, so map label/group index is never assumed to fix a camp layout. Collection feature describes original camp group tiles, not the recipient tile or an attack firing position.',
    'Strict recall feature describes distance from the recall command position to own spawn. It does not describe the next field objective, so return-latency bins are descriptive context only.',
    'Dynamic camps/champions, locks, move permissions and readiness are excluded. Distances are lower bounds; samples are correlated and selected; no causal map or distance effect is estimated.',
    'All collection followups are ordered event relations and can contain mixed gems. Clean exact rows require complete native personal-gem ledger. n is the available outcome denominator, events includes censored/unavailable outcomes.'],
    feature_sha256=hashlib.sha256(a.features.read_bytes()).hexdigest(),source_summary_sha256=hashlib.sha256((d/'summary.json').read_bytes()).hexdigest(),thresholds=thresholds,missing=dict(missing),source_feature_checks=featurechecks,valid_static_field_streams=sum(x['static_dense_field_valid']for x in featurechecks),camp_variant_streams=sum(not x['initial_camp_members_match_exemplar']for x in featurechecks),rows=out)
(d/'geometry-bins.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(rows=len(out),thresholds=thresholds,missing=dict(missing))))
