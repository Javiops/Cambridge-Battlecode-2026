"""Conservative bank-level joins across observed collection, recovery and return stages."""
from pathlib import Path
from collections import defaultdict,Counter
import argparse,gzip,json,statistics
p=argparse.ArgumentParser();p.add_argument('directory',type=Path);a=p.parse_args();d=a.directory
def rows(name):
    with gzip.open(d/(name+'.jsonl.gz'),'rt',encoding='utf8')as f:
        return [x for line in f if (x:=json.loads(line))['patch']=='0.0.2'and x['cohort']=='top4_h2h']
captures={(x['raw_sha256'],x['seq']):x for x in rows('capture-payouts')}
collections=defaultdict(list)
for x in rows('collection-followups'):
    if x['next_tribute_completion_round'] is not None:collections[x['raw_sha256'],x['body'],x['next_tribute_completion_round']].append(x)
resets=defaultdict(list)
for x in rows('recall-followups'):
    if x['recall_channel_to_alive_spawn_boundary_observed']and x['first_productive_event_round']is not None:resets[x['raw_sha256'],x['body']].append(x)
joined=[];denom=Counter();outcomes=Counter()
for bank in rows('tribute-completions'):
    denom[bank['team']]+=1;receipts=collections.get((bank['raw_sha256'],bank['body'],bank['round']),[])
    if not receipts:outcomes['no_prior_capture_receipt_linked_to_next_bank']+=1;continue
    first=min(x['round']for x in receipts);candidates=[]
    for reset in resets[bank['raw_sha256'],bank['body']]:
        # Strict world-round inequality avoids guessing order of equal-round bank/return events.
        if reset['first_alive_spawn_sample_round']<first or reset['first_productive_event_round']<=bank['round']:continue
        # At least one linked receipt must retain the full chain inside its pre-death followup.
        eligible=[x for x in receipts if x['followup_stop']=='trace_end'or reset['first_productive_event_round']<x['round']+x['followup_available_rounds']]
        if not eligible:continue
        # A later reset after the bank is allowed; an earlier reset must overlap collection/home.
        if reset['round']<first and reset['first_alive_spawn_sample_round']<first:continue
        candidates.append((reset,eligible))
    if not candidates:outcomes['capture_and_bank_without_conservative_strict_reset_return_join']+=1;continue
    reset,eligible=min(candidates,key=lambda z:(z[0]['first_productive_event_round'],z[0]['seq']))
    clean=[x for x in eligible if x['clean_receipt_to_bank_status']=='clean_exact_personal_gem_ledger']
    farmed=[x for x in eligible if bank['body']in captures[x['raw_sha256'],x['seq']]['farming_bodies_since_previous_payout']]
    row={k:bank[k]for k in ['match_id','raw_sha256','patch','map','cohort','side','teamId','team','rank','body','champion']}
    row.update(bank_seq=bank['seq'],bank_round=bank['round'],banked_gems=bank['banked_gems'],linked_receipt_count=len(eligible),receipt_rounds=sorted(x['round']for x in eligible),receipt_seqs=sorted(x['seq']for x in eligible),
               recipient_dealt_group_camp_hp_loss_in_at_least_one_linked_receipt=bool(farmed),clean_exact_single_receipt_bank=bool(clean),
               recall_seq=reset['seq'],recall_round=reset['round'],first_alive_spawn_sample_round=reset['first_alive_spawn_sample_round'],first_productive_event_round=reset['first_productive_event_round'],first_productive_event_kind=reset['first_productive_event_kind'],first_productive_event_input=reset['first_productive_event_input'],
               bank_to_productive_rounds=reset['first_productive_event_round']-bank['round'],first_receipt_to_productive_rounds=reset['first_productive_event_round']-min(x['round']for x in eligible),
               order='bank_before_recall_command'if bank['seq']<reset['seq']else'recall_command_before_bank',strict_return_definition='sampled recall channel→alive spawn boundary; actual subsequent field HP loss or reward receipt; productive event strictly later world round than bank')
    joined.append(row);outcomes['conservative_collection_bank_reset_return_join']+=1
with gzip.open(d/'joined-cycle-stages.jsonl.gz','wt',encoding='utf8')as f:
    for x in joined:f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
panels=[]
for team in sorted(denom):
    xs=[x for x in joined if x['team']==team]
    panels.append(dict(team=team,bank_completion_denominator=denom[team],joined_bank_events=len(xs),streams=len({x['raw_sha256']for x in xs}),clean_exact_single_receipt_banks=sum(x['clean_exact_single_receipt_bank']for x in xs),recipient_also_farmed=sum(x['recipient_dealt_group_camp_hp_loss_in_at_least_one_linked_receipt']for x in xs),bank_to_productive_rounds_median=statistics.median(x['bank_to_productive_rounds']for x in xs)if xs else None,order_counts=dict(Counter(x['order']for x in xs))))
report=dict(scope='Conservative primary current-top4 H2H bank-level observed stage join; selected descriptive subset, not full policy-cycle incidence or causal return on a reset.',notes=['Each exact body bank is counted at most once. Multiple prior receipts can link to a bank; mixed bags retain no resource-origin attribution. Clean exact single-receipt status requires the complete native personal-gem ledger.','The reset can precede a bank or follow it, reflecting observed order. The first sampled alive spawn must occur at or after the earliest linked receipt. The first recorded productive return must occur in a strictly later world round than the bank, to avoid equal-round ordering guesses.','The chain must remain before a linked receipt personal death; same-round death/followup ties are conservatively excluded. Missing/later productive events outside the narrow recall ledger are not proof of no productive action.','One later reset/return can be shared by multiple bank events, so these are bank-level stage joins, not independent cycles. A farming check requires actual source-mapped camp HP loss by that recipient on at least one linked group.'],outcomes=dict(outcomes),primary_bank_completions=sum(denom.values()),joined_bank_events=len(joined),distinct_reset_return_events=len({(x['raw_sha256'],x['body'],x['recall_seq'],x['first_productive_event_input'])for x in joined}),teams=panels)
(d/'joined-cycle-stages-summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(report,ensure_ascii=False))
