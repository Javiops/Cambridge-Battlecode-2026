"""Bounded parallel pass, then source-checked merge of independent trajectory shards."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,subprocess,sys,time,json
p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=4);p.add_argument('--out-dir',type=Path,required=True)
a,rest=p.parse_known_args();a.out_dir.mkdir(parents=True,exist_ok=True);parts=a.out_dir/'parts';parts.mkdir(exist_ok=True)
script=Path(__file__).with_name('analyze-cycles.py');started=time.time()
def run(i):
    dest=parts/f'part-{i}';dest.mkdir(exist_ok=True)
    cmd=[sys.executable,str(script),'--stride',str(a.workers),'--index',str(i),'--out-dir',str(dest),*rest]
    with(dest/'run.log').open('w',encoding='utf8')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
    return dict(worker=i,exit_code=r.returncode)
results=[]
with ThreadPoolExecutor(max_workers=a.workers)as pool:
    for future in as_completed(pool.submit(run,i)for i in range(a.workers)):
        result=future.result();results.append(result);print(json.dumps(result),flush=True)
if any(r['exit_code']for r in results):raise SystemExit('Worker failure; inspect part run.log')
cmd=[sys.executable,str(script),'--merge-parts',str(parts),'--out-dir',str(a.out_dir),*rest]
with(a.out_dir/'merge.log').open('w',encoding='utf8')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
result=dict(elapsed_seconds=time.time()-started,workers=results,merge_exit_code=r.returncode)
(a.out_dir/'run-report.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result),flush=True)
if r.returncode:raise SystemExit('Merge failure; inspect merge.log')
