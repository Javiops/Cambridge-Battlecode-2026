from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,subprocess,sys,os,json,time
p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=4);p.add_argument('--out-dir',type=Path,required=True);p.add_argument('--engine',type=Path,required=True)
a,rest=p.parse_known_args();a.out_dir.mkdir(parents=True,exist_ok=True);logs=a.out_dir/'logs';logs.mkdir(exist_ok=True)
script=Path(__file__).with_name('scan-gem-ledger.mjs');node=r'C:/Users/frans/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe';started=time.time()
def run(i):
    with(logs/f'worker-{i}.log').open('w',encoding='utf8')as f:
        r=subprocess.run([node,str(script),'--stride',str(a.workers),'--index',str(i),'--out-dir',str(a.out_dir),'--resume',*rest],env={**os.environ,'COMBAT_ENGINE_PATH':str(a.engine.resolve())},stdout=f,stderr=subprocess.STDOUT)
    return dict(worker=i,exit_code=r.returncode)
results=[]
with ThreadPoolExecutor(max_workers=a.workers)as pool:
    for future in as_completed(pool.submit(run,i)for i in range(a.workers)):
        x=future.result();results.append(x);print(json.dumps(x),flush=True)
out=dict(elapsed_seconds=time.time()-started,results=results,ledger_files=len(list(a.out_dir.glob('*.gems.json.gz'))));(a.out_dir/'run-report.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
if any(x['exit_code'] for x in results):raise SystemExit(1)
