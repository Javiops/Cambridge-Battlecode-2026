// Read-only native personal-gem deltas, reusing the already validated coordination ABI.
// Replays existing input files; never executes a bot or queues/simulates a game.
import fs from 'node:fs';import path from 'node:path';import zlib from 'node:zlib';import crypto from 'node:crypto';
import{E,out,checked}from'../../combat-research/matches/engine.mjs';
const args={};for(let i=2;i<process.argv.length;i++){const k=process.argv[i].slice(2);args[k]=['resume','skip-missing'].includes(k)?true:process.argv[++i];}
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const manifest=JSON.parse(fs.readFileSync(args.manifest)),ladder=JSON.parse(fs.readFileSync(args.ladder));
const top4=new Set(ladder.teams.filter(t=>t.rank<=4).map(t=>t.teamId));
let requests=manifest.requests.filter(r=>r.replay_patch==='0.0.2'&&['a','b'].every(s=>top4.has(r.teams[s].teamId)));
requests=requests.filter((_,i)=>i%Number(args.stride??1)===Number(args.index??0)).slice(0,args.limit?Number(args.limit):undefined);
const folder=path.resolve(args['out-dir']);fs.mkdirSync(folder,{recursive:true});
const engineSha=sha(fs.readFileSync(process.env.COMBAT_ENGINE_PATH));
if(engineSha!=='e123b59d9dea198762ab7a04db9b3cb6d06dfa991088e41c24750fc4cb88b947')throw Error('Expected verified patch2 engine');
const snap=E.Engine_Malloc(40152),full=E.Engine_Malloc(184696),pp=E.Engine_Malloc(8),view=()=>new DataView(E.memory.buffer);
view().setUint32(pp,2,true);view().setUint32(pp+4,0xffffffff,true);
function state(game,seq){checked('Game_Visualiser_ReadTimelineState',game,snap);const d=view(),u=n=>d.getUint32(snap+n,true),i=n=>d.getInt32(snap+n,true);return{seq,r:u(8),phase:u(24),input:u(56),owner:u(60),kind:u(68),actorKind:u(72),actor:u(76),sub:u(104),score:[Number(d.getBigUint64(snap+32,true)),Number(d.getBigUint64(snap+40,true))],c:Array.from({length:u(172)},(_,k)=>{const p=196+k*252;return{id:u(p+4),team:u(p+8),x:i(p+16),y:i(p+20),alive:!!u(p+32),gems:u(p+40)};}),groups:Array.from({length:u(180)},(_,k)=>[u(18228+k*8),u(18232+k*8)])};}
function channels(game){checked('Game_Visualiser_ReadState',game,pp,full);const d=view(),u=n=>d.getUint32(full+n,true),i=n=>d.getInt32(full+n,true);return Array.from({length:u(120)},(_,k)=>{const p=140+k*456;return{id:u(p+4),channel:u(p+440),timer:i(p+436)};});}
let failures=0;
for(const r of requests){
 const dest=path.join(folder,r.raw_sha256+'.gems.json.gz');if(args.resume&&fs.existsSync(dest))continue;
 try{
  const tracepath=r.trace_path??path.join(args['trace-dir'],r.id+'.coord.json.gz');
  if(args['skip-missing']&&!fs.existsSync(tracepath)){console.log(JSON.stringify({id:r.id,pending:true}));continue;}
  const raw=fs.readFileSync(r.raw);if(sha(raw)!==r.raw_sha256)throw Error('Raw SHA mismatch');
  const tracebytes=fs.readFileSync(tracepath),trace=JSON.parse(zlib.gunzipSync(tracebytes));
  if(trace.raw_sha256!==r.raw_sha256||trace.engine_sha256!==engineSha||trace.apiFinalErrors.length||['a','b'].some(s=>trace.teams[s].teamId!==r.teams[s].teamId))throw Error('Validated trace raw/identity binding failed');
  const ptr=E.Engine_Malloc(raw.length);new Uint8Array(E.memory.buffer,ptr,raw.length).set(raw);checked('Game_FromReplayFileBytes',ptr,raw.length,out);const game=view().getBigUint64(out,true);E.Engine_Free(ptr);
  try{
   checked('Game_Visualiser_Timeline_GetMain',game,out);const timeline=view().getBigUint64(out,true);checked('Game_Visualiser_Timeline_Seek',game,timeline,0,0);
   const events=[],groupEvents=[],commandChannels=[],seenCommands=new Set();let previous=null,initial=null,final=null,frames=0;
   for(let seq=0;seq<500000;seq++){
    const w=state(game,seq);frames++;if(w.c.length===trace.roster.length&&!initial)initial=w;
    if(previous){for(const c of w.c){const b=previous.c.find(x=>x.id===c.id);if(b&&b.gems!==c.gems)events.push({r:w.r,seq,input:w.input,id:c.id,team:c.team,before:b.gems,after:c.gems,delta:c.gems-b.gems,aliveBefore:b.alive,aliveAfter:c.alive,position:[c.x,c.y],step:[w.phase,w.kind,w.actorKind,w.actor,w.sub],scoreDelta:w.score.map((x,t)=>x-previous.score[t])});}}
    if(previous)for(let group=0;group<w.groups.length;group++){const b=previous.groups[group],v=w.groups[group];if(b&&(b[0]!==v[0]||b[1]!==v[1]))groupEvents.push({r:w.r,seq,input:w.input,group,before:b,after:v,step:[w.phase,w.kind,w.actorKind,w.actor,w.sub]});}
    if(w.actorKind===1&&w.sub===0&&[11,12].includes(w.kind)&&!seenCommands.has(w.input)){seenCommands.add(w.input);const c=channels(game).find(c=>c.id===w.actor);if(c)commandChannels.push({r:w.r,seq,input:w.input,kind:w.kind,actor:w.actor,channel:c.channel,timer:c.timer});}
    previous=w;if(w.phase===11){final=w;break;}checked('Game_Visualiser_Timeline_ReplayNext',game,1);
   }
   const errors=[];if(!initial||!final||frames!==trace.frames||final.r!==trace.final.round)errors.push('complete_matching_native_timeline');
   for(const c of trace.final.c){const n=final?.c.find(x=>x.id===c.id),b=initial?.c.find(x=>x.id===c.id);if(!n||n.gems!==c.gems||b.gems+events.filter(x=>x.id===c.id).reduce((s,e)=>s+e.delta,0)!==c.gems)errors.push('final_personal_gem_ledger_'+c.id);}
   for(const e of trace.captures)for(const c of e.recipients){const n=events.find(x=>x.seq===e.seq&&x.id===c.id);if(c.gems&&(!n||n.delta!==c.gems))errors.push('capture_binding_'+e.seq+'_'+c.id);}
   for(const e of trace.submissions)for(let t=0;t<2;t++)if(e.delta[t]){const es=events.filter(x=>x.seq===e.seq&&x.team===t&&x.delta<0);if(es.length!==1||-es[0].delta!==e.delta[t])errors.push('banking_binding_'+e.seq+'_'+t);}
   for(const e of trace.captures){const n=groupEvents.find(x=>x.seq===e.seq&&x.group===e.group);if(!n||JSON.stringify(n.before)!==JSON.stringify(e.before)||JSON.stringify(n.after)!==JSON.stringify(e.after))errors.push('group_transition_binding_'+e.seq+'_'+e.group);}
   const result={id:r.id,source_trace_id:trace.id,ordered_team_ids:['a','b'].map(s=>r.teams[s].teamId),raw_sha256:r.raw_sha256,patch:r.replay_patch,engine_sha256:engineSha,trace_sha256:sha(tracebytes),scanner_sha256:sha(fs.readFileSync(new URL(import.meta.url))),frames,initial:initial?.c,final:final?.c,score:final?.score,events,groupEvents,commandChannels,errors,definition:'Every exact sequential native frame change in a champion personal gem counter, including unnamed sources, and group [rewardAvailable,captureTeam] pairs. Same validated timeline ABI as combat scanner; initial+sum(deltas)=final; exact event binding to existing capture and score events.'};
   if(errors.length)throw Error(errors.join(','));fs.writeFileSync(dest,zlib.gzipSync(JSON.stringify(result),{level:1}));
   console.log(JSON.stringify({id:r.id,frames,gemEvents:events.length,channelObservations:commandChannels.length,errors:errors.length}));
  }finally{checked('Game_Destroy',game);}
 }catch(e){failures++;console.error(JSON.stringify({id:r.id,error:e.stack}));}
}
if(failures)process.exitCode=1;
