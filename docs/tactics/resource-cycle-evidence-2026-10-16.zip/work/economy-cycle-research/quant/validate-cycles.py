"""Independent ledger conservation and source binding validation after aggregation."""
from pathlib import Path
from collections import Counter,defaultdict
import argparse,csv,gzip,hashlib,json
p=argparse.ArgumentParser();p.add_argument('directory',type=Path);p.add_argument('--gem-dir',type=Path);a=p.parse_args();d=a.directory
s=json.loads((d/'summary.json').read_bytes());audit=json.loads((d/'source-audit.json').read_bytes());errors=[];checks=Counter()
def check(ok,label,**extra):
    checks[label]+=1
    if not ok:errors.append(dict(check=label,**extra))
check(not audit['errors'],'source_audit_clear',errors=audit['errors'])
check(hashlib.sha256(Path(s['manifest_path']).read_bytes()).hexdigest()==s['manifest_sha256'],'manifest_hash')
check(hashlib.sha256(Path(s['ladder_path']).read_bytes()).hexdigest()==s['ladder_sha256'],'ladder_hash')
check(len({x['raw_sha256'] for x in audit['checks']})==len(audit['checks']),'deduplicated_raw_trajectories')
tables={}
for name,n in s['event_rows'].items():
    if name=='team-games':continue
    with gzip.open(d/(name+'.jsonl.gz'),'rt',encoding='utf8') as f:rows=[json.loads(x) for x in f]
    check(len(rows)==n,'row_count',table=name);tables[name]=rows
    key=lambda x:(x['raw_sha256'],x.get('seq',x.get('first_waiting_sample_seq',x.get('exact_wait_start_seq'))),x.get('body',x.get('side')),x.get('group'))
    check(len({key(x) for x in rows})==len(rows),'event_identity_unique',table=name)
caps=tables['capture-payouts'];collections=tables['collection-followups'];roles=tables['body-roles'];starts=tables['tribute-starts'];done=tables['tribute-completions']
receipts=defaultdict(list)
for x in collections:receipts[(x['raw_sha256'],x['seq'])].append(x)
for x in caps:
    rs=receipts[(x['raw_sha256'],x['seq'])]
    check(len(rs)==x['recipient_count'],'capture_recipient_count',match_id=x['match_id'],seq=x['seq'])
    check(sum(z['receipt_gems'] for z in rs)==x['gems'] and sum(z['receipt_gold'] for z in rs)==x['gold'],'capture_resources_conserve',match_id=x['match_id'],seq=x['seq'])
    check(sorted(z['body'] for z in rs)==x['recipient_bodies'],'capture_recipient_identity',match_id=x['match_id'],seq=x['seq'])
    for z in rs:check(z['bag_after']-z['bag_before']==z['receipt_gems'],'collection_bag_delta',match_id=z['match_id'],seq=z['seq'])
banked=Counter();rolebank=Counter();capturegems=Counter();rolegems=Counter()
for x in done:
    banked[x['raw_sha256'],x['side']]+=x['banked_gems']
    check(x.get('bag_before_completion',x['banked_gems'])-x.get('bag_after_completion',0)==x['banked_gems'],'banked_exact_bag_delta',match_id=x['match_id'],seq=x['seq'])
for x in roles:
    rolebank[x['raw_sha256'],x['side']]+=x['banked_gems'];rolegems[x['raw_sha256'],x['side']]+=x['capture_gems']
for x in caps:capturegems[x['raw_sha256'],x['side']]+=x['gems']
check(banked==rolebank,'role_banked_conservation');check(capturegems==rolegems,'role_capture_gems_conservation')
with (d/'team-games.csv').open(newline='',encoding='utf8') as f:
    for x in csv.DictReader(f):
        key=x['raw_sha256'],int(x['side']);check(banked[key]==int(x['banked_score_from_deltas']),'team_score_ledger_conservation',match_id=x['match_id'],side=x['side'])
        if x['api_score']!='':check(banked[key]==int(x['api_score']),'team_score_api_conservation',match_id=x['match_id'],side=x['side'])
linked={(x['raw_sha256'],x['start_seq']):x for x in done if x.get('start_seq') is not None}
matched={(x['raw_sha256'],x['seq']):x for x in starts if x['outcome']=='completed_exact_score'}
check(linked.keys()==matched.keys(),'start_completion_bijection')
for key,x in matched.items():check(x['banked_gems']==linked[key]['banked_gems'],'start_completion_amount')
nativewait={(x['raw_sha256'],x['payout_seq'],x['group']):x for x in tables.get('native-waiting-episodes',[])if x['completed']}
supplemented={x['raw_sha256'] for x in audit['checks']if x.get('complete_personal_gem_ledger_available')}
for x in caps:
    if x['raw_sha256'] in supplemented:
        check((x['raw_sha256'],x['seq'],x['group'])in nativewait,'complete_native_wait_payout_coverage',match_id=x['match_id'],seq=x['seq'])
if a.gem_dir:
    ledgers={}
    for x in audit['checks']:
        if not x.get('complete_personal_gem_ledger_available'):continue
        raw=x['raw_sha256'];path=a.gem_dir/(raw+'.gems.json.gz');data=path.read_bytes();g=json.loads(gzip.decompress(data));ledgers[raw]=g
        check(hashlib.sha256(data).hexdigest()==x['personal_gem_ledger_sha256'],'native_gem_ledger_hash',match_id=x['match_id'])
        check(not g['errors'] and g['raw_sha256']==raw and g['trace_sha256']==x['trace_sha256'],'native_gem_ledger_binding',match_id=x['match_id'])
        for c in g['final']:
            start=next(z for z in g['initial']if z['id']==c['id'])['gems'];delta=sum(z['delta']for z in g['events']if z['id']==c['id'])
            check(start+delta==c['gems'],'complete_personal_gem_conservation',match_id=x['match_id'],body=c['id'])
    bycomplete={(x['raw_sha256'],x.get('body'),x['round']):x for x in done}
    for x in collections:
        if x['clean_receipt_to_bank_status']!='clean_exact_personal_gem_ledger':continue
        g=ledgers[x['raw_sha256']];bank=bycomplete[x['raw_sha256'],x['body'],x['next_tribute_completion_round']]
        changes=[z for z in g['events']if z['id']==x['body']and x['seq']<=z['seq']<=bank['seq']]
        check(len(changes)==2 and changes[0]['before']==0 and changes[0]['delta']==x['receipt_gems'] and changes[1]['delta']==-x['receipt_gems'] and changes[1]['scoreDelta'][x['side']]==x['receipt_gems'],'clean_exact_full_native_ledger',match_id=x['match_id'],seq=x['seq'])
out=dict(errors=errors,checks=dict(checks),source_summary_sha256=hashlib.sha256((d/'summary.json').read_bytes()).hexdigest())
(d/'validation.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(errors=len(errors),checks=dict(checks))))
if errors:raise SystemExit(1)
