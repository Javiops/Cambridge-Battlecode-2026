"""Concise, denominator-explicit report from already validated cycle tables."""
from pathlib import Path
from collections import Counter,defaultdict
import argparse,csv,gzip,json
p=argparse.ArgumentParser();p.add_argument('directory',type=Path);a=p.parse_args();d=a.directory
s=json.loads((d/'summary.json').read_bytes());v=json.loads((d/'validation.json').read_bytes());ag=json.loads((d/'aggregates.json').read_bytes())
if v['errors']:raise SystemExit('Validation errors prevent report')
def select(kind,group='cohort',cohort='top4_h2h',patch='0.0.2'):
    return [x for x in ag.get(kind,{}).get(group,[]) if x['patch']==patch and x['cohort']==cohort]
def single(kind,group='cohort',**kw):
    rs=select(kind,group,**kw);return rs[0] if rs else None
def med(row,name):return row['metrics'][name]['median'] if row else None
def num(x):return 'unavailable' if x is None else str(int(x)) if isinstance(x,(int,float)) and x==int(x) else f'{x:.2f}' if isinstance(x,float) else str(x)
def pct(n,den):return f'{n}/{den} ({n/den:.1%})' if den else '0/0'
cp=single('capture-payouts');ts=single('tribute-starts');tc=single('tribute-completions');rr=single('recall-followups','recall_to_spawn_boundary_cohort');cf=single('collection-followups');cl=single('collection-followups','clean_exact_receipt_to_bank_cohort');nw=single('native-waiting-episodes')
notes=[]
if cp:
    shared=cp['events']-cp['recipient_count_counts'].get('1',0)
    notes.append(f"Primary current-top4 H2H: {cp['streams']} distinct raw trajectories, {cp['events']} exact capture payouts and {int(cp['metrics']['recipient_count']['sum'])} recipient observations. {pct(shared,cp['events'])} payouts had multiple recipients. {pct(cp['events_with_recipient_only_body'],cp['events'])} payouts included a recipient with no source-mapped camp damage since the previous payout; this is a role observation, not evidence of deliberate delegation.")
    exact=cp['metrics']['wait_to_payout_rounds_exact'];sampled=cp['metrics']['observed_wait_to_payout_rounds']
    notes.append(f"Exact reward-available→payout lag is available for {exact['n']}/{cp['events']} payouts: median {num(exact['median'])}, IQR {num(exact['p25'])}–{num(exact['p75'])}, p90 {num(exact['p90'])} world rounds. Fixed-stage sampled lag is separately retained (n={sampled['n']}); the two definitions must not be pooled.")
if nw:notes.append(f"The complete native group ledger contains {nw['events']} waiting episodes, of which {nw['completed_counts'].get('True',0)} end in payout and {nw['completed_counts'].get('False',0)} remain right-censored. It records {int(nw['metrics']['exact_control_to_neutral_transitions']['sum'])} control-to-neutral transitions and {int(nw['metrics']['exact_side_switches']['sum'])} direct side switches. These transitions do not establish intentional abandonment or its cause.")
if ts and tc:notes.append(f"There are {ts['events']} tribute start commands and {tc['events']} exact score/bag-drop completions, banking {int(tc['metrics']['banked_gems']['sum'])} gems in total. Start bag median {num(med(ts,'bag_at_start'))}; actual completed bank median {num(med(tc,'banked_gems'))}. Start outcomes: {ts.get('outcome_counts',{})}. Uncompleted commands are not automatically failures.")
if cf:notes.append(f"Collection followups cover {cf['events']} recipient observations, stopping at the next personal death or trace end. A next exact bank exists for {cf['metrics']['rounds_to_next_tribute_completion']['n']}; its latency median is {num(med(cf,'rounds_to_next_tribute_completion'))} rounds. This is an ordered event relation, not attribution of those banked gems to the receipt.")
if cl:notes.append(f"The complete personal-gem ledger identifies {cl['events']} clean receipt→bank sequences: pre-receipt bag zero, no intervening personal gem delta or death, and an exact equal terminal bank with a linked tribute start. Their bank latency median is {num(med(cl,'rounds_to_next_tribute_completion'))} rounds (IQR {num(cl['metrics']['rounds_to_next_tribute_completion']['p25'])}–{num(cl['metrics']['rounds_to_next_tribute_completion']['p75'])}). This selected subset is not a general conversion-rate estimate.")
if rr:notes.append(f"Strict sampled recall→alive-spawn boundaries number {rr['events']} (distinct streams {rr['streams']}). Of these, {rr['metrics']['spawn_to_first_productive_event_rounds']['n']} have a subsequent trace-confirmed field productive event before death, next recall or trace end: median spawn→event {num(med(rr,'spawn_to_first_productive_event_rounds'))} rounds. Camp HP loss and enemy HP loss followups are separately reported (n={rr['metrics']['spawn_to_first_camp_hp_loss_rounds']['n']} and n={rr['metrics']['spawn_to_first_enemy_hp_loss_rounds']['n']}). Delayed spell damage is outside this narrow command-confirmed return measure.")

teams={}
for kind,group in [('capture-payouts','team'),('tribute-starts','team'),('tribute-completions','team'),('collection-followups','team'),('recall-followups','recall_to_spawn_boundary_team')]:
    for row in select(kind,group):teams.setdefault(row['teamId'],dict(team=row['team'],rank=row['rank']))[kind]=row
table=['| Current rank / team | H2H streams | Payouts / shared | Exact wait median / p90 | Tribute bag median | Banked completions / gems | Strict recall boundaries / return median |',
       '|---|---:|---:|---:|---:|---:|---:|']
for x in sorted(teams.values(),key=lambda x:x['rank']):
    c=x.get('capture-payouts');t=x.get('tribute-starts');b=x.get('tribute-completions');r=x.get('recall-followups');shared=c['events']-c['recipient_count_counts'].get('1',0) if c else 0
    table.append(f"| {x['rank']}. {x['team']} | {c['streams'] if c else 0} | {c['events'] if c else 0} / {shared} | {num(med(c,'wait_to_payout_rounds_exact'))} / {num(c['metrics']['wait_to_payout_rounds_exact']['p90']) if c else 'unavailable'} | {num(med(t,'bag_at_start'))} | {b['events'] if b else 0} / {num(b['metrics']['banked_gems']['sum']) if b else 0} | {r['events'] if r else 0} / {num(med(r,'spawn_to_first_productive_event_rounds'))} |")

text='# Economy-cycle quantitative findings\n\n'+'\n\n'.join(notes)+'\n\n'+'\n'.join(table)+'\n\n'
text+='Each team table row is an observed event distribution within its own H2H appearances. Opponent, side, map, duration, roster size and policy version differ; these are not matched or causal performance estimates. Current rank belongs to the timestamped supplied ladder and is not rank at play.\n\n'
text+=f"Corpus: {s['counts']}; exact raw SHA deduplication; source/audit errors {s['errors']}; independent ledger validation errors {len(v['errors'])}. Event tables keep patch 0.0.1 separate as historical sensitivity and preserve missing native/API counters.\n\n"
text+=f"Manifest SHA256 `{s['manifest_sha256']}`. Ladder SHA256 `{s['ladder_sha256']}` fetched {s.get('ladder_fetched_at_utc')}. Analyzer SHA256 `{s['analyzer_sha256']}`. Definitions: `../definitions.md`; complete source checks: `source-audit.json`; conservation checks: `validation.json`; distributions and denominators: `aggregates.json`; auditable event ledgers: `*.jsonl.gz`.\n"
def ledger(name):
    with gzip.open(d/(name+'.jsonl.gz'),'rt',encoding='utf8')as f:
        for line in f:yield json.loads(line)
def quant(v,t):
    v=sorted(x for x in v if x is not None)
    if not v:return None
    k=(len(v)-1)*t;i=int(k);return v[i]+(v[min(i+1,len(v)-1)]-v[i])*(k-i)
panels=defaultdict(lambda:defaultdict(list))
for kind in ['capture-payouts','tribute-starts','tribute-completions','recall-followups']:
    for row in ledger(kind):
        if row['patch']=='0.0.2' and row.get('current_top10'):panels[row['teamId']][kind].append(row)
full10=[]
game_panels=defaultdict(list)
for row in json.loads((d/'team-games.json').read_bytes()):
    if row['patch']=='0.0.2' and row['current_top10']:game_panels[row['teamId']].append(row)
for tid,kinds in panels.items():
    c=kinds['capture-payouts'];t=kinds['tribute-starts'];b=kinds['tribute-completions'];r=[x for x in kinds['recall-followups']if x['recall_channel_to_alive_spawn_boundary_observed']and not x['inside_own_spawn_at_start']];one=next(iter(next(iter(kinds.values()))))
    full10.append(dict(teamId=tid,team=one['team'],rank=one['rank'],patch2_streams=len({x['raw_sha256']for x in game_panels[tid]}),capture_payouts=len(c),shared_payouts=sum(x['recipient_count']>1 for x in c),capture_recipient_observations=sum(x['recipient_count']for x in c),capture_gems=sum(x['gems']for x in c),tribute_start_commands=len(t),tribute_start_bag_median=quant([x['bag_at_start']for x in t],.5),tribute_start_bag_p25=quant([x['bag_at_start']for x in t],.25),tribute_start_bag_p75=quant([x['bag_at_start']for x in t],.75),tribute_completions=len(b),banked_gems=sum(x['banked_gems']for x in b),strict_recall_spawn_boundaries=len(r),productive_return_observed=sum(x['spawn_to_first_productive_event_rounds']is not None for x in r),spawn_to_productive_return_median=quant([x['spawn_to_first_productive_event_rounds']for x in r],.5)))
full10.sort(key=lambda x:x['rank'])
(d/'top10-primary-team-summary.json').write_text(json.dumps(full10,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
with(d/'top10-primary-team-summary.csv').open('w',newline='',encoding='utf8')as f:
    w=csv.DictWriter(f,fieldnames=list(full10[0])if full10 else[]);w.writeheader();w.writerows(full10)
audit=json.loads((d/'source-audit.json').read_bytes());manifest=json.loads(Path(s['manifest_path']).read_bytes())
denom=dict(source_trajectories=len(audit['checks']),source_api_scopes=dict(Counter(x['apiFinalChecks'].get('scope','unavailable')for x in audit['checks'])),canonical_full_api_statistics_streams=sum(bool(x['game'].get('statistics'))for x in manifest['requests']),native_personal_gem_group_ledger_streams=sum(x.get('complete_personal_gem_ledger_available',False)for x in audit['checks']),event_counts=s['event_rows'],primary_top4_capture_summary=cp,primary_top4_tribute_start_outcomes=ts.get('outcome_counts')if ts else None,primary_top4_collection_outcomes=cf,primary_top4_strict_recall_return=rr,notes=['Source API scopes refer to original trace API validation. Canonical round/score and any available canonical champion counters are rechecked separately. Legacy trace scope missing is retained as not_recorded_in_legacy_trace.','A next bank can be shared by multiple preceding receipts; next_banked_amount is never summed as converted camp gems.','Return metric n is its available observed followup denominator; missing is not zero.','Current rank belongs to the frozen current ladder; primary patch2 and historical patch1 are never pooled.'])
(d/'denominator-audit.json').write_text(json.dumps(denom,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(d/'findings.md').write_text(text,encoding='utf8')
(d/'findings.json').write_text(json.dumps(dict(primary_notes=notes,primary_teams=list(teams.values()),source_summary=s),ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(text[:7000])
