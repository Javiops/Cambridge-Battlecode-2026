from pathlib import Path
import json,collections
R=Path(__file__).resolve().parent;P=R/'publication';Q=R/'quant/current'
lad=json.loads((R/'acquisition/ladder-snapshot.json').read_bytes())
episodes=json.loads((R/'episodes/audited-episodes.json').read_bytes())
findings=(Q/'findings.md').read_text(encoding='utf8')
geo=(Q/'geometry-findings.md').read_text(encoding='utf8')
summary=json.loads((Q/'summary.json').read_bytes())
ag=json.loads((Q/'aggregates.json').read_bytes())
def rows(kind,group,cohort='top10_internal',patch='0.0.2'):
    return [x for x in ag[kind][group] if x['cohort']==cohort and x['patch']==patch]
def median(x,n):return x['metrics'][n]['median']
def fmt(n):return '—' if n is None else str(int(n)) if n==int(n) else f'{n:.1f}'

intro='''# Farming, capture, delivery and return — evidence and policy

**16 October 2026. Documentation and replay research; all new decision policies are Planned.** The outcome to optimize is a completed productive cycle: useful clear → preserved capture → actual personal receipt → safe conversion → useful next field action. A camp kill, recall command or arrival at home is only an intermediate event.

Start with the [single decision contract](cycle-decision-contract.md), then [08 farming/capture](08-farming-and-capture.md), [09 delivery/objectives](09-gems-and-objectives.md), [10 recall/return](10-recall-and-recovery.md), the [source comparison](cycle-source-audit.md), and [controlled timing checks](cycle-timing-current-002.md). Information, team commitments, legal combat and purchases retain the authorities already defined in 04/06/07/11.

## What changes in the intended tactic

| Decision | Evidence-backed problem/opportunity | Planned rule |
|---|---|---|
| Start or continue a camp | A damaged camp and nearby bodies do not establish a safe next response or ready help | Check actual legal contributions, monster/enemy reply, escape/control reserve and a viable collector before expenditure; recheck after each action |
| Kill versus collect | Clearers and recipients can differ; excess bodies dilute personal income or lose useful time | Keep an actual eligible holder through payout, release redundant bodies toward useful work, and make local handoff acyclic |
| Capture plus recall | Successful overlap exists, but Home changes departure and an enemy can reset another capture tile | Use verified phase/duration and supported continuity guards; actual replacement or payout-first when those guards are unavailable |
| Bank versus another camp | Another reward can delay or prevent conversion; current bag is not new income | Compare bank-now with one additional feasible reward followed by bank; keep the current bag exactly once and stop indefinite chaining |
| Recall and shop | Full HP recall can reposition productively; a long return can also consume the apparent benefit | Require a named survival/purchase/next-work benefit and include actual channel, heal, shop and return route cost |
| Use all tactics together | Current independent early branches can consume actions before the delivery/farm decision | One action-budget owner selects a mission, executes one compatible legal action, refreshes and continues or releases |
| Unseen tournament maps | A map label does not identify safe routes, capture continuity or delivery expense | Use geometry/resource/arrival features; keep unknowns explicit and test on untouched generated maps |

These rules are our proposed synthesis. Public replays reveal outcomes and actions, not private policy code, personal observations or counterfactual optimal decisions. Their association with top teams does not prove that copying a threshold causes wins.

## Corpus, identities and limits

The public [ladder](https://2026a.battlecode.co.uk/game/ladder) was fetched at **2026-10-16 12:39:47 UTC**; histories use a fixed **12:41:26.627 UTC** cutoff. “Top four” means the identities at that snapshot: **Sneaky Bush Campers, Intercontinental Fish, Univardisty of Shingtonwash and procless**. It is not a claim about their rank when an older game was played. All ten current identities, including new number ten Full Damage, were refreshed.

Complete histories with hashed prior-cache overlap identified **4,319 finished internal top-ten series**, including 310 between the current top four. Selection was made without reading outcomes: all top-four head-to-head game IDs plus the latest two game IDs per other unordered-pair/map/match-kind stratum. **3,580 selected source IDs** produced **2,588 distinct raw replay streams and unambiguous ordered external team pairs**, across 17 map labels. Repeated replay IDs with identical bytes are aliases, not extra independent games. No raw hash crossed conflicting external identities in this selection.

Replay headers and matching native engines separate **952 streams on patch 0.0.2** from **1,636 on 0.0.1**. There are **951 unique top-four H2H streams overall: 150 current-patch primary and 801 historical**. Never pool the patches to estimate a current timing or strategy. Existing traces were reused only when raw SHA and ordered external identities matched; all 530 missing traces were decoded successfully. Bundle CRC/raw/source binding checks report no acquisition errors.

The current-patch primary analysis additionally scans every native frame: **13,587,626 frames**, 12,331 personal-gem changes and 28,621 group-pair changes across the 150 H2H streams. This catches capture control lost during actor actions that phase-7-only sampling misses. The complete gem ledger supports a strictly defined clean receipt-to-bank subset rather than assuming fungible banked gems came from a particular camp.

Native reconstruction/resource conservation are checked per stream; API rounds/scores and champion counters are compared where available. The denominator audit records 2,188 public-summary source traces, 291 full-statistics and 109 legacy traces with the old API scope unrecorded; the refreshed canonical API has full statistics for 378 streams. Exact available-API-score conservation applies to 2,660 of 5,176 team-game rows, while native score-ledger conservation covers all 5,176. Missing public counters remain unavailable; final-summary agreement does not establish an unavailable damage/stat check. Personal visibility, exact guest fuel, private enemy actions/cooldowns and the causal effect of a tactic are outside these replay measures. Maps, sides, matchup, draft/roster size, duration and evolving opponent versions confound comparisons. Bodies and events within a game are correlated. There are no confidence claims based on treating every event as an independent trial.

The code reference is **`bots/study27-economy/src`**, freshly retrieved at main **`ba93427c94c344b0fade0757208c5e0eeeb88c41`**. All six bot files match the earlier immutable source pin; [line-bounded audit links](cycle-source-audit.md) therefore retain that existing pin. This does not confirm identity with screenshot live-v43 or a later upload. No bot source, ladder submission or competitive challenge was changed by this update.

## Current top-four head-to-head measurements

'''
findings=findings.split('\n',1)[1].strip()
# Keep concise auditable results; local relative reproduction pointers are described later.
findings=findings.split('Manifest SHA256')[0].strip()
text=intro+findings+'\n\n'
text+='''The stage-join audit directly links **3,320 distinct exact bank events** with a prior collection receipt, a strict sampled recall→spawn boundary and a later actual field productive event. These banks share **2,810 distinct reset/return events**, so they are bank-level joins, not 3,320 independent complete cycles. Of the banks, 2,371 satisfy the clean single-receipt attribution, and 3,171 have mapped recipient camp HP loss on a linked group. There are 1,871 bank-before-recall and 1,449 recall-before-bank orders. Both orderings therefore occur in observed completed sequences; no universal ordering or optimality follows.

Historical sensitivity remains separate: the 801 patch-0.0.1 H2H streams and 150 primary streams both have sampled wait median 6 and tribute-start bag median 44; observed productive return medians are 19 versus 21 rounds. This is descriptive sensitivity with different opponents/versions/maps/exposure, not an estimated patch effect. Exact all-frame wait timing is available only for the 150 primary streams.

'''
text+='''## Wider current-patch top-ten coverage

The following uses the selected current-top-ten internal sample, not just H2H among ranks 1–4. “Shared” is a payout with more than one actual recipient. A recipient who did no mapped camp damage is a role observation; it does not establish deliberate delegation. Actual cleared/captured/banked outcomes must be kept distinct.

| Snapshot rank / team | Current-patch streams | Payouts / shared | Tribute start bag median | Exact bank completions / gems |
|---|---:|---:|---:|---:|
'''
cs=json.loads((Q/'top10-primary-team-summary.json').read_bytes())
for c in sorted(cs,key=lambda x:x['rank']):
 text+=f"| {c['rank']}. {c['team']} | {c['patch2_streams']} | {c['capture_payouts']} / {c['shared_payouts']} | {fmt(c['tribute_start_bag_median'])} | {c['tribute_completions']} / {c['banked_gems']} |\n"
text+='''
These event counts are exposure and outcome descriptions, not an economy-strength ranking. High bank volume can reflect a long game or a particular roster/map. Choose per-stream/pair/side/geometry comparisons for later policy evaluation, and keep missing followup rather than silently excluding unfinished cycles.

### Champion work and income can differ

| Team / body | Body appearances / distinct streams | Share of that team's source-mapped camp HP loss | Share of that team's captured gems |
|---|---:|---:|---:|
'''
role_rows=json.loads((Q/'champion-role-summary.json').read_bytes())['rows']
for team,champion in [('Intercontinental Fish','Ren'),('Intercontinental Fish','Stellar'),('Univardisty of Shingtonwash','Issac')]:
 x=next(x for x in role_rows if x['team']==team and x['champion']==champion)
 text+=f"| {team} / {champion} | {x['bodyObservations']} / {x['streams']} | {x['campHPShare']:.1%} | {x['captureGemShare']:.1%} |\n"
text+='''
The shares use the team's whole primary-H2H exposure, including drafts where a listed body is absent; they do not normalize a matched composition or imply that work and income should be equal. Cassi and Issac are separate physical bodies. These resource/work differences support considering different local jobs, but do not recover a private assignment algorithm or prove one champion should always collect.

## What the completed cycles show

**Collection is a separate job.** In primary H2H, 8,275/8,640 payouts (95.8%) have a single actual recipient, while 5,085/8,640 (58.9%) include at least one mapped clear contributor who does not receive that payout. This is compatible with clearers leaving collection to another body, but the contribution window can include earlier failed clears, so it does not prove an assigned handoff. Sneaky shares 279/2,053 payouts (13.6%), whereas the other three share only 17–42 each; there is no single copying rule that fits every top team. Useful parallel work is possible: one body holds a finished group, another clears or protects, and different carriers bank separately. More bodies are justified when they change clear feasibility, contest outcome or a concrete purchase breakpoint; “everyone helps and everyone waits” is not automatically best. A lone unsupported collector can instead lose the bag. The specification names a collector before expenditure where evidence supports it, keeps the last real holder, and prices each helper's alternative.

**Overlap is valuable when it actually completes.** Several top-four sequences receive the camp reward immediately before recall relocation, then bank and resume work. This saves overlapping occupied time; it does not make the subsequent walking/shop/re-entry free. The adverse examples show interruption or loss after receipt. A successful command, an active recall and a capture reward are three different facts.

**Delivery precedes the scoreboard.** Bank-now can be correct before healing, or a protected recall can precede delivery; the viable ordering depends on route, HP, threats, channel timing and next useful action. Larger observed bags do not define an optimal threshold. A next tribute may contain multiple receipts or another gem source, so it cannot automatically be attributed back to the immediately preceding camp. Only the explicit clean ledger subset supports exact one-receipt conversion.

**Recovery should end at productive re-entry.** A return trip can enable survival, an installed upgrade or a better route. The first move outside spawn is not proof of return value: we separately measure actual camp HP loss, enemy HP loss and new collection. Long examples make the route cost visible even when the bank succeeds. Declining a fight may be correct; declining it while continuing to spend HP/casts on an unsafe camp can still be wrong.

## Eleven exact current-patch episodes

These deliberately selected examples came from the earlier 92-stream current-patch top-four subset; all their raw hashes are present with unambiguous identities in the refreshed 150-stream primary cohort. They illustrate successful and adverse outcomes, not their population frequency. Map names below locate evidence and never select the new policy. Native sequence/phase, body IDs, roster, group IDs, bags, score changes and source hashes are retained in the evidence archive. **57 recorded capture/submission event checks** agree with the independent trace/native reconstruction.

'''
for i,e in enumerate(episodes['episodes'],1):
 text+=f"### {i}. {e['key']} — {e['map']}\n\n[Public series]({e['series_url']}), game `{e['id']}`, inspected rounds {e['bounds'][0]}–{e['bounds'][1]}.\n\n"
 text+='\n\n'.join(e['observations'])+'\n\n'
text+='''The corners concession is especially easy to overinterpret: the body physically leaving the capture region reset its progress; two nearby-in-time recalls belonged to remote bodies and did not cause that reset. The enemy recipient then died before banking. Do not equate conceded capture with permanent enemy score, or the actor executing a frame with the killer when retaliation/secondary effects also occur.

## Mechanics that the policy must respect

The separate [current-engine timing report](cycle-timing-current-002.md) contains **12 controlled cases / 97 passing assertions**, including real enemy movement, occupied-tile rejection and a real basic attack. This is a mechanics probe, not new bot matches or a comparison of policy strength.

Normal recall uses five owner-end ticks; Home uses three. Capture first establishes its progress, then decrements; in the uncontested fixture normal recall needs one prior hold interval, Home three. A multi-tile region can be contested through its unoccupied second tile while recall continues. The actual public camp-group state stays `reward_available` before setup, during progress and after reset, and has no audited capture owner/countdown query. The host replay timer is not a bot input. Damage can interrupt recall without removing the holder. An actual remaining channel time of zero can still mean pending completion at the next owner start.

The narrow Planned overlap exception uses a sole spawn tile, uninterrupted living presence, verified duration/hold, credible survival and a worthwhile return mission. Ordinary enemy movement into that occupied tile rejects. The Home-plus-single-tile combination is a mechanics-based inference requiring implementation coverage. Broader regions need supported contest/continuity bounds or a real replacement; payout-first is the uncertain-continuity fallback and can cost five/three owner intervals relative to successful overlap. It is explicitly not universally superior.

Tribute starts with duration `max(1, ceil(start_bag/10))`. In controlled cases, 22 newly captured gems join an already active tribute: 31→53 banks at its original four-tick completion, and 5→27 banks after its original one tick. No new duration is added. This is a geometry/timing opportunity, conditional on legal altar approach, holding continuity and the distinct tribute interruption rules. It does not justify starting an unsafe channel near every camp.

## Generalizing across geometry

Do not add one tactic per map. The static feature pass uses the official 0.0.2 engine's managed distance field on walls, holes, altars and the opposing spawn mask, with legal altar approach roots and original capture tiles. Four small distance/connectivity checks pass. Dynamic champions/camps, movement locks, spell readiness, forced displacement, personal visibility and enemy decisions are excluded: these are **static route lower bounds, not full action ETAs or combat reach**.

'''
text+=geo.split('\n',1)[1].strip()+'\n\n'
text+='''| Feature | How it changes the candidate decision |
|---|---|
| Route cost from useful camp/capture tiles to a legal altar ring | Compare direct bank, one more reward then bank, and recall-assisted bank with actual channel ticks |
| Route from spawn to the next viable job | Charge re-entry; a saved recall tick can be small relative to a long return |
| Our and enemy arrival to this objective and its exits | Determine whether a clear/hold window needs help, protection, warning vision or abandonment |
| Capture-region tile count and actual continuous occupancy | One tile supports a narrower continuity proof; several tiles allow contest without removing us |
| Damaging versus harmless resources, reward mix, monolith-only gems | Change squad size, damage reserve, gold investment and where score can actually be produced |
| Chokes, alternative exits, obstacles and warning sight | Change legal action tiles, escape feasibility and whether a carrier can finish tribute |

For example, pilgrimage's 122-tile static opposing approach versus fragment's 22 and packs'25 distinguishes route scale, but does not by itself justify aggression or a bag target. Expanse has ten altars and lanes eighteen versus eight's one; candidate-specific altar access still matters more than total count. Rushbait_v2's opposing-spawn approach lower bound is zero because the spawn rectangles touch: treating that global number as immediate field combat would be misleading. Use objective-specific arrival and actionable reach instead. A square map can contain long disconnected routes; width/aspect alone is insufficient.

Geometry bins are descriptive sensitivity, not fitted policy coefficients. No “if map==…” rule is added. Later implementation must reserve unseen generated maps, keep the same feature definitions, and promote only after matched tests across opponent styles and both sides.

## Comparison with our source and implementation order

The [source audit](cycle-source-audit.md) links every material claim to immutable code and active flags. Existing strengths include walking-distance camp selection, local in-range monster targeting, reset mode2, a present-holder evacuation check, recall path pricing and walking-ring altar routing. These should be retained where compatible.

Material gaps are: claims/headcounts standing in for timely contribution; permissive camp-HP affordability rather than an enemy-aware reserve; the damaged-camp rally bypass; capture nomination before physical arrival; capture timeout/gain proxies; no public-score-driven finish; fixed bank/recall and named-map exceptions; same-turn pre-shop maximum HP; independent pre-sweep/support/kite/front branches before common arbitration; no typed accepted-versus-moved/rejected channel result; and no explicit priced useful return mission. This is a source comparison, not evidence every gap caused a particular loss.

Implement fresh state and action outcome semantics first, then common arbitration, local readiness/secure expenditure, collector continuity, one-reward delivery and priced recovery/re-entry. Preserve 04's personal-vision contract, 06's real commitments, 07's action legality and 11's purchase breakpoints. The first version adds no shared bytes: the existing eight are occupied and claims lack freshness; a richer team role/ETA protocol needs its own encoding/ownership/migration design.

Compare arbitration-only, cycle-only, guarded-overlap/fallback variants and useful combinations. Evaluate actual activations, completed banks, lost bags, capture resets, wasted clear damage/cooldowns, assembly/idle time, productive return, fuel and endgame completion. Use the same pinned engine/source on both sides, several sparring styles and development geometries, then untouched generated maps. The native viewer is unmetered and cannot prove guest-fuel safety. None of these Planned policies is a measured improvement yet.

## Evidence and reproduction

The [evidence archive](resource-cycle-evidence-2026-10-16.zip) and [external checksum manifest](resource-cycle-evidence-manifest-2026-10-16.json) contain cohort/source projections, raw/engine/source hashes, full-population aggregates and audits, primary event ledgers, all 150 thin native gem/group ledgers, eleven exact episode extracts and selected raw replays, geometry fields/fixtures, timing probes and scripts. The archive member manifest verifies each included byte; omitted full-population trace/event caches remain explicitly omitted to keep the publication bounded. Public replay bundles can be reacquired by the IDs/URLs in the source manifests.

The full population is reproducible from the acquisition scripts and public bundle references; exact raw-byte/header/ordered-team verification is required before reuse. Replay engines are the official CLI 2.2.2 embedded viewer binaries pinned by SHA, not assumed interchangeable patches. The current engine is `e123b59d9dea198762ab7a04db9b3cb6d06dfa991088e41c24750fc4cb88b947`; historical0.0.1 is `ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc`. The research stores engine hashes rather than redistributing the binaries. See archive `REPRODUCTION.md` for environment variables, stages and metric definitions.

The archive contains no authentication material, private opponent source or new ladder challenges. [Official rules](https://2026a.battlecode.co.uk/game/docs) and [Bot API](https://2026a.battlecode.co.uk/game/api) govern legality; controlled observations and the cached-SDK audit make their scope explicit. This update changes the specification and evidence only.
'''
(P/'resource-cycle-research-2026-10-16.md').write_text(text,encoding='utf8')
print(json.dumps({'appendix_bytes':len(text.encode()),'episodes':len(episodes['episodes'])}))
