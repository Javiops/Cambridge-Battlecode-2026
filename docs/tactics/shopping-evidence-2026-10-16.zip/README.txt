# Shopping research evidence — 16 October 2026

RESEARCH ONLY. This is not a Battlecode bot submission.

Same frozen cohort as the ward study: 3,766 API game IDs, 2,119 distinct raw
replay streams, 21,312 champion-body appearances. replay-index.csv retains
every selected ID, alias binding, raw/bundle hash and public bundle URL.
The prior cohort audit already verified all source bundles/CRC/attribution.

Native observations confirm 155,467 item-buy transactions (357,296 charged
shards), 11,544 consumable buys, 63,744 automatic emblem completions, 5,905
consumable uses and 22 full-refund Tavi sales. Automatic emblems are not extra
charged purchases. Gross spend, refunds, net spend and personal final cash
remain separate. Twenty-two Tavi Health-shard buy/sell pairs actually heal
current HP at spawn: zero net cash/inventory is not proof of useless churn.

Included: complete descriptive summary and transaction/body/team/context/
checkpoint CSVs; precise before/after illustrative cases; source identities,
mechanics metadata/probes (51 cases, 35 checks); independent final API and
arithmetic audits, methods/summary/publication reviews, source-code audit,
analysis/plot/probe scripts, SVG/PNG figures and final documentation sources.
The exact scope of each audit is stated in its file. The independent arithmetic
audit does not independently decode every replay a second time.

Excluded: the approximately 521 MB complete per-match native pre/post state tree,
all original raw replays/bundles and history/group API payloads, credentials,
private opponent code, repository metadata, runtime installations and vendor
WASM/SDK binaries. Per-match analysis hashes remain in the audits. The index
permits retrieving the public source bundles. This is not a complete raw dump.

Reproduction requires the official engine WASM with SHA-256
ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc
and recorded SDK/CLI2.1.6 metadata. Scripts preserve original workspace-relative
paths: configure loaders/runtimes/source manifests for a new checkout. The
included loader is source provenance, not a one-command portable installation.
The original scan omitted sale enum25; five residual-ledger trajectories were
replayed with it. sale-repair-ledger.json preserves that correction. The final
scanner includes25; all final personal ledgers and API counters balance.

Ranks are a frozen snapshot, private upload/version fields are null, repeated
raw hashes are aliases, and distinct trajectories are not necessarily different
private bot versions or independent experiments. Owner-start opportunity samples
exclude dead shopping and intra-turn access. Conditional timings are censored
by game end; grouped medians are not causal delay or optimal deadlines.
Confirmed consumable use is not proof of strategically useful objective effect.

The included own source audit is pinned to e72cec8. Proposed policy is Planned;
no bot strategy or competitive test matches were performed in this task.
The prior ward memory correction is documented: byte7 actively carries danger
alerts when help is disabled; do not overwrite it as if it were unused.

manifest.json lists every payload's byte length and SHA-256. The external ZIP
manifest is intentionally excluded to prevent recursive hashes.
