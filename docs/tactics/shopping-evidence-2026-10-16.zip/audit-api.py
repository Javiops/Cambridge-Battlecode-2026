"""Independent final-API accounting baseline for the already frozen ward cohort."""
from pathlib import Path
from collections import defaultdict, Counter
import json,hashlib,csv
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'ward-research/matches/manifest-current-unique.json'
data=json.loads(SRC.read_bytes()); rows=data['requests']
names=['Ryth','Vesper Vale','Vendetta','Cassi','Issac','Stellar','Prism','Marcella','Willow','Ren','Varg','Tavi','Heart of Ruin']
families=['Monster','Power','Durability','Treasure','Jungle','Home','Bruiser']
stats=['Strength','Focus','Health']
teams={}; bodies=[]; differences=[]
for r in rows:
 s=r['game']['statistics']
 for side in [0,1]:
  t=r['teams']['a' if side==0 else 'b']; tid=t['teamId']
  z=teams.setdefault(tid,{'rank':t['rank'],'team':t['name'],'streams':0,'body_appearances':0,'earned_gold':0,'spent_gold':0,'leftover_gold':0,'no_spending_bodies':0,'bought_shards':0,'automatic_emblem_entries':0,'bought_consumables':0})
  z['streams']+=1
  for c in s['champions']:
   if c['team']!=side:continue
   z['body_appearances']+=1
   for dst,src in [('earned_gold','earnedGold'),('spent_gold','spentGold'),('leftover_gold','gold')]:z[dst]+=c[src]
   z['no_spending_bodies']+=int(c['spentGold']==0)
   z['bought_shards']+=sum(c['itemsBought'][::2]);z['automatic_emblem_entries']+=sum(c['itemsBought'][1::2]);z['bought_consumables']+=sum(c['consumablesBought'])
   record={'id':r['id'],'raw_sha256':r['raw_sha256'],'map':r['map'],'team':t['name'],'rank':t['rank'],'champion_id':c['champion'],'champion':names[c['type']],'earned_gold':c['earnedGold'],'spent_gold':c['spentGold'],'leftover_gold':c['gold'],'shards_bought':sum(c['itemsBought'][::2]),'emblem_entries':sum(c['itemsBought'][1::2]),'consumables_bought':sum(c['consumablesBought'])}
   record['earned_minus_spent_minus_remaining']=c['earnedGold']-c['spentGold']-c['gold']
   record['listed_buy_cost_minus_spent']=30*record['shards_bought']+10*record['consumables_bought']-c['spentGold']
   if record['earned_minus_spent_minus_remaining'] or record['listed_buy_cost_minus_spent']:differences.append(record)
   bodies.append(record)
result={'scope':'Frozen unique-replay final public API statistics only; independent of native shopping scanner. itemsBought includes auto-combined emblems and is not all charged purchases.', 'source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'streams':len(rows),'body_appearances':len(bodies),'teams':sorted(teams.values(),key=lambda x:x['rank']),'accounting_differences':differences,'difference_count':len(differences)}
(ROOT/'api-accounting-baseline.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
with (ROOT/'api-accounting-bodies.csv').open('w',encoding='utf8',newline='')as f:
 w=csv.DictWriter(f,fieldnames=list(bodies[0]));w.writeheader();w.writerows(bodies)
print(json.dumps({'streams':len(rows),'bodies':len(bodies),'differences':len(differences),'teams':result['teams'],'first_differences':differences[:3]},ensure_ascii=False))
