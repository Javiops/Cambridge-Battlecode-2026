"""Independent arithmetic/source audit; does not re-decode every native replay."""
from pathlib import Path
from collections import Counter,defaultdict
import json,hashlib,math,csv
R=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
source=R.parent/'ward-research/matches/manifest-current-unique.json'
manifest=json.loads(source.read_bytes()); requests={r['id']:r for r in manifest['requests']}
metadata=json.loads((R/'mechanics-metadata.json').read_bytes()); catalog=metadata['items']
design={c['id']:c for c in metadata['champions']}
errors=[];counts=Counter();hashes=[];teams=defaultdict(Counter);sales=[];unclassified=Counter()
def check(ok,kind,detail):
 if not ok: errors.append({'check':kind,**detail})
def eq(a,b):return math.isclose(a,b,rel_tol=1e-6,abs_tol=1e-4)
for p in sorted((R/'matches/current').glob('*.shopping.json')):
 raw=p.read_bytes();g=json.loads(raw);r=requests.get(g['id']);d={'id':g['id']}
 check(r is not None,'cohort_member',d)
 if r is None:continue
 check(g['sourceSha256']==r['raw_sha256'],'source_hash',d)
 check(g['map']==r['map'] and g['teams']==r['teams'],'map_and_teams',d)
 check(g['rounds']==r['game']['statistics']['round'],'api_rounds',d)
 check(not g['apiFinalErrors'] and not g['ledgerErrors'],'native_final_and_ledger',d)
 api={c['champion']:c for c in r['game']['statistics']['champions']}
 check(len(g['championLedgers'])==len(api),'full_roster',d)
 groups=defaultdict(list)
 for e in g['events']:
  x={'id':g['id'],'input':e['input'],'category':e['category']};counts['recorded_events']+=1
  if not e['confirmed']:
   unclassified[(e['kind'],e['category'],e['cost'])]+=1
   check(e['cost']==0 and e['inventoryValueDelta']==0,'unconfirmed_not_monetary',x)
   continue
  groups[e['actor']].append(e);counts[e['category']]+=1
  b,a=e['before'],e['after'];di=[aa-bb for aa,bb in zip(a['items'],b['items'])];dc=[aa-bb for aa,bb in zip(a['consumables'],b['consumables'])]
  check(di==e['itemsDelta'] and dc==e['consumablesDelta'],'reported_deltas',x)
  check(b['gold']-a['gold']==e['cost'],'gold_delta',x)
  check(not e['otherBodyResourceChanges'],'private_transaction',x)
  if e['category']=='item_purchase':
   j,q=e['item'],e['quantity'];expected=b['items'].copy();expected[j]+=q;expected[j+1]+=expected[j]//5;expected[j]%=5
   check(j%2==0 and q>0 and catalog[j]['purchasable'],'charged_shards_only',x)
   check(a['items']==expected and a['consumables']==b['consumables'],'exact_autocombination',x)
   check(e['cost']==30*q and e['inventoryValueDelta']==30*q,'shard_price_and_face_value',x)
   counts['charged_shard_units']+=q
   counts['automatic_emblems']+=sum(max(0,n)for j,n in enumerate(di)if j%2)
  elif e['category']=='consumable_purchase':
   j,q=e['item'],e['quantity'];expected=b['consumables'].copy();expected[j]+=q
   check(j in [0,2] and q>0 and expected[j]<=1,'usable_consumable_and_limit',x)
   check(a['consumables']==expected and a['items']==b['items'] and e['cost']==10*q,'consumable_exact_purchase',x)
   counts['charged_consumable_units']+=q
  elif e['category']=='item_sale':
   face=sum(n*catalog[j]['cost']for j,n in enumerate(di))
   check(a['type']==11 and e['cost']==face and all(n<=0 for n in di) and sum(n<0 for n in di)==1,'tavi_full_refund',x)
   check(a['consumables']==b['consumables'],'sale_consumables_unchanged',x)
   counts['sale_receipts']-=e['cost'];sales.append({**x,'round':e['round'],'receipts':-e['cost'],'item':e['item'],'quantity':e['quantity']})
  elif e['category']=='consumable_use':
   check(e['cost']==0 and a['items']==b['items'] and sum(n<0 for n in dc)==1 and all(n<=0 for n in dc),'exact_consumable_use',x)
  for state in [b,a]:
   calculated={s:sum(state['items'][j]*catalog[j][s+'Points']for j in range(42))for s in ['health','strength','focus']}
   check(state['points']==calculated,'item_points',x)
   for stat in ['strength','focus']:
    check(eq(state[stat]['items'],calculated[stat]*design[state['type']][stat+'Growth']),'growth_contribution',x)
 for c in g['championLedgers']:
  a=api[c['id']];es=groups[c['id']];t=r['teams']['a' if c['team']==0 else 'b'];tot=teams[t['teamId']]
  tot['bodies']+=1;tot['earned_gold']+=a['earnedGold'];tot['gross_spent_gold']+=a['spentGold'];tot['leftover_gold']+=a['gold'];tot['sale_receipts']+=c['saleReceipts']
  check(c['final']['gold']==a['gold'] and c['final']['items']==a['items'] and c['final']['consumables']==a['consumables'],'independent_api_final',{'id':g['id'],'actor':c['id']})
  paid=sum(e['cost']for e in es if e['category'].endswith('_purchase'));refund=-sum(e['cost']for e in es if e['category']=='item_sale')
  check(paid==a['spentGold'] and c['initialGold']+a['earnedGold']-c['initialEarnedGold']+refund-paid==a['gold'],'independent_gold_accounting',{'id':g['id'],'actor':c['id']})
  for j in range(42):
   actual=sum(e['quantity']for e in es if e['category']=='item_purchase' and e['item']==j) if j%2==0 else sum(max(0,e['itemsDelta'][j])for e in es if e['category']=='item_purchase')
   check(actual==a['itemsBought'][j],'all_api_item_counters_including_auto',{'id':g['id'],'actor':c['id'],'item':j})
 hashes.append({'id':g['id'],'bytes':len(raw),'sha256':sha(raw),'raw_sha256':g['sourceSha256'],'events':len(g['events'])})
counts['streams']=len(hashes);counts['bodies']=sum(t['bodies']for t in teams.values())
check(set(requests)=={x['id']for x in hashes},'complete_cohort',{})
baseline=json.loads((R/'api-accounting-baseline.json').read_bytes())
for t in baseline['teams']:
 n=next(v for k,v in teams.items()if requests[next(iter(requests))] is not None and any(k==tt['teamId'] and tt['name']==t['team']for rr in manifest['requests'] for tt in rr['teams'].values()))
 check(n['earned_gold']==t['earned_gold'] and n['gross_spent_gold']==t['spent_gold'] and n['leftover_gold']==t['leftover_gold'],'root_api_totals',{'team':t['team']})
result={'pass':not errors,'scope':'Independent complete-file arithmetic, catalogue/stat growth, reconstructed purchase/autocombination and final API accounting audit. Relies on the native scanner for state decoding; does not independently replay all source bytes. Frozen source bindings reuse the prior full cohort audit.','source_manifest_sha256':sha(source.read_bytes()),'counts':dict(counts),'teams':{k:dict(v)for k,v in teams.items()},'unconfirmed_nonmonetary_events':[{'kind':k[0],'category':k[1],'cost':k[2],'count':v}for k,v in unclassified.items()],'sales':sales,'error_count':len(errors),'errors':errors[:100],'per_file':hashes}
(R/'transaction-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:result[k]for k in ['pass','counts','error_count','errors','unconfirmed_nonmonetary_events','sales']},ensure_ascii=False))
