"""Assemble the research appendix from reviewed frozen observations and mechanics."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent;P=R/'publication'
findings=(R/'matches/current-findings.md').read_text(encoding='utf8')
findings=findings.replace('# Shopping and resource investment: frozen elite replay cohort\n','',1)
findings=findings.replace('selected games span October 13–15, ending 22:50:49 UTC.','selected game creation times span 13 October 16:10 to 15 October 22:50:49 UTC.')
mechanics=(R/'mechanics.md').read_text(encoding='utf8')
def section(start,end):return mechanics.split(start,1)[1].split(end,1)[0]
catalog=section('## Catalogue and the completion threshold\n','## What a growth point actually buys\n')
growth=section('## What a growth point actually buys\n','## Stacking, damage and diminishing returns\n')
stack=section('## Stacking, damage and diminishing returns\n','## Treasure: income timing and the correct opportunity cost\n')
treasure=section('## Treasure: income timing and the correct opportunity cost\n','## When shopping is legal and what it costs in turns\n')
prefix='''# Shopping strategy research — 16 October 2026

[Operational tactics: Chapter 11](11-shopping-and-investment.md)

Our proposed starting point is **invest for the next useful mission breakpoint, and price the trip separately from the purchase**. Preserve each body's private budget, first-copy passive effects and completion state. A strong team's repeated item order motivates a test; it does not establish a globally optimal build.

This report covers exactly the same frozen elite games as the [ward study](ward-research-2026-10-16.md). It separates confirmed transactions, verified rules, observed associations and our original planned policy. The top four at that snapshot are **Intercontinental Fish, Sneaky Bush Campers, Mite and Univardisty of Shingtonwash**. Short team names below refer to those names; Quantom is ❤️Quantom❤️.

'''
middle='''
## Map and champion contrasts in a visual comparison

![Fish first-emblem families, holding champion fixed across maps](shopping-first-emblem-maps.png)

This figure uses the top-four head-to-head subset. Right labels are first-emblem completers / all body appearances, and bars condition on completion. It deliberately holds the team and champion fixed. That removes one draft confound, but not game duration, income allocation, opponent, role, chronology or unexposed source versions. A small five-completer sample is not given the same evidential weight as a 60-completer sample.

The most useful conclusions are narrower than “build X on map Y.” Fish's Monster-first examples on rows and expanse motivate testing camp-throughput investment on routes where that multiplier changes the clear cycle. Mite's stable Jungle-first opening motivates testing camp-sustain before expensive monster exposure. Univardisty's Tavi Treasure opening motivates testing an economy purchase on a body that can convert future gold into field equipment without another trip. These are proposed mechanisms to test, not inferred private intent.

For unseen maps, derive the shopping horizon from the actual reachable resource route, expected incoming damage, enemy reinforcement time, next tribute opportunity and spawn-to-mission path. A big map can make returns expensive, but dimensions alone do not tell us the actual path or whether Tavi needs a return at all. A harmless-cluster route does not need the same Jungle insurance as a route where the owner tanks repeated monsters. The [adaptive-build table](11-shopping-and-investment.md#7-adaptive-builds) specifies these feature-based decisions.

## Verified rules and investment mathematics

The [official Items & gold article](https://2026a.battlecode.co.uk/game/docs/items), [API](https://2026a.battlecode.co.uk/game/api), SDK/CLI **2.1.6**, and **51 controlled engine cases / 35 passing checks** support this section. Fixtures are mechanics experiments, not competitive bot matches. The exact official executable is WASM SHA-256 `ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc`; matching live high-level text does not prove byte identity with every deployed server executable. Native transaction ledgers separately agree with the public final API statistics.

### Catalogue and completion

'''
suffix='''
## Tavi's same-turn spawn healing

The source-bound [Mite versus Fish series](https://2026a.battlecode.co.uk/game/match-groups/ad1ad53e-84ee-4650-bb99-272590c9258a), lanes game `17a5c872-dd06-4e5d-b6af-13c0dfaec889`, demonstrates an interaction that a final-inventory comparison would miss. At round 139, Tavi starts with **210/750 HP and 160 gold**. Inputs 4292–4307 perform eight one-shard Treasure Health purchases and immediate full-price sales. Each purchase adds 75 current/max HP; selling preserves current HP up to the restored maximum. The sequence ends at **750/750 HP, the same 160 gold, and the same inventory**. The next resource inputs buy a Jungle Focus emblem for 150 and an altar lock for 10.

![Exact observed Tavi health and gold through the eight cycles](shopping-tavi-healing.png)

An independent controlled engine fixture reproduces the sequence, unchanged earned-gold ledger and ordinary action flags, and a successful damaging cast afterward. This confirms available same-turn healing, not that it caused the observed win or that the private bot chose it for a known reason. Spawn already heals at turn end, so its additional value depends on a useful action before then. Zero net gold does not mean zero API/fuel cost; exact fuel cost is unmeasured in the unmetered editor fixture.

Our **planned** use is deliberately bounded: living Tavi on own spawn, missing HP, legal equipment purchase and sale, temporary gold at least 30, and a Health shard whose existing loose count is at most three to avoid accidental fifth-shard combination. At Tavi's current growth of 75, at most `ceil(missing HP / 75)` successful pairs are needed. Check refund and inventory after each pair and stop on full HP, a restriction, failure or fuel limit. Field purchases cannot supply this heal because Health there does not raise current HP, field sales are unavailable, and dead purchases do not resurrect. The first implementation can keep this as a separate optional exception rather than coupling it to every build-policy change.

## Our existing bot

The audited cleaned study27 combat derivative is commit [`e72cec84391cf0623d15c2eb3f2f864e2b0bddea`](https://github.com/Javiops/Cambridge-Battlecode-2026/commit/e72cec84391cf0623d15c2eb3f2f864e2b0bddea). The archive contains the source audit, active parameter/override proof and source hashes. This is an exact reference revision, not an assertion about whichever upload the team currently has active.

| Body | Actual ordered completed-emblem targets after enabled overrides |
|---|---|
| Ryth, Varg, Vendetta | Power Strength 1 → Durability Strength 1 → Jungle Strength 1 → Bruiser Health 1 → Power Strength 99 |
| Issac | Power Strength 2 → Jungle Strength 1 → Power Strength 99 |
| Tavi | Power Focus 1 → Bruiser Focus 1 → Power Focus 99 |
| Cassi, Stellar, Ren, Prism | Power Focus 1 → Durability Health 1 → Power Focus 99 |
| Vesper Vale, Marcella, Willow | Durability Strength 1 → Jungle Strength 1 → Bruiser Health 1 → Power Strength 99 |

Targets are cumulative counts of each exact completed emblem, not additional quantities after each line. Partial shards contribute immediately. The enabled plans do not adapt to current mission or map features. Older branches and comments can be overridden by later enabled branches; merely reading the first plan definition misidentifies the actual policy.

Shopping loops are bounded at 12 iterations, but the body generally spends down below 30 rather than keeping a purpose-specific gold reserve. Healthy elective trips use fixed gates such as 180 gold, 40-round spacing and distance/health rules instead of evaluating the actual affordable bundle, route absence or deciding bank. A nominal gold-plus-low-HP condition is dominated by a broader health recall threshold. The enabled lock helper buys a missing lock at own spawn with 10–29 gold for a living, non-channeling eligible body, before checking for a useful nearby altar. It does not make a shopping detour. There is no Tavi selling/heal routine in this audited source.

These are diagnoses and integration opportunities, not proof that replacing every current threshold improves the bot. The old online notes about shop detours concern older code/cohorts; they are historical motivation, not new controlled measurements on this revision.

### Shared-memory correction

The shopping source audit caught one omission in the earlier ward source note: **byte 7 already carries active danger alerts when help is disabled**. `params.h:33` sets `P_DANGER=3`; `P_CALLHELP` defaults to zero. `main.cpp:2462` calls `update_danger`, and `:1771–1785` uses byte 7 unless help owns it. Bytes 0–4 hold camp claims and 5–6 camp lifecycle data. [Chapter 04](04-vision-and-information.md#8-information-sharing) is corrected accordingly. A new vision protocol must preserve or explicitly migrate the active danger signal too. The original ward evidence ZIP is preserved as a historical snapshot; `memory-correction.md` in this study's archive records the correction and exact proof.

## Our original strategy and implementation priorities

The leaders support several competing candidate templates, not a universal shopping list. Our proposed design chooses between a few candidates using the next useful mission and the cost of obtaining the upgrade:

1. **Use an existing legal opportunity well.** Shop during an already-required heal or dead owner turn; let Tavi equip before an action it improves. Component shards are real power now. Preserve a reserve only for a named likely consumable use with an expiry.
2. **Choose the next useful threshold.** Compare the established role-build fallback, a relevant partial-emblem completion and one survival/farm alternative. Prefer a credible survival/clear failure turning into success, then an action/monster volley saved; otherwise compare useful first-passive/Power completion and retain the fallback if unresolved. This small ordering is an untested prototype and may miss continuous gains that do not cross its simple tests.
3. **Price a new trip separately.** Identify the affordable bundle before recalling. Include actual path back, team absence and missed capture/tribute; subtract recovery time already necessary. A late shopping detour can lose more gems than its stats can earn back.
4. **Match the body to the action.** Focus is not universally the caster label and Health is not purely passive defense: Ryth's Health also adds Strength; Ren's retaliation needs qualifying hits; Willow needs effective healing; Prism changes Focus when banking; reset/dash kits have no direct Focus coefficient. Use the released-body table above and the actions the controller actually takes.
5. **Treat economy and travel passives as horizon-dependent.** Tavi Treasure Focus is a plausible experiment because future private income can be spent in the field. Home has no observed purchases in this cohort and can break our capture-overlap timing; it needs a deliberate timer-aware experiment. Neither gets an invented universal round deadline or a guaranteed payback claim.
6. **Use consumables and Tavi healing for concrete actions.** A lock must delay a relevant opposing tribute, a crystal must justify its channel and destination, and same-turn healing must enable something before spawn regeneration. Buying/holding/using alone is not evidence of strategic payoff.

The authoritative situation/action/stop/fallback rules are in [Chapter 11](11-shopping-and-investment.md). For the first prototype, keep drafting, combat, reward allocation and navigation unchanged; test purchase choice and elective-trip timing separately, then together. First-copy Jungle/Durability/Monster versus primary Power and champion-specific mixed-stat choices are bounded alternatives. Do not add a global inventory optimizer, probabilistic income allocator or broad selling policy all at once. The narrowly verified Tavi heal can be tested independently.

Measure the decision enabled, not only spend ratio: actual stat delta, completion/unique-passive state, attacks/casts/monster volleys saved, useful heals/shields, avoidable recalls/deaths, return-to-productive-action time, interrupted captures, missed banks, consumable use and remaining private gold. Compare no-policy/fixed-build, individual choices and combinations across several opponents and unseen maps. Elite observations do not identify the weights, switching margin, mission horizon or globally best item order. **No bot strategy implementation or competitive test matches were performed in this research task.**

## Sources and reproducibility

- [Official items and gold](https://2026a.battlecode.co.uk/game/docs/items), [combat](https://2026a.battlecode.co.uk/game/docs/combat), [capture](https://2026a.battlecode.co.uk/game/docs/camps), [death and recall](https://2026a.battlecode.co.uk/game/docs/death-and-recall), and [Bot API](https://2026a.battlecode.co.uk/game/api).
- [Original frozen cohort and ward study](ward-research-2026-10-16.md): rank snapshot, public history selection, source bundle/alias binding and full original cohort audit. This study intentionally reuses that cohort rather than silently mixing in a new ladder or new games.
- [Shopping evidence archive](shopping-evidence-2026-10-16.zip): all selected match-ID/raw-hash/public-bundle bindings, full descriptive summary, transaction/body/team/context/checkpoint CSVs, exact illustrative cases, 51 mechanics fixtures, source identity/probe/analysis scripts, source audit and independent accounting/method/summary reviews. Its manifest lists every included file and SHA-256. This is research evidence, **not a bot submission ZIP**.
- The archive excludes the complete approximately 521 MB native per-frame purchase-state tree, original raw replay payloads/bundles, full API histories, private opponent source, credentials, runtime installations and the vendor engine/SDK binaries. The public index and pinned executable identities permit retrieval/reconstruction; scripts retain recorded workspace paths and need path/runtime setup for a new checkout. Compact cases retain their stated native pre/post scope; not every omitted microstate is embedded in the ZIP.

All data are descriptive. A raw replay difference is not proof of a different private version or an independent experiment. Game end censors purchases and milestones; missing opportunities between sparse observations cannot be called avoidable delay. Monetary before/after effects are confirmed, while opponent intent and why a match was won remain unobserved. The planned policy needs later implementation and controlled outcome validation.
'''
result=prefix+findings+middle+catalog+'\n### Champion-specific growth and kit use\n\n'+growth+'\n### Diminishing returns and complementarity\n\n'+stack+'\n### Treasure horizon and opportunity cost\n\n'+treasure+suffix
result=result.replace('cohort: 3,766 API match IDs','cohort: 3,766 API game IDs')
(P/'shopping-research-2026-10-16.md').write_text(result,encoding='utf8')
print(json.dumps({'words':len(result.split()),'bytes':len(result.encode()),'summary_sha256':hashlib.sha256((R/'matches/current-summary.json').read_bytes()).hexdigest()}))
