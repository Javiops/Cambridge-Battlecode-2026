# Investment reasoning to check against native evidence

These are analytical comparisons using queried item/champion metadata and controlled mechanics. They are not measured win-rate improvements or an inferred private opponent algorithm.

## Four different effects often called diminishing returns

1. **Price and absolute stat gain:** a shard always costs 30 gold and supplies the champion's fixed growth in its selected stat. Repeated ordinary shards do not become more expensive or mechanically weaker. No XP/level investment is inferred.
2. **Relative gain:** for base stat `B`, growth `g` and current stat `S`, one ordinary shard adds `g/S` proportionally. That fraction falls as `S` increases even though the absolute increase stays `g`. Compare actual ability coefficients and discrete action counts rather than assuming percentage stat gain equals mission value.
3. **Completion jumps:** five identical shards combine. Power supplies six growth points, so the fifth purchase adds two points relative to the prior four; Bruiser also supplies one point in each other stat at completion. A passive family unlocks its unique effect at the first completed emblem. Splitting a budget between families can delay these jumps.
4. **Saturated family passives:** another completed emblem of the same family, including a different stat variant, adds stats but no second passive. A repeat Durability/Monster/Treasure/Jungle/Home emblem must compete with a Power/Bruiser emblem or a still-missing useful family on its stat contribution alone. This does not make every duplicate purchase a demonstrated error: temporary shards, a planned Tavi respec, or an alternative stat allocation can change the comparison.

## Exact numerical examples

Ryth's queried base Strength is 50 and Strength growth is 5. Ordinary Strength shards take 50 to 55 to 60, each for 30 gold. Their relative increases are 10%, then 9.09%, then 8.33%; there is no rising price. Five Power Strength shards cost 150 and yield Strength 80 rather than 75. Five Monster Strength shards yield Strength 75 and camp-only basic damage 82.5 after the 1.1 multiplier; against a champion the same attack remains 75. These are unmodified attack examples, not whole-fight DPS calculations.

For fixed incoming damage, Durability's 0.9 multiplier gives `1/0.9 = 1.111...` times effective health. Jungle's 0.7 gives `1/0.7 = 1.42857...` against camps only. Together their 0.63 multiplier gives `1/0.63 = 1.58730...`. These effects do not stack again with same-family duplicates. Current health, shields, healing, enemy burst, damage type and avoidable damage still determine actual survival and the next action threshold.

## Treasure does not have a universal 750-gold purchase rule

The first Treasure emblem adds 20 percentage points to eligible earned-gold bonuses. At an otherwise unchanged base income, 750 additional base earned gold produces 150 additional gold; 150 produces 30 additional gold. Fractional bonus accounting carries across events in the audited engine. Refunds from sales are not earned income.

Those figures describe extra cash, **not** the complete opportunity-cost break-even. The 150 spent also bought five ordinary growth points. Against another 150-gold emblem, the foregone benefit is that alternative's passive or Power's one extra growth point, plus its effect on survival, farm pace and objectives. Buying Treasure can itself change future income, so a constant-rate horizon is only an approximation. Evaluate expected personal base income before the next decisive period, whether the extra gold can be spent in time, and how the alternative changes those same missions. Do not assume total game duration alone guarantees repayment.

## Home trades channel time against resource collection timing

Home reduces a five-owner-turn-end recall to three. A capture timer of five completes after five subsequent global capture phases following the phase that starts it; those phases differ from the owner's turn ends. Starting the shorter recall too early can leave before collection and reset capture. The buying decision therefore includes the required capture wait and the planned return route, not just a nominal two-turn saving. A capture-aware bot can wait before channeling when appropriate; it must not preserve an otherwise doomed hold just to recover a purchase's value.

## A bounded purchase comparator

For the next mission, compare a few purchase bundles affordable from this body's gold: finish the next useful emblem, cross a lethal-damage/clear-cycle/survival breakpoint, buy a justified consumable, or defer spending until an already-required return. Include recall, travel and lost camp/tribute opportunities when comparing a new shopping trip. Do not charge the full trip to shopping if recovery already requires the same return; do not call dead-shopping free of the death that preceded it.

The first prototype can use small champion-role templates and a priority list rather than a full combat/economy optimizer. All thresholds, mission horizons and weights must remain explicitly planned until tested on multiple opponents and unseen maps.
