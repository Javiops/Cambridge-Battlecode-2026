"""Preserve the exact observed Tavi buy/sell healing sequence and its public source binding."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent
mid='17a5c872-dd06-4e5d-b6af-13c0dfaec889';p=R/f'matches/current/{mid}.shopping.json';raw=p.read_bytes();g=json.loads(raw)
m=json.loads((R.parent/'ward-research/acquisition/manifest-native.json').read_bytes())
aliases=[r for r in m['requests']if r['raw_sha256']==g['sourceSha256']]
es=[e for e in g['events']if e['actor']==4 and e['round']==139 and 4292<=e['input']<=4307]
assert len(es)==16 and es[0]['before']['health']==210 and es[-1]['after']['health']==750
assert es[0]['before']['gold']==es[-1]['after']['gold']==160
assert es[0]['before']['items']==es[-1]['after']['items']
assert all(e['atOwnSpawnBefore']and e['confirmed']for e in es)
value={'purpose':'Exact observed sequence demonstrating retained same-turn spawn healing, not an inferred private motive or causal win advantage. End-of-turn spawn healing may make it unnecessary without an intervening useful action.','match_id':mid,'source_sha256':g['sourceSha256'],'native_analysis_sha256':hashlib.sha256(raw).hexdigest(),'engine_sha256':g['engineSha256'],'map':g['map'],'teams':g['teams'],'round':139,'actor':4,'series_id':g['series_id'],'series_url':aliases[0]['series_url'],'bundle_url':next(r['bundle_url']for r in aliases if r['id']==mid),'geometry':g['geometry'],'events':es,'following_same_round_events':[e for e in g['events']if e['actor']==4 and e['round']==139 and e['input']>4307],'totals':{'buy_sell_cycles':8,'gross_shard_spending':240,'sale_refunds':240,'net_gold_spending':0,'current_health_before':210,'current_health_after':750,'net_health_gained':540,'max_health_before':750,'max_health_after':750,'gold_before':160,'gold_after':160,'final_inventory_equals_initial':True}}
folder=R/'matches/cases';folder.mkdir(exist_ok=True)
target=folder/'mite-tavi-spawn-healing.json';target.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'path':str(target),'source_sha256':value['source_sha256'],'series_url':value['series_url'],'totals':value['totals']}))
