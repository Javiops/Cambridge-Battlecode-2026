"""Bounded per-game native audit, compact body/game tables, conditional build summaries."""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timezone
import json,csv,hashlib,statistics,gzip
ROOT=Path(__file__).resolve().parent;WARD=ROOT.parent.parent/'ward-research';UNIQUE=WARD/'matches/manifest-current-unique.json';FULL=WARD/'acquisition/manifest-native.json'
manifest=json.loads(UNIQUE.read_bytes());allmanifest=json.loads(FULL.read_bytes());ladder=json.loads((WARD/'acquisition/api/ladder.json').read_bytes());rank={t['teamId']:t for t in ladder['teams']};catalog=json.loads((ROOT/'current/shop-catalog.json').read_bytes());items=catalog['items']
sha=lambda b:hashlib.sha256(b).hexdigest();requests={r['id']:r for r in manifest['requests']};aliascount=Counter(r['raw_sha256']for r in allmanifest['requests']);aliases=defaultdict(list)
for r in allmanifest['requests']:aliases[r['raw_sha256']].append(r['id'])
latest=[];strata=Counter()
for r in sorted(allmanifest['requests'],key=lambda r:(r['created_at'],r['id']),reverse=True):
 k=(tuple(sorted(t['teamId']for t in r['teams'].values())),r['map'],r['kind'])
 if strata[k]<2:latest.append(r);strata[k]+=1
latestbyraw={}
for r in latest:latestbyraw.setdefault(r['raw_sha256'],r)
errors=[];warnings=Counter();bodyrows=[];gamerows=[];counts=Counter();auditrecords=[];casecandidates=defaultdict(list);batch_effects=defaultdict(list)
def check(ok,mid,kind,**details):
 if not ok:errors.append({'id':mid,'kind':kind,**details})
def dist(v):
 v=sorted(v)
 def q(p):
  if not v:return None
  x=(len(v)-1)*p;i=int(x);return v[i]+(v[min(i+1,len(v)-1)]-v[i])*(x-i)
 return{'n':len(v),'sum':sum(v),'mean':statistics.mean(v)if v else None,'median':q(.5),'p25':q(.25),'p75':q(.75),'min':v[0]if v else None,'max':v[-1]if v else None}
def band(r):return'top4_h2h'if max(rank[t['teamId']]['rank']for t in r['teams'].values())<=4 else'top4_vs_5_10'if min(rank[t['teamId']]['rank']for t in r['teams'].values())<=4 else'top10_other'
def meta(r,side):
 t=r['teams']['a'if side==0 else'b'];rr=rank[t['teamId']];return{'match_id':r['id'],'raw_sha256':r['raw_sha256'],'map':r['map'],'kind':r['kind'],'created_at':r['created_at'],'teamId':t['teamId'],'team':rr['name'],'rank':rr['rank'],'side':side,'band':band(r),'latest_slice':r['raw_sha256']in latestbyraw}
eventfile=(ROOT/'purchase-events.csv').open('w',newline='',encoding='utf8');eventfields=['match_id','raw_sha256','map','kind','created_at','team','rank','actor','champion','round','input','native_kind','category','confirmed','item','item_name','family','stat','quantity','cost','gold_before','gold_after','hp_before','hp_after','maxhp_before','maxhp_after','strength_before','strength_after','focus_before','focus_after','health_points_before','health_points_after','strength_points_before','strength_points_after','focus_points_before','focus_points_after','at_own_spawn','can_shop_item','emblems_created','peer_resource_changes','rounds_after_last_recall_command','rounds_after_last_spawn_observation']
ew=csv.DictWriter(eventfile,fieldnames=eventfields);ew.writeheader()
cpfile=(ROOT/'checkpoints.csv').open('w',newline='',encoding='utf8');cpfields=['match_id','raw_sha256','map','team','rank','round','body_count','gold','earned_gold','treasure_gold','item_value','cumulative_gross_spend','cumulative_sale_receipts','cumulative_net_spend'];cw=csv.DictWriter(cpfile,fieldnames=cpfields);cw.writeheader()
for ix,(mid,r)in enumerate(requests.items()):
 file=ROOT/'current'/f'{mid}.shopping.json'
 if not file.exists():errors.append({'id':mid,'kind':'missing'});continue
 g=json.loads(file.read_bytes());check(g['id']==mid and g['sourceSha256']==r['raw_sha256'],mid,'source_binding');check(sha(Path(r['raw']).read_bytes())==r['raw_sha256'],mid,'raw_hash');check(not g['apiFinalErrors'],mid,'api_final',errors=g['apiFinalErrors']);check(not g['ledgerErrors'],mid,'gold_ledger',errors=g['ledgerErrors']);check(g['rounds']==r['game']['statistics']['round'],mid,'round_binding');counts['raw_streams']+=1;counts['resource_commands']+=g['commandCount'];counts['confirmed_resource_events']+=g['confirmedCount']
 perbody=defaultdict(list);perteam=defaultdict(list)
 for e in g['events']:
  m=meta(r,e['team']);b=e['before'];a=e['after'];perbody[e['actor']].append(e);perteam[e['team']].append(e);counts[e['category']+('_confirmed'if e['confirmed']else'_unconfirmed')]+=1
  if e['kind']==13:check(e['confirmed']and e['category']in['item_purchase','consumable_purchase'],mid,'shop_buy_confirmation',input=e['input'])
  if e['category']=='item_sale':check(e['confirmed']and e['kind']==25 and e['name']=='Tavi'and e['cost']==e['inventoryValueDelta']and all(x<=0 for x in e['itemsDelta'])and sum(x<0 for x in e['itemsDelta'])==1,mid,'sale_full_refund',input=e['input']);counts['sale_refunds']-=e['cost']
  if e['otherBodyResourceChanges']:counts['events_with_peer_resource_changes']+=1;check(False,mid,'peer_resource_change',input=e['input'],changes=e['otherBodyResourceChanges'])
  if e['category']=='unclassified':warnings[f"unclassified_kind{e['kind']}_cost{e['cost']}_itemvalue{e['inventoryValueDelta']}"]+=1;check(e['cost']==0 and e['inventoryValueDelta']==0 and not any(e['itemsDelta'])and not any(e['consumablesDelta']),mid,'unclassified_resource_delta',input=e['input'])
  it=items[e['item']]if e['category']in['item_purchase','item_sale']and e['item']is not None else None
  row={k:m[k]for k in['match_id','raw_sha256','map','kind','created_at','team','rank']};row.update(actor=e['actor'],champion=e['name'],round=e['round'],input=e['input'],native_kind=e['kind'],category=e['category'],confirmed=e['confirmed'],item=e['item'],item_name=it['name']if it else catalog['consumables'][e['item']]['name']if e['item']is not None else'',family=it['family']if it else'',stat=it['stat']if it else'',quantity=e['quantity'],cost=e['cost'],gold_before=b['gold'],gold_after=a['gold'],hp_before=b['health'],hp_after=a['health'],maxhp_before=b['maxHealth'],maxhp_after=a['maxHealth'],strength_before=b['strength']['effective'],strength_after=a['strength']['effective'],focus_before=b['focus']['effective'],focus_after=a['focus']['effective'],at_own_spawn=e['atOwnSpawnBefore'],can_shop_item=e['canShopItemBefore'],emblems_created=json.dumps(e['emblemsCreated'],separators=(',',':')),peer_resource_changes=len(e['otherBodyResourceChanges']),rounds_after_last_recall_command=e['round']-e['lastRecallCommand']['round']if e['lastRecallCommand']else'',rounds_after_last_spawn_observation=e['round']-e['lastObservedSpawnEntry']['round']if e['lastObservedSpawnEntry']else'')
  for stat in['health','strength','focus']:row[stat+'_points_before']=b['points'][stat];row[stat+'_points_after']=a['points'][stat]
  ew.writerow(row)
  if e['confirmed']and e['category']=='item_purchase':
   stat=it['stat'].lower();effect=(a['maxHealth']-b['maxHealth'])if stat=='health'else(a[stat]['effective']-b[stat]['effective']);pre=b['points'][stat];bucket='0'if pre==0 else'1-4'if pre<5 else'5-9'if pre<10 else'10-19'if pre<20 else'20+';batch_effects[(e['name'],stat,bucket)].append(effect*30/e['cost'])
   if m['rank']<=4:casecandidates[m['teamId']].append((len(e['emblemsCreated'])*100+(e['quantity']==5)*30+(e['round']<100)*20,{'match_id':mid,'sourceSha256':g['sourceSha256'],'map':r['map'],'team':m['team'],'rank':m['rank'],'event':e,'source_file':str(file.resolve())}))
 for c in g['championLedgers']:
  m=meta(r,c['team']);es=perbody[c['id']];buys=[e for e in es if e['confirmed']and e['category']=='item_purchase'];cons=[e for e in es if e['confirmed']and e['category']=='consumable_purchase'];sales=[e for e in es if e['confirmed']and e['category']=='item_sale'];uses=[e for e in es if e['confirmed']and e['category']=='consumable_use'];o=c['opportunities']or{};build=Counter();family=Counter();stats=Counter()
  for e in buys:it=items[e['item']];build[f"{it['family']}/{it['stat']}"]+=e['cost'];family[it['family']]+=e['cost'];stats[it['stat']]+=e['cost']
  check(c['grossSpend']==c['apiSpentGold'],mid,'body_gross_api',body=c['id']);check(c['goldResidual']==0,mid,'body_cash_balance',body=c['id']);check(c['initialGold']==0 and c['initialEarnedGold']==0,mid,'initial_economic_zero',body=c['id']);check(sum(build.values())==c['itemSpend'],mid,'body_build_spend',body=c['id'])
  row={**m,'body':c['id'],'champion':c['name'],'type':c['type'],'rounds':g['rounds'],'earnedGold':c['earnedGold'],'treasureGold':c['treasureGold'],'grossSpend':c['grossSpend'],'netSpend':c['netSpend'],'itemSpend':c['itemSpend'],'consumableSpend':c['consumableSpend'],'saleReceipts':c['saleReceipts'],'finalGold':c['finalGold'],'itemPurchaseEvents':len(buys),'consumablePurchaseEvents':len(cons),'saleEvents':len(sales),'consumableUses':len(uses),'shardsBought':sum(e['quantity']for e in buys),'consumablesBought':sum(e['quantity']for e in cons),'purchaseBatchSizes':[e['quantity']for e in buys],'firstThreePurchaseRounds':c['firstThreePurchaseRounds'],'firstThreeEmblemMilestones':c['firstThreeEmblemMilestones'],'emblemCount':len(c['emblemMilestones']),'buildSpend':dict(build),'familySpend':dict(family),'statSpend':dict(stats),'opportunities':o,'finalPoints':c['final']['points'],'finalItems':c['final']['items'],'finalStrength':c['final']['strength']['effective'],'finalFocus':c['final']['focus']['effective'],'finalMaxHealth':c['final']['maxHealth'],'atSpawnPurchaseEvents':sum(e['atOwnSpawnBefore']for e in buys),'recallWithin3PurchaseEvents':sum(e['lastRecallCommand']is not None and 0<=e['round']-e['lastRecallCommand']['round']<=3 for e in buys),'spendWithin3ReturnObservations':sum(e['lastObservedSpawnEntry']is not None and e['lastObservedSpawnEntry']['round']>1 and 0<=e['round']-e['lastObservedSpawnEntry']['round']<=3 for e in buys)};bodyrows.append(row);counts['body_appearances']+=1
 for side in[0,1]:
  cs=[c for c in g['championLedgers']if c['team']==side];row={**meta(r,side),'rounds':g['rounds'],'bodyCount':len(cs)}
  for k in['earnedGold','treasureGold','grossSpend','netSpend','itemSpend','consumableSpend','saleReceipts','finalGold']:row[k]=sum(c[k]for c in cs)
  row['bodyNoSpend']=sum(c['grossSpend']==0 for c in cs);row['bodyNoItemPurchase']=sum(c['itemSpend']==0 for c in cs);gamerows.append(row)
 for cp in g['checkpoints']:
  if not isinstance(cp,dict)or cp['round']<1 or len(cp['champions'])!=len(g['championLedgers']):continue
  for side in[0,1]:
   m=meta(r,side);cs=[c for c in cp['champions']if c['team']==side];es=[e for e in perteam[side]if e['confirmed']and e['input']<=cp['input']];gross=sum(e['cost']for e in es if e['category']in['item_purchase','consumable_purchase']);refund=-sum(e['cost']for e in es if e['category']=='item_sale');cw.writerow({'match_id':mid,'raw_sha256':r['raw_sha256'],'map':r['map'],'team':m['team'],'rank':m['rank'],'round':cp['round'],'body_count':len(cs),'gold':sum(c['gold']for c in cs),'earned_gold':sum(c['earnedGold']for c in cs),'treasure_gold':sum(c['treasureGold']for c in cs),'item_value':sum(c['itemValue']for c in cs),'cumulative_gross_spend':gross,'cumulative_sale_receipts':refund,'cumulative_net_spend':gross-refund})
 auditrecords.append({'id':mid,'raw_sha256':r['raw_sha256'],'file_sha256':sha(file.read_bytes()),'resource_commands':g['commandCount'],'confirmed_events':g['confirmedCount'],'bodies':len(g['championLedgers']),'ledger_errors':g['ledgerErrors'],'api_errors':g['apiFinalErrors']})
 if(ix+1)%500==0:print('Audited',ix+1,flush=True)
eventfile.close();cpfile.close()
def summarize(bs,gs):
 result={'bodies':len(bs),'streams':len(gs),'noSpendBodies':sum(b['grossSpend']==0 for b in bs),'noItemPurchaseBodies':sum(b['itemSpend']==0 for b in bs)}
 for k in['earnedGold','treasureGold','grossSpend','netSpend','itemSpend','consumableSpend','saleReceipts','finalGold','itemPurchaseEvents','consumablePurchaseEvents','saleEvents','consumableUses','shardsBought','consumablesBought','emblemCount','atSpawnPurchaseEvents','recallWithin3PurchaseEvents','spendWithin3ReturnObservations']:result[k]=sum(b[k]for b in bs)
 for k in['finalGold','earnedGold','itemSpend','finalStrength','finalFocus','finalMaxHealth']:result[k+'PerBody']=dist([b[k]for b in bs])
 for k in['finalGold','earnedGold','grossSpend']:result[k+'PerGame']=dist([g[k]for g in gs])
 for i in range(3):result[f'purchase{i+1}Round']=dist([b['firstThreePurchaseRounds'][i]for b in bs if len(b['firstThreePurchaseRounds'])>i]);result[f'emblem{i+1}Round']=dist([b['firstThreeEmblemMilestones'][i]['round']for b in bs if len(b['firstThreeEmblemMilestones'])>i])
 for key in['buildSpend','familySpend','statSpend']:
  c=Counter()
  for b in bs:c.update(b[key])
  result[key]=dict(c.most_common())
 result['firstEmblemCounts']=dict(Counter(b['firstThreeEmblemMilestones'][0]['name']for b in bs if b['firstThreeEmblemMilestones']).most_common());result['firstThreeEmblemPrefixes']=[{'items':list(items),'bodies':n}for items,n in Counter(tuple(m['name']for m in b['firstThreeEmblemMilestones'])for b in bs if len(b['firstThreeEmblemMilestones'])>=3).most_common(15)];result['purchaseBatchSize']=dist([n for b in bs for n in b['purchaseBatchSizes']]);result['bodiesWithAtLeast3Emblems']=sum(len(b['firstThreeEmblemMilestones'])>=3 for b in bs)
 okeys=['aliveOwnerTurns','goldSumAtOwnerStart','turnsGoldAtLeast10','turnsGoldAtLeast30','turnsGoldAtLeast150','turnsAtOwnSpawn','shopLocationEligibleWith30','shopLocationEligibleWith150','shopLocationEligibleWith10'];result['ownerStartObservations']={k:sum(b['opportunities'].get(k,0)for b in bs)for k in okeys};result['peakGoldAtOwnerStart']=dist([b['opportunities'].get('peakGoldAtOwnerStart',0)for b in bs]);result['firstOwnerStartWith30']=dist([b['opportunities']['firstOwnerStartWith30']for b in bs if b['opportunities'].get('firstOwnerStartWith30')is not None]);result['firstEligibleOwnerStartWith30']=dist([b['opportunities']['firstEligibleOwnerStartWith30']for b in bs if b['opportunities'].get('firstEligibleOwnerStartWith30')is not None]);result['firstBuyMinusFirstEligible30']=dist([b['firstThreePurchaseRounds'][0]-b['opportunities']['firstEligibleOwnerStartWith30']for b in bs if b['firstThreePurchaseRounds']and b['opportunities'].get('firstEligibleOwnerStartWith30')is not None]);return result
def group(sourceB,sourceG,keys):
 bs=defaultdict(list);gs=defaultdict(list)
 for b in sourceB:bs[tuple(b[k]for k in keys)].append(b)
 # Champion groups count contributing games via the body appearances themselves.
 for g in sourceG:
  if 'champion'not in keys:gs[tuple(g[k]for k in keys)].append(g)
 rows=[]
 for key,values in bs.items():
  groupgames=gs[key]if 'champion'not in keys else[{'match_id':b['match_id'],'finalGold':b['finalGold'],'earnedGold':b['earnedGold'],'grossSpend':b['grossSpend']}for b in values];rows.append({**dict(zip(keys,key)),**summarize(values,groupgames)})
 return sorted(rows,key=lambda x:tuple(x[k]for k in keys))
def tables(bs,gs):
 return{'per_team':group(bs,gs,['rank','teamId','team']),'per_map_team':group(bs,gs,['rank','teamId','team','map']),'per_team_champion':group(bs,gs,['rank','teamId','team','champion']),'per_map_team_champion':group(bs,gs,['rank','teamId','team','champion','map'])}
print('Building summaries',flush=True)
summary={'generated_at_utc':datetime.now(timezone.utc).isoformat(),'counts':dict(counts),'warnings':dict(warnings),'expectedUniqueStreams':2119,'expectedMatchIDs':3766,'rawAliasExtraIDs':1647,'bodies':len(bodyrows),'latestSlice':{'IDs':len(latest),'rawStreams':len(latestbyraw)},'unique':tables(bodyrows,gamerows),'top4_h2h':tables([b for b in bodyrows if b['band']=='top4_h2h'],[g for g in gamerows if g['band']=='top4_h2h']),'latest':tables([b for b in bodyrows if b['latest_slice']],[g for g in gamerows if g['latest_slice']]),'batchStatEffectPer30Gold':[{'champion':key[0],'stat':key[1],'pointsBeforeBucket':key[2],'observedBatchGainPer30Gold':dist(v)}for key,v in sorted(batch_effects.items())],'definitions':{'primary':'Each raw replay SHA256 once; each body is a champion-body/game appearance. Cassi and Issac remain distinct private budgets. A game contributes one team observation to each participant.','purchase':'Gold+inventory+catalog-confirmed successful item/consumable buys; nativekind13 is generic buy. Automatic emblems are completion milestones, not separately charged purchases.','sale':'Kind25 with inventory loss and exact full face-value gold refund, actor Tavi. Gross spend retains repurchases; net spend subtracts sale receipts.','levels':'No XP/levels. Itempoints and actual per-purchase stat-block/HP changes are separate.','availability':'Alive owner-turn-start observations, not every microstate. CanShop(false) is location eligibility, not proof a desired item can legally fit. First buy minus first observed eligible30 may be negative if gold or opportunity arose within the same turn; not a causal delay estimate.','buildOrder':'First-three emblems are normalized completed-five-shard milestones; first-three purchase events are raw buy input events and can be small shard batches.','time':'Latest2 IDs by timestamp+ID for every unordered pair/map/kind, then raw dedup; fixed cohort ranks do not identify code versions.','checkpoint':'Round>=1 checkpoints with complete final roster only; right-censored by game duration.','scope':'Descriptive observations, not optimal builds or causal win effects.'}}
(ROOT/'current-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
audit={'passed':not errors and counts['raw_streams']==2119,'source_unique_manifest_sha256':sha(UNIQUE.read_bytes()),'source_all_manifest_sha256':sha(FULL.read_bytes()),'engine_sha256':'ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc','counts':dict(counts),'warnings':dict(warnings),'errors':errors,'records':auditrecords,'sale_repair_ledger':str((ROOT/'sale-repair-ledger.json').resolve())};(ROOT/'current-audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf8')
for name,rows in [('body-ledgers',bodyrows),('team-game-ledgers',gamerows)]:
 with(ROOT/f'{name}.jsonl.gz').open('wb')as raw:
  with gzip.GzipFile(fileobj=raw,mode='wb',compresslevel=1)as z:
   for row in rows:z.write((json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n').encode('utf8'))
 fields=sorted({k for row in rows for k in row})
 with(ROOT/f'{name}.csv').open('w',newline='',encoding='utf8')as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  for row in rows:w.writerow({k:json.dumps(v,ensure_ascii=False,separators=(',',':'))if isinstance(v,(dict,list))else v for k,v in row.items()})
selected=[]
for tid,rows in casecandidates.items():
 seen=set()
 for score,row in sorted(rows,key=lambda x:x[0],reverse=True):
  if row['match_id']in seen:continue
  selected.append(row);seen.add(row['match_id'])
  if len(seen)>=2:break
(ROOT/'case-candidates.json').write_text(json.dumps(selected,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'passed':audit['passed'],'counts':dict(counts),'warnings':dict(warnings),'errors':len(errors),'latest':summary['latestSlice']},indent=2),flush=True)
