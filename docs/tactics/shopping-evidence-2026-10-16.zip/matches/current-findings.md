# Shopping and resource investment: frozen elite replay cohort

The 2,119 distinct native raw streams contain **167,011 confirmed shop transactions**: 155,467 item buys (357,296 charged shards) and 11,544 consumable buys. Five shards automatically form one emblem; the 63,744 observed emblem completions are not additional purchases. Native before/after gold, inventory and catalog costs confirm each buy. No XP or champion levels exist in this engine: item points, HP and effective Strength/Focus are recorded separately.

## Scope and reconstruction

This is exactly the frozen ward cohort: 3,766 API match IDs, 2,119 distinct raw SHA-256 streams, 4,238 team/game observations and 21,312 champion-body/game appearances. Extra IDs alias 1,647 already counted streams. The frozen top-four head-to-head subset is 2,460 IDs / 1,078 streams. Ranks refer to the 2026-10-15 22:51:52 UTC ladder snapshot; selected games span October 13–15, ending 22:50:49 UTC. All nine maps are covered. No outcome filter was used. Distinct streams are not asserted to be independent bot versions, and private submission/version fields are unavailable.

The scanner uses the pinned official WASM (`ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc`) and sequential native ReplayNext states. It captures the exact state immediately before and after each resource command, full initial/final roster, alive owner-turn-start gold/shop-location observations, and complete-roster checkpoints every 25 rounds. Gold/items are personal, including separate Cassi and Issac budgets. Team totals below sum those budgets. Gold exists from rewards and recipient-specific bonuses; there is no passive income or starting gold.

## All ten teams: spending, saving and batch size

| Team | Streams / bodies | Earned gold | Item / consumable gross spend | Net / earned | Final gold | No item buy bodies | Median item batch |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Fish | 567 / 2,938 | 1,719,340 | 1,583,670 / 0 | 92.11% | 135,670 | 356 / 2,938 | 3 |
| Sneaky | 380 / 1,876 | 933,445 | 844,950 / 0 | 90.52% | 88,495 | 401 / 1,876 | 3 |
| Mite | 1,011 / 5,295 | 2,975,025 | 2,642,160 / 43,800 | 90.26% | 289,725 | 652 / 5,295 | 3 |
| Univardisty | 821 / 4,037 | 2,230,537 | 1,994,370 / 60,290 | 92.12% | 175,877 | 449 / 4,037 | 3 |
| VeryGood | 227 / 1,176 | 577,880 | 525,330 / 0 | 90.91% | 52,550 | 178 / 1,176 | 1 |
| Quantom | 264 / 1,233 | 781,280 | 703,890 / 4,260 | 90.64% | 73,130 | 83 / 1,233 | 1 |
| hello | 264 / 1,321 | 715,194 | 642,510 / 6,910 | 90.80% | 65,774 | 194 / 1,321 | 3 |
| Nyxius | 243 / 1,196 | 708,725 | 587,610 / 0 | 82.91% | 121,115 | 269 / 1,196 | 3 |
| geese geese go | 221 / 1,087 | 610,664 | 565,650 / 0 | 92.63% | 45,014 | 122 / 1,087 | 1 |
| Full Damage | 240 / 1,153 | 677,395 | 628,740 / 180 | 92.84% | 48,475 | 155 / 1,153 | 1 |

Across the cohort, earned gold is 11,929,485; gross spend 10,834,320; refunds 660; net spend 10,833,660; final gold 1,095,825. Every personal ledger balances: initial gold + earned + refunds − gross spend = final gold. Gross spend counts health-shard purchases subsequently refunded by Tavi; net spend removes the refunds. Spending totals are duration- and reward-dependent, not efficiency or win-effect estimates.

Single-shard commands are prominent for VeryGood, geese geese go and Full Damage; each has exactly one shard per item transaction. First/second/third command rounds can therefore coincide or have misleadingly different medians. A 150-gold completed emblem is the comparable build milestone; it may be assembled through several commands or one five-shard batch.

## Strongest opponents and purchase timing

All rows here are top-four versus top-four. Cells show median round **(number of bodies reaching that transaction or milestone)**; each column has its own denominator. Transaction rounds are item buys, not individual shards. Bodies that never reach a milestone remain in the reported total bodies but not its timing median.

| Team | Streams / bodies | Item buy 1 / 2 / 3 | Emblem 1 / 2 / 3 | Net / earned |
| --- | --- | --- | --- | --- |
| Fish | 437 / 2264 | 111 (1,977) / 148 (1,740) / 211 (1,492) | 135 (1,719) / 223 (1,317) / 256 (1,055) | 92.30% |
| Sneaky | 221 / 1102 | 93 (850) / 171.5 (674) / 222 (594) | 143 (690) / 236 (521) / 288 (414) | 91.45% |
| Mite | 839 / 4414 | 120 (3,846) / 170 (3,275) / 225 (2,817) | 150 (3,268) / 248 (2,445) / 290 (1,983) | 90.64% |
| Univardisty | 659 / 3247 | 102 (2,854) / 173 (2,339) / 222 (1,929) | 140 (2,241) / 231 (1,646) / 272 (1,326) | 92.16% |

The latest sensitivity slice selects the newest two match IDs by timestamp then ID within each unordered team pair × map × game kind, before raw-hash deduplication. It has 1,513 IDs / 1,174 raw streams. Its intersection with top-four head-to-head has **133 raw streams**; the four team appearances below sum to 266.

| Team | Recent h2h streams / bodies | First item buy: all h2h → recent | First emblem: all h2h → recent | Net / earned: all h2h → recent |
| --- | --- | --- | --- | --- |
| Fish | 62 / 312 | 111 (1,977) → 112 (279) | 135 (1,719) → 125.5 (248) | 92.30% → 92.48% |
| Sneaky | 64 / 304 | 93 (850) → 81 (248) | 143 (690) → 127 (212) | 91.45% → 90.76% |
| Mite | 84 / 426 | 120 (3,846) → 113 (382) | 150 (3,268) → 158 (342) | 90.64% → 86.35% |
| Univardisty | 56 / 276 | 102 (2,854) → 100.5 (264) | 140 (2,241) → 149.5 (220) | 92.16% → 92.31% |

The recent comparison preserves Mite’s Jungle-first pattern (all 342 recent first emblems are Jungle: 193 Strength, 149 Focus) and Univardisty’s mixture of Power, Bruiser and Treasure. Timing and saved-gold levels change: Mite’s recent net-spend fraction falls, while first-emblem timing shifts in different directions across teams. Fish’s Jungle share of first emblems falls from 418/1,719 in all h2h to 18/248 recently; Monster rises from 98/1,719 to 53/248. Those changes make a single all-history “current policy” label unsafe. Map, chronology, opponent, draft and private versions remain confounded even within a team/champion.

## Build composition and champion conditioning

| Team | Power | Durability | Bruiser | Jungle | Monster | Treasure | Home |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Fish | 972,090 | 261,420 | 190,140 | 101,130 | 58,890 | 0 | 0 |
| Sneaky | 497,790 | 134,490 | 86,190 | 125,070 | 1,410 | 0 | 0 |
| Mite | 1,159,740 | 466,500 | 370,260 | 645,000 | 0 | 660 | 0 |
| Univardisty | 1,427,910 | 359,190 | 138,840 | 0 | 0 | 68,430 | 0 |

These are gross gold by item family. **Mite’s 660 Treasure gold is entirely 22 temporary Treasure Health shard purchases, each immediately sold for a 30-gold refund; no Treasure emblem or Treasure bonus income results.** Its retained Treasure investment is zero. Across all ten teams Home purchases are zero. Univardisty spends 68,430 on Treasure and records 30,254 Treasure bonus gold; those are separate descriptive flows, not a causal return-on-investment estimate. The `treasureGold` field tracks Treasure-item bonus only, excluding Vesper’s passive bonus. Camp reward splitting occurs before each recipient’s bonuses; team totals do not imply transfers to teammates.

Among bodies completing a first emblem, Mite is exactly Jungle Strength 2,257 / Jungle Focus 1,717. Univardisty’s first completions are Power Strength 935, Power Focus 730, Bruiser Health 720, Treasure Focus 388 and Bruiser Strength 96. Fish and Sneaky mix families more broadly; their composition changes with champion and cohort.

| Team / champion | Body appearances | No item buy | Most common first completion (count / all first completions) | Most common first-three emblem sequence (count) |
| --- | --- | --- | --- | --- |
| Fish / Issac | 567 | 16 | Power Emblem of Strength (378 / 525) | Power Emblem of Strength → Durability Emblem of Health → Power Emblem of Strength (252) |
| Fish / Stellar | 493 | 60 | Power Emblem of Focus (276 / 356) | Power Emblem of Focus → Durability Emblem of Health → Power Emblem of Focus (124) |
| Sneaky / Issac | 312 | 81 | Jungle Emblem of Strength (104 / 207) | Jungle Emblem of Strength → Durability Emblem of Strength → Bruiser Emblem of Health (81) |
| Sneaky / Stellar | 379 | 88 | Power Emblem of Focus (241 / 241) | Power Emblem of Focus → Jungle Emblem of Focus → Durability Emblem of Focus (96) |
| Sneaky / Tavi | 273 | 35 | Jungle Emblem of Focus (144 / 193) | Jungle Emblem of Focus → Durability Emblem of Focus → Bruiser Emblem of Health (73) |
| Mite / Issac | 1011 | 125 | Jungle Emblem of Strength (802 / 802) | Jungle Emblem of Strength → Durability Emblem of Strength → Bruiser Emblem of Health (393) |
| Mite / Stellar | 707 | 104 | Jungle Emblem of Focus (473 / 473) | Jungle Emblem of Focus → Durability Emblem of Focus → Bruiser Emblem of Health (239) |
| Mite / Tavi | 261 | 42 | Jungle Emblem of Focus (121 / 161) | Jungle Emblem of Focus → Durability Emblem of Focus → Bruiser Emblem of Health (24) |
| Univardisty / Issac | 580 | 61 | Power Emblem of Strength (426 / 442) | Power Emblem of Strength → Durability Emblem of Health → Power Emblem of Strength (270) |
| Univardisty / Stellar | 700 | 40 | Power Emblem of Focus (539 / 539) | Power Emblem of Focus → Durability Emblem of Health → Power Emblem of Focus (292) |
| Univardisty / Tavi | 593 | 47 | Treasure Emblem of Focus (388 / 409) | Treasure Emblem of Focus → Durability Emblem of Focus → Power Emblem of Focus (218) |

Repeated emblems still add their stat points; the same family’s passive is not multiplied by owning it across stats or copies. `batchStatEffectPer30Gold` preserves actual observed batch stat/HP gains grouped by champion, stat and prior-points bucket. It is not a per-point marginal curve or evidence that a particular extra purchase improved the result.

## Nine maps with the champion held fixed

Fish/Issac appears on every map and avoids mixing different champion drafts. Counts below condition on the first completed emblem; the body column includes non-completers. These are observed map associations, not proof of map adaptation. Full team × champion × map tables for all ten teams and each temporal slice are in `conditional-builds.csv` and `current-summary.json`.

| Map | Bodies / first completions | Power Strength | Jungle Strength | Monster Strength | Jungle Health | First item buy round (n) |
| --- | --- | --- | --- | --- | --- | --- |
| collision | 55 / 55 | 46 | 8 | 0 | 1 | 59 (55) |
| corners | 80 / 63 | 46 | 15 | 0 | 2 | 86 (75) |
| elkring | 73 / 73 | 59 | 13 | 0 | 1 | 34 (73) |
| expanse | 49 / 48 | 23 | 7 | 16 | 2 | 76 (49) |
| interlock | 47 / 47 | 40 | 5 | 0 | 2 | 37 (47) |
| lanes | 79 / 55 | 43 | 10 | 0 | 2 | 147.5 (68) |
| monolith | 49 / 49 | 38 | 9 | 0 | 2 | 37 (49) |
| packs | 74 / 74 | 56 | 15 | 0 | 3 | 46 (74) |
| rows | 61 / 61 | 27 | 13 | 19 | 2 | 88 (61) |

Fish/Issac’s Monster-first completions occur on expanse (16/48) and rows (19/61); Fish/Stellar also records Monster Focus first on rows (19/40 first completions). This remains chronology-confounded, especially given the recent Fish family shift. Absence in one group is descriptive; no geometric or economic cause is inferred. Map-specific game duration and surviving income opportunities also affect timing and completion rates.

## Shop context, unspent gold and consumables

| Team | Item buys in own spawn | Item buys while dead | Alive field item buys (all Tavi) | No spend / zero earned | No item buy despite ≥30 lifetime earned | No spend with ≥150 final gold |
| --- | --- | --- | --- | --- | --- | --- |
| Fish | 17,017 | 1,034 | 0 | 262 | 94 | 11 |
| Sneaky | 5,891 | 1,032 | 1,136 | 358 | 43 | 20 |
| Mite | 24,233 | 0 | 796 | 512 | 139 | 55 |
| Univardisty | 13,263 | 1,077 | 2,950 | 362 | 87 | 9 |

Exact pre-transaction snapshots distinguish alive/dead, then half-open embedded spawn rectangles. Every confirmed item buy has official item CanShop=true; every alive field item buy is Tavi. Dead bodies can shop, so alive owner-turn-start counters omit a real purchase opportunity class. First observed gold ≥30 is not necessarily immediately spendable: the alive first eligible owner-start median is Fish 112, Sneaky 93, Mite 116, Univardisty 103, versus first item-buy medians 111/87/117/103. Within-turn reward arrival and dead shopping can make a purchase precede the first sampled alive eligible start. These counters do not measure every legal microstate or establish avoidable delay. A round-one spawn observation is initial placement, not a return; later observed returns and preceding recall commands are retained separately. Recorded recall commands do not prove a successful recall.

Most top-four bodies with no spending earned no gold at all (262 Fish, 358 Sneaky, 512 Mite, 362 Univardisty). Some funded bodies end without item purchases, but neither lifetime affordability nor final gold establishes an actionable missed buy. Opportunity counters sample alive turn starts and are right-censored at game end. Whole-team leftover gold is a sum of private balances, not a transferable pool.

| Team | Altar locks bought / used | Teleport crystals bought / used |
| --- | --- | --- |
| Fish | 0 / 0 | 0 / 0 |
| Sneaky | 0 / 0 | 0 / 0 |
| Mite | 4380 / 2473 | 0 / 0 |
| Univardisty | 6029 / 3355 | 0 / 0 |
| VeryGood | 0 / 0 | 0 / 0 |
| Quantom | 426 / 12 | 0 / 0 |
| hello | 691 / 65 | 0 / 0 |
| Nyxius | 0 / 0 | 0 / 0 |
| geese geese go | 0 / 0 | 0 / 0 |
| Full Damage | 0 / 0 | 18 / 0 |

All consumable purchases are confirmed inventory increases with ten-gold cost each. A use is a native inventory decrement, not proof of strategic value or successful objective protection. Mite’s 4,380 lock purchases all occur alive in its spawn rectangle; Univardisty’s 6,029 include 851 while dead. No alive field consumable purchase occurs. Fish and Sneaky buy none in this cohort. Full Damage’s 18 Teleport crystals have no observed use before the replay ends; unused units are inventory, not an inferred mistake.

## Source-bound transaction examples

Nine compact exports in `cases/index.json` retain exact before/after actor state, match, map, round, input, coordinates, source SHA and replay URL. Examples include Mite versus Univardisty on packs: R25 input545 buys five Jungle Focus shards (150g), and R27 input585 buys five Power Strength shards (150g). Fish examples include monolith R37 input933 Power Strength and collision R42 input599 Bruiser Health. They illustrate actual transitions, not optimality.

The exceptional Tavi case is Mite versus Fish, lanes, `17a5c872-dd06-4e5d-b6af-13c0dfaec889`, R139 actor 4, inputs 4292–4307. Eight consecutive Treasure Health shard buy/sell pairs leave inventory, maxHP and 160 gold unchanged but raise current HP from 210/750 to750/750. Each buy temporarily raises current and maximum HP; each full-price sale reduces maximum HP while preserving current HP up to the new maximum. The next inputs buy five Jungle Focus shards for 150 and an altar lock for 10. The five sale-containing streams have 22 such immediate pairs; all 22 gain HP, totaling 1,462 observed HP across pairs. This is mechanically effective healing, not evidence of private intent or match-winning causality. An independent bounded mechanics fixture reproduces the 210→750 interaction. See `health-refund-cycles.json` and `cases/tavi-health-refund-cycle.json`.

## Audit and reuse boundaries

`current-audit.json` passes with zero errors across all 2,119 streams and 21,312 personal ledgers. Source hashes, roster/final native–API values, gold conservation, all confirmed costs and cross-body resource deltas are checked. There are zero other-body resource changes during confirmed resource transactions. Root’s independent `../transaction-audit.json` also passes all 175,832 candidate events and reconstructs all 42 API item counters, including automatic emblems. The API baseline independently agrees on team totals. All 22 sales are Tavi, one negative item change, exact full-face-value refund; they explain all five initial residual games. Native sale tag 25 was added after the first pass and only those five streams were replayed; `sale-repair-ledger.json` preserves old/new evidence hashes. The other 2,894 tag 16 events have no gold or inventory delta and are not counted as failed purchases.

This study reconstructs public outcomes, commands and state changes. It cannot observe the private shop policy, intended build, rejected commands outside the native stream, counterfactual opportunity cost, or whether a purchase caused a win. Rankings, map mix, chronology, opponent, role, draft composition and game duration may explain differences. Read small champion/map samples with their explicit denominators. Sparse checkpoints and owner-turn-start availability are samples; transaction pre/post states and final ledgers are exact within the pinned decoder.

Authoritative outputs: `current-summary.json`, `current-audit.json`, `team-summary.csv`, `map-team-summary.csv`, `conditional-builds.csv`, `body-ledgers.{csv,jsonl.gz}`, `team-game-ledgers.{csv,jsonl.gz}`, `purchase-events.csv`, `purchase-context.csv`, `checkpoints.csv`, `cases/index.json`, `health-refund-cycles.json`, and `sale-repair-ledger.json`. Source bindings use the same ward manifests. Keep the API accounting baseline, independent transaction audit, mechanics metadata/probes and methods/summary reviews with the evidence package.
