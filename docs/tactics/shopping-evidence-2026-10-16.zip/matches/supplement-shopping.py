"""Cached-output enrichment only: no engine, replay advancement, or new games."""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timezone
import ast,csv,gzip,json,statistics
ROOT=Path(__file__).resolve().parent
def readrows(name):
 with gzip.open(ROOT/name,'rt',encoding='utf8')as f:return[json.loads(line)for line in f]
bodies=readrows('body-ledgers.jsonl.gz');games=readrows('team-game-ledgers.jsonl.gz');summary=json.loads((ROOT/'current-summary.json').read_bytes());bygame={(g['match_id'],g['side']):g for g in games}
# Reuse only our pure, audited summary functions; do not execute its input/scan loop.
tree=ast.parse((ROOT/'analyze-shopping.py').read_text(encoding='utf8'));pure=ast.Module(body=[node for node in tree.body if isinstance(node,ast.FunctionDef)and node.name in['dist','summarize','group','tables']],type_ignores=[]);ns={'Counter':Counter,'defaultdict':defaultdict,'statistics':statistics};exec(compile(pure,'shopping_pure_summary_functions','exec'),ns)
bs=[b for b in bodies if b['latest_slice']and b['band']=='top4_h2h'];gs=[g for g in games if g['latest_slice']and g['band']=='top4_h2h'];summary['latest_h2h']=ns['tables'](bs,gs);summary['latestH2hRawStreams']=len({g['raw_sha256']for g in gs})
summary['noPurchaseContexts']=[]
for team in sorted({(b['rank'],b['team'])for b in bodies}):
 rows=[b for b in bodies if(b['rank'],b['team'])==team];summary['noPurchaseContexts'].append({'rank':team[0],'team':team[1],'bodies':len(rows),'noItemPurchase':sum(b['itemSpend']==0 for b in rows),'noItemPurchaseWithEarnedAtLeast30':sum(b['itemSpend']==0 and b['earnedGold']>=30 for b in rows),'noSpendWithFinalGoldAtLeast150':sum(b['grossSpend']==0 and b['finalGold']>=150 for b in rows),'noSpendWithAliveEligible30OwnerStarts':sum(b['grossSpend']==0 and b['opportunities'].get('shopLocationEligibleWith30',0)>0 for b in rows),'noSpendWithZeroEarned':sum(b['grossSpend']==0 and b['earnedGold']==0 for b in rows)})
contexts=defaultdict(Counter);bychamp=defaultdict(Counter);errors=[];caseextras=[]
fields=['match_id','raw_sha256','map','team','rank','actor','champion','round','input','category','cost','alive_before','x','y','location','can_shop_item_before','can_shop_consumable_before','gold_before','gold_after','initial_or_return_spawn_observation']
with(ROOT/'purchase-context.csv').open('w',newline='',encoding='utf8')as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for ix,file in enumerate((ROOT/'current').glob('*.shopping.json')):
  g=json.loads(file.read_bytes())
  for e in g['events']:
   if not e['confirmed']or e['category']not in['item_purchase','consumable_purchase','item_sale']:continue
   gr=bygame[(g['id'],e['team'])];p=e['before']['position'];bounds=g['geometry']['spawn'];inside=lambda b:p['x']>=b[0]and p['x']<b[2]and p['y']>=b[1]and p['y']<b[3];alive=e['before']['alive']
   location='dead'if not alive else'own_spawn_rectangle'if inside(bounds[e['team']])else'enemy_spawn_rectangle'if inside(bounds[1-e['team']])else'alive_elsewhere'
   key=(gr['rank'],gr['team'],e['category']);contexts[key][location]+=1;bychamp[(gr['rank'],gr['team'],e['name'],e['category'])][location]+=1
   if e['category']=='item_purchase'and not e['canShopItemBefore']:errors.append({'id':g['id'],'input':e['input'],'kind':'confirmed_item_buy_CanShop_false'})
   entry=e['lastObservedSpawnEntry'];entrykind='initial_spawn_observation'if entry and entry['round']<=1 else'observed_return_after_prior_owner_start'if entry else'none'
   w.writerow({'match_id':g['id'],'raw_sha256':g['sourceSha256'],'map':g['map'],'team':gr['team'],'rank':gr['rank'],'actor':e['actor'],'champion':e['name'],'round':e['round'],'input':e['input'],'category':e['category'],'cost':e['cost'],'alive_before':alive,'x':p['x'],'y':p['y'],'location':location,'can_shop_item_before':e['canShopItemBefore'],'can_shop_consumable_before':e['canShopConsumableBefore'],'gold_before':e['before']['gold'],'gold_after':e['after']['gold'],'initial_or_return_spawn_observation':entrykind})
   if gr['rank']<=4 and(e['category']=='item_sale'or not alive or(location=='alive_elsewhere'and e['name']=='Tavi'))and len(caseextras)<24:caseextras.append({'match_id':g['id'],'sourceSha256':g['sourceSha256'],'map':g['map'],'team':gr['team'],'rank':gr['rank'],'location':location,'event':e,'source_file':str(file.resolve())})
  if(ix+1)%500==0:print('Contexts',ix+1,flush=True)
summary['purchaseLocationContexts']=[{'rank':k[0],'team':k[1],'category':k[2],'counts':dict(c),'total':sum(c.values())}for k,c in sorted(contexts.items())];summary['purchaseLocationByChampion']=[{'rank':k[0],'team':k[1],'champion':k[2],'category':k[3],'counts':dict(c),'total':sum(c.values())}for k,c in sorted(bychamp.items())];summary['contextErrors']=errors
summary['definitions']['location']='Exact native pre-state: alive/dead first, then half-open own/enemy embedded spawn rectangles, otherwise alive elsewhere. These are geometry labels, not the complete shop legality rule; official CanShop(true/false) is separately recorded. Alive owner-start opportunity counts exclude dead-state shopping.'
(ROOT/'current-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8');(ROOT/'case-context-extras.json').write_text(json.dumps(caseextras,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'latestH2hRaw':summary['latestH2hRawStreams'],'latestH2hTeams':[(t['team'],t['streams'])for t in summary['latest_h2h']['per_team']],'contextErrors':errors,'itemContexts':[r for r in summary['purchaseLocationContexts']if r['category']=='item_purchase']},ensure_ascii=True,indent=2),flush=True)
