"""Publish compact tables from frozen cached aggregates; no replay access."""
from pathlib import Path
from collections import Counter, defaultdict
import json,csv,hashlib
ROOT=Path(__file__).resolve().parent
s=json.loads((ROOT/'current-summary.json').read_bytes())
def n(x):return f'{x:,}'
def pct(a,b):return f'{100*a/b:.2f}%' if b else '—'
def val(x):return f'{x:g}' if isinstance(x,(float,int)) else '—'
def short(r):return {1:'Fish',2:'Sneaky',3:'Mite',4:'Univardisty',6:'Quantom'}.get(r['rank'],r['team'])
def med(r,key):
 d=r[key];return f"{val(d['median'])} ({n(d['n'])})"
def tbl(headers,rows):return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join('---'for _ in headers)+' |']+['| '+' | '.join(map(str,r))+' |'for r in rows])
def export(name,rows):
 fields=list(dict.fromkeys(k for r in rows for k in r))
 with(ROOT/name).open('w',newline='',encoding='utf8')as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
teams=s['unique']['per_team']; top=teams[:4]
flat=[]
for sec in ['unique','top4_h2h','latest','latest_h2h']:
 for r in s[sec]['per_team']:
  d={'cohort':sec,**{k:r[k]for k in ['rank','team','streams','bodies','earnedGold','grossSpend','netSpend','itemSpend','consumableSpend','saleReceipts','finalGold','itemPurchaseEvents','consumablePurchaseEvents','shardsBought','emblemCount','consumableUses','noSpendBodies','noItemPurchaseBodies','treasureGold']},'netSpendPctIncome':100*r['netSpend']/r['earnedGold'] if r['earnedGold']else None}
  for i in [1,2,3]:
   for k in [f'purchase{i}Round',f'emblem{i}Round']:d[k+'Median']=r[k]['median'];d[k+'N']=r[k]['n']
  for family in ['Monster','Power','Durability','Treasure','Jungle','Home','Bruiser']:d[family+'GrossSpend']=r['familySpend'].get(family,0)
  flat.append(d)
export('team-summary.csv',flat)
buildrows=[]
for sec in ['unique','top4_h2h','latest','latest_h2h']:
 for group in ['per_team_champion','per_map_team_champion']:
  for r in s[sec][group]:
   denominator=sum(r['firstEmblemCounts'].values())
   for item,count in r['firstEmblemCounts'].items():buildrows.append({'cohort':sec,'rank':r['rank'],'team':r['team'],'champion':r['champion'],'map':r.get('map','ALL'),'bodyAppearances':r['bodies'],'noItemPurchaseBodies':r['noItemPurchaseBodies'],'bodiesCompletingFirstEmblem':denominator,'firstCompletedEmblem':item,'firstCompletedCount':count,'shareAmongFirstCompletions':count/denominator,'firstPurchaseMedian':r['purchase1Round']['median'],'firstPurchaseN':r['purchase1Round']['n'],'firstEmblemMedian':r['emblem1Round']['median'],'firstEmblemN':r['emblem1Round']['n']})
export('conditional-builds.csv',buildrows)
maps=[]
for sec in ['unique','top4_h2h','latest','latest_h2h']:
 for r in s[sec]['per_map_team']:
  maps.append({'cohort':sec,**{k:r[k]for k in ['rank','team','map','streams','bodies','earnedGold','grossSpend','netSpend','finalGold','itemPurchaseEvents','consumablePurchaseEvents','noItemPurchaseBodies']},'firstBuyMedian':r['purchase1Round']['median'],'firstBuyN':r['purchase1Round']['n'],'firstEmblemMedian':r['emblem1Round']['median'],'firstEmblemN':r['emblem1Round']['n'],**{f+'GrossSpend':r['familySpend'].get(f,0)for f in ['Monster','Power','Durability','Treasure','Jungle','Home','Bruiser']}})
export('map-team-summary.csv',maps)
cons=defaultdict(Counter)
with(ROOT/'purchase-events.csv').open(encoding='utf8',newline='')as f:
 for r in csv.DictReader(f):
  if r['confirmed']=='True'and r['category']in['consumable_purchase','consumable_use']:cons[(r['team'],r['category'])][r['item_name']]+=int(r['quantity'])
lines=[]
def add(x=''):lines.append(x)
add('# Shopping and resource investment: frozen elite replay cohort')
add('')
add('The 2,119 distinct native raw streams contain **167,011 confirmed shop transactions**: 155,467 item buys (357,296 charged shards) and 11,544 consumable buys. Five shards automatically form one emblem; the 63,744 observed emblem completions are not additional purchases. Native before/after gold, inventory and catalog costs confirm each buy. No XP or champion levels exist in this engine: item points, HP and effective Strength/Focus are recorded separately.')
add('')
add('## Scope and reconstruction')
add('')
add('This is exactly the frozen ward cohort: 3,766 API match IDs, 2,119 distinct raw SHA-256 streams, 4,238 team/game observations and 21,312 champion-body/game appearances. Extra IDs alias 1,647 already counted streams. The frozen top-four head-to-head subset is 2,460 IDs / 1,078 streams. Ranks refer to the 2026-10-15 22:51:52 UTC ladder snapshot; selected games span October 13–15, ending 22:50:49 UTC. All nine maps are covered. No outcome filter was used. Distinct streams are not asserted to be independent bot versions, and private submission/version fields are unavailable.')
add('')
add('The scanner uses the pinned official WASM (`ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc`) and sequential native ReplayNext states. It captures the exact state immediately before and after each resource command, full initial/final roster, alive owner-turn-start gold/shop-location observations, and complete-roster checkpoints every 25 rounds. Gold/items are personal, including separate Cassi and Issac budgets. Team totals below sum those budgets. Gold exists from rewards and recipient-specific bonuses; there is no passive income or starting gold.')
add('')
add('## All ten teams: spending, saving and batch size')
add('')
add(tbl(['Team','Streams / bodies','Earned gold','Item / consumable gross spend','Net / earned','Final gold','No item buy bodies','Median item batch'],[[short(r),f"{n(r['streams'])} / {n(r['bodies'])}",n(r['earnedGold']),f"{n(r['itemSpend'])} / {n(r['consumableSpend'])}",pct(r['netSpend'],r['earnedGold']),n(r['finalGold']),f"{n(r['noItemPurchaseBodies'])} / {n(r['bodies'])}",val(r['purchaseBatchSize']['median'])]for r in teams]))
add('')
add('Across the cohort, earned gold is 11,929,485; gross spend 10,834,320; refunds 660; net spend 10,833,660; final gold 1,095,825. Every personal ledger balances: initial gold + earned + refunds − gross spend = final gold. Gross spend counts health-shard purchases subsequently refunded by Tavi; net spend removes the refunds. Spending totals are duration- and reward-dependent, not efficiency or win-effect estimates.')
add('')
add('Single-shard commands are prominent for VeryGood, geese geese go and Full Damage; each has exactly one shard per item transaction. First/second/third command rounds can therefore coincide or have misleadingly different medians. A 150-gold completed emblem is the comparable build milestone; it may be assembled through several commands or one five-shard batch.')
add('')
add('## Strongest opponents and purchase timing')
add('')
add('All rows here are top-four versus top-four. Cells show median round **(number of bodies reaching that transaction or milestone)**; each column has its own denominator. Transaction rounds are item buys, not individual shards. Bodies that never reach a milestone remain in the reported total bodies but not its timing median.')
add('')
add(tbl(['Team','Streams / bodies','Item buy 1 / 2 / 3','Emblem 1 / 2 / 3','Net / earned'],[[short(r),f"{r['streams']} / {r['bodies']}",' / '.join(med(r,f'purchase{i}Round')for i in [1,2,3]),' / '.join(med(r,f'emblem{i}Round')for i in [1,2,3]),pct(r['netSpend'],r['earnedGold'])]for r in s['top4_h2h']['per_team']]))
add('')
add('The latest sensitivity slice selects the newest two match IDs by timestamp then ID within each unordered team pair × map × game kind, before raw-hash deduplication. It has 1,513 IDs / 1,174 raw streams. Its intersection with top-four head-to-head has **133 raw streams**; the four team appearances below sum to 266.')
add('')
add(tbl(['Team','Recent h2h streams / bodies','First item buy: all h2h → recent','First emblem: all h2h → recent','Net / earned: all h2h → recent'],[[short(a),f"{b['streams']} / {b['bodies']}",f"{med(a,'purchase1Round')} → {med(b,'purchase1Round')}",f"{med(a,'emblem1Round')} → {med(b,'emblem1Round')}",f"{pct(a['netSpend'],a['earnedGold'])} → {pct(b['netSpend'],b['earnedGold'])}"]for a,b in zip(s['top4_h2h']['per_team'],s['latest_h2h']['per_team'])]))
add('')
add('The recent comparison preserves Mite’s Jungle-first pattern (all 342 recent first emblems are Jungle: 193 Strength, 149 Focus) and Univardisty’s mixture of Power, Bruiser and Treasure. Timing and saved-gold levels change: Mite’s recent net-spend fraction falls, while first-emblem timing shifts in different directions across teams. Fish’s Jungle share of first emblems falls from 418/1,719 in all h2h to 18/248 recently; Monster rises from 98/1,719 to 53/248. Those changes make a single all-history “current policy” label unsafe. Map, chronology, opponent, draft and private versions remain confounded even within a team/champion.')
add('')
add('## Build composition and champion conditioning')
add('')
add(tbl(['Team','Power','Durability','Bruiser','Jungle','Monster','Treasure','Home'],[[short(r)]+[n(r['familySpend'].get(f,0))for f in ['Power','Durability','Bruiser','Jungle','Monster','Treasure','Home']]for r in top]))
add('')
add('These are gross gold by item family. **Mite’s 660 Treasure gold is entirely 22 temporary Treasure Health shard purchases, each immediately sold for a 30-gold refund; no Treasure emblem or Treasure bonus income results.** Its retained Treasure investment is zero. Across all ten teams Home purchases are zero. Univardisty spends 68,430 on Treasure and records 30,254 Treasure bonus gold; those are separate descriptive flows, not a causal return-on-investment estimate. The `treasureGold` field tracks Treasure-item bonus only, excluding Vesper’s passive bonus. Camp reward splitting occurs before each recipient’s bonuses; team totals do not imply transfers to teammates.')
add('')
add('Among bodies completing a first emblem, Mite is exactly Jungle Strength 2,257 / Jungle Focus 1,717. Univardisty’s first completions are Power Strength 935, Power Focus 730, Bruiser Health 720, Treasure Focus 388 and Bruiser Strength 96. Fish and Sneaky mix families more broadly; their composition changes with champion and cohort.')
add('')
add(tbl(['Team / champion','Body appearances','No item buy','Most common first completion (count / all first completions)','Most common first-three emblem sequence (count)'],[[short(r)+' / '+r['champion'],r['bodies'],r['noItemPurchaseBodies'],(next(iter(r['firstEmblemCounts']))+f" ({next(iter(r['firstEmblemCounts'].values()))} / {sum(r['firstEmblemCounts'].values())})")if r['firstEmblemCounts']else'—',(' → '.join(r['firstThreeEmblemPrefixes'][0]['items'])+f" ({r['firstThreeEmblemPrefixes'][0]['bodies']})")if r['firstThreeEmblemPrefixes']else'—']for r in s['unique']['per_team_champion']if r['rank']<=4 and r['champion']in['Issac','Stellar','Tavi']]))
add('')
add('Repeated emblems still add their stat points; the same family’s passive is not multiplied by owning it across stats or copies. `batchStatEffectPer30Gold` preserves actual observed batch stat/HP gains grouped by champion, stat and prior-points bucket. It is not a per-point marginal curve or evidence that a particular extra purchase improved the result.')
add('')
add('## Nine maps with the champion held fixed')
add('')
add('Fish/Issac appears on every map and avoids mixing different champion drafts. Counts below condition on the first completed emblem; the body column includes non-completers. These are observed map associations, not proof of map adaptation. Full team × champion × map tables for all ten teams and each temporal slice are in `conditional-builds.csv` and `current-summary.json`.')
add('')
fishmap=[r for r in s['unique']['per_map_team_champion']if r['rank']==1 and r['champion']=='Issac']
add(tbl(['Map','Bodies / first completions','Power Strength','Jungle Strength','Monster Strength','Jungle Health','First item buy round (n)'],[[r['map'],f"{r['bodies']} / {sum(r['firstEmblemCounts'].values())}"]+[r['firstEmblemCounts'].get(f,0)for f in ['Power Emblem of Strength','Jungle Emblem of Strength','Monster Emblem of Strength','Jungle Emblem of Health']]+[med(r,'purchase1Round')]for r in fishmap]))
add('')
add('Fish/Issac’s Monster-first completions occur on expanse (16/48) and rows (19/61); Fish/Stellar also records Monster Focus first on rows (19/40 first completions). This remains chronology-confounded, especially given the recent Fish family shift. Absence in one group is descriptive; no geometric or economic cause is inferred. Map-specific game duration and surviving income opportunities also affect timing and completion rates.')
add('')
add('## Shop context, unspent gold and consumables')
add('')
add(tbl(['Team','Item buys in own spawn','Item buys while dead','Alive field item buys (all Tavi)','No spend / zero earned','No item buy despite ≥30 lifetime earned','No spend with ≥150 final gold'],[[short(r),n(next(x for x in s['purchaseLocationContexts']if x['rank']==r['rank']and x['category']=='item_purchase')['counts'].get('own_spawn_rectangle',0)),n(next(x for x in s['purchaseLocationContexts']if x['rank']==r['rank']and x['category']=='item_purchase')['counts'].get('dead',0)),n(next(x for x in s['purchaseLocationContexts']if x['rank']==r['rank']and x['category']=='item_purchase')['counts'].get('alive_elsewhere',0)),n(next(x for x in s['noPurchaseContexts']if x['rank']==r['rank'])['noSpendWithZeroEarned']),n(next(x for x in s['noPurchaseContexts']if x['rank']==r['rank'])['noItemPurchaseWithEarnedAtLeast30']),n(next(x for x in s['noPurchaseContexts']if x['rank']==r['rank'])['noSpendWithFinalGoldAtLeast150'])]for r in top]))
add('')
add('Exact pre-transaction snapshots distinguish alive/dead, then half-open embedded spawn rectangles. Every confirmed item buy has official item CanShop=true; every alive field item buy is Tavi. Dead bodies can shop, so alive owner-turn-start counters omit a real purchase opportunity class. First observed gold ≥30 is not necessarily immediately spendable: the alive first eligible owner-start median is Fish112, Sneaky93, Mite116, Univardisty103, versus first item-buy medians111/87/117/103. Within-turn reward arrival and dead shopping can make a purchase precede the first sampled alive eligible start. These counters do not measure every legal microstate or establish avoidable delay. A round-one spawn observation is initial placement, not a return; later observed returns and preceding recall commands are retained separately. Recorded recall commands do not prove a successful recall.')
add('')
add('Most top-four bodies with no spending earned no gold at all (262 Fish, 358 Sneaky, 512 Mite, 362 Univardisty). Some funded bodies end without item purchases, but neither lifetime affordability nor final gold establishes an actionable missed buy. Opportunity counters sample alive turn starts and are right-censored at game end. Whole-team leftover gold is a sum of private balances, not a transferable pool.')
add('')
add(tbl(['Team','Altar locks bought / used','Teleport crystals bought / used'],[[short(r),f"{cons[(r['team'],'consumable_purchase')]['Altar lock']} / {cons[(r['team'],'consumable_use')]['Altar lock']}",f"{cons[(r['team'],'consumable_purchase')]['Teleport crystal']} / {cons[(r['team'],'consumable_use')]['Teleport crystal']}"]for r in teams]))
add('')
add('All consumable purchases are confirmed inventory increases with ten-gold cost each. A use is a native inventory decrement, not proof of strategic value or successful objective protection. Mite’s 4,380 lock purchases all occur alive in its spawn rectangle; Univardisty’s 6,029 include 851 while dead. No alive field consumable purchase occurs. Fish and Sneaky buy none in this cohort. Full Damage’s 18 Teleport crystals have no observed use before the replay ends; unused units are inventory, not an inferred mistake.')
add('')
add('## Source-bound transaction examples')
add('')
add('Nine compact exports in `cases/index.json` retain exact before/after actor state, match, map, round, input, coordinates, source SHA and replay URL. Examples include Mite versus Univardisty on packs: R25 input545 buys five Jungle Focus shards (150g), and R27 input585 buys five Power Strength shards (150g). Fish examples include monolith R37 input933 Power Strength and collision R42 input599 Bruiser Health. They illustrate actual transitions, not optimality.')
add('')
add('The exceptional Tavi case is Mite versus Fish, lanes, `17a5c872-dd06-4e5d-b6af-13c0dfaec889`, R139 actor4, inputs4292–4307. Eight consecutive Treasure Health shard buy/sell pairs leave inventory, maxHP and 160 gold unchanged but raise current HP from210/750 to750/750. Each buy temporarily raises current and maximum HP; each full-price sale reduces maximum HP while preserving current HP up to the new maximum. The next inputs buy five Jungle Focus shards for150 and an altar lock for10. The five sale-containing streams have 22 such immediate pairs; all22 gain HP, totaling1,462 observed HP across pairs. This is mechanically effective healing, not evidence of private intent or match-winning causality. An independent bounded mechanics fixture reproduces the 210→750 interaction. See `health-refund-cycles.json` and `cases/tavi-health-refund-cycle.json`.')
add('')
add('## Audit and reuse boundaries')
add('')
add('`current-audit.json` passes with zero errors across all2,119 streams and21,312 personal ledgers. Source hashes, roster/final native–API values, gold conservation, all confirmed costs and cross-body resource deltas are checked. There are zero other-body resource changes during confirmed resource transactions. Root’s independent `../transaction-audit.json` also passes all175,832 candidate events and reconstructs all42 API item counters, including automatic emblems. The API baseline independently agrees on team totals. All22 sales are Tavi, one negative item change, exact full-face-value refund; they explain all five initial residual games. Native sale tag25 was added after the first pass and only those five streams were replayed; `sale-repair-ledger.json` preserves old/new evidence hashes. The other2,894 tag16 events have no gold or inventory delta and are not counted as failed purchases.')
add('')
add('This study reconstructs public outcomes, commands and state changes. It cannot observe the private shop policy, intended build, rejected commands outside the native stream, counterfactual opportunity cost, or whether a purchase caused a win. Rankings, map mix, chronology, opponent, role, draft composition and game duration may explain differences. Read small champion/map samples with their explicit denominators. Sparse checkpoints and owner-turn-start availability are samples; transaction pre/post states and final ledgers are exact within the pinned decoder.')
add('')
add('Authoritative outputs: `current-summary.json`, `current-audit.json`, `team-summary.csv`, `map-team-summary.csv`, `conditional-builds.csv`, `body-ledgers.{csv,jsonl.gz}`, `team-game-ledgers.{csv,jsonl.gz}`, `purchase-events.csv`, `purchase-context.csv`, `checkpoints.csv`, `cases/index.json`, `health-refund-cycles.json`, and `sale-repair-ledger.json`. Source bindings use the same ward manifests. Keep the API accounting baseline, independent transaction audit, mechanics metadata/probes and methods/summary reviews with the evidence package.')
prose='\n'.join(lines)+'\n'
for before,after in [('Fish112','Fish 112'),('Sneaky93','Sneaky 93'),('Mite116','Mite 116'),('Univardisty103','Univardisty 103'),('medians111','medians 111'),('from210','from 210'),('for150','for 150'),('for10','for 10'),('all22','all 22'),('totaling1,462','totaling 1,462'),('all2,119','all 2,119'),('and21,312','and 21,312'),('all175,832','all 175,832'),('all42','all 42'),('All22','All 22'),('tag25','tag 25'),('other2,894','other 2,894'),('tag16','tag 16'),('R139 actor4','R139 actor 4'),('inputs4292','inputs 4292')]:prose=prose.replace(before,after)
(ROOT/'current-findings.md').write_text(prose,encoding='utf8')
print(json.dumps({'findings':str(ROOT/'current-findings.md'),'summary_sha256':hashlib.sha256((ROOT/'current-summary.json').read_bytes()).hexdigest(),'team_rows':len(flat),'conditional_rows':len(buildrows),'map_rows':len(maps)},indent=2))
