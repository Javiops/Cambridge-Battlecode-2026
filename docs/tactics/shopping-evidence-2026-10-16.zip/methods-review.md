# Independent shopping-methods review

Review date: 16 October 2026. Numerical aggregates and the latest-head-to-head/context supplements have passed review; final publication prose is pending. This review covers accounting, extraction definitions, the API baseline, supplied fixtures, repaired sales and grouped summaries. No bot game, replay rescan, upload, or repository edit was performed.

## What the method measures correctly

The cohort remains the frozen ward-study cohort: 3,766 public match identities and 2,119 distinct raw replay streams. A trajectory contributes one observation to each participating team. Ranks refer to the recorded collection snapshot, not historical rank or a known private source version. Raw aliases must remain separate from independent trajectory counts.

`scan-shopping.mjs` compares full states immediately before and after selected native actions. Item purchases require a positive inventory face-value increase equal to the actor's gold loss and reconstructed shard quantity times its catalogue price. This is substantially stronger evidence than a purchase-looking command name.

Five shards of one exact even-ID item combine into an odd-ID emblem automatically. The emblem is not a second charged purchase. For example, the reviewed `fixture-v2/f92b1d52-...` trace contains five Jungle Strength shards bought in one command for 150 gold, with one Jungle Strength emblem created. Count the command as one transaction, the quantity as five bought shards, and the emblem as one completion. The API's odd `itemsBought` entries are historical automatic completions; adding those entries to charged shard counts would double-count spending.

The API baseline contains 21,312 distinct body appearances. All listed purchase-cost reconciliations are exact at 30 gold per shard and 10 per usable consumable. `earnedGold - spentGold - finalGold` is zero for 21,307 bodies. The remaining five bodies are Mite's Tavi on lanes, explained by full-value sales: 22 sales refund 660 gold across those five raw trajectories. Each corrected file matches its repair-ledger hash, has no final-API or cash-ledger errors, and every repaired sale independently satisfies refund = lost inventory face value. Each sale removes exactly one equipment type, changes no consumable inventory, and produces no other body's resource change.

Keep the three ledgers explicit:

```text
gross spend = charged item purchases + charged consumable purchases
net spend   = gross spend - sale refunds
final cash  = initial cash + newly earned gold + refunds - gross spend
```

Refunds are recycled principal, not new earned income. The API `spentGold` is gross purchase spending, including repurchases; it is not net investment. Gross spending can exceed newly earned income after sales. Final inventory face value is a stock and must not be added to historical gross spending as another expenditure.

Equal final inventory and zero net cash spending do not prove that a buy/sell sequence was pointless. The source-bound Mite/Tavi case in `matches/cases/mite-tavi-spawn-healing.json` records eight round-139 Health-shard buy/sell cycles: 240 gross spending, 240 refunds, unchanged inventory and 160 cash, but current HP rises from 210 to 750. This is an immediate retained-health effect, not a demonstrated improvement in match outcome. Separate spawn turn-end healing may make the sequence unnecessary when no useful action occurs before that heal.

## Qualifications needed in tables and prose

- **Personal resources.** Gold, item points, cash and refunds belong to a controlled body. Cassi and Issac require separate denominators. Capture division, who remains to claim a camp, Vesper's innate bonus and Treasure ownership affect personal budgets. Team totals are descriptive sums, not a shared purchasing account.
- **Treasure ledger.** The supplied fixtures distinguish item Treasure income from Vesper's innate income: Vesper without Treasure has zero `treasureGold` increase; with Treasure it records only the item's additional portion. The counter can describe recorded Treasure bonus income, but not net profit relative to a different build or a causal match advantage.
- **Transaction order.** The first three purchase rounds are the first three confirmed item-purchase commands. They are not necessarily the first three individual shards, distinct items, emblems or shopping visits. Several commands can occur in one turn. Distinguish repeated same-family completions from the first family passive unlocked by a body.
- **Point totals.** Catalogue-weighted item points are not XP levels or actual universal stat gains. Champion growth, Ryth's health-to-Strength conversion, Prism's carried-gem Focus and temporary effects change realized stats. Use the separately captured stat blocks when making those claims.
- **Batch-normalized effects.** `batchStatEffectPer30Gold` averages observed transaction gains normalized by batch cost. Transactions have equal statistical weight even when batch sizes differ. Completion bonuses, family mixtures and champion kits remain mixed within a point bucket. This is not the counterfactual marginal value of the next shard or proof of a universal diminishing-return curve.
- **Consumable use.** An inventory-decreasing native use confirms consumption or initiation. It does not by itself establish completed teleport arrival, useful altar denial, or value greater than the purchase's opportunity cost.
- **Alive-only owner-start observations.** Opportunity/cash samples contain first observations of living owner turns. Dead bodies can also shop, but are excluded from these samples. The samples miss gold changes and shopping access later in the same turn. They therefore cannot establish every legal purchase opportunity, universal idle-cash time, or a failure to purchase when a specific item was legally desirable.
- **Permission versus a chosen item.** `CanShop(false)` is a general equipment permission check, with the current location and restrictions. It is not proof that every particular item/count was affordable and legal. Threshold counters at 10/30/150 gold should be labelled sampled states, not available ideal purchases or wasted turns.
- **Spawn entry and recall.** Last observed outside-to-inside spawn transitions are between living owner-start samples and may cross death/respawn or other unobserved movement. A prior recall command is not proof it completed or caused that entry. Neither field independently measures a return trip's causal cost.
- **Censoring and conditional medians.** First purchase/completion timings are conditional on the event occurring unless a survival-style analysis is supplied. A no-purchase body may lack income, access, time or a useful target. Game end truncates later purchases, Treasure returns, cash histories and repeated investments. End cash is not automatically waste, and spending before game end is not automatically useful.
- **Confounding.** Map size, draft slots/body counts, champion kit, Tavi's field access, opponent, game length, income opportunities and outcome all vary. Current-rank labels and observed build frequencies cannot identify causal item value, an optimal fixed build, or a win-rate benefit. Use stratified comparisons and describe remaining confounding.
- **Sale classification.** The scanner's sale branch accepts positive refunds with inventory loss without itself testing full-value equality. The five actual repaired cases pass the stricter independent equality and single-item checks. Preserve those checks if sale extraction is generalized.
- **Executable scope.** Controlled cases and supplied consistency checks are pinned to WASM `ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc` and SDK/CLI 2.1.6. The final evidence record reports 51 controlled cases and 35 passing consistency checks, including the bounded healing fixtures. This review checks recorded consistency and hashes; it does not rerun the fixtures or establish byte identity with the currently deployed server.

## Completed numerical review and remaining publication review

The numerical review reconciled every one of 21,312 body ledgers to the source-verified API baseline and checked 4,238 team-game observations. It independently recomputed all 1,909 original grouped summary rows and 271 latest-head-to-head rows, including distributions, conditional timing denominators, prefixes and owner-start counters. The transaction export reproduces all 175,832 recorded events; the location supplement reproduces 167,033 confirmed purchase/sale contexts. The latest selection is 1,513 match IDs, 1,174 raw streams, including 133 latest top-four-head-to-head streams.

All checks passed. Final publication tables, rounding, source-bound case claims and causal language still require review after the report freezes. Preserve body/transaction/item/sample denominators and the timing limitations above; in particular, 600 bodies buy before their first observed eligible-30 owner start, so that observed timing difference cannot be presented as a causal delay. Detailed checks, scope and hashes are in `summary-review.json`.
