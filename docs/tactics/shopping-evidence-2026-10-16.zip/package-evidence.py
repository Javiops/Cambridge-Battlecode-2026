"""Curated full-table shopping evidence, with explicit omissions and no recursive artifacts."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parent;P=R/'publication'
sha=lambda b:hashlib.sha256(b).hexdigest()
include=['mechanics.md','mechanics-evidence.json','mechanics-metadata.json','mechanics-probes.json','our-policy-review.md','our-policy-notes.json','economic-reasoning.md','api-accounting-baseline.json','api-accounting-bodies.csv','transaction-audit.json','methods-review.md','summary-review.json','publication-review.json','audit-api.py','audit-transactions.py','extract-healing-case.py','plot-shopping.py','build-report.py','package-evidence.py',
 'matches/current-findings.md','matches/current-summary.json','matches/current-audit.json','matches/evidence-index.json','matches/team-summary.csv','matches/map-team-summary.csv','matches/conditional-builds.csv','matches/body-ledgers.csv','matches/team-game-ledgers.csv','matches/purchase-events.csv','matches/purchase-context.csv','matches/checkpoints.csv','matches/sale-repair-ledger.json','matches/manifest-sale-repair.json','matches/health-refund-cycles.json','matches/case-context-extras.json','matches/current/run-report.json','matches/current/shop-catalog.json',
 'publication/11-shopping-and-investment.md','publication/shopping-research-2026-10-16.md','publication/04-vision-and-information.md','publication/shopping-figure-sources.json']
for pattern in ['probes/*.mjs','probes/*.py','probes/*review*.json','matches/*.py','matches/*.mjs','matches/cases/*.json','publication/shopping-*.svg','publication/shopping-*.png']:
 include +=[p.relative_to(R).as_posix()for p in R.glob(pattern)]
payload={name:(R/name).read_bytes()for name in sorted(set(include))}
ward=R.parent/'ward-research'
payload['prior-cohort/cohort-audit.json']=(ward/'cohort-audit.json').read_bytes()
payload['prior-cohort/ladder-snapshot.json']=(ward/'acquisition/ladder-snapshot.json').read_bytes()
payload['prior-cohort/memory-correction.md']=(ward/'memory-correction.md').read_bytes()
payload['dependencies/map-variants.mjs']=(R.parent/'battlecode-bot-v1/r2-ward/map-variants.mjs').read_bytes()
with zipfile.ZipFile(ward/'publication/ward-evidence-2026-10-16.zip')as z:payload['replay-index.csv']=z.read('replay-index.csv')
readme='''# Shopping research evidence — 16 October 2026

RESEARCH ONLY. This is not a Battlecode bot submission.

Same frozen cohort as the ward study: 3,766 API game IDs, 2,119 distinct raw
replay streams, 21,312 champion-body appearances. replay-index.csv retains
every selected ID, alias binding, raw/bundle hash and public bundle URL.
The prior cohort audit already verified all source bundles/CRC/attribution.

Native observations confirm 155,467 item-buy transactions (357,296 charged
shards), 11,544 consumable buys, 63,744 automatic emblem completions, 5,905
consumable uses and 22 full-refund Tavi sales. Automatic emblems are not extra
charged purchases. Gross spend, refunds, net spend and personal final cash
remain separate. Twenty-two Tavi Health-shard buy/sell pairs actually heal
current HP at spawn: zero net cash/inventory is not proof of useless churn.

Included: complete descriptive summary and transaction/body/team/context/
checkpoint CSVs; precise before/after illustrative cases; source identities,
mechanics metadata/probes (51 cases, 35 checks); independent final API and
arithmetic audits, methods/summary/publication reviews, source-code audit,
analysis/plot/probe scripts, SVG/PNG figures and final documentation sources.
The exact scope of each audit is stated in its file. The independent arithmetic
audit does not independently decode every replay a second time.

Excluded: the approximately 521 MB complete per-match native pre/post state tree,
all original raw replays/bundles and history/group API payloads, credentials,
private opponent code, repository metadata, runtime installations and vendor
WASM/SDK binaries. Per-match analysis hashes remain in the audits. The index
permits retrieving the public source bundles. This is not a complete raw dump.

Reproduction requires the official engine WASM with SHA-256
ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc
and recorded SDK/CLI2.1.6 metadata. Scripts preserve original workspace-relative
paths: configure loaders/runtimes/source manifests for a new checkout. The
included loader is source provenance, not a one-command portable installation.
The original scan omitted sale enum25; five residual-ledger trajectories were
replayed with it. sale-repair-ledger.json preserves that correction. The final
scanner includes25; all final personal ledgers and API counters balance.

Ranks are a frozen snapshot, private upload/version fields are null, repeated
raw hashes are aliases, and distinct trajectories are not necessarily different
private bot versions or independent experiments. Owner-start opportunity samples
exclude dead shopping and intra-turn access. Conditional timings are censored
by game end; grouped medians are not causal delay or optimal deadlines.
Confirmed consumable use is not proof of strategically useful objective effect.

The included own source audit is pinned to e72cec8. Proposed policy is Planned;
no bot strategy or competitive test matches were performed in this task.
The prior ward memory correction is documented: byte7 actively carries danger
alerts when help is disabled; do not overwrite it as if it were unused.

manifest.json lists every payload's byte length and SHA-256. The external ZIP
manifest is intentionally excluded to prevent recursive hashes.
'''
payload['README.txt']=readme.encode('utf8')
manifest={'purpose':'Curated shopping research evidence, not a bot upload or complete raw state archive','game_ids':3766,'raw_replay_streams':2119,'source_summary_sha256':sha((R/'matches/current-summary.json').read_bytes()),'source_transaction_audit_sha256':sha((R/'transaction-audit.json').read_bytes()),'files':{n:{'bytes':len(b),'sha256':sha(b)}for n,b in sorted(payload.items())}}
payload['manifest.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf8')
target=P/'shopping-evidence-2026-10-16.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,b in sorted(payload.items()):
  assert not Path(name).is_absolute()and'..'not in Path(name).parts
  info=zipfile.ZipInfo(name,(2026,10,16,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
  z.writestr(info,b,compresslevel=9)
with zipfile.ZipFile(target)as z:
 assert z.testzip()is None and len(z.namelist())==len(payload)
 for name,b in payload.items():assert z.read(name)==b
result={'archive':target.name,'bytes':target.stat().st_size,'sha256':sha(target.read_bytes()),'entries':len(payload),'payload_manifest_sha256':sha(payload['manifest.json']),'full_native_state_tree_included':False,'raw_sources_included':False}
(P/'shopping-evidence-2026-10-16.manifest.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,indent=2))
