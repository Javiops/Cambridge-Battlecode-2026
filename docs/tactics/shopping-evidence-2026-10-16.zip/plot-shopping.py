"""Standalone research figures from frozen native transactions / descriptive summaries."""
from pathlib import Path
import sys,json,hashlib
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R.parent/'battlecode-match-analysis/pythonlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
P=R/'publication';P.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white'})

case=json.loads((R/'matches/cases/mite-tavi-spawn-healing.json').read_bytes());es=case['events']
x=list(range(len(es)+1));hp=[es[0]['before']['health']]+[e['after']['health']for e in es];maxhp=[es[0]['before']['maxHealth']]+[e['after']['maxHealth']for e in es];gold=[es[0]['before']['gold']]+[e['after']['gold']for e in es]
fig,axes=plt.subplots(2,1,figsize=(12,6.5),sharex=True,gridspec_kw={'height_ratios':[2,1]})
axes[0].plot(x,hp,'o-',color='#21856a',label='Current HP',linewidth=2);axes[0].step(x,maxhp,where='post',color='#80919c',linestyle='--',label='Maximum HP');axes[0].set_ylabel('Health');axes[0].set_ylim(150,870);axes[0].legend(loc='lower right',ncol=2);axes[0].grid(axis='y',alpha=.2)
axes[1].plot(x,gold,'o-',color='#b47a17',linewidth=2);axes[1].set_ylabel('Gold');axes[1].set_ylim(110,175);axes[1].set_yticks([130,160]);axes[1].grid(axis='y',alpha=.2)
axes[1].set_xticks(x);axes[1].set_xticklabels(['Start']+['Buy'if i%2 else'Sell'for i in range(1,17)],rotation=45,ha='right');axes[1].set_xlabel('Recorded transaction order, all within round 139')
fig.suptitle('Mite Tavi: 210 → 750 HP, same gold and inventory after eight buy/sell cycles',fontweight='bold',fontsize=13,x=.5,y=.97)
fig.text(.08,.02,'Native replay: Mite vs Fish, lanes · Net gold cost 0 · Gross buys 240, refunds 240\nThis demonstrates healing mechanics; it does not prove an advantage over waiting for the spawn end-of-turn heal.',fontsize=9,color='#4e5964')
fig.subplots_adjust(left=.08,right=.98,top=.89,bottom=.19,hspace=.15)
for ext in ['png','svg']:fig.savefig(P/f'shopping-tavi-healing.{ext}',dpi=170)
plt.close(fig)

source=R/'matches/current-summary.json';a=json.loads(source.read_bytes());rows=a['top4_h2h']['per_map_team_champion'];maps=['collision','corners','elkring','expanse','interlock','lanes','monolith','packs','rows'];families=['Power','Bruiser','Jungle','Monster','Treasure','Durability','Home'];colors={'Power':'#366ea9','Bruiser':'#8c65a3','Jungle':'#318568','Monster':'#c48735','Treasure':'#d5b322','Durability':'#c25a55','Home':'#7b8793'}
fig,axes=plt.subplots(1,2,figsize=(13.5,6.8),sharey=True)
for ax,champ in zip(axes,['Issac','Stellar']):
 for i,map_name in enumerate(maps):
  r=next((r for r in rows if r['rank']==1 and r['champion']==champ and r['map']==map_name),None)
  if r is None:continue
  counts={f:sum(n for item,n in r['firstEmblemCounts'].items()if item.startswith(f+' '))for f in families};n=sum(counts.values());start=0
  for f in families:
   width=counts[f]/n*100 if n else 0
   if width:ax.barh(i,width,left=start,color=colors[f],height=.65)
   start+=width
  ax.text(102,i,f"{n}/{r['bodies']}",va='center',fontsize=9,color='#4e5964')
 ax.set_title(champ,fontweight='bold');ax.set_xlim(0,119);ax.set_xticks([0,25,50,75,100],['0%','25%','50%','75%','100%']);ax.grid(axis='x',alpha=.14);ax.set_xlabel('Family of first completed emblem');ax.set_yticks(range(len(maps)),maps)
axes[0].invert_yaxis()
fig.suptitle('Fish vs current top four: first-emblem families on the same champion',fontweight='bold',fontsize=13,y=.97)
fig.legend(handles=[Patch(color=colors[f],label=f)for f in families if any(any(item.startswith(f+' ')for item in r['firstEmblemCounts'])for r in rows if r['rank']==1 and r['champion']in ['Issac','Stellar'])],ncol=5,loc='lower center',bbox_to_anchor=(.5,.10),frameon=False)
fig.text(.07,.025,'Right labels: bodies completing a first emblem / all appearances. Bars exclude non-completers.\nDifferent drafts, game lengths, opponents, income allocation and unexposed bot versions remain confounded; map causation is not established.',fontsize=9,color='#4e5964')
fig.subplots_adjust(left=.09,right=.96,top=.88,bottom=.24,wspace=.2)
for ext in ['png','svg']:fig.savefig(P/f'shopping-first-emblem-maps.{ext}',dpi=170)
plt.close(fig)
(P/'shopping-figure-sources.json').write_text(json.dumps({'source_summary_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'cohort':'top4_h2h','team':'Intercontinental Fish','bodies':['Issac','Stellar'],'map_order':maps,'healing_case_sha256':hashlib.sha256((R/'matches/cases/mite-tavi-spawn-healing.json').read_bytes()).hexdigest(),'figures':['shopping-tavi-healing.png','shopping-first-emblem-maps.png']},indent=2)+'\n')
print('Created two PNG and SVG figures.')
