# Correction: active byte-7 danger alerts in the audited stable bot

Audit date: 2026-10-16. Source: the six-file cleaned study27 combat baseline at full commit `e72cec84391cf0623d15c2eb3f2f864e2b0bddea`, available in `work/study27-economy-v2/baseline/src/`; its hashes match `work/study27-combat/publication/src/` and the baseline manifest.

The earlier ward source note described byte 7 as an optional help slot without identifying its active alternative. **Byte 7 is already used for danger alerts in the current configuration.** It is not free capacity for a new ward or shopping protocol. This is a source-audit correction, not an engine change or newly implemented behavior.

| Bytes | Current use | Code proof |
| --- | --- | --- |
| 0-4 | Camp claims; packed six-body claims where enabled | `main.cpp:1561-1564`, `:1570-1627`; `params.h:57` enables `P_D5_PACKED_CLAIMS 1`. |
| 5-6 | Camp lifecycle broadcast: group index plus estimated ready round | `main.cpp:1562-1564`, `:1638-1641`. |
| 7 | **Active danger alert** when `P_CALLHELP=0`; optional help alert replaces this format when enabled | `params.h:33` sets `P_DANGER 3`; `fight.h:18-20` defaults `P_CALLHELP 0` and params has no override. `main.cpp:2462` calls `update_danger` when danger is enabled. |

The active danger path is explicit in `main.cpp:1757-1786`:

```cpp
// Danger spot: an enemy pack (P_DANGER+ champions within 4 of each other) seen this turn, or
// one an ally reported in byte 7 (nearest altar index + 1, then round / 8, mod 32).
...
if (P_CALLHELP) return;  // byte 7 belongs to the help call then
if (s.danger_r == round) {
    int ai = -1, ad = P_DANGER_R + 1;
    for (std::size_t i = 0; i < s.altars.size() && i < 7; ++i)
        if (dist(s.altars[i], s.danger_p) < ad) { ad = dist(s.altars[i], s.danger_p); ai = static_cast<int>(i); }
    if (ai >= 0) write_sm(7, static_cast<std::uint8_t>((ai + 1) | (((round / 8) & 31) << 3)));
    return;
}
int b = read_sm()[7];
int ai = (b & 7) - 1, age = ((round / 8) - (b >> 3)) & 31;
if (ai < 0 || ai >= static_cast<int>(s.altars.size()) || age * 8 > P_DANGER_T) return;
```

When a visible enemy has at least `P_DANGER` enemies within distance 4, including itself, the bot records the location/round (`main.cpp:1760-1768`). With help disabled it can publish the nearest representable altar index in the low three bits and `floor(round/8) mod 32` in the high five bits. This is a coarse location and age report; it is not exact shared vision. The receiver anchors the alert to that altar (`:1783-1785`).

If help is enabled, the danger routine returns before touching byte 7 (`:1771`). The alternative help sender writes enemy roster index plus `round mod 32` (`fight.h:183-197`); its reader accepts recent reports and searches only currently visible foes (`:200-211`). These are mutually selected formats with different timestamp scales, not compatible simultaneous messages.

Recommended publication correction: “The current source allocates bytes 0-4 to camp claims, bytes 5-6 to camp lifecycle, and byte 7 to active danger alerts (or the alternative help signal when enabled). Any new information-sharing protocol must explicitly migrate and preserve these uses.”

No files in the bot or publication were changed for this correction, and no new tests were run.
