import fs from 'node:fs';
import {E,out,checked,v,scratch,state} from '../../ward-research/mechanics-harness.mjs';
import {createGame} from '../../ward-research/probe-grid.mjs';
const exports=Object.fromEntries(Object.entries(E).filter(([n,f])=>typeof f==='function' && /Item|Shop|Consum|Gold|Sell|Damage|Settings|Champion_Design|Passive/.test(n)).map(([n,f])=>[n,f.length]));
const items=[],consumables=[],champions=[];
for(let id=0;id<42;id++){checked('Game_Visualiser_GetShopEntry',0,id,scratch);const d=v();items.push({id,cost:d.getUint32(scratch,true),combineCount:d.getUint32(scratch+4,true),result:d.getUint32(scratch+8,true),carryLimit:d.getUint32(scratch+12,true),healthPoints:d.getInt32(scratch+16,true),strengthPoints:d.getInt32(scratch+20,true),focusPoints:d.getInt32(scratch+24,true),passive:d.getUint32(scratch+28,true),passiveMagnitude:d.getFloat32(scratch+32,true),purchasable:!!d.getUint32(scratch+36,true)});}
for(let id=0;id<4;id++){checked('Game_Visualiser_GetShopEntry',1,id,scratch);consumables.push({id,words:Array.from({length:10},(_,k)=>v().getUint32(scratch+k*4,true))});}
const g=createGame();
for(let id=0;id<13;id++){checked('Game_API_Champion_Design',g,id,scratch);const d=v(),f=k=>d.getFloat32(scratch+k,true),i=k=>d.getInt32(scratch+k,true);const ability=p=>{let kind=i(p);return{kind,cooldown:i(p+4),targets:i(p+12),attributes:i(p+16),range:f(p+20),modifier:kind===3?f(p+28):[2,4,5,7].includes(kind)?f(p+24):null,radius:kind===3?f(p+24):null,duration:[4,7].includes(kind)?i(p+28):kind===3?i(p+32):null}};const c={id,baseHealth:f(100),healthGrowth:f(104),baseStrength:f(108),strengthGrowth:f(112),baseFocus:f(116),focusGrowth:f(120),campDamageMultiplier:f(124),vision:i(88),move:i(92),range:i(96),ability0:ability(12),ability1:ability(48)};checked('Game_API_GetChampionPassiveInfo',id,scratch);c.passive={kind:v().getUint32(scratch,true),magnitude:v().getFloat32(scratch+4,true)};champions.push(c);}
checked('Game_API_GetSettings',scratch);const settingsBytes=Array.from(new Uint8Array(E.memory.buffer,scratch,160));
const settings={captureTime:v().getInt32(scratch,true),campSleepTime:v().getInt32(scratch+4,true),respawnTime:v().getInt32(scratch+8,true),recallTime:v().getInt32(scratch+12,true),killGold:v().getUint32(scratch+44,true),assistGold:v().getUint32(scratch+48,true),passiveGold:v().getUint32(scratch+52,true),spawnHealing:v().getFloat32(scratch+56,true)};
const result={exports,items,consumables,champions,settings,settingsBytes,initial:state(g)};
fs.writeFileSync('work/shopping-research/mechanics-metadata.json',JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
checked('Game_Destroy',g);
