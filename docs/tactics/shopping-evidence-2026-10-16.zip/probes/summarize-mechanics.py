import json,hashlib,pathlib,datetime
root=pathlib.Path('work/shopping-research')
records=json.loads((root/'mechanics-probes.json').read_text())
metadata=json.loads((root/'mechanics-metadata.json').read_text())
by={r['name']:r for r in records}
checks=[]
def check(name,condition):
 checks.append({'name':name,'pass':bool(condition)})
check('all_fixture_cases_execute',all('error' not in r for r in records))
check('21_shards_cost_30_and_combine_5',all(x['cost']==30 and x['combineCount']==5 and x['purchasable'] for x in metadata['items'][::2]))
check('21_emblems_cost_150_are_not_directly_buyable',all(x['cost']==150 and not x['purchasable'] for x in metadata['items'][1::2]))
check('initial_idle_gold_zero',all(x['gold']==0 for x in by['initial_and_idle_income']['before']+by['initial_and_idle_income']['after']))
for label,champ,camp in [('base',100,100),('durability',90,90),('durability_double',90,90),('jungle',100,70),('jungle_double',100,70),('both',90,63)]:
 r=by['incoming_damage_'+label];check('incoming_'+label,r['champDamage']==champ and r['campDamage']==camp)
for label,basic,spell in [('base',50,100),('monster_strength',82.5,110),('monster_focus',55,165),('monster_double',82.5,165),('power_strength',80,100)]:
 r=by['outgoing_damage_'+label];check('outgoing_'+label,r['basicDamage']==basic and r['spellDamage']==spell)
for copies,timer in [(0,5),(1,3),(2,3)]:check('home_'+str(copies),by['home_recall_duration_'+str(copies)]['after']['channelTimer']==timer)
r=by['gold_bonus_treasure'];check('bonus_fraction_carries', [x['delta'] for x in r['stages'][1:5]]==[1,1,1,3])
check('treasure_duplicate_crossstat_no_additional_bonus',[x.get('delta') for x in by['gold_bonus_treasure']['stages']]==[x.get('delta') for x in by['gold_bonus_treasure_double']['stages']])
check('vesper_treasure_additive_40pct',by['gold_bonus_vesper_treasure']['stages'][-1]['delta']==126)
r=by['capture_split_bonus_true'];check('capture_base_split_then_personal_bonus',[x['gold'] for x in r['after'][:2]]==[75,62] and r['after'][0]['treasureGold']=='12')
r=by['gold_and_items_personal_cassi_issac'];check('cassi_issac_resources_separate',r['after'][0]['gold']==150 and r['after'][1]['gold']==0 and sum(r['after'][1]['items'])==0)
r=by['dead_shop_gold_persistence'];check('death_preserves_gold_equipment',r['before']['gold']==r['dead']['gold'] and r['before']['items']==r['dead']['items'])
r=by['tavi_field_and_sale'];check('tavi_field_health_no_heal',r['before']['health']==r['after']['health'] and r['after']['maxHealth']-r['before']['maxHealth']==450)
check('tavi_spawn_full_sale_not_earned',r['afterSell']['gold']-r['beforeSell']['gold']==150 and r['afterSell']['earnedGold']==r['beforeSell']['earnedGold'])
r=by['spawn_health_purchase_and_sale'];check('spawn_health_heals_exact_max_delta',r['after5']['health']-r['before']['health']==r['after5']['maxHealth']-r['before']['maxHealth']==600)
check('tavi_dead_sell_legal',by['dead_tavi_sell']['sell']['code']==0)
check('standard_sell_illegal',by['standard_field_and_sell']['sell']['code']!=0)
for name,code in [('shop_while_recalling',34),('shop_while_stunned',33)]:check(name,by[name]['item']['code']==code and by[name]['consumable']['code']==code)
r=by['cast_then_shop_does_not_spend_cast'];check('purchase_cast_purchase_same_turn',r['purchase']['code']==r['cast']['code']==r['purchase2']['code']==0)
check('home_can_break_capture_overlap',by['capture_and_recall_false']['observations'][-1]['self']['gems']==22 and by['capture_and_recall_true']['observations'][-1]['self']['gems']==0)
r=by['shop_and_sale_step_kinds'];check('native_shop_and_sale_step_kinds',r['itemKind']==r['consumableKind']==13 and r['sellKind']==25)
r=by['tavi_bounded_health_shard_buy_sell_healing'];check('tavi_bounded_health_roundtrip',len(r['cycles'])==8 and r['before']['health']==210 and r['after']['health']==r['after']['maxHealth']==750 and r['before']['gold']==r['after']['gold']==160 and r['before']['items']==r['after']['items'] and r['before']['earnedGold']==r['after']['earnedGold'] and r['before']['flags']==r['after']['flags'] and r['cast']['code']==0 and all(c['purchase']['code']==c['sale']['code']==0 for c in r['cycles']))
sources=[]
for p in [pathlib.Path('work/battlecode-review/docs/GameRules.md'),pathlib.Path('work/study27-economy-v2/arena/sdk/cpp/cambc.h'),pathlib.Path('work/study27-economy-v2/arena/sdk/cpp/imports.h'),pathlib.Path('work/battlecode-bot-v1/r2-research/v0_0_1-ctH8uuEb.wasm'),pathlib.Path('work/battlecode-bot-v1/r2-research/index-B9nRJ5Z_.js'),root/'live-items-rules.txt',root/'mechanics-probes.json',root/'mechanics-metadata.json',root/'probes/metadata.mjs',root/'probes/shopping.mjs']:
 if p.exists():sources.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
result={'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Exact shopping mechanics and analytic investment consequences. No bot implementation and no competitive outcome test.','cli_sdk_version':'2.1.6','engine_sha256':'ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc','official_urls':['https://2026a.battlecode.co.uk/game/docs/items','https://2026a.battlecode.co.uk/game/api'],'fixture_case_count':len(records),'checks':checks,'all_pass':all(x['pass'] for x in checks),'sources':sources,'caveats':['Exact executable edges are pinned to the recorded public editor WASM; do not assert a byte-identical currently deployed server executable.','Sandbox_GiveGold uses the engine earned-gold path; actual camp split and kill fixtures independently verify those income sources.','Damage fixtures verify actual engine actions and sandbox damage rather than infer multipliers from item text.','Displayed lifetime gold ledger counts sandbox-granted fixture gold; fixture gold is not real match earnings.','No item has XP, armor, attack-speed or cooldown-reduction points; Focus changes kit magnitudes where supported, not range, duration or cooldown.']}
(root/'mechanics-evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'cases':len(records),'checks':len(checks),'all_pass':result['all_pass'],'failures':[x for x in checks if not x['pass']]},indent=2))
