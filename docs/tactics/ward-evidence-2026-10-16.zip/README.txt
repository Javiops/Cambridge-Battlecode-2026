# Ward research evidence — 16 October 2026

Research documentation only; this ZIP is NOT a Battlecode bot submission.

The core cohort contains 3,766 public game IDs and 2,119 raw replay streams.
The replay index preserves every ID's team attribution, public bundle URL,
raw/bundle SHA-256, and the exact representative used for native inspection.
Current-summary.json contains descriptive tables; current-audit.json retains
per-representative output hashes and ward/sample totals. The independent cohort
and summary reviews state their precise scopes. Illustrated cases contain exact
embedded terrain, owner/ward state, masks and recorded follow-up commands.
The compact Mite-v-Fish case instead retains audited placement/later records,
counts, enemy positions and source hashes, without full later tile-mask arrays.

Included: compact evidence, case frames, source/probe notes, engine fixtures,
public source identities and the actual analysis scripts. All match sources are
public API/replay observations; no opponents' private bot code is present.

Excluded: the ~1.90 GB complete per-placement/action trace tree, all raw replays
and bundles, all history/group API payloads, credentials, private configs,
repository metadata, runtime installations, and the vendor engine binary/SDK.
These remain either local evidence or separately retrievable public source.
The archive is not a substitute for those full raw source files.

To reproduce, retrieve the public bundles listed in replay-index.csv and verify
their SHA-256 and replay.repl26a CRC/member bytes. Use the recorded official
engine WASM ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc
with matching SDK/CLI2.1.6. The scripts retain their original workspace-relative
loader and runtime paths for provenance: configure those paths for your checkout,
including dependencies/map-variants.mjs, before running them. They are source
records, not a promised one-command portable rerun installation.

Native placement scans advance recorded replays, not new bots. Mechanics fixtures
use controlled editor sandbox setups. They do not establish a winning strategy.
Recorded non-ward commands are not independently classified as successful.
Later owner vision is sampled on alive owner turns, not every legal opportunity.
Ranks are a frozen retrieval snapshot; all public version fields were null.
Repeated raw streams are aliases, not independent new executions.

The source of each table and all archive payload hashes are in manifest.json.
