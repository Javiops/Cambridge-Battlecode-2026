"""Read-only, timestamped public ladder/history acquisition."""
from pathlib import Path
from datetime import datetime,timezone
import urllib.request,json,hashlib,time
ROOT=Path(__file__).resolve().parent
BASE='https://2026a.battlecode.co.uk'
def fetch(url,path):
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url,timeout=35)as response:raw=response.read()
            break
        except Exception:
            if attempt==2:raise
            time.sleep(1+attempt)
    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
    return json.loads(raw),{'url':url,'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'fetched_at_utc':datetime.now(timezone.utc).isoformat()}
if __name__=='__main__':
    d,ref=fetch(BASE+'/api/v1/ladder',ROOT/'api/ladder.json')
    teams=d['teams'][:10]
    (ROOT/'ladder-snapshot.json').write_text(json.dumps({'fetch':ref,'updatedAt':d.get('updatedAt'),'teams':teams},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps({'snapshot':ref,'top10':[{k:t[k]for k in ['rank','teamId','name','rating','matches']}for t in teams]},ensure_ascii=True,indent=2))
    tid=teams[0]['teamId']
    history,h=fetch(BASE+'/api/v1/match-groups?teamId='+tid+'&limit=100',ROOT/'api/history-probe.json')
    print('history-type',type(history).__name__)
    if isinstance(history,dict):
        print('history-keys',list(history))
        for k,v in history.items():
            if isinstance(v,list):print(k,'count',len(v),'first',json.dumps(v[:1],ensure_ascii=True)[:2200])
            else:print(k,str(v)[:200])
