"""Acquire every selected series' public per-map statistics; no online actions."""
from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter,defaultdict
import json,hashlib
from discover import fetch,BASE,ROOT
read=lambda p:json.loads(Path(p).read_bytes())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
index=read(ROOT/'history-index.json');rank={t['teamId']:t for t in read(ROOT/'api/ladder.json')['teams']}
def one(group):
    path=ROOT/'api/groups'/(group['id']+'.json');url=BASE+'/api/v1/match-groups/'+group['id']
    if path.exists():data=read(path);ref={'url':url,'path':str(path),'sha256':sha(path),'cached':True}
    else:data,ref=fetch(url,path)
    assert data['group']['id']==group['id']
    assert {s['teamId']for s in data['group']['sides']}=={s['teamId']for s in group['sides']}
    return group,data,ref
results=[];errors=[]
with ThreadPoolExecutor(max_workers=10)as pool:
    futures={pool.submit(one,g):g for g in index['groups']}
    for future in as_completed(futures):
        group=futures[future]
        try:results.append(future.result())
        except Exception as e:errors.append({'id':group['id'],'error':repr(e)})
        if len(results)%250==0:print('Series statistics',len(results),'/',len(index['groups']),'errors',len(errors),flush=True)
groups=[];games={};fingerprints=defaultdict(list)
for ordinal,(group,data,ref)in enumerate(sorted(results,key=lambda r:r[0]['createdAt'],reverse=True),1):
    groups.append({**group,'index':ordinal,'api_reference':ref,'game_ids':[m['id']for m in data['matches']]})
    for game in data['matches']:
        if game['id']in games:assert games[game['id']]['game']==game;continue
        teams={s['side']:{'teamId':s['teamId'],'name':s['teamName'],'rank':rank.get(s['teamId'],{}).get('rank'),
                          'version':s.get('version'),'submissionId':next((x.get('submissionId')for x in data['group']['sides']if x['teamId']==s['teamId']),None)}for s in game['sides']}
        request={'id':game['id'],'map':game.get('mapName')or game.get('map'),'series_id':group['id'],'series_index':ordinal,
                 'kind':group['kind'],'created_at':game['createdAt'],'cohort_band':group['cohort_band'],'teams':teams,'game':game,
                 'series_url':BASE+'/game/match-groups/'+group['id'],'group_api_reference':ref}
        # A statistics fingerprint is a SAMPLING stratum, not proof that the raw
        # trajectory or private source version is identical.
        fingerprint={'map':request['map'],'ordered_team_ids':[teams[s]['teamId']for s in ['a','b']],
                     'statistics':game.get('statistics'),'rounds':game.get('rounds'),'result':[s.get('result')for s in game['sides']],
                     'error':game.get('error')}
        digest=hashlib.sha256(json.dumps(fingerprint,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        request['statistics_fingerprint']=digest;fingerprints[digest].append(request['id']);games[request['id']]=request
record={'created_at_utc':datetime.now(timezone.utc).isoformat(),'data_cutoff_utc':index['data_cutoff_utc'],'ladder_snapshot':index['ladder_snapshot'],
        'scope':index['selection'],'history_complete':index['all_histories_complete'],'selected_series':len(index['groups']),
        'acquired_series':len(groups),'errors':errors,'series':groups,'requests':list(games.values()),
        'statistics_fingerprint_count':len(fingerprints),'fingerprint_warning':'Equal public final statistics are sampling strata only, not proven equal replay trajectories or bot versions.'}
(ROOT/'manifest-api.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(ROOT/'statistics-fingerprints.json').write_text(json.dumps(dict(fingerprints),indent=2)+'\n')
print(json.dumps({'series':len(groups),'games':len(games),'statistic_strata':len(fingerprints),'errors':errors,
                  'maps':Counter(r['map']for r in games.values()),'statuses':Counter(r['game']['status']for r in games.values()),
                  'engines':Counter(str((r['game'].get('statistics')or{}).get('engineVersion'))for r in games.values())},indent=2),flush=True)
