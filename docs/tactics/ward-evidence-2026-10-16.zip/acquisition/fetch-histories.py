"""Paginate all ten frozen-cohort team histories using the UI-observed cursor."""
from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor
import urllib.parse,json
from discover import fetch,BASE,ROOT

snapshot=json.loads((ROOT/'ladder-snapshot.json').read_text())
cutoff=datetime.now(timezone.utc).isoformat()
top=snapshot['teams'];rank={t['teamId']:t for t in json.loads((ROOT/'api/ladder.json').read_text())['teams']}
def history(team):
    tid=team['teamId'];before=None;groups={};pages=[];complete=False
    for index in range(500):
        query={'team':tid}
        if before:query['before']=before
        url=BASE+'/api/v1/match-groups?'+urllib.parse.urlencode(query)
        data,ref=fetch(url,ROOT/'api/histories'/tid/f'page-{index:04}.json')
        rows=data['groups'];pages.append({**ref,'more':data['more'],'count':len(rows),'before':before,
                                      'newest':rows[0]['createdAt']if rows else None,'oldest':rows[-1]['createdAt']if rows else None})
        for row in rows:
            if row['createdAt']<=cutoff:
                assert tid in [s['teamId']for s in row['sides']]
                assert row['id']not in groups,'Pagination duplicated a group'
                groups[row['id']]=row
        if not data['more']or not rows:complete=True;break
        last=rows[-1];cursor=last['createdAt']+'_'+last['id']
        assert cursor!=before;before=cursor
    result={'team':team,'pages':pages,'groups':list(groups.values()),'complete':complete,'stop':'end_of_public_history'if complete else'page_safety_cap'}
    (ROOT/'api/histories'/tid/'index.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps({'team':team['name'],'pages':len(pages),'groups':len(groups),'complete':complete},ensure_ascii=True),flush=True)
    return result
with ThreadPoolExecutor(max_workers=5)as pool:histories=list(pool.map(history,top))
allgroups={};appearances={}
for h in histories:
    for g in h['groups']:
        if g['id']in allgroups:assert allgroups[g['id']]==g
        allgroups[g['id']]=g;appearances.setdefault(g['id'],[]).append(h['team']['teamId'])
topids={t['teamId']for t in top}
eligible=[]
for g in allgroups.values():
    ids={s['teamId']for s in g['sides']};ranks=[rank.get(t,{}).get('rank',99999)for t in ids]
    band='top10_internal'if len(ids)==2 and ids<=topids else'outside_context'
    if g['status']=='finished'and band!='outside_context':eligible.append({**g,'cohort_band':band,'history_appearances':appearances[g['id']]})
record={'created_at_utc':datetime.now(timezone.utc).isoformat(),'data_cutoff_utc':cutoff,'ladder_snapshot':snapshot['fetch'],
        'teams':top,'history_count':len(histories),'all_histories_complete':all(h['complete']for h in histories),
        'all_unique_groups':len(allgroups),'selected_groups':len(eligible),'selection':'ALL finished groups between two distinct current top10 teams created before fixed cutoff. No lower-ranked opponents or self-play in primary strategic cohort.',
        'histories':[{'teamId':h['team']['teamId'],'page_count':len(h['pages']),'complete':h['complete'],'groups':len(h['groups'])}for h in histories],
        'groups':sorted(eligible,key=lambda g:g['createdAt'],reverse=True)}
(ROOT/'history-index.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in record.items()if k not in['groups','teams','histories']},indent=2),flush=True)
