"""Read-only public replay bundle acquisition with CRC/hash provenance."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime,timezone
import json,hashlib,urllib.request,zipfile,io,time,argparse
ROOT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
parser=argparse.ArgumentParser();parser.add_argument('--limit',type=int);args=parser.parse_args()
manifest=json.loads((ROOT/'manifest-native-selected.json').read_bytes())
requests=manifest['requests'][:args.limit]if args.limit else manifest['requests']
for name in ['bundles','raw','native-metadata','compact']:(ROOT/name).mkdir(exist_ok=True)
def one(r):
    mid=r['id'];meta=ROOT/'native-metadata'/f'{mid}.json'
    if meta.exists():return json.loads(meta.read_bytes())
    old_meta=ROOT.parent.parent/'battlecode-top10/native-metadata'/f'{mid}.json'
    if old_meta.is_file():
        old=json.loads(old_meta.read_bytes())
        old_bundle=Path(old['bundle']);old_raw=Path(old['raw'])
        data=old_bundle.read_bytes();raw=old_raw.read_bytes()
        assert sha(data)==old['bundle_sha256']and sha(raw)==old['raw_sha256']
        with zipfile.ZipFile(io.BytesIO(data))as z:
            assert z.testzip()is None and z.read('replay.repl26a')==raw
        result={**r,**{key:old[key]for key in ('raw','bundle','bundle_url','bundle_sha256','raw_sha256','bundle_members','crc_verified','downloaded_at_utc')},
                'cache_reuse':{'metadata':str(old_meta),'metadata_sha256':sha(old_meta.read_bytes()),'reused_at_utc':datetime.now(timezone.utc).isoformat()}}
        meta.write_text(json.dumps(result,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf8')
        return result
    url=f'https://2026a.battlecode.co.uk/api/v1/matches/{mid}/bundle'
    for attempt in range(3):
        try:
            data=urllib.request.urlopen(url,timeout=45).read();break
        except Exception:
            if attempt==2:raise
            time.sleep(1+attempt)
    with zipfile.ZipFile(io.BytesIO(data))as z:
        assert z.testzip()is None
        raw=z.read('replay.repl26a');members=z.namelist()
    bundle=ROOT/'bundles'/f'{mid}.zip';rawpath=ROOT/'raw'/f'{mid}.repl26a'
    bundle.write_bytes(data);rawpath.write_bytes(raw)
    result={**r,'raw':str(rawpath),'bundle':str(bundle),'bundle_url':url,'bundle_sha256':sha(data),'raw_sha256':sha(raw),'bundle_members':members,'crc_verified':True,'downloaded_at_utc':datetime.now(timezone.utc).isoformat()}
    meta.write_text(json.dumps(result,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf8')
    return result
results=[];errors=[]
with ThreadPoolExecutor(max_workers=8)as pool:
    futures={pool.submit(one,r):r for r in requests}
    for f in as_completed(futures):
        try:results.append(f.result())
        except Exception as e:errors.append({'id':futures[f]['id'],'error':repr(e)})
        if len(results)%100==0:print('Bundles',len(results),'/',len(requests),'errors',len(errors),flush=True)
byid={r['id']:r for r in results}
manifest['requests']=[byid[r['id']]for r in requests if r['id']in byid]
manifest['bundle_errors']=errors
target=ROOT/('manifest-native-pilot.json'if args.limit else 'manifest-native.json')
target.write_text(json.dumps(manifest,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf8')
print(json.dumps({'manifest':str(target),'downloaded':len(results),'errors':errors,'distinct_raw_sha256':len({r['raw_sha256']for r in results}),'bundle_bytes':sum(Path(r['bundle']).stat().st_size for r in results)},indent=2),flush=True)
