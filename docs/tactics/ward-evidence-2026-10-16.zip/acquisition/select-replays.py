"""Freeze outcome-independent ward replay coverage with all top-four head-to-head games."""
from pathlib import Path
from datetime import datetime,timezone
from collections import defaultdict,Counter
import json,hashlib
ROOT=Path(__file__).resolve().parent
read=lambda name:json.loads((ROOT/name).read_bytes())
source=read('manifest-api.json');ladder=read('ladder-snapshot.json')
top4={team['teamId']for team in ladder['teams'][:4]}
selected={};reasons=defaultdict(list);strata=defaultdict(list)
for game in source['requests']:
    ids={team['teamId']for team in game['teams'].values()}
    if ids<=top4:
        selected[game['id']]=game;reasons[game['id']].append('ALL_current_top4_head_to_head')
    else:
        key=(tuple(sorted(ids)),game['map'],game['kind'])
        strata[key].append(game)
for key,games in sorted(strata.items()):
    for game in sorted(games,key=lambda r:(r['created_at'],r['id']),reverse=True)[:2]:
        selected[game['id']]=game;reasons[game['id']].append('latest_two_per_other_pair_map_kind')
record={key:value for key,value in source.items()if key not in ('requests','series')}
record.update(created_at_utc=datetime.now(timezone.utc).isoformat(),
    selection={'rule':'ALL current top4-v-top4 finished game IDs, plus latest two finished IDs for every other unordered current-top10 pair/map/match-kind stratum. No win, ward, damage, champion, final-statistics-fingerprint or source-version filter.',
    'all_top4_head_to_head_games':sum('ALL_current_top4_head_to_head'in values for values in reasons.values()),
    'other_strata':len(strata),'current_top4_team_ids':sorted(top4),
    'source_manifest_sha256':hashlib.sha256((ROOT/'manifest-api.json').read_bytes()).hexdigest(),
    'raw_deduplication':'Only after bundle acquisition: exact raw SHA for workload reuse; keep match identity and team attribution separately.'},
    requests=[{**selected[mid],'ward_selection_reasons':reasons[mid]}for mid in sorted(selected)])
(ROOT/'manifest-native-selected.json').write_text(json.dumps(record,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf8')
print(json.dumps({'selected_games':len(selected),'top4_h2h':record['selection']['all_top4_head_to_head_games'],'other_games':len(selected)-record['selection']['all_top4_head_to_head_games'],'maps':dict(Counter(g['map']for g in selected.values()))},indent=2))
