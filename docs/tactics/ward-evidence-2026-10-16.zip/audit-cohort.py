"""Independent read-only cohort/provenance audit. Never decode replay records."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter, defaultdict
import concurrent.futures, gc, hashlib, json, time, urllib.parse, zipfile

ROOT = Path(__file__).resolve().parent
ACQ = ROOT / 'acquisition'
OUT = ROOT / 'cohort-audit.json'
START = datetime.now(timezone.utc).isoformat()
checks = []
failures = []
hashes = {}
def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024), b''): h.update(block)
    return h.hexdigest()
def read(p, bind=True):
    p=Path(p); b=p.read_bytes()
    if bind: hashes[p.relative_to(ROOT).as_posix()]=sha_bytes(b)
    return json.loads(b)
def check(name, ok, details=None):
    item={'name':name, 'pass':bool(ok)}
    if details is not None: item['details']=details
    checks.append(item)
    if not ok: failures.append(item)
def ordered(r): return tuple(r['teams'][s]['teamId'] for s in ('a','b'))
def key(r): return (tuple(sorted(ordered(r))),r['map'],r['kind'])
def basic(r):
    g=r['game']
    return {'id':r['id'],'map':r['map'],'series_id':r['series_id'],'kind':r['kind'],
        'created_at':r['created_at'],'teams':r['teams'],'status':g['status'],
        'finished_at':g.get('finishedAt'),'game_created_at':g['createdAt'],
        'replayUrl':g.get('replayUrl'),'engineVersion':(g.get('statistics')or{}).get('engineVersion')}

snapshot=read(ACQ/'ladder-snapshot.json'); ladder=read(ACQ/'api/ladder.json')
history=read(ACQ/'history-index.json')
top=snapshot['teams']; topids={t['teamId'] for t in top}; top4={t['teamId'] for t in top[:4]}
rank={t['teamId']:t['rank'] for t in top}; cutoff=history['data_cutoff_utc']
check('frozen_ladder_sha256_binding',sha_file(ACQ/'api/ladder.json')==snapshot['fetch']['sha256'])
check('snapshot_is_current_ladder_first_ten',top==ladder['teams'][:10] and [x['rank']for x in top]==list(range(1,11)))
check('ten_distinct_cohort_teams',len(top)==len(topids)==10)
check('history_cutoff_matches_snapshot_binding',history['ladder_snapshot']==snapshot['fetch'])

union={}; appearances=defaultdict(set); page_count=0; page_errors=[]; history_details=[]
for team in top:
    tid=team['teamId']; idx=read(ACQ/'api/histories'/tid/'index.json')
    found={}; expected_before=None; pages=idx['pages']; last_more=None
    for n,ref in enumerate(pages):
        page_count+=1; p=Path(ref['path']); data=read(p)
        if hashes[p.relative_to(ROOT).as_posix()]!=ref['sha256']: page_errors.append([tid,n,'sha256'])
        params=urllib.parse.parse_qs(urllib.parse.urlparse(ref['url']).query)
        if params.get('team')!=[tid] or params.get('before',[None])!=[expected_before] or ref['before']!=expected_before:
            page_errors.append([tid,n,'cursor_or_team_binding'])
        rows=data['groups']; last_more=data['more']
        if len(rows)!=ref['count'] or data['more']!=ref['more']: page_errors.append([tid,n,'recorded_count_or_more'])
        if rows and (ref['newest']!=rows[0]['createdAt'] or ref['oldest']!=rows[-1]['createdAt']):
            page_errors.append([tid,n,'boundary_record'])
        if any((rows[j]['createdAt'],rows[j]['id'])<(rows[j+1]['createdAt'],rows[j+1]['id']) for j in range(len(rows)-1)):
            page_errors.append([tid,n,'descending_order'])
        for row in rows:
            if tid not in {s['teamId']for s in row['sides']}: page_errors.append([tid,n,'wrong_team'])
            if row['createdAt']<=cutoff:
                if row['id'] in found: page_errors.append([tid,n,'duplicate_group'])
                found[row['id']]=row
                if row['id'] in union and union[row['id']]!=row: page_errors.append([tid,n,'cross_history_payload_disagreement'])
                union[row['id']]=row; appearances[row['id']].add(tid)
        if rows: expected_before=rows[-1]['createdAt']+'_'+rows[-1]['id']
        if n<len(pages)-1 and not data['more']: page_errors.append([tid,n,'pages_after_end'])
    indexed={g['id']:g for g in idx['groups']}
    complete=bool(idx['complete'] and idx['stop']=='end_of_public_history' and last_more is False)
    check('history_complete_and_page_exact_'+tid, complete and found==indexed,
          {'team':team['name'],'pages':len(pages),'groups':len(found),'last_more':last_more})
    history_details.append({'rank':team['rank'],'teamId':tid,'name':team['name'],'pages':len(pages),'groups':len(found),'complete':complete})
check('all_paginated_page_provenance_and_cursors',not page_errors,{'pages':page_count,'errors':page_errors[:30],'error_count':len(page_errors)})
check('history_summary_counts',history['history_count']==10 and history['all_histories_complete'] and history['all_unique_groups']==len(union))
eligible={g['id']:g for g in union.values() if g['status']=='finished' and len({s['teamId']for s in g['sides']})==2 and {s['teamId']for s in g['sides']}<=topids}
indexed={g['id']:g for g in history['groups']}
hist_bad=[]
for mid,g in indexed.items():
    core={k:v for k,v in g.items()if k not in ('cohort_band','history_appearances')}
    if core!=eligible.get(mid) or g.get('cohort_band')!='top10_internal' or set(g.get('history_appearances',[]))!=appearances[mid]: hist_bad.append(mid)
check('eligible_finished_distinct_top10_groups_exact',set(eligible)==set(indexed) and not hist_bad and len(eligible)==2774,
      {'count':len(eligible),'mismatched_ids':hist_bad[:20]})
print('History reconstruction complete:',len(eligible),'eligible groups;',len(failures),'failed checks',flush=True)

api=read(ACQ/'manifest-api.json')
api_reqs=api['requests']; api_by={r['id']:r for r in api_reqs}; series=api['series']
check('api_manifest_no_acquisition_errors',api['errors']==[] and api['selected_series']==api['acquired_series']==2774)
check('api_manifest_group_and_game_counts',len(series)==2774 and len(api_reqs)==len(api_by)==13870 and {s['id']for s in series}==set(eligible),
      {'series':len(series),'game_ids':len(api_reqs),'distinct_game_ids':len(api_by)})
group_errors=[]; group_game_ids=set(); per_group=Counter(); after_cutoff_groups=[]
for s in series:
    ref=s['api_reference']; p=Path(ref['path']); d=read(p)
    if hashes[p.relative_to(ROOT).as_posix()]!=ref['sha256']: group_errors.append([s['id'],'group_sha256'])
    if not ref['url'].endswith('/'+s['id']) or d['group']['id']!=s['id']: group_errors.append([s['id'],'endpoint_id'])
    if {x['teamId']for x in d['group']['sides']}!={x['teamId']for x in eligible[s['id']]['sides']}: group_errors.append([s['id'],'group_team_attribution'])
    ids=[g['id']for g in d['matches']]
    if ids!=s['game_ids']: group_errors.append([s['id'],'group_game_id_list'])
    for g in d['matches']:
        mid=g['id']; group_game_ids.add(mid); per_group[s['id']]+=1; r=api_by.get(mid)
        if r is None or r['game']!=g or r['series_id']!=s['id']: group_errors.append([mid,'api_game_payload_or_group'])
        if r and (r['created_at']!=g['createdAt'] or r['map']!=(g.get('mapName')or g.get('map'))): group_errors.append([mid,'game_timestamp_or_map'])
        if r and ordered(r)!=tuple(x['teamId']for x in sorted(g['sides'],key=lambda x:x['side'])): group_errors.append([mid,'ordered_team_binding'])
    if eligible[s['id']].get('finishedAt') and eligible[s['id']]['finishedAt']>cutoff: after_cutoff_groups.append(s['id'])
check('all_group_json_hash_and_game_payload_binding',not group_errors and group_game_ids==set(api_by),
      {'verified_groups':len(series),'errors':group_errors[:30],'error_count':len(group_errors),'games_per_group':dict(Counter(per_group.values()))})
check('all_api_games_finished_distinct_current_top10',all(r['game']['status']=='finished' and len(set(ordered(r)))==2 and set(ordered(r))<=topids for r in api_reqs))
check('rank_annotations_are_frozen_snapshot_ranks',all(t['rank']==rank[t['teamId']]for r in api_reqs for t in r['teams'].values()))
print('API group binding complete:',len(api_by),'game IDs;',len(failures),'failed checks',flush=True)

strata=defaultdict(list); expected=set(); top4ids=set()
for r in api_reqs:
    if set(ordered(r))<=top4: expected.add(r['id']); top4ids.add(r['id'])
    else: strata[key(r)].append(r)
for rows in strata.values(): expected.update(r['id']for r in sorted(rows,key=lambda r:(r['created_at'],r['id']),reverse=True)[:2])
selected=read(ACQ/'manifest-native-selected.json'); native=read(ACQ/'manifest-native.json')
selected_by={r['id']:r for r in selected['requests']}; native_by={r['id']:r for r in native['requests']}
check('selected_source_manifest_hash_binding',selected['selection']['source_manifest_sha256']==hashes['acquisition/manifest-api.json'])
check('outcome_independent_selection_exact',set(selected_by)==expected and len(selected_by)==3766 and len(top4ids)==2460 and len(expected-top4ids)==1306,
      {'top4_h2h_ids':len(top4ids),'other_selected_ids':len(expected-top4ids),'other_pair_map_kind_strata':len(strata),'other_strata_by_available_games':dict(Counter(min(2,len(v))for v in strata.values())),'selected_ids':len(selected_by),'missing':sorted(expected-set(selected_by))[:20],'extra':sorted(set(selected_by)-expected)[:20]})
check('selected_payloads_match_api_source',all({k:v for k,v in r.items()if k!='ward_selection_reasons'}==api_by[mid] for mid,r in selected_by.items()))
check('native_manifest_exact_selected_id_coverage',set(native_by)==set(selected_by) and len(native['requests'])==len(native_by)==3766 and native.get('bundle_errors')==[])
native_core_errors=[]
for mid,r in native_by.items():
    if any(r.get(k)!=v for k,v in selected_by[mid].items()): native_core_errors.append(mid)
check('native_attribution_preserves_selected_payload',not native_core_errors,{'errors':native_core_errors[:20]})

# Release the 427 MB manifest tree before binary checking; only compact request facts survive.
api_basic={mid:basic(r)for mid,r in api_by.items()}
maps_api=Counter(r['map']for r in api_reqs); maps_selected=Counter(r['map']for r in selected_by.values())
versions=Counter(str(t.get('version'))for r in api_reqs for t in r['teams'].values())
submissions=Counter(str(t.get('submissionId'))for r in api_reqs for t in r['teams'].values())
del api,api_reqs,api_by,series,selected,selected_by,strata; gc.collect()

def verify_native(r):
    errors=[]; mid=r['id']; rawpath=Path(r['raw']); bundle=Path(r['bundle'])
    raw=rawpath.read_bytes(); rawsha=sha_bytes(raw); bundlesha=sha_file(bundle)
    if rawsha!=r['raw_sha256']: errors.append('raw_sha256')
    if bundlesha!=r['bundle_sha256']: errors.append('bundle_sha256')
    if r['bundle_url']!=f'https://2026a.battlecode.co.uk/api/v1/matches/{mid}/bundle': errors.append('bundle_endpoint_id')
    with zipfile.ZipFile(bundle)as z:
        if z.testzip()is not None: errors.append('zip_crc')
        if z.read('replay.repl26a')!=raw: errors.append('zip_member_raw_bytes')
        if z.namelist()!=r['bundle_members']: errors.append('zip_member_list')
    meta=read(ACQ/'native-metadata'/f'{mid}.json')
    if meta!=r: errors.append('native_metadata_exact')
    if not r.get('crc_verified'): errors.append('crc_manifest_flag')
    reuse=r.get('cache_reuse')
    if reuse:
        oldp=Path(reuse['metadata']); old=read(oldp,False)
        if sha_file(oldp)!=reuse['metadata_sha256']: errors.append('cache_metadata_sha256')
        if old['id']!=mid or old['raw_sha256']!=rawsha or old['bundle_sha256']!=bundlesha: errors.append('cache_id_hash_binding')
    return {'id':mid,'errors':errors,'raw_bytes':len(raw),'bundle_bytes':bundle.stat().st_size,'raw_sha256':rawsha,'bundle_sha256':bundlesha,'cache_reuse':bool(reuse)}

binary=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:
    for n,result in enumerate(pool.map(verify_native,native['requests']),1):
        binary.append(result)
        if n%500==0: print('CRC/hash audited',n,'/',len(native_by),flush=True)
badbinary=[r for r in binary if r['errors']]
check('all_native_zip_crc_member_bytes_hashes_and_id_provenance',not badbinary,
      {'verified_match_ids':len(binary),'errors':badbinary[:20],'error_count':len(badbinary),'cache_reuse_ids':sum(r['cache_reuse']for r in binary)})
check('native_files_each_under_50_MiB',all(max(r['raw_bytes'],r['bundle_bytes'])<=50*1024*1024 for r in binary),
      {'max_raw_bytes':max(r['raw_bytes']for r in binary),'max_bundle_bytes':max(r['bundle_bytes']for r in binary),'total_raw_bytes':sum(r['raw_bytes']for r in binary),'total_bundle_bytes':sum(r['bundle_bytes']for r in binary)})

alias=defaultdict(list)
for r in native['requests']: alias[r['raw_sha256']].append(r['id'])
crossordered={h:ids for h,ids in alias.items()if len({ordered(native_by[mid])for mid in ids})>1}
crossmap={h:ids for h,ids in alias.items()if len({native_by[mid]['map']for mid in ids})>1}
check('raw_hash_deduplication_2119_and_no_cross_ordered_pair',len(alias)==2119 and not crossordered and not crossmap,
      {'unique_raw_hashes':len(alias),'appearance_ids':sum(map(len,alias.values())),'cross_ordered_pair_aliases':crossordered,'cross_map_aliases':crossmap,'alias_multiplicity':dict(Counter(map(len,alias.values())))})
unique=read(ROOT/'matches/manifest-current-unique.json'); unique_by={r['raw_sha256']:r for r in unique['requests']}
alias_sets={h:set(ids)for h,ids in alias.items()}
check('unique_manifest_alias_partition_exact',set(unique['aliases'])==set(alias) and all(set(unique['aliases'].get(h,[]))==ids for h,ids in alias_sets.items())
      and unique['appearance_count']==3766 and unique['unique_raw_count']==2119 and len(unique['requests'])==len(unique_by)==2119)
check('unique_representative_hash_and_attribution_binding',set(unique_by)==set(alias) and all(r['id']in alias[h]and r==native_by[r['id']]for h,r in unique_by.items()))

datefields={name:{'min':min(r[name]for r in api_basic.values()if r[name]),'max':max(r[name]for r in api_basic.values()if r[name])}for name in ('created_at','finished_at')}
after_finished=[r['id']for r in api_basic.values()if r['finished_at'] and r['finished_at']>cutoff]
after_game_created=[r['id']for r in api_basic.values()if r['created_at']>cutoff]
check('all_selected_groups_created_before_cutoff',all(g['createdAt']<=cutoff for g in eligible.values()))
check('all_api_games_created_before_cutoff',not after_game_created,{'count_after_cutoff':len(after_game_created),'ids':after_game_created[:20]})

# Rehash all main manifests/scripts after auditing to establish unchanged inputs.
core_files=['acquisition/ladder-snapshot.json','acquisition/api/ladder.json','acquisition/history-index.json','acquisition/manifest-api.json','acquisition/manifest-native-selected.json','acquisition/manifest-native.json','matches/manifest-current-unique.json']
for rel in ['acquisition/select-replays.py','acquisition/fetch-histories.py','acquisition/fetch-groups.py','acquisition/fetch-native.py','acquisition/discover.py']:
    hashes[rel]=sha_file(ROOT/rel)
end_core={rel:sha_file(ROOT/rel)for rel in core_files}
check('primary_metadata_unchanged_during_audit',all(end_core[rel]==hashes[rel]for rel in core_files))
report={'audit_started_at_utc':START,'audit_finished_at_utc':datetime.now(timezone.utc).isoformat(),
    'auditor':'Independent ward_lol agent; read-only cohort reconstruction and binary provenance audit',
    'scope':'No replay decode, native game execution, ward-output reading, or evidence mutation. ZIP containers only were opened to test CRC, hash, and byte equality.',
    'pass':not failures,'checks':checks,'failures':failures,
    'cohort':{'frozen_ladder_fetched_at_utc':snapshot['fetch']['fetched_at_utc'],'ladder_updated_at_utc':snapshot['updatedAt'],
       'data_created_at_cutoff_utc':cutoff,'histories':history_details,'history_pages':page_count,'all_unique_history_groups':len(union),
       'eligible_series':len(eligible),'api_game_ids':len(api_basic),'native_game_ids':len(native_by),'unique_raw_hashes':len(alias),
       'maps_api':dict(sorted(maps_api.items())),'maps_native_ids':dict(sorted(maps_selected.items())),
       'maps_unique_raw':dict(sorted(Counter(r['map']for r in unique['requests']).items())),
       'kind_api':dict(Counter(r['kind']for r in api_basic.values())),'date_ranges_api_games':datefields,
       'public_version_values_per_game_side':dict(versions),'public_submission_id_values_per_game_side':dict(submissions),
       'groups_finished_after_created_cutoff_count':len(after_cutoff_groups),'games_finished_after_created_cutoff_count':len(after_finished),'games_created_after_cutoff_count':len(after_game_created)},
    'caveats':[
      'Ranks are ranks in the frozen ladder fetched on 2026-10-15, not ranks at the historical match time.',
      'The cutoff filters group creation time. Finished status comes from later paginated/public-detail observations; this is not a transactional as-of-cutoff completion snapshot.',
      'Public bot versions and submission IDs are unknown when null; current team rank is not evidence that every historical replay uses the team\'s current source.',
      'Exact raw hashes establish workload identity and provenance but do not prove independent games; alias identity and ordered team attribution must remain separate.',
      'The native subset preserves every current-top4 head-to-head game ID and samples other pair/map/kind strata by recency; it is not the full 13870-game cohort.',
      'This audit establishes provenance and sampling, not correctness of downstream ward metrics or causal strategy effects.'
    ],
    'input_sha256':dict(sorted(hashes.items())),
    'raw_aliases_sha256':sha_bytes(json.dumps({h:sorted(ids)for h,ids in sorted(alias.items())},sort_keys=True,separators=(',',':')).encode()),
    'raw_and_bundle_audit_rows_sha256':sha_bytes(json.dumps(sorted(binary,key=lambda r:r['id']),sort_keys=True,separators=(',',':')).encode())}
OUT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'pass':report['pass'],'checks':len(checks),'failures':failures,'cohort':report['cohort'],'audit_file':str(OUT)},ensure_ascii=True,indent=2))
