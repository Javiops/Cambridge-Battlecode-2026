"""Descriptive ward evidence; raw aliases remain distinct appearances, not executions."""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timezone
import argparse,json,statistics,math,csv,bisect
p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--ladder',required=True);p.add_argument('--output',required=True);p.add_argument('--appearance-manifest');a=p.parse_args()
root=Path(a.input);output=Path(a.output);output.parent.mkdir(parents=True,exist_ok=True)
ladder=json.loads(Path(a.ladder).read_bytes());teams=ladder.get('teams',ladder.get('data',{}).get('teams',[]));rank={t['teamId']:t for t in teams}
def quantile(values,q):
 if not values:return None
 v=sorted(values);x=(len(v)-1)*q;i=int(x);return v[i]+(v[min(i+1,len(v)-1)]-v[i])*(x-i)
def distribution(values):return{'n':len(values),'sum':sum(values),'mean':statistics.mean(values)if values else None,'p25':quantile(values,.25),'median':quantile(values,.5),'p75':quantile(values,.75),'p90':quantile(values,.9),'min':min(values)if values else None,'max':max(values)if values else None}
games=[];errors=[]
def decisions(g):
 actions=g.pop('actions',[]);byowner=defaultdict(list);byturn=defaultdict(Counter);channels=defaultdict(list)
 for x in actions:
  if x['kind']==14:continue
  byowner[x['actor']].append(x);byturn[(x['round'],x['actor'])][x['kind']]+=1
  if x['kind']in[11,12]:channels[(x['actor'],x['kind'])].append(x)
 for owner,xs in byowner.items():xs.sort(key=lambda x:x['input'])
 ownerinputs={owner:[x['input']for x in xs]for owner,xs in byowner.items()};channelinputs={key:[x['input']for x in xs]for key,xs in channels.items()}
 for w in g['wards']:
  xs=byowner[w['owner']];ix=bisect.bisect_right(ownerinputs.get(w['owner'],[]),w['input']);after=xs[ix:ix+3];turn=byturn[(w['round'],w['owner'])]
  close={}
  for kind in[11,12]:
   key=(w['owner'],kind);cix=bisect.bisect_right(channelinputs.get(key,[]),w['input']);cs=channels[key];close[kind]=cix<len(cs)and cs[cix]['round']<=w['round']+3
  w['decisionContext']={'sameRoundMove':turn[4]>0,'sameRoundAttack':turn[5]>0,'sameRoundCast':turn[6]>0,'sameRoundRecall':turn[11]>0,'sameRoundSubmit':turn[12]>0,'nextCommands':[{k:x[k]for k in ['input','round','kind','from','to','slot']}for x in after if x['round']<=w['round']+3],'submitCommandWithin3Rounds':close[12],'recallCommandWithin3Rounds':close[11]}
def compact(g):
 for w in g['wards']:
  v=w['vision'];vs={k:v[k]for k in ['personalMaskUnionMatches','wardTiles','extraToChampionTiles','gainedVsPreviousTiles','lostVsPreviousTiles','altarTiles','extraAltarTiles','newAltarTiles']}
  vs['visibleCamps']=[{'extraToChampion':any(c['extraToChampion']for c in v['visibleCamps']),'newComparedWithOld':any(c['newComparedWithOld']for c in v['visibleCamps'])}]if v['visibleCamps']else[]
  vs['enemyTiles']=[{'newComparedWithOld':any(e['newComparedWithOld']for e in v['enemyTiles'])}]if v['enemyTiles']else[]
  keep={k:w[k]for k in ['owner','team','name','round','roundsSincePrior','relocationDistance','inBush','nearestAltarDistance','ownerGems','placementDistance','timer','radius','wardChargesAfter','wardTimerAfter','disabled','laterVision']}
  keep['previous']=True if w['previous']else None;keep['nearestCamp']={'distance':w['nearestCamp']['distance']};keep['vision']=vs;keep['decisionContext']={k:v for k,v in w['decisionContext'].items()if k!='nextCommands'};w.clear();w.update(keep)
 for key in ['followupExamples','terrain','camps','notes','raw']:g.pop(key,None)
 g['finalWards']=[{'team':w['team']}for w in g['finalWards']]
for file in sorted(root.glob('*.wards.json')):
 try:
  g=json.loads(file.read_bytes());decisions(g);compact(g);g['ward_file']=str(file.resolve());games.append(g)
  if len(games)%500==0:print('Loaded',len(games),flush=True)
 except Exception as e:errors.append({'file':str(file),'error':repr(e)})
aliases=defaultdict(list)
alias_validation=[]
if a.appearance_manifest:
 manifest=json.loads(Path(a.appearance_manifest).read_bytes());byraw={g['sourceSha256']:g for g in games};expanded=[]
 for r in manifest['requests']:
  if r['raw_sha256']not in byraw:continue
  source=byraw[r['raw_sha256']];stats=r['game']['statistics'];errs=[]
  if stats['round']!=source['rounds']:errs.append('round')
  if any(t['submittedGems']!=source['score'][t['team']]for t in stats['teams']):errs.append('score')
  if [source['teams'][s]['teamId']for s in ['a','b']]!=[r['teams'][s]['teamId']for s in ['a','b']]:errs.append('ordered_team_attribution')
  if r['map']!=source['map']:errs.append('map')
  if errs:alias_validation.append({'id':r['id'],'errors':errs})
  names=['Ryth','Vesper Vale','Vendetta','Cassi','Issac','Stellar','Prism','Marcella','Willow','Ren','Varg','Tavi','Heart of Ruin'];roster=[{'id':c['champion'],'team':c['team'],'type':c['type'],'name':names[c['type']]}for c in stats['champions']]
  expanded.append({**source,'id':r['id'],'representative_id':source['id'],'map':r['map'],'teams':r['teams'],'kind':r['kind'],'created_at':r['created_at'],'series_id':r['series_id'],'drafts':{str(t['team']):t['draftPicks']for t in stats['teams']},'initialChampions':roster,'bodyRosterSource':'Official API final champion roster; native initial snapshots can be during drafting.'})
 games=expanded
for g in games:aliases[g['sourceSha256']].append(g['id'])
unique={}
for g in sorted(games,key=lambda g:(g.get('created_at')or'',g['id']),reverse=True):unique.setdefault(g['sourceSha256'],g)
def side_rows(g):
 result=[]
 for side,index in [('a',0),('b',1)]:
  if side not in(g.get('teams')or{}):continue
  t=g['teams'][side];current=rank.get(t['teamId'],{});result.append((index,{**t,'currentRank':current.get('rank'),'currentName':current.get('name',t.get('name',t.get('teamName')))}))
 return result
def band(g):
 ranks=[t['currentRank']or 999999 for _,t in side_rows(g)]
 return'top4_h2h'if len(ranks)==2 and max(ranks)<=4 else'top4_vs_5_10'if len(ranks)==2 and min(ranks)<=4 and max(ranks)<=10 else'top10_other'if len(ranks)==2 and max(ranks)<=10 else'outside_current_top10'
def summarize(rows):
 counts=Counter();wards=[];first=[];per_game=[];rounds=0;owners=Counter();maxactive=[];initialowners=[];champions=defaultdict(Counter)
 for g,side,t in rows:
  ws=[w for w in g['wards']if w['team']==side];wards+=ws;per_game.append(len(ws));rounds+=g['rounds'];counts['games']+=1;counts['games_no_wards']+=not ws
  if ws:first.append(min(w['round']for w in ws))
  bodies=[c for c in g['initialChampions']if c['team']==side];counts['bodies']+=len(bodies);counts['bodies_with_placements']+=len({w['owner']for w in ws});maxactive.append(g['maxObservedCounts'][side]);counts['final_wards']+=sum(w['team']==side for w in g['finalWards'])
  for c in bodies:champions[c['name']]['body_appearances']+=1;champions[c['name']]['bodies_with_placements']+=any(w['owner']==c['id']for w in ws)
  for w in ws:owners[w['name']]+=1;champions[w['name']]['placements']+=1
 intervals=[w['roundsSincePrior']for w in wards if w['previous']];valid=[w for w in wards if w['vision']['personalMaskUnionMatches']];replacements=[w for w in valid if w['previous']]
 flags={'in_bush':lambda w:w['inBush'],'nearest_camp_within3':lambda w:w['nearestCamp']['distance']<=3,'nearest_camp_within6':lambda w:w['nearestCamp']['distance']<=6,'nearest_altar_within3':lambda w:w['nearestAltarDistance']<=3,'exact_ward_covers_camp':lambda w:bool(w['vision']['visibleCamps']),'exact_ward_covers_altar':lambda w:w['vision']['altarTiles']>0,'exact_extra_camp_beyond_champion_reveals':lambda w:any(c['extraToChampion']for c in w['vision']['visibleCamps']),'exact_new_camp_compared_with_old':lambda w:any(c['newComparedWithOld']for c in w['vision']['visibleCamps']),'exact_extra_altar_beyond_champion_reveals':lambda w:w['vision']['extraAltarTiles']>0,'exact_new_altar_compared_with_old':lambda w:w['vision']['newAltarTiles']>0,'exact_zero_extra_tiles':lambda w:w['vision']['extraToChampionTiles']==0,'exact_zero_new_tiles':lambda w:w['vision']['gainedVsPreviousTiles']==0,'carrying_gems':lambda w:w['ownerGems']>0,'enemy_tile_in_ward_mask':lambda w:bool(w['vision']['enemyTiles']),'new_enemy_tile':lambda w:any(e['newComparedWithOld']for e in w['vision']['enemyTiles'])}
 later=[w['laterVision']for w in wards if w.get('laterVision')];future={k:sum(v[k]for v in later)for k in ['samples','maskMismatches','samplesWithExtra','samplesWithExtraCamp','samplesWithExtraEnemy','samplesWithWardBeyondRange8','extraTilesSum']}
 future.update(placements_with_future_samples=sum(v['samples']>0 for v in later),placements_with_any_future_extra=sum(v['samplesWithExtra']>0 for v in later),initial_zero_extra_but_later_positive=sum(bool(w['vision']['extraToChampionTiles']==0 and w.get('laterVision')and w['laterVision']['samplesWithExtra']>0)for w in wards),initial_zero_new_but_later_positive=sum(bool(w['vision']['gainedVsPreviousTiles']==0 and w.get('laterVision')and w['laterVision']['samplesWithExtra']>0)for w in wards))
 result={'counts':dict(counts),'ward_placements':len(wards),'rounds_total':rounds,'placements_per100rounds':len(wards)/rounds*100 if rounds else None,'per_game':distribution(per_game),'first_placement_round':distribution(first),'first_round_thresholds':{str(n):sum(r<=n for r in first)for n in[1,2,3,5,10,25,50]},'replacements':sum(w['previous']is not None for w in wards),'intervals_rounds':distribution(intervals),'interval_exactly1':intervals.count(1),'same_position_replacements':sum(w['previous']is not None and w['relocationDistance']==0 for w in wards),'owner_champion_placements':dict(owners),'max_observed_active_per_game':distribution(maxactive),'mask_valid_placements':len(valid),'mask_invalid_placements':len(wards)-len(valid),'placement_categories':{name:sum(fn(w)for w in(valid if name.startswith('exact_')else wards))for name,fn in flags.items()},'placement_distance':distribution([w['placementDistance']for w in wards]),'relocation_distance':distribution([w['relocationDistance']for w in wards if w['previous']]),'ward_visible_tiles':distribution([w['vision']['wardTiles']for w in valid]),'extra_tiles_beyond_champion_and_reveals':distribution([w['vision']['extraToChampionTiles']for w in valid]),'gained_tiles_compared_with_previous':distribution([w['vision']['gainedVsPreviousTiles']for w in valid]),'lost_tiles_compared_with_previous':distribution([w['vision']['lostVsPreviousTiles']for w in valid]),'replacement_lost_more_than_gained':sum(w['vision']['lostVsPreviousTiles']>w['vision']['gainedVsPreviousTiles']for w in replacements),'ward_timers':dict(Counter(w['timer']for w in wards)),'ward_radii':dict(Counter(w['radius']for w in wards)),'post_placement_charges':dict(Counter(w['wardChargesAfter']for w in wards)),'post_placement_timer':dict(Counter(w['wardTimerAfter']for w in wards)),'disabled_at_placement':sum(w['disabled']for w in wards),'future_vision_samples':future}
 result['champion_body_denominators']={name:dict(v)for name,v in champions.items()}
 result['observed_commands_around_placements']={key:sum(bool(w.get('decisionContext',{}).get(key))for w in wards)for key in ['sameRoundMove','sameRoundAttack','sameRoundCast','sameRoundRecall','sameRoundSubmit','submitCommandWithin3Rounds','recallCommandWithin3Rounds']}
 return result
def report_games(source):
 grouped=defaultdict(list);bandgroups=defaultdict(list);maps=defaultdict(list);drafts=defaultdict(list)
 for g in source:
  for side,t in side_rows(g):
   if t['currentRank']and t['currentRank']<=10:
    grouped[t['teamId']].append((g,side,t));bandgroups[(band(g),t['teamId'])].append((g,side,t));maps[(g['map'],t['teamId'])].append((g,side,t));drafts[(tuple(g.get('drafts',{}).get(str(side),[])),t['teamId'])].append((g,side,t))
 return{'per_team':[{'teamId':tid,'name':rank[tid]['name'],'rank':rank[tid]['rank'],**summarize(rows)}for tid,rows in sorted(grouped.items(),key=lambda x:rank[x[0]]['rank'])],'per_band_team':[{'band':b,'teamId':tid,'name':rank[tid]['name'],'rank':rank[tid]['rank'],**summarize(rows)}for(b,tid),rows in sorted(bandgroups.items(),key=lambda x:(x[0][0],rank[x[0][1]]['rank']))],'per_map_team':[{'map':m,'teamId':tid,'name':rank[tid]['name'],'rank':rank[tid]['rank'],**summarize(rows)}for(m,tid),rows in sorted(maps.items(),key=lambda x:(x[0][0],rank[x[0][1]]['rank']))],'per_draft_team':[{'orderedDraft':list(d),'teamId':tid,'name':rank[tid]['name'],'rank':rank[tid]['rank'],**summarize(rows)}for(d,tid),rows in sorted(drafts.items(),key=lambda x:(rank[x[0][1]]['rank'],x[0][0]))]}
strata=Counter();latest=[]
for g in sorted(games,key=lambda g:(g.get('created_at')or'',g['id']),reverse=True):
 key=(tuple(sorted(t['teamId']for _,t in side_rows(g))),g['map'],g['kind'])
 if strata[key]<2:latest.append(g);strata[key]+=1
latestunique={}
for g in latest:latestunique.setdefault(g['sourceSha256'],g)
report={'generated_at_utc':datetime.now(timezone.utc).isoformat(),'input_dir':str(root.resolve()),'ladder':str(Path(a.ladder).resolve()),'games':len(games),'unique_raw_trajectories':len(unique),'extra_raw_alias_appearances':len(games)-len(unique),'games_by_current_band':dict(Counter(band(g)for g in games)),'unique_by_current_band':dict(Counter(band(g)for g in unique.values())),'kinds':dict(Counter(g.get('kind')for g in games)),'maps':dict(Counter(g['map']for g in games)),'oldest':min((g.get('created_at')or''for g in games),default=None),'newest':max((g.get('created_at')or''for g in games),default=None),'mask_errors':sum(len(g['maskErrors'])for g in games),'api_final_errors':sum(len(g['apiFinalValidation'])for g in games),'errors':errors,'aliases':{h:ids for h,ids in aliases.items()if len(ids)>1},'unique':report_games(list(unique.values())),'appearances':report_games(games),'definitions':{'raw_dedup':'SHA256 of replay.repl26a. Distinct raw hashes are distinct replay streams, not necessarily independent bot versions.','placement':'Native action kind14 confirmed full standard ward owned by casting champion at exact target tile.','coverage':'Exact engine shadowcast masks, not Chebyshev proximity. Personal baseline=champion design sight OR current transient tile-reveals. Gained/lost compare replacement with retained previous ward at the same current owner position. Masks must reproduce official current personal vision; mismatches excluded from exact metrics.','causality':'Counts and followup actions establish observed behavior; they do not establish source-code intent, benefit, optimality, or a causal win effect.','active':'Actual full snapshots at ward placements and final phase; max sampled concurrency, not a simulation.','intervals':'Same champion consecutive successful placement rounds. One-round intervals measure repeated use of the one-round cooldown, not all legal opportunities.'}}
report['alias_validation_errors']=alias_validation
report['latest_two_per_pair_map_kind']={'appearances':len(latest),'unique_raw_trajectories':len(latestunique),'rule':'Latest two IDs in every unordered current top10 pair/map/kind stratum, selected by timestamp+ID only, then raw-SHA deduplicated for metrics. This is a recent coverage slice, not proof of private current code versions.',**report_games(list(latestunique.values()))}
output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
table=output.with_suffix('.csv')
with table.open('w',encoding='utf8',newline='')as f:
 writer=csv.DictWriter(f,fieldnames=['rank','name','games','wards','mean_per_game','median_per_game','median_first_round','median_replacement_interval','pct_bush','pct_camp_exact','pct_altar_exact','pct_zero_incremental','median_incremental_tiles','median_lost_tiles']);writer.writeheader()
 for t in report['unique']['per_team']:
  n=t['ward_placements'];valid=t['mask_valid_placements'];cat=t['placement_categories'];writer.writerow({'rank':t['rank'],'name':t['name'],'games':t['counts']['games'],'wards':n,'mean_per_game':t['per_game']['mean'],'median_per_game':t['per_game']['median'],'median_first_round':t['first_placement_round']['median'],'median_replacement_interval':t['intervals_rounds']['median'],'pct_bush':cat['in_bush']/n*100 if n else None,'pct_camp_exact':cat['exact_ward_covers_camp']/valid*100 if valid else None,'pct_altar_exact':cat['exact_ward_covers_altar']/valid*100 if valid else None,'pct_zero_incremental':cat['exact_zero_new_tiles']/valid*100 if valid else None,'median_incremental_tiles':t['gained_tiles_compared_with_previous']['median'],'median_lost_tiles':t['lost_tiles_compared_with_previous']['median']})
print(json.dumps({k:report[k]for k in ['games','unique_raw_trajectories','games_by_current_band','mask_errors','api_final_errors','oldest','newest']},indent=2),flush=True)
