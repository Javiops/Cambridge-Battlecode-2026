"""Independent binding/counter audit of durable ward outputs and all raw alias identities."""
from pathlib import Path
from collections import defaultdict,Counter
from datetime import datetime,timezone
import hashlib,json
ROOT=Path(__file__).resolve().parent;acq=ROOT.parent/'acquisition';manifest=json.loads((acq/'manifest-native.json').read_bytes());selected=json.loads((ROOT/'manifest-current-unique.json').read_bytes());folder=ROOT/'current'
sha=lambda b:hashlib.sha256(b).hexdigest();expected={r['id']:r for r in selected['requests']};errors=[];missing=[];counts=Counter();pairs=defaultdict(set);aliases=defaultdict(list);records=[];byraw={}
for r in manifest['requests']:
 pairs[r['raw_sha256']].add(tuple(r['teams'][s]['teamId']for s in ['a','b']));aliases[r['raw_sha256']].append(r['id'])
for mid,r in expected.items():
 file=folder/f'{mid}.wards.json'
 if not file.exists():missing.append(mid);continue
 try:g=json.loads(file.read_bytes())
 except Exception as e:errors.append({'id':mid,'kind':'json_read','error':repr(e)});continue
 byraw[g['sourceSha256']]=g
 def check(ok,kind,**more):
  if not ok:errors.append({'id':mid,'kind':kind,**more})
 check(g['id']==r['id'],'id_binding');check(g['sourceSha256']==r['raw_sha256'],'manifest_raw_binding');check(sha(Path(r['raw']).read_bytes())==r['raw_sha256'],'raw_hash');check(g['map']==r['map'],'map_binding');check(g['teams']==r['teams'],'team_binding');check(g['placementCount']==len(g['wards']),'placement_count');check(not g['apiFinalValidation'],'api_final_validation');check(not g['maskErrors'],'placement_mask_model');check(not g['followupSampling']['maskMismatches'],'future_mask_model')
 names=['Ryth','Vesper Vale','Vendetta','Cassi','Issac','Stellar','Prism','Marcella','Willow','Ren','Varg','Tavi','Heart of Ruin'];bodies={c['champion']:{'id':c['champion'],'team':c['team'],'type':c['type'],'name':names[c['type']]}for c in r['game']['statistics']['champions']};last={};ownerIds=set();teamcounts=Counter()
 for w in g['wards']:
  counts['placements']+=1;counts['placement_mask_mismatches']+=not w['vision']['personalMaskUnionMatches'];check(w['owner']in bodies,'owner_exists',owner=w['owner']);b=bodies[w['owner']];check(b['team']==w['team']and b['name']==w['name'],'owner_team_name');check(w['placementDistance']<=2,'placement_range',input=w['input']);check(w['timer']==-1 and w['radius']==6,'ward_constants',input=w['input']);check(w['wardChargesAfter']==0 and w['wardTimerAfter']==1,'postplacement_resources',input=w['input']);check(not w['disabled'],'disabled_standard_ward')
  if w['owner']in last:
   old=last[w['owner']];check(w['previous']=={'position':old['position'],'round':old['round'],'input':old['input']},'previous_ward_link');check(w['roundsSincePrior']==w['round']-old['round']and w['roundsSincePrior']>=1,'replacement_interval');counts['replacements']+=1
  else:check(w['previous']is None,'first_ward_link')
  last[w['owner']]=w;ownerIds.add(w['owner']);teamcounts[w['team']]+=1
  later=w.get('laterVision')or{};counts['future_samples']+=later.get('samples',0);counts['future_mask_mismatches']+=later.get('maskMismatches',0)
 check(sum((w.get('laterVision')or{}).get('samples',0)for w in g['wards'])==g['followupSampling']['samples'],'future_sample_sum')
 finalowners={w['owner']for w in g['finalWards']};check(finalowners==ownerIds,'final_owners_match_ever_placed');check(len(g['finalWards'])==len(finalowners),'one_final_ward_per_owner')
 for w in g['finalWards']:check(w['position']==last[w['owner']]['position'],'final_position_matches_last');check(w['timer']==-1 and w['radius']==6 and not w['disabled'],'final_standard_ward_constants')
 for side in [0,1]:check(g['maxObservedCounts'][side]<=sum(c['team']==side for c in bodies.values()),'concurrency_limit')
 check(g['maxControlWardsSeen']==0,'unexpected_control_wards')
 counts['games']+=1;counts['rounds']+=g['rounds'];counts['native_inputs']+=g['inputs'];counts['bodies']+=len(bodies);counts['final_wards']+=len(g['finalWards'])
 records.append({'id':mid,'raw_sha256':r['raw_sha256'],'ward_file_sha256':sha(file.read_bytes()),'placements':len(g['wards']),'future_samples':g['followupSampling']['samples']})
for r in manifest['requests']:
 g=byraw.get(r['raw_sha256'])
 if not g:continue
 stats=r['game']['statistics'];outcome={'teamA':1,'teamB':2,'draw':3}.get(stats['outcome'])
 if stats['round']!=g['rounds']or any(t['submittedGems']!=g['score'][t['team']]for t in stats['teams'])or outcome!=g['outcome']:errors.append({'id':r['id'],'kind':'alias_api_final_binding'})
 if tuple(r['teams'][s]['teamId']for s in ['a','b'])!=tuple(g['teams'][s]['teamId']for s in ['a','b']):errors.append({'id':r['id'],'kind':'alias_ordered_team_binding'})
for h,pairset in pairs.items():
 if len(pairset)>1:errors.append({'raw_sha256':h,'kind':'cross_ordered_team_raw_alias'})
report={'created_at_utc':datetime.now(timezone.utc).isoformat(),'passed':not errors and not missing,'appearance_manifest':str((acq/'manifest-native.json').resolve()),'appearance_manifest_sha256':sha((acq/'manifest-native.json').read_bytes()),'unique_manifest_sha256':sha((ROOT/'manifest-current-unique.json').read_bytes()),'scanner_sha256':sha((ROOT/'scan-wards.mjs').read_bytes()),'engine_sha256':sha((ROOT.parent.parent/'battlecode-bot-v1/r2-research/v0_0_1-ctH8uuEb.wasm').read_bytes()),'expected_appearances':len(manifest['requests']),'expected_unique_raw':len(expected),'completed_unique_raw':len(records),'cross_ordered_pair_alias_hashes':sum(len(v)>1 for v in pairs.values()),'counts':dict(counts),'errors':errors,'missing':missing,'records':records,'scope':'Read-only official replay decoding; finite observations and mask reconstruction do not prove source-code intent or causal benefit.'}
(ROOT/'current-audit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print(json.dumps({k:v for k,v in report.items()if k not in ['records','missing','errors']},indent=2));print('errors',len(errors),'missing',len(missing))
