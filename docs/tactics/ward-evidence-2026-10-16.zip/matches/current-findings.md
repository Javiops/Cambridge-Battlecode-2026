# Ward behavior in the frozen current top ten

Ladder fetched 2026-10-15T22:51:52.700629+00:00. Replay cutoff 2026-10-15T22:52:39.723421+00:00. Current ranks define the cohort; public bot version/submission fields do not identify private source versions.

Analyzed **3,766 match IDs, 2,119 distinct raw replay SHA-256 streams**, across nine maps. Exact repeated raw streams account for 1,647 additional match identities. Zero raw hashes cross different ordered team pairs. The selection includes all 2,460 current-top-four head-to-head IDs plus 1,306 latest-two IDs from other current-top-ten pair/map/match-kind strata. Selection used timestamps and identities, never wins or ward behavior.

Native audit passed: 240,868 successful placements and 1,501,844 sampled later owner turns; zero missing files, binding errors, placement mask errors, or sampled future mask errors. Every final owner ward matched that owner's last successful placement. No control wards were present at the full placement/final snapshots examined.

## Distinct replay streams: all ten teams

The table counts each raw replay once. A stream contributes one team observation to each participant. “Per 100 rounds” means **game rounds**, not available, alive, or legal champion turns. Rates also reflect map/body/draft mixtures.

| Rank | Team | Streams | Mean wards/game | Wards/100 game rounds | Median first round | Median replacement interval | In bush | Zero immediate extra | Zero incremental vs old |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | Intercontinental Fish | 567 | 30.9 | 6.3 | 18.0 | 30.0 | 100.0% | 0.0% | 0.0% |
| 2 | Sneaky Bush Campers | 380 | 22.4 | 4.6 | 30.0 | 26.0 | 100.0% | 0.0% | 0.0% |
| 3 | Mite | 1011 | 37.5 | 7.5 | 22.0 | 28.0 | 100.0% | 0.0% | 0.0% |
| 4 | Univardisty of Shingtonwash | 821 | 34.9 | 6.9 | 30.0 | 12.0 | 86.6% | 0.0% | 0.0% |
| 5 | VeryGood | 227 | 43.2 | 9.0 | 29.0 | 14.0 | 100.0% | 0.0% | 7.1% |
| 6 | ❤️Quantom❤️ | 264 | 287.9 | 60.4 | 1.0 | 3.0 | 3.1% | 71.3% | 73.9% |
| 7 | hello | 264 | 87.2 | 16.4 | 5.0 | 13.0 | 51.7% | 33.4% | 40.1% |
| 8 | Nyxius | 243 | 32.5 | 6.9 | 21.0 | 19.0 | 100.0% | 0.0% | 0.0% |
| 9 | geese geese go | 221 | 38.0 | 7.7 | 20.0 | 28.0 | 100.0% | 0.0% | 0.0% |
| 10 | Full Damage | 240 | 96.7 | 19.8 | 26.0 | 1.0 | 100.0% | 19.0% | 25.4% |

Immediate extra is ward sight beyond the owner’s body sight and transient round reveals. Incremental vs old also subtracts sight that retaining the prior ward would supply at the same current owner position. These coverage summaries include first placements; with no old ward, incremental coverage equals immediate extra coverage. Zero immediate extra can still become useful personal monitoring after movement.

## Current top four playing each other

| Team | Distinct streams | Mean wards/game | Bush | Median first round | Median replacement interval | Median new tiles vs retained old ward | Median lost old tiles |
|---|---:|---:|---:|---:|---:|---:|---:|
| Intercontinental Fish | 437 | 31.1 | 100.0% | 18.0 | 30.0 | 56.0 | 97.0 |
| Sneaky Bush Campers | 221 | 18.2 | 100.0% | 28.0 | 27.0 | 56.0 | 85.0 |
| Mite | 839 | 38.5 | 100.0% | 22.0 | 28.0 | 56.0 | 94.0 |
| Univardisty of Shingtonwash | 659 | 36.8 | 87.7% | 28.0 | 12.0 | 42.0 | 41.0 |

## Recent coverage slice

A separate timestamp-only latest-two slice contains 1,513 IDs and 1,174 distinct raw streams. This limits long historical head-to-head repetitions while retaining every pair/map/kind stratum. It still does not establish private current code versions.

| Team | Streams | Mean wards/game | Bush | Median replacement interval | Zero immediate extra |
|---|---:|---:|---:|---:|---:|
| Intercontinental Fish | 192 | 31.2 | 100.0% | 30.0 | 0.0% |
| Sneaky Bush Campers | 223 | 29.6 | 100.0% | 25.0 | 0.0% |
| Mite | 256 | 33.1 | 100.0% | 28.0 | 0.0% |
| Univardisty of Shingtonwash | 218 | 27.6 | 81.9% | 13.0 | 0.0% |

Direct sensitivity comparison restricted to current-top-four head-to-head play:

| Team | All h2h streams | Recent h2h streams | Bush: all → recent | Median interval: all → recent |
|---|---:|---:|---:|---:|
| Intercontinental Fish | 437 | 62 | 100.0% → 100.0% | 30.0 → 31.0 |
| Sneaky Bush Campers | 221 | 64 | 100.0% → 100.0% | 27.0 → 25.0 |
| Mite | 839 | 84 | 100.0% → 100.0% | 28.0 → 28.0 |
| Univardisty of Shingtonwash | 659 | 56 | 87.7% → 85.3% | 12.0 → 12.0 |

## Persistent monitoring after movement

Sampling reads the first phase-10 state of an alive owner turn on the immediately following round after placement and subsequently whenever the game round is divisible by five, until replacement. Every sample reconstructs exact personal sight from official champion-design sight, the current owned ward, and transient round tile reveals, then compares it with the official personal vision buffer. Sampling does not enumerate every owner turn.

| Team | Valid later samples | Extra ward sight | Extra camp-spawn sight | Extra enemy-position sight | Ward more than 8 tiles away | Initial-zero placements later positive |
|---|---:|---:|---:|---:|---:|---:|
| Intercontinental Fish | 186,843 | 98.1% | 51.9% | 14.5% | 35.2% | 0 |
| Sneaky Bush Campers | 93,602 | 97.0% | 52.6% | 18.0% | 38.5% | 0 |
| Mite | 392,376 | 97.0% | 52.0% | 16.7% | 37.7% | 0 |
| Univardisty of Shingtonwash | 242,457 | 96.5% | 63.2% | 19.6% | 40.6% | 0 |
| VeryGood | 82,136 | 96.6% | 50.3% | 16.7% | 35.7% | 0 |
| ❤️Quantom❤️ | 136,921 | 38.6% | 7.9% | 2.4% | 0.9% | 13,593 |
| hello | 130,315 | 76.0% | 36.7% | 12.3% | 22.7% | 4,308 |
| Nyxius | 73,475 | 98.5% | 53.8% | 19.2% | 40.4% | 0 |
| geese geese go | 78,480 | 97.5% | 51.2% | 15.0% | 38.2% | 0 |
| Full Damage | 85,239 | 94.4% | 46.6% | 18.4% | 33.7% | 3,696 |

Camp coverage means the actual embedded map’s camp **spawn tiles**, including currently empty or respawning spawns. Enemy coverage uses actual live enemy tile positions filtered through the official ward mask; it establishes available geometric tile sight, not that the bot queried or consumed it. The same warning applies to camp information.

## Nine-map comparison

Each cell is median placements/game; median same-owner replacement interval; bush percentage. Counts are distinct raw streams. Differences in map layout, game duration, draft/body counts and opponent mixture remain confounded.

| Map | Intercontinental Fish | Sneaky Bush Campers | Mite | Univardisty |
|---|---|---|---|---|
| collision | 2.0; 70.0; 100.0% (n=55) | 0.0; 7.0; 100.0% (n=42) | 2.0; 139.0; 100.0% (n=73) | 0.0; —; 0.0% (n=65) |
| corners | 50.0; 42.0; 100.0% (n=80) | 20.0; 48.5; 100.0% (n=41) | 26.0; 61.0; 100.0% (n=156) | 3.0; 91.5; 14.5% (n=120) |
| elkring | 56.0; 33.0; 100.0% (n=73) | 24.5; 43.0; 100.0% (n=44) | 33.0; 49.0; 100.0% (n=157) | 46.0; 21.0; 82.9% (n=119) |
| expanse | 0.0; —; — (n=49) | 0.0; —; — (n=36) | 0.0; —; — (n=67) | 1.0; 200.5; 0.0% (n=63) |
| interlock | 16.0; 77.5; 100.0% (n=47) | 24.0; 56.0; 100.0% (n=44) | 20.0; 70.0; 100.0% (n=65) | 10.0; 95.5; 36.9% (n=64) |
| lanes | 53.0; 24.0; 100.0% (n=79) | 54.0; 18.0; 100.0% (n=45) | 69.0; 21.0; 100.0% (n=156) | 112.0; 9.0; 98.0% (n=122) |
| monolith | 11.0; 46.0; 100.0% (n=49) | 21.5; 39.0; 100.0% (n=42) | 35.0; 30.0; 100.0% (n=67) | 17.0; 49.0; 21.7% (n=58) |
| packs | 46.0; 21.0; 100.0% (n=74) | 35.5; 23.0; 100.0% (n=50) | 43.0; 24.0; 100.0% (n=156) | 52.5; 9.0; 97.0% (n=118) |
| rows | 48.0; 29.0; 100.0% (n=61) | 51.0; 7.0; 100.0% (n=36) | 58.0; 21.0; 100.0% (n=114) | 9.0; 51.0; 8.1% (n=92) |

## Actors and actions around warding

The attached champion-body CSV counts each champion body’s game appearance, bodies that ever placed, and placements; tactical role assignments are not exposed. Complete body denominators use the official API final champion roster because an initial native snapshot can still be during drafting. Every native ward actor’s name and team was checked against that roster. Cassi and Issac have separate body denominators and personal wards. A deployment percentage is per observed body appearance, not per legal opportunity.

| Team | Ward-bearing bodies / body appearances | Same-round move | Same-round basic attack | Same-round cast | Submit command within 3 rounds | Recall command within 3 rounds |
|---|---:|---:|---:|---:|---:|---:|
| Intercontinental Fish | 2244/2938 | 99.3% | 6.5% | 13.1% | 6.5% | 1.4% |
| Sneaky Bush Campers | 1160/1876 | 85.1% | 6.8% | 8.0% | 12.7% | 3.9% |
| Mite | 4821/5295 | 97.8% | 6.3% | 8.7% | 9.8% | 3.0% |
| Univardisty of Shingtonwash | 3099/4037 | 74.8% | 8.1% | 12.5% | 5.0% | 2.1% |
| VeryGood | 1034/1176 | 86.5% | 5.7% | 8.1% | 4.2% | 2.9% |
| ❤️Quantom❤️ | 945/1233 | 83.2% | 7.1% | 8.7% | 5.7% | 4.3% |
| hello | 1308/1321 | 82.5% | 16.5% | 9.7% | 3.9% | 1.8% |
| Nyxius | 1001/1196 | 99.2% | 4.4% | 9.3% | 5.1% | 2.5% |
| geese geese go | 954/1087 | 84.5% | 11.6% | 12.1% | 5.6% | 2.7% |
| Full Damage | 951/1153 | 92.5% | 4.3% | 7.5% | 5.2% | 4.1% |

These are native recorded command associations around a confirmed ward placement. The other command’s success or damage result is not independently established here. A submit/recall command is not evidence of completion or of why the ward was placed. The scanner does not infer a camp capture plan, choke definition, combat avoidance, or a lost action from distance alone.

## Spatial situations

| Team | Ward covers a camp spawn | Ward covers altar | Adds new camp-spawn sight vs old | Adds new altar sight vs old | Carrying gems when placing | Replacements lose more tiles than gained |
|---|---:|---:|---:|---:|---:|---:|
| Intercontinental Fish | 73.8% | 38.9% | 33.9% | 20.2% | 27.7% | 93.3% |
| Sneaky Bush Campers | 61.2% | 58.6% | 28.2% | 20.1% | 28.2% | 88.0% |
| Mite | 63.1% | 49.4% | 25.4% | 27.5% | 24.9% | 92.7% |
| Univardisty of Shingtonwash | 74.7% | 41.5% | 47.3% | 24.3% | 28.5% | 62.5% |
| VeryGood | 65.8% | 51.4% | 23.7% | 19.1% | 18.0% | 92.3% |
| ❤️Quantom❤️ | 76.1% | 34.8% | 3.9% | 3.0% | 38.9% | 40.5% |
| hello | 86.1% | 38.8% | 12.1% | 10.4% | 27.9% | 70.9% |
| Nyxius | 71.3% | 48.5% | 27.3% | 20.2% | 35.1% | 56.8% |
| geese geese go | 74.1% | 40.5% | 36.3% | 19.2% | 24.8% | 92.0% |
| Full Damage | 70.4% | 46.3% | 14.5% | 8.0% | 21.8% | 50.6% |

Losing more old tiles than new ones is a spatial tradeoff, not evidence of a bad placement: tile counts do not encode which information mattered or how long it remained relevant. Base and nearest-objective distances are available in per-placement files; “choke” and enemy-territory labels were not guessed from map names.

## Draft coverage

Ordered drafts are retained in the summary JSON. The table shows the three most frequent ordered drafts for each current top-four team. It describes behavior under observed drafts without assigning changes to a particular ability.

| Team | Ordered draft | Streams | Mean wards/game | Median replacement interval | Bush |
|---|---|---:|---:|---:|---:|
| Intercontinental Fish | Ren → Stellar → Cassi & Issac → Ryth → Varg | 210 | 41.3 | 35.0 | 100.0% |
| Intercontinental Fish | Ren → Stellar → Cassi & Issac | 117 | 24.9 | 22.0 | 100.0% |
| Intercontinental Fish | Ren → Stellar → Cassi & Issac → Ryth | 43 | 16.2 | 77.5 | 100.0% |
| Sneaky Bush Campers | Cassi & Issac → Stellar → Varg | 85 | 18.5 | 23.0 | 100.0% |
| Sneaky Bush Campers | Cassi & Issac → Stellar → Prism → Willow → Tavi | 50 | 19.8 | 48.5 | 100.0% |
| Sneaky Bush Campers | Cassi & Issac → Stellar → Varg → Tavi | 44 | 30.1 | 7.0 | 100.0% |
| Mite | Varg → Stellar → Cassi & Issac → Tavi → Ren | 261 | 53.1 | 25.0 | 100.0% |
| Mite | Varg → Stellar → Cassi & Issac → Ryth → Ren | 233 | 32.2 | 52.0 | 100.0% |
| Mite | Varg → Ryth → Cassi & Issac → Ren | 168 | 44.8 | 26.0 | 100.0% |
| Univardisty of Shingtonwash | Cassi & Issac → Ren → Stellar → Tavi → Varg | 71 | 58.2 | 13.0 | 92.1% |
| Univardisty of Shingtonwash | Ryth → Stellar → Prism → Ren → Tavi | 63 | 54.5 | 9.0 | 95.5% |
| Univardisty of Shingtonwash | Cassi & Issac → Stellar → Varg | 53 | 38.4 | 9.0 | 95.6% |

## Replay examples with exact frames

- Fish versus Univardisty, lanes, match `4b5c61db-a064-4459-bc95-31150aa96347`: round 47 placement and round 60 monitoring. Extra personal ward tiles 91 → 151. Plot-ready case in `cases-h2h/`.
- Sneaky Bush Campers versus Fish, corners, `9c830c09-e7bf-4032-ad35-4cadfac6c49f`: round 39 placement and round 110 monitoring, 67 → 169 extra tiles. The next recorded command is slot-1 cast on round 110. No causal reaction is inferred.
- Univardisty versus Mite, elkring, `7259213a-b026-4ee3-a974-1f82b0b71cde`: round 33 placement and round 135 monitoring, 90 → 169 extra tiles. The next recorded move is on round 136; it is not presented as an immediate reaction.
- Quantom, monolith, `b9b40d5e-dacc-443a-af00-b4e571359090`: Issac places on ordinary floor at (28,42), round 267, with owner at (30,40): zero immediate extra tiles. Round 270 owner at (30,45), the retained ward adds 13 tiles; next command attacks the Wolf at (29,46). Seven of eight later sampled owner turns have extra sight, and the maximum is 169. This is a concrete counterexample to treating zero immediate coverage as useless.

## Limits and interpretation

- Current rank is fixed at collection. Matches can contain older strategies; public versions/submission identifiers remain unavailable. The recent slice and all-history head-to-head table answer different descriptive questions.
- Distinct raw streams are distinct replay trajectories, not independent versions, independent experiments, or causal trials. Repeated IDs are retained for provenance and kept separate from trajectory counts.
- Both ranked and unranked games are retained and labelled. No winner-conditioned sampling or ward-win regression is used to claim an optimal policy.
- Wards provide personal sight. Seeing a tile does not prove a branch in private code used it. Example follow-up commands show recorded commands only.
- Owner-turn monitoring is sampled, so positive sample counts are observations and unsampled intervals remain unknown. The placement census itself is complete for the selected raw streams.
- No full legal-ward-opportunity denominator was collected. Channeling, restrictions, charge timing and decision state can affect legality; game-round rates are not availability rates.
- Geometry is decoded from actual embedded replay terrain and official engine masks. Distances to camps/altars are secondary descriptors, not substitutes for exact sight.

Engine SHA-256: `ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc`. Full native audit: `current-audit.json`; summaries: `current-summary.json` and `.csv`; source match bindings and bundle provenance: acquisition manifests. No original bot/source/evidence or GitHub files were modified.
