"""Bounded official-engine ward extraction workers; keeps per-match artifacts durable."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import json,argparse,subprocess,time
ROOT=Path(__file__).resolve().parent
NODE=Path(r'C:\Users\frans\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe')
p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--out-dir',required=True);p.add_argument('--workers',type=int,default=8);p.add_argument('--cached-events-dir');p.add_argument('--followup-stride',type=int,default=5);a=p.parse_args()
out=Path(a.out_dir).resolve();out.mkdir(parents=True,exist_ok=True);logs=out/'logs';logs.mkdir(exist_ok=True)
def worker(i):
 cmd=[str(NODE),str(ROOT/'scan-wards.mjs'),'--manifest',str(Path(a.manifest).resolve()),'--out-dir',str(out),'--stride',str(a.workers),'--index',str(i),'--resume']
 if a.cached_events_dir:cmd+=['--cached-events-dir',str(Path(a.cached_events_dir).resolve())]
 if a.followup_stride:cmd+=['--followup-stride',str(a.followup_stride)]
 with(logs/f'worker-{i:02}.log').open('w',encoding='utf8')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 return{'worker':i,'exit_code':r.returncode}
start=time.time();results=[]
with ThreadPoolExecutor(max_workers=a.workers)as pool:
 for f in as_completed([pool.submit(worker,i)for i in range(a.workers)]):
  result=f.result();results.append(result);print(json.dumps(result),flush=True)
report={'manifest':str(Path(a.manifest).resolve()),'out_dir':str(out),'finished_at_utc':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.time()-start,'workers':results,'completed_matches':len(list(out.glob('*.wards.json')))}
(out/'run-report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print(json.dumps(report),flush=True)
