# Mechanics cross-audit of `our-policy-review.md`

Checked against `mechanics.md`, current live Vision & wards article, SDK 2.1.6, and the official WASM fixture outputs. No bot source was changed.

The policy note correctly treats the stable ward flag as disabled, the dormant helper's frequency limits as bot choices, allied ward cells as exact legality exclusions rather than shared-vision overlap, future personal sight as the replacement baseline, and the open-field `2+6=8` containment result. Its proposal is clearly labeled untested strategy.

One precise wording fix was sent to the parent: “One charge recharges at owner turn end” should say “The recharge timer ticks at owner turn end; the charge is restored at the next owner turn start.” `ward_recharge_and_replace` explicitly records charge0/recharge0 between those phases. At regular bot turn entry, the charge has restored.

Additional mechanics that should inform the eventual tactics document:

- The helper's champion/camp/TP-reservation destination exclusions are conservative strategy filters, not engine placement rules. Ordinary wards can overlap all three. Own spawn is legal, enemy spawn is forbidden.
- Placement can cross an intervening wall into an unseen legal bush without direct sight. This supports an early observation point for a hidden branch.
- A hidden allied ward collision returns false, reveals only that tile for the rest of the round, and retains the charge. A known allied ward collision throws117; own same-tile replacement also throws117. A different legal retry can succeed.
- Enemy wards may overlap; ward placement does not remove an enemy ward. Ordinary wards cannot be attacked or cleared. Internal legacy controlward fields are not a current purchasable tool.
- Existing ward vision survives death and recall. The public bot API, not only the spectator buffer, returns130 visible tiles for the dead owner in the bush fixture (`probe-dead-api-output.json`). Dead owners recharge but cannot deploy; reporting existing remote sightings on their turns is a possible future feature.
- Cassi and Issac each have one ward, one charge, and personal sight. Team maximum depends on champion body count, not draft-pick count.
- Ward then move/attack or cast is legal; recall/tribute/teleport channels block subsequent placement. The immediate visibility requery can matter within the current turn, as demonstrated by a previously hidden bush enemy becoming a valid move-and-attack target after placement.
- A ward observes a camp but cannot perform capture occupancy; ward-only camp remains unclaimed after eight rounds in the fixture.

The note's caution about distinguishing current effective sight from hypothetical champion-only sight is appropriate. Effective sight can include temporary collision reveal tiles as well as the own ward. Replay comparison should flag a mismatch rather than force every observation into a natural-sight-plus-ward union.
