# Our ward policy: source audit and original design

Research snapshot: 2026-10-16. This is strategy research only. No bot implementation or new match/test run was performed for this note. Proposed policies, timings, weights, and outcomes below remain untested hypotheses unless explicitly identified as source facts.

## Exact stable source identity

The audited stable source is `work/study27-economy-v2/baseline/src/`. Its six files match SHA-256 hashes in `work/study27-economy-v2/baseline/manifest.json` and independently match `work/study27-combat/publication/src/`. The manifest names abbreviated commit `e72cec8`, cleaned PR11 publication, with the same compiled policy as the confirmed combat combination. These are a better current reference than the older downloaded GitHub snapshot, whose line numbers differ.

**The stable bot does not place wards.** `params.h:82` defines `P_R5_WARD 0`. The dormant helper exists, and its call remains guarded by that zero flag at `main.cpp:3297`. A future proposal is a change from no active ward policy, not merely a retuning of active ward behavior.

Historical evidence is narrower than a general verdict on wards. The old downloaded `docs/study26-fixes.md:5-16` reports the previous `P_R5_WARD 1` experiment alone against study25 on 313 maps, both sides: 55 maps won on both sides and 58 lost on both sides, with the remainder split. The parameter comment calls this noise. It tested that specific old heuristic against that opponent/cohort; it does not establish that decision-directed scouting, earlier placement, or personal-information handling cannot help.

## Dormant implementation audit

All source locations in this section refer to the stable baseline above.

| Concern | Exact existing behavior | Implication |
| --- | --- | --- |
| Call timing | `main.cpp:3212` pre-movement spell sweep; `:3233` complete `play_turn`; `:3245` older post-turn sweep when applicable; `:3288-3295` remaining optional spell passes; `:3296` altar lock; `:3297` ward; then logs and `end_turn` at `:3303-3308`. | If enabled, the ward is an end-of-turn add-on. New sight cannot change that turn's already completed route, first engagement, shop, or channel decision. There is no tactical action pass after placement. |
| Shop and channels | `play_turn` shops at `main.cpp:2390-2395`, then returns for an existing channel at `:2401-2403`. It can also start recall or submission later and return. The ward helper independently refuses recalling/submitting/teleporting at `utility.h:19-21`. | A return from `play_turn` does not itself skip the final helper, but its channel gate does. The current design cannot set vision immediately before beginning a vulnerable channel. Exact legal action ordering belongs to the separate mechanics audit. |
| Entry/readiness | `utility.h:13` requires initialized state, team identity, and `fuel_ok(9000)`; `:19-21` checks alive, no channel, zero ward cooldown, and no ward restriction. | Sensible basic safety gates. There is no `can_place_ward` method in this SDK wrapper to substitute blindly; the action still owns final legality. |
| Frequency | Static `next_check`, `utility.h:12-16`: a qualifying check immediately schedules the next check four rounds later, before checking channels, current bush, candidates, or success. Successful placement sets eight rounds at `:64`. | These delays are bot choices, not a ward recharge requirement. Being channeling or finding no local bush can postpone the next opportunity. Fuel failure at the initial gate does not update the timer. |
| Candidate set | `utility.h:44-50`: 5x5 local window, within placement radius, not current tile, **bush tiles only**, in bounds, no static/dynamic blocker, neither spawn; no candidate within two Chebyshev tiles of the old ward. | It can miss useful legal open-ground observation points and useful small repositioning. `s.static_block` is walls/holes/altars/enemy spawn (`main.cpp:1062`); `s.blocked` adds current visible champions/camps at the start of decisions (`:2412`). This is conservative filtering, not the full action contract. |
| Extra legality | `utility.h:61-67`: reject visible champion, camp, teleport reservation, or allied ward on the destination; attempt placement; stop if cooldown becomes positive. `main.cpp:485-496` catches exceptions. SDK `cambc.h:3677-3685` documents false for a newly revealed hidden obstruction and throws for known invalid destinations. | Failed attempts are contained. A future policy must handle both false and exceptions and account for hidden-obstruction side effects from the mechanics audit. Exact allied-ward-cell exclusion is a legality check: SDK `cambc.h:524-525` defines `invalid_action_place_ward_ally_ward_present`. It is not evidence of a broad allied-vision-overlap bug. |
| Goal | `utility.h:26-36`: default enemy spawn center; use selected camp center when there is a target; override with nearest apparently usable altar once gems reach the tribute threshold. All distances use Chebyshev `dist`, `main.cpp:467`. | The helper does not consume the actual route or decision mode. It may scout toward a camp while retreating, or toward the nearest geometric altar rather than the altar selected by the banking route/safety planner. |
| Score | `utility.h:51`: `3*distance(owner,candidate) + 2*(distance(owner,goal)-distance(candidate,goal))`; keep top three at `:41-57`. Ties preserve loop order. | This favors separation and geometric progress. It measures neither visible tiles nor actionable warning. A farther candidate has a built-in advantage even when occluded or strategically irrelevant. |
| Old ward retention | Skip all placement if owner is already in any bush (`utility.h:24-25`). Preserve an old bush ward whenever it lies within radius 6 of the geometric goal (`:37-40`). Otherwise, no old-versus-new information comparison. | The retention rule can preserve a ward whose view is blocked, while replacement can erase a valuable remote watcher. Being in a bush now does not make a persistent ward useless after departure. |
| Personal versus allies | Exact allied ward cells are excluded, but **no allied footprint overlap penalty is implemented**. There is also no personal vision-mask comparison. | The strategy mistake to avoid in new work is assuming an ally's nearby ward gives this champion equivalent sight. Nearby distinct wards with overlapping masks can be rational when both owners need direct tactical visibility. Do not label the exact-cell legality filter as that mistake. |
| Fuel | `main.cpp:460,468`: reserve 6000 and strict `fuel_remaining > need+reserve`. Thus helper entry requires more than 15000 fuel, and each candidate attempt gate (`utility.h:60`) more than 12000. | The existing helper is deliberately small and uses leftover fuel. A useful replacement needs measured visibility-query costs and bounded rescoring; these numbers are not measured costs of a new design. |
| Telemetry | No ward-specific log, skip reason, coverage statistic, placement outcome, or old-coverage loss record in `utility.h`. General exception totals at `main.cpp:477-482`; sampled status logs position/mode/target/errors/fuel at `:2942-2959`. | Existing outcome evidence cannot explain whether the old experiment failed through late timing, irrelevant coverage, scarce opportunities, CPU cost, or useful information that decisions ignored. |

## Mechanics boundary used for design

The parallel official-source audit owns final verification. Its confirmed update says all 13 current champion IDs have Chebyshev vision radius 8. Ordinary wards are free, persistent, invulnerable, one active per owner, deployed within Chebyshev radius 2 and giving radius-6 sight; a new ward relinquishes the owner's old observation point. One charge recharges at owner turn end, so a multi-turn reserve policy is not justified. Vision is personal, and team shared writable memory totals eight bytes.

Use the SDK's actual hypothetical mask, `bc::ward::visible_tiles_from[_into]` (`cambc.h:4012-4029`), rather than treating a radius disk as sight through walls/bushes. Use hypothetical owner sight `me.visible_tiles_from[_into]` (`:3482-3496`) for the natural-sight counterfactual where its semantics are confirmed. Do not assume `me.visible_tiles()` and `bc::vision::visible_tiles()` are interchangeable: stable source itself distinguishes champion sight from effective engine vision (`main.cpp:2415`, `:1653-1654`).

**Open-field consequence, derived from the confirmed radii:** for owner position `p`, legal ward center `w`, and any ward-visible tile `t`, Chebyshev distance obeys `d(p,t) <= d(p,w)+d(w,t) <= 2+6 = 8`. With no wall/bush occlusion, the new ward's entire mask is inside the owner's current natural vision. Thus immediate new pixels are zero in open terrain. This is a geometric inference from the mechanics, not a match result. Walls/bushes can make actual masks differ and create immediate information gain.

The principal open-field job is **persistent observation after the owner leaves**, including after a move away, completed objective, tribute trip, or recall. A useful policy must not require positive current `ward_mask - natural_mask` as an admission rule. Equally, a ward covering an open approach during a stationary channel adds no sight while that approach remains inside natural vision; pre-channel placement is justified by actual occlusion benefit or a later departure plan, not the channel label alone.

## Original policy: assign an observation job before choosing a tile

The policy should answer: **which uncertainty could change the next important decision, who must observe it, and how early must it arrive?** Bush proximity, total area, and ward volume are secondary diagnostics.

Use the actual mission selected by the bot, with a small ordered set of jobs:

1. **Protect a vulnerable commitment.** Before a recall, tribute, capture hold, or camp fight that spends health/time, observe likely enemy approaches and flanks. A view of the objective tile alone may be too late. Weight the stake: carried gems, expected death loss, exposure duration, and value of completing the action.
2. **Protect the next route decision.** Before crossing a region boundary, rounding a wall, entering a contested camp, or taking a retreat fork, reveal the branch that could change the next step. Reuse planned movement and danger estimates, rather than the default enemy-spawn vector.
3. **Maintain a remote watcher.** If the old ward still observes a relevant attack route, valuable camp, or retreat corridor while its owner moves elsewhere, retain it. The observer's useful lifetime is the mission's lifetime, not distance from the owner.
4. **Resolve enemy allocation.** When a previously seen enemy disappears, watch reachable exits or transitions that distinguish credible routes. Empty observations can eliminate only actually observed positions at the observed time. They cannot certify the whole route safe.
5. **Scout unresolved geometry only when it changes routing.** If map geometry is already public/known, do not spend score on rediscovering it. Static knowledge persists; the absence of enemies does not.

This prioritization is a hypothesis, not a new unconditional rule that must delay urgent combat or survival. Prefer useful positions already within legal deployment range. Do not add an unsafe detour for a hypothetical future warning.

## Compare replacement against keeping the old observer

For each bounded legal candidate `w`, and for the current ward `old`, score utility under the **same future mission and same owner-only natural-vision baseline**. Build a short set of predicted mission waypoints `p_i(t)` at meaningful times: next step/fork, expected camp/capture hold, departure from the objective, retreat/banking route, and post-recall position where relevant. Let `N_i(t)` be actual hypothetical natural sight at that waypoint, and `W(w)` actual ward sight. The ward's marginal personal mask at time `t` is `W(w) - N_i(t)`; weight it by what could happen there at that time and which decision it can change. These waypoints and timing estimates are a planning approximation to test, not guaranteed future positions.

```text
U_i(w) = useful_route_warning_i(w)
       + commitment_and_flank_information_i(w)
       + enemy_route_disambiguation_i(w)
       + relevant_unknown_geometry_i(w)
       - exposure_or_action_opportunity_cost_i(w)

replace only when U_i(w) - U_i(old) exceeds a small tested switching margin
```

Evaluate no ward as zero ward contribution. Utility is marginal over what this owner expects to see naturally over the mission horizon. **Do not limit the horizon to the current tile or current turn.** In open terrain this would reject every fresh legal ward by construction. Predicting departure matters: overlap with the owner's sight right now can become useful remote coverage after departure. A long expected stay may make a new local ward less urgent; an imminent recall can make a relevant remote watcher valuable immediately after arrival at spawn.

Do **not** use only `candidate_mask - current_effective_vision`. That can erase the cost of losing the old remote view, and it treats information already supplied by the old ward as valueless. Compute both counterfactual states (keep old versus replace), then compare. Do not subtract allies' masks as if pixels were shared. An allied report is a separate, timestamped, lower-bandwidth information source with a reader delay.

The old helper's `distance<=6 from goal` retention proxy should become an actual mission-value comparison. A useful old chokepoint view can remain better than a larger new local view; a blocked old ward near the goal can be worse than a modest new view.

## Route warning: use travel time and response time

Build a small walkable-region/transition graph from the actual map. Select a few plausible enemy routes toward the planned path, commitment, retreat corridor, or protected location. For each route, find the first tile the ward would reveal and estimate:

```text
warning_slack = earliest_enemy_time(detection_tile -> dangerous_contact)
              - owner_response_time
              - report_and_reader_delay_if_protecting_an_ally
```

Positive slack means the information could arrive early enough to change an action. Use conservative enemy movement/ability reach and turn order; do not substitute Chebyshev distance for travel time through walls. Bound extreme values and count route families once, so a long unimportant route cannot dominate an uncovered short attack route. Include a worst-credible-approach penalty alongside weighted route coverage when several flanks exist. Treat dash routes, unseen bypasses, and uncertain enemy locations as uncertainty, not as proven choke geometry.

A first version can reuse existing path fields and a few mission-specific transition points. Evaluate warning at predicted future owner/mission states, not just the placement turn: open-field placement cannot extend current vision, but a persistent remote interception point can detect a later rotation. Full map all-pairs routing, an enemy belief model, and precise initiative prediction are separate experiments, not prerequisites for every placement.

## Timing hypotheses that the current end-of-turn call cannot express

- **Before moving:** where wall/bush occlusion makes it informative, place from the current tile when the resulting view can approve, redirect, or cancel the next step. Rescan the newly revealed enemy/obstruction state before committing. End-of-turn sight cannot prevent the crossing already taken. In open terrain use future persistent value instead of claiming immediate extended reach.
- **Before committing:** where the mechanics audit permits both actions, place before starting a long channel, spending a movement-exclusive cast, attacking a dangerous camp, or beginning a close fight only when actual new sight can feed that decision, or the observer is valuable after the planned departure/recall. An unobstructed local ward cannot add immediate sight to the stationary owner's radius-8 square.
- **After moving:** retain an opportunity when moving safely grants a better legal deployment point or a new mission is selected. This competes with an earlier placement because there is only one charge that owner turn.

Choose the timing that answers the current decision. The free one-turn recharge does not make an early placement irrelevant: it spends that turn's one observation choice and replaces the old ward. Conversely, waiting an arbitrary four/eight rounds wastes opportunities unrelated to recharge. Cheap readiness/event checks can run each turn; expensive rescoring can be event-gated. Continuing channels and every action-order exception must follow the verified engine contract.

## Concrete original scenario presets to test later

These are policy hypotheses, not observed success cases or map-specific copied coordinates. Each preset still compares keeping the old observer.

| Job | Trigger | Placement and decision loop | Stop/retire condition |
| --- | --- | --- | --- |
| Blind corner / bush crossing | The next planned step or commitment passes an occluded branch with credible enemy access. | Consider legal nearby ward centers whose true masks reveal that branch. Place before crossing only if the gain can change the decision; rescan and then cross, reroute, or wait according to the revealed risk. Never claim immediate open-field radius extension. | Branch is naturally visible, crossing is completed, the route is abandoned, or no legal candidate resolves the uncertainty. |
| Guard a camp approach | A valuable camp/capture will occupy the owner, or the owner will leave while the approach remains relevant. | Watch enemy ingress/flank transitions, rather than automatically the camp center. During an open stationary hold the natural radius-8 mask may already cover everything; count only occluded immediate gain and persistent coverage after the predicted departure. | Camp job is resolved/abandoned, relevant approach changes, or old coverage answers a more valuable mission. |
| Preserve a watcher through recall | The owner is about to leave a strategically relevant region for spawn. | If legal before beginning recall, compare the best local future watcher with the existing remote ward using post-recall natural sight. Prefer the observation point that can inform the next route, enemy rotation, or objective choice after arrival. Rescan/read it after recall. | Remote information no longer changes any next mission, or a later candidate wins the replacement comparison. Do not refresh just because the ward is old. |
| Retreat or tribute route warning | Carried gems/health make a particular corridor or fork costly to misread. | Use the actual chosen escape/banking route and enemy approach graph. Before entering an occluded fork, seek immediate useful sight; after departure, keep the rear/side watcher only if its warning reaches the owner before contact. No detour into threat to obtain it. | The protected travel segment ends, natural sight covers the threat, warning would be too late, or route switches. |
| Off-path allocation watch | A known mission depends on whether an enemy uses one of several reachable exits. | Keep or place a persistent observer at a legal local transition while already passing it. Observe it personally after moving away; report to an ally only with a verified compact protocol and enough response slack. | The last-sighting reachable set/mission no longer intersects the watched exit, or fresh observation resolves the allocation question. |

There is no raw global-coverage objective. An unobserved region has value only when its future contents could change a relevant decision for its actual observer or a reachable report recipient.

## Team allocation must respect personal sight and existing memory

An owner can use its remote ward immediately without broadcasting pixels. Protecting another champion is different: the observer must publish an actionable alert and that champion must read it before the threat arrives. Do not infer collective coverage from a union of allied ward masks.

The stable eight-byte channel is already allocated: claims bytes 0-4 and camp lifecycle bytes 5-6 (`main.cpp:1561-1564`), including packed six-body claims (`:1570-1627`). `fight.h:60-62` reserves byte 7 for an optional help call; the current `P_CALLHELP` defaults to zero at `fight.h:18-20`. Its format is enemy index plus round modulo 32 (`:183-202`), not a general location report.

Start with personal scouting, requiring no protocol change. A later team-warning phase must explicitly budget compatible bytes/bits, derive coordinate/region/time widths from verified limits, define writer priority and freshness wraparound, and preserve claim/cooldown behavior. A compact region or known-enemy alert may fit more plausibly than coordinates plus a full enemy list. An alert must remain evidence with source, observation time, and expiry; it must not become an unconditional current target. Test owner/reader initiative delay and overwrites before using it for survival decisions.

## Bounded first implementation phases, for later authorization

No phase is implemented in this research pass.

1. **Personal mission baseline:** retain existing movement/combat/economy; no ward detours, no team-memory changes. Evaluate the legal local window (at most 25 geometric candidates), actual ward masks, a few mission approaches, and keep-versus-replace value over predicted mission waypoints. Establish a cheap fuel budget and explicit fallbacks. Include the planned departure/post-recall natural-sight counterfactual from the start; a current-only overlap score is invalid as the open-field gate. Label the waypoint/time prediction approximation.
2. **Decision timing:** separately compare end-of-turn placement with one pre-movement/pre-commit observation point where legal. Rescan only the state that can change the pending decision. Do not combine this with broad combat or economy changes.
3. **Route warning:** add cached region transitions and conservative detection-to-contact slack. Include open maps and multiple-route maps, not only convenient chokepoints.
4. **Coordinated alerts:** only after personal value is demonstrated, add a separately versioned byte budget and timestamped priority report; then evaluate team allocation. This phase can be rejected independently without losing personal scouting.

Required diagnostic proposals: check reason, no ward/keep/replace, mission job, candidate/current utility, placement point, true personal novel mask, relevant old coverage lost, placement success/false/exception, fuel delta, first detection and estimated threat time, and whether a decision actually changed. Use bounded sampled logs rather than unbounded per-tile output.

Later comparisons should include stable no-ward, the old dormant heuristic, always-place-if-legal, maximum personal new-mask coverage, and mission-directed placement, on identical map/seed/side pairs. Ablate replacement retention, early timing, route warning, and messaging separately. Report match outcomes together with unobserved flank arrivals, warning slack, unsafe detours, old useful coverage discarded, stale alerts acted on, and compute. A higher ward count or larger mask alone does not establish benefit.

## Transfer and evidence limits

`work/ward-research/lol-transfer.md` supplies the source-backed transferable ideas: give a ward a job, watch approaches before a planned action, use depth for warning time, preserve useful off-path information, and avoid redundant information. This note's graph score, counterfactual replacement comparison, owner-sensitive allocation, timing phases, and protocol constraints are original adaptations to this SDK. No elite Battlecode implementation is required to derive them, and no LoL cost/expiry/sweeper/timer assumption is imported.

The strongest current conclusion is diagnostic: our stable policy is off, and the dormant experiment is late, bush-only, geometric, weakly mission-aware, and uninstrumented. The proposed policy has a clear causal goal and measurable failure cases, but still needs later implementation and controlled matches before any claim of improvement.
