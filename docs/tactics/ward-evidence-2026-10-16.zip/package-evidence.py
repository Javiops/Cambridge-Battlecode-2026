"""Package curated ward research evidence, explicitly excluding huge raw traces."""
from pathlib import Path
import csv,io,json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
PUB=ROOT/'publication'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
native=json.loads((ROOT/'acquisition/manifest-native.json').read_bytes())
unique=json.loads((ROOT/'matches/manifest-current-unique.json').read_bytes())
representatives={r['raw_sha256']:r['id']for r in unique['requests']}
stream=io.StringIO(newline='')
fields=['id','representative_id','raw_sha256','bundle_sha256','bundle_url','series_id','series_url','map','created_at','kind','team_a_id','team_a','team_a_rank','team_b_id','team_b','team_b_rank','selection_reasons']
writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
for r in native['requests']:
    row={key:r[key]for key in ['id','raw_sha256','bundle_sha256','bundle_url','series_id','series_url','map','created_at','kind']}
    row['representative_id']=representatives[r['raw_sha256']]
    for side in ['a','b']:
        t=r['teams'][side]
        row.update({f'team_{side}_id':t['teamId'],f'team_{side}':t['name'],f'team_{side}_rank':t['rank']})
    row['selection_reasons']=';'.join(r['ward_selection_reasons'])
    writer.writerow(row)
payload={'replay-index.csv':stream.getvalue().encode('utf8')}
include=['cohort-audit.json','ward-summary-review.json','mechanics.md','mechanics-evidence.json','mechanics-crossaudit.md','our-policy-review.md','lol-sources.json',
         'matches/current-findings.md','matches/current-summary.json','matches/current-summary.csv','matches/current-champion-bodies.csv','matches/current-audit.json','matches/native-map-audit.json','matches/map-ward-context.json',
         'acquisition/ladder-snapshot.json','acquisition/discover.py','acquisition/fetch-histories.py','acquisition/fetch-groups.py','acquisition/select-replays.py','acquisition/fetch-native.py',
         'matches/scan-wards.mjs','matches/run-scanner.py','matches/aggregate-wards.py','matches/audit-current.py','audit-cohort.py','plot-ward-case.py','package-evidence.py',
         'matches/cases/rank1-4b5c61db-a064-4459-bc95-31150aa96347.json']
optional=['publication-review.json']
include +=[name for name in optional if(ROOT/name).is_file()]
for pattern in ['probe-*.mjs','probe-*-output.json','probe-*-summary.json','matches/cases-h2h/*.json','matches/cases-contrast/*.json','publication/ward-*-persistence.json','publication/ward-*-persistence.svg']:
    include +=[p.relative_to(ROOT).as_posix()for p in ROOT.glob(pattern)]
for name in sorted(set(include)):
    payload[name]=(ROOT/name).read_bytes()
payload['dependencies/map-variants.mjs']=(ROOT.parent/'battlecode-bot-v1/r2-ward/map-variants.mjs').read_bytes()
readme='''# Ward research evidence — 16 October 2026

Research documentation only; this ZIP is NOT a Battlecode bot submission.

The core cohort contains 3,766 public game IDs and 2,119 raw replay streams.
The replay index preserves every ID's team attribution, public bundle URL,
raw/bundle SHA-256, and the exact representative used for native inspection.
Current-summary.json contains descriptive tables; current-audit.json retains
per-representative output hashes and ward/sample totals. The independent cohort
and summary reviews state their precise scopes. Illustrated cases contain exact
embedded terrain, owner/ward state, masks and recorded follow-up commands.
The compact Mite-v-Fish case instead retains audited placement/later records,
counts, enemy positions and source hashes, without full later tile-mask arrays.

Included: compact evidence, case frames, source/probe notes, engine fixtures,
public source identities and the actual analysis scripts. All match sources are
public API/replay observations; no opponents' private bot code is present.

Excluded: the ~1.90 GB complete per-placement/action trace tree, all raw replays
and bundles, all history/group API payloads, credentials, private configs,
repository metadata, runtime installations, and the vendor engine binary/SDK.
These remain either local evidence or separately retrievable public source.
The archive is not a substitute for those full raw source files.

To reproduce, retrieve the public bundles listed in replay-index.csv and verify
their SHA-256 and replay.repl26a CRC/member bytes. Use the recorded official
engine WASM ce302dc6666ae43592f6936e572bc4baca92a345bff13ef7f986609ac666a0dc
with matching SDK/CLI2.1.6. The scripts retain their original workspace-relative
loader and runtime paths for provenance: configure those paths for your checkout,
including dependencies/map-variants.mjs, before running them. They are source
records, not a promised one-command portable rerun installation.

Native placement scans advance recorded replays, not new bots. Mechanics fixtures
use controlled editor sandbox setups. They do not establish a winning strategy.
Recorded non-ward commands are not independently classified as successful.
Later owner vision is sampled on alive owner turns, not every legal opportunity.
Ranks are a frozen retrieval snapshot; all public version fields were null.
Repeated raw streams are aliases, not independent new executions.

The source of each table and all archive payload hashes are in manifest.json.
'''
payload['README.txt']=readme.encode('utf8')
entries={name:{'bytes':len(raw),'sha256':sha(raw)}for name,raw in sorted(payload.items())}
manifest={'purpose':'Curated descriptive ward strategy evidence, not a bot upload or complete raw-trace archive','native_manifest_sha256':sha((ROOT/'acquisition/manifest-native.json').read_bytes()),'game_ids':3766,'raw_replay_streams':2119,'files':entries}
payload['manifest.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf8')
path=PUB/'ward-evidence-2026-10-16.zip'
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for name,raw in sorted(payload.items()):
        assert not Path(name).is_absolute()and'..'not in Path(name).parts
        item=zipfile.ZipInfo(name,date_time=(2026,10,16,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;item.external_attr=0o100644<<16
        z.writestr(item,raw,compresslevel=9)
with zipfile.ZipFile(path)as z:
    assert z.testzip()is None and len(z.namelist())==len(payload)
    for name,raw in payload.items():assert z.read(name)==raw
out={'archive':path.name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'entries':len(payload),'payload_manifest_sha256':sha(payload['manifest.json']),'raw_sources_included':False,'complete_local_per_placement_traces_included':False}
(PUB/'ward-evidence-2026-10-16.manifest.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
