"""Render exact native replay masks, not an assumed visibility radius."""
from pathlib import Path
import json,sys,hashlib
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'battlecode-match-analysis/pythonlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Patch
from matplotlib.lines import Line2D

contrast='--contrast'in sys.argv
path=ROOT/('matches/cases-contrast/rank6-b9b40d5e-dacc-443a-af00-b4e571359090.json'if contrast else'matches/cases/rank1-4b5c61db-a064-4459-bc95-31150aa96347.json')
d=json.loads(path.read_bytes())
folder=ROOT/'publication';folder.mkdir(exist_ok=True)
fig,axes=plt.subplots(1,2,figsize=(12,6.4))
fig.subplots_adjust(top=.78,bottom=.20,left=.055,right=.985,wspace=.15)
colors={'Bush':'#b6cf9b','Wall':'#44494f','Hole':'#9b9da4','Altar':'#e0bd60'}
xmin,xmax,ymin,ymax=(18,42,32,55)if contrast else(30,63,0,23)
for ax,key in zip(axes,['placed','later']):
 s=d[key];assert s['personalUnionMatches']
 ax.set_facecolor('#f8f7f2')
 for kind,tiles in d['terrain']['tiles'].items():
  for x,y in tiles:
   if xmin<=x<=xmax and ymin<=y<=ymax:
    ax.add_patch(Rectangle((x-.5,y-.5),1,1,facecolor=colors.get(kind,'#f8f7f2'),edgecolor='none',zorder=1))
 for name,color,alpha in [('champion','#91c5e9',.48),('roundReveals','#91c5e9',.48),('extraWard','#f6a83e',.62)]:
  for x,y in s['masks'][name]:
   if xmin<=x<=xmax and ymin<=y<=ymax:
    ax.add_patch(Rectangle((x-.5,y-.5),1,1,facecolor=color,alpha=alpha,edgecolor='none',zorder=2))
 visible={tuple(t)for t in s['masks']['personal']}
 for c in s['camps']:
  pos=c.get('position',{});x,y=pos.get('x'),pos.get('y')
  if(x,y)in visible and xmin<=x<=xmax and ymin<=y<=ymax:
   ax.scatter(x,y,s=20,marker='o',facecolor='white',edgecolor='#576541',linewidth=.8,zorder=4)
 for c in s['champions']:
  pos=c.get('position',{});x,y=pos.get('x'),pos.get('y')
  if c.get('alive')and c.get('team')!=s['owner']['team']and(x,y)in visible and xmin<=x<=xmax and ymin<=y<=ymax:
   ax.scatter(x,y,s=45,marker='x',color='#b72137',linewidth=1.8,zorder=5)
 p=s['owner']['position'];w=s['ward']['position']
 ax.scatter(p['x'],p['y'],s=130,marker='*',color='#1260a0',edgecolor='white',linewidth=.8,zorder=6)
 ax.scatter(w['x'],w['y'],s=80,marker='D',color='#782b86',edgecolor='white',linewidth=.8,zorder=6)
 ax.set(xlim=(xmin-.5,xmax+.5),ylim=(ymax+.5,ymin-.5),aspect='equal',xlabel='Map x',ylabel='Map y')
 ax.set_xticks(range(xmin,xmax+1,5));ax.set_yticks(range(ymin,ymax+1,5))
 ax.set_title(f"Round {s['round']} · {d['placement']['name']} at ({p['x']}, {p['y']})\nWard-only personal sight: {len(s['masks']['extraWard'])} tiles",fontsize=11)
 ax.tick_params(labelsize=9)
 for spine in ax.spines.values():spine.set_color('#c4c6c9')
topic='Zero new sight at placement can become additional remote sight'if contrast else'A persistent bush observer after its owner leaves'
team=d['team'].replace('\u2764','').replace('\ufe0f','')
fig.suptitle(f"{topic}\n{team} vs {d['opponent']} · {d['map']}",fontsize=13,fontweight='bold',y=.975)
legend=[Patch(facecolor='#b6cf9b',label='Bush'),Patch(facecolor='#91c5e9',alpha=.6,label='Body sight'),Patch(facecolor='#f6a83e',alpha=.7,label='Ward-only sight'),Line2D([0],[0],marker='*',color='none',markerfacecolor='#1260a0',markersize=11,label='Owner'),Line2D([0],[0],marker='D',color='none',markerfacecolor='#782b86',markersize=7,label='Own ward'),Line2D([0],[0],marker='o',color='none',markerfacecolor='white',markeredgecolor='#576541',label='Visible camp')]
legend += [Line2D([0],[0],marker='x',color='none',markeredgecolor='#b72137',markersize=7,label='Visible enemy'),Patch(facecolor='#9b9da4',label='Hole'),Patch(facecolor='#e0bd60',label='Altar'),Patch(facecolor='#44494f',label='Wall')]
fig.legend(handles=legend,loc='lower center',bbox_to_anchor=(.5,.02),ncol=5,frameon=False,fontsize=9)
basename='ward-open-persistence'if contrast else'ward-lanes-persistence'
for suffix in ['png','svg']:
 fig.savefig(folder/f'{basename}.{suffix}',dpi=170,metadata={'Creator':'Matplotlib; exact recorded official-engine masks'})
plt.close(fig)
record={'case':str(path),'case_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'match_id':d['id'],'raw_sha256':d['sourceSha256'],'rounds':[d['placed']['round'],d['later']['round']],'ward_position':d['placed']['ward']['position'],'extra_tiles':[len(d[k]['masks']['extraWard'])for k in ['placed','later']],'coordinate_system':'Native map coordinates; y increases downward','scope':'Cropped static map terrain and exact owner sight masks; only owner-visible camps/enemies rendered. This demonstrates observed visibility, not intent or a causal winning effect.'}
(folder/f'{basename}.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
