import fs from 'node:fs';
import {E,out,checked,v,scratch,state,pos,entity,perspective,ward,cstring} from './mechanics-harness.mjs';
import {createGame,teleport,finish} from './probe-grid.mjs';
const records=[];
function toTurn(g,id){let s=state(g);for(let i=0;i<100;i++){if(s.current===id)return s;s=finish(g)}throw Error('turn loop')}
function test(name,fn,picks){let g=createGame(picks);try{teleport(g,0,12,12);records.push({name,...fn(g)});}catch(e){records.push({name,error:String(e)})}finally{checked('Game_Destroy',g)}}
test('dead_owner_ward_action',g=>{const w=ward(g,14,14);checked('Game_Sandbox_Damage',g,entity(1,2),entity(1,0,24),100000);const atDeath=state(g).champs[0];finish(g);const s=toTurn(g,0);return {ward:w,atDeath,next:s.champs[0],result:ward(g,12,12),wards:state(g).wards}});
test('cassi_issac_separate_wards',g=>{const before=state(g);const first=ward(g,14,14);finish(g);const s=toTurn(g,1);teleport(g,1,10,10);const second=ward(g,10,10);return {before,first,firstOwner:state(g).champs[0],second,secondOwner:state(g).champs[1],wards:state(g).wards,firstView:state(g,0,0).wards,secondView:state(g,0,1).wards}},[3,1,4,5]);
test('ward_during_tribute',g=>{teleport(g,0,12,15);checked('Game_Sandbox_GiveGems',g,0,10);checked('Game_Action_SubmitGems',g,pos(13,15));return {result:ward(g,12,15),after:state(g).champs[0]}});
test('ward_during_tpcrystal',g=>{teleport(g,0,1,1);checked('Game_Sandbox_GiveGold',g,0,1000);checked('Game_Action_BuyConsumable',g,0);teleport(g,0,12,12);checked('Game_Action_UseConsumable',g,0,pos(11,11),out);return {result:ward(g,12,12),after:state(g).champs[0]}});
test('control_ward_unpurchasable',g=>{teleport(g,0,1,1);checked('Game_Sandbox_GiveGold',g,0,1000);const code=E.Game_Action_BuyConsumable(g,1);const error=cstring(E.GetLastErrorMsg());checked('Game_Visualiser_GetShopEntry',1,1,scratch);return {code,error,carryLimit:v().getUint32(scratch+12,true),purchasable:!!v().getUint32(scratch+36,true)}});
test('ward_reveal_immediate_targeted_action',g=>{teleport(g,0,12,13);teleport(g,2,14,13);const hidden=state(g,0,0).champs[2];const firstAttack=E.Game_Action_Attack(g,entity(1,2));const firstError=cstring(E.GetLastErrorMsg());const w=ward(g,14,13);const seen=state(g,0,0).champs[2];const move=E.Game_Action_Move(g,13,12,out);const secondAttack=E.Game_Action_Attack(g,entity(1,2));return {hidden,firstAttack,firstError,ward:w,seen,move,secondAttack}});
fs.writeFileSync('work/ward-research/probe-exceptions-output.json',JSON.stringify(records,null,2));console.log(JSON.stringify(records,null,2));

