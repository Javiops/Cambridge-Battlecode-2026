import {E,checked,v,out,loadGame,state} from './mechanics-harness.mjs';
const g=loadGame();checked('Game_Runner_Init',g);console.log('init',JSON.stringify(state(g)));
for(let k=0;k<20;k++){let s=state(g);if(s.input && s.phase===12){const t=k%11; const c=E.Game_Draft_Champion(g,t);console.log('draft',t,c);}else if(s.input&&s.phase===10){break;}else checked('Game_Runner_Step',g);console.log(k,JSON.stringify(state(g)));}
checked('Game_Destroy',g);

