import fs from 'node:fs';
import crypto from 'node:crypto';
import {E,out,checked} from '../battlecode-bot-v1/r2-ward/map-variants.mjs';
const v=()=>new DataView(E.memory.buffer);
const p=E.Engine_Malloc(256); new Uint8Array(E.memory.buffer,p,256).fill(0);
const exports=Object.fromEntries(Object.entries(E).filter(([n,f])=>typeof f==='function' && /Settings|Ward|VisionMask|Runner_|Draft|Sandbox_Teleport/.test(n)).map(([n,f])=>[n,f.length]));
console.log(JSON.stringify({exports}));
let code=E.Game_API_GetSettings(p); console.log(JSON.stringify({settingsReturn:code,bytes:Array.from(new Uint8Array(E.memory.buffer,p,160))}));
console.log(JSON.stringify({wardSettings:{active:v().getUint32(p+60,true),charges:v().getUint32(p+64,true),shared:v().getUint32(p+68,true),draft:v().getUint32(p+72,true),reveal:v().getUint32(p+76,true),cooldown:v().getInt32(p+80,true),lifetime:v().getInt32(p+84,true),vision:v().getFloat32(p+88,true),placement:v().getFloat32(p+92,true),controlVision:v().getFloat32(p+96,true),controlPlacement:v().getFloat32(p+100,true)}}));
const wasm=fs.readFileSync('work/battlecode-bot-v1/r2-research/v0_0_1-ctH8uuEb.wasm');
console.log(JSON.stringify({engineSha256:crypto.createHash('sha256').update(wasm).digest('hex')}));
E.Engine_Free(p);

