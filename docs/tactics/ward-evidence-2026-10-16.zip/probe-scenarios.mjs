import fs from 'node:fs';
import {E,out,checked,v,scratch,state,pos,entity,perspective,ward,cstring} from './mechanics-harness.mjs';
import {createGame,teleport,mask,finish} from './probe-grid.mjs';
const records=[];
function test(name,fn){let g=createGame();try{teleport(g,0,12,12);records.push({name,...fn(g)});}catch(e){records.push({name,error:String(e)})}finally{checked('Game_Destroy',g)}}
for(const [name,p] of Object.entries({self:[12,12],floor:[11,12],bush:[14,14],wall:[14,15],hole:[15,14],altar:[13,15],camp:[13,14],diagonal2:[10,10],distance3:[9,12],outside:[-1,12]}))test('placement_'+name,g=>{if(['wall','hole','altar'].includes(name))teleport(g,0,13,12);return {from:state(g).champs[0],destination:p,result:ward(g,...p),after:state(g).champs[0],wards:state(g).wards}});
test('placement_on_ally',g=>{teleport(g,1,13,12);return {result:ward(g,13,12)}});
test('placement_on_visible_enemy',g=>{teleport(g,2,13,12);return {visibleBefore:state(g,0,0).champs[2],result:ward(g,13,12),after:state(g).champs[0]}});
test('placement_on_hidden_enemy',g=>{teleport(g,2,14,14);return {visibleBefore:state(g,0,0).champs[2],result:ward(g,14,14),visibleAfter:state(g,0,0).champs[2],after:state(g).champs[0]}});
test('placement_behind_wall',g=>{teleport(g,0,14,16);return {visibleBefore:state(g,0,0).champs[0],result:ward(g,14,14)}});
test('placement_on_own_spawn',g=>{teleport(g,0,4,2);return {result:ward(g,3,2)}});
test('placement_on_enemy_spawn',g=>{teleport(g,0,27,2);return {result:ward(g,29,2)}});
test('ward_then_move_attack_cast',g=>{teleport(g,2,13,11);const w=ward(g,12,12);const afterWard=state(g).champs[0];const move=E.Game_Action_Move(g,12,11,out);const attack=E.Game_Action_Attack(g,entity(1,2));const cast=E.Game_Action_Cast(g,0,entity(0,0),pos(13,11),out);return {ward:w,afterWard,move,attack,cast,secondWard:ward(g,12,12),after:state(g).champs[0]}});
test('move_then_ward',g=>{const move=E.Game_Action_Move(g,11,11,out);return {move,result:ward(g,9,9)}});
test('ward_recharge_and_replace',g=>{const first=ward(g,12,12),after=state(g).champs[0];let s=finish(g);const end=s.champs[0];while(s.current!==0)s=finish(g);const next=s.champs[0],second=ward(g,11,11);return {first,after,end,next,second,wards:state(g).wards}});
test('ward_during_recall',g=>{checked('Game_Action_Recall',g);return {result:ward(g,12,12),after:state(g).champs[0]}});
test('ward_then_recall',g=>{const w=ward(g,12,12);const r=E.Game_Action_Recall(g);return {ward:w,recall:r,after:state(g).champs[0]}});
test('ward_during_stun',g=>{checked('Game_Sandbox_Buff',g,entity(1,0),1,1,1);return {result:ward(g,12,12),after:state(g).champs[0]}});
test('ward_after_death',g=>{checked('Game_Sandbox_Damage',g,entity(1,2),entity(1,0,24),100000);return {result:ward(g,12,12),after:state(g).champs[0]}});
test('own_remote_ward_personal_vision',g=>{const first=ward(g,14,14);teleport(g,0,2,10);return {first,ownerView:state(g,0,0).wards,allyView:state(g,0,1).wards,enemyView:state(g,1,2).wards,ownerSelf:state(g,0,0).champs[0]}});
test('ward_masks',g=>{return {open:mask(g,8,24),insideBush:mask(g,14,14),outsideBush:mask(g,12,14),aboveHole:mask(g,15,13),againstWall:mask(g,14,16)}});
fs.writeFileSync('work/ward-research/probe-scenarios-output.json',JSON.stringify(records,null,2));console.log(JSON.stringify(records.map(r=>({name:r.name,result:r.result,first:r.first,second:r.second,move:r.move,attack:r.attack,cast:r.cast,recall:r.recall,error:r.error,wards:r.wards,openCount:r.open?.length})),null,2));

