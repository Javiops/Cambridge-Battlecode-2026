import fs from 'node:fs';
import {E,out,checked,v,scratch,state,pos,entity,perspective,ward,cstring} from './mechanics-harness.mjs';
import {createGame,teleport,mask,finish} from './probe-grid.mjs';
const records=[];
function test(name,fn){let g=createGame();try{teleport(g,0,12,12);records.push({name,...fn(g)});}catch(e){records.push({name,error:String(e)})}finally{checked('Game_Destroy',g)}}
function toTurn(g,id){let s=state(g);for(let i=0;i<100;i++){if(s.current===id)return s;s=finish(g)}throw Error('turn loop')}
function vision(g,team,id){checked('Game_Visualiser_GetVisionBuffer',g,perspective(team,id),out);const p=v().getUint32(out,true),d=v();const tiles=[];for(let yy=0;yy<32;yy++)for(let xx=0;xx<32;xx++)if(d.getBigUint64(p+((yy>>3)*4+(xx>>3))*8,true)&1n<<BigInt((yy%8)*8+xx%8))tiles.push([xx,yy]);return tiles;}
test('same_own_tile_replacement',g=>{const first=ward(g,14,14);finish(g);toTurn(g,0);return {first,second:ward(g,14,14),after:state(g).champs[0],wards:state(g).wards}});
test('known_allied_ward_overlap',g=>{const first=ward(g,12,12);finish(g);toTurn(g,1);teleport(g,1,11,12);return {first,before:state(g,0,1).wards,second:ward(g,12,12),after:state(g).champs[1]}});
test('hidden_allied_ward_overlap',g=>{const first=ward(g,14,14);finish(g);toTurn(g,1);teleport(g,0,10,10);teleport(g,1,12,12);const before=state(g,0,1).wards;const visBefore=vision(g,0,1);const second=ward(g,14,14);return {first,before,second,after:state(g).champs[1],visibleAfter:state(g,0,1).wards,visBefore,visAfter:vision(g,0,1),retry:ward(g,13,12),afterRetry:state(g).champs[1]}});
test('enemy_ward_overlap',g=>{const first=ward(g,12,12);finish(g);toTurn(g,2);teleport(g,2,12,11);return {first,second:ward(g,12,12),after:state(g).champs[2],wards:state(g).wards}});
test('ward_then_spell',g=>{const w=ward(g,12,12);const cast=E.Game_Action_Cast(g,0,entity(0,0),pos(13,11),out);return {ward:w,cast,after:state(g).champs[0]}});
test('ranged_ward_then_attack',g=>{finish(g);toTurn(g,2);teleport(g,2,13,12);const w=ward(g,13,11);const attack=E.Game_Action_Attack(g,entity(1,0));return {ward:w,attack,after:state(g).champs[2]}});
test('walk_onto_enemy_ward',g=>{const w=ward(g,12,12);finish(g);toTurn(g,2);teleport(g,2,12,11);teleport(g,0,10,10);const move=E.Game_Action_Move(g,12,12,out);return {ward:w,move,success:!!v().getInt32(out,true),after:state(g).champs[2]}});
test('attack_ordinary_ward',g=>{const w=ward(g,12,12);const id=state(g).wards[0].id;finish(g);toTurn(g,2);teleport(g,2,12,11);const attack=E.Game_Action_Attack(g,entity(3,id));return {ward:w,attack,error:cstring(E.GetLastErrorMsg()),wards:state(g).wards}});
test('kill_owner_preserves_ward',g=>{const w=ward(g,14,14);const kill=E.Game_Sandbox_Damage(g,entity(1,2),entity(1,0,24),100000);return {ward:w,kill,owner:state(g).champs[0],wards:state(g).wards,ownerVision:vision(g,0,0)}});
test('recall_preserves_remote_ward',g=>{const w=ward(g,14,14);checked('Game_Action_Recall',g);let s=state(g);for(let i=0;i<6;i++){finish(g);s=toTurn(g,0)}return {ward:w,owner:s.champs[0],wards:s.wards,ownerView:state(g,0,0).wards}});
test('bush_and_wall_tiles',g=>{const inside=mask(g,14,14),outside=mask(g,12,14),wall=mask(g,14,16),hole=mask(g,15,13);const points=[[14,14],[14,13],[13,13],[11,13],[14,15],[14,16],[14,17],[14,12],[15,14],[15,15]];return {samples:points.map(p=>({p,inside:inside.some(q=>q+''===p+''),outside:outside.some(q=>q+''===p+''),wall:wall.some(q=>q+''===p+''),hole:hole.some(q=>q+''===p+'')}))}});
for(let type=0;type<=12;type++){let g=createGame();try{checked('Game_API_Champion_Design',g,type,scratch);records.push({name:'champion_design_'+type,visionType:v().getUint32(scratch+4,true),baseVision:v().getInt32(scratch+88,true),bytes:Array.from(new Uint8Array(E.memory.buffer,scratch,160))});}finally{checked('Game_Destroy',g)}}
fs.writeFileSync('work/ward-research/probe-supplement-output.json',JSON.stringify(records,null,2));console.log(JSON.stringify(records.map(({visBefore,visAfter,ownerVision,bytes,...r})=>({...r,visionBefore:visBefore?.length,visionAfter:visAfter?.length,ownerVisionCount:ownerVision?.length})),null,2));



