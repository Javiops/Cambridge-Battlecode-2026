import {E,out,checked,v,state,pos,entity,ward,cstring} from './mechanics-harness.mjs';
import {createGame,teleport,finish} from './probe-grid.mjs';
let g=createGame();checked('Game_Sandbox_GiveGold',g,0,1000);checked('Game_Action_BuyConsumable',g,0);teleport(g,0,12,12);checked('Game_Action_UseConsumable',g,0,pos(11,11),out);let s=finish(g);while(s.current!==1)s=finish(g);teleport(g,1,12,10);console.log(JSON.stringify({name:'placement_on_teleport_reservation',result:ward(g,11,11),wards:state(g).wards}));checked('Game_Destroy',g);

