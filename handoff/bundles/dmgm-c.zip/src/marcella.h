#pragma once
// marcella.h - Marcella (draft slot 3, in Ren's place: P_DRAFT_SWAP).
// Hooks: shop_plan (champions.h shop part 2). Her damage work (build, spell use) goes here.

namespace marcella {

CHAMP_HOOK bool is(const std::string& n) { return starts_with(n, "marcella"); }

// t10shop-v1: top-10 Marcella build (45 top-10 games on 1.0.3, 10-22): Treasure first, Jungle-s, 2 Bruiser-h,
// Durab-h, 2 Bruiser-f, then Bruiser-h.
CHAMP_HOOK bool shop_plan(State& s) {
    if (!is(s.name)) return false;
    s.plan = {{"treasure", 'h', 1}, {"jungle", 's', 1}, {"bruiser", 'h', 2}, {"durab", 'h', 1}, {"bruiser", 'f', 2}, {"bruiser", 'h', 99}};
#if P_DMGBUILD
    // dmgbuild-m: shards by r100 (top-10 vs top-10, 165 Marcella sides): theirs 51% Focus 32% Strength 17% Health
    // (Treasure-f, Jungle-s), ours 89% Health. Damage emblem first; the health Treasure moves third.
    // (pack-v3 tests: runmech +10, deaths -0.78; panel17 +8/800.) Late shards at r600: their Bruiser-f 3.6 vs our 2.4.
    s.plan = {{"treasure", 'f', 1}, {"jungle", 's', 1}, {"treasure", 'h', 1}, {"bruiser", 'h', 2}, {"durab", 'h', 1}, {"bruiser", 'f', 2}, {"bruiser", 'h', 99}};
    std::printf("[dmgbuild] %s opens %s-%c\n", s.name.c_str(), s.plan[0].family, s.plan[0].stat);
#endif
    return true;
}

}  // namespace marcella
