#pragma once
// ryth.h - Ryth (draft slot 4). Hooks: shop_plan (champions.h shop part 2); champ::hp_share has her health share.

namespace ryth {

CHAMP_HOOK bool is(const std::string& n) { return starts_with(n, "ryth"); }

// t10shop-v1: top-10 Ryth build: Treasure first, Jungle-s, Bruiser-h, Durab-h, Bruiser-s, then Bruiser-h.
CHAMP_HOOK bool shop_plan(State& s) {
    if (!is(s.name)) return false;
    s.plan = {{"treasure", 'h', 1}, {"jungle", 's', 1}, {"bruiser", 'h', 1}, {"durab", 'h', 1}, {"bruiser", 's', 1}, {"bruiser", 'h', 99}};
#if P_DMON
    // dmon (10-24): top-10 emblem completions (t10 vs t10 summaries) put Durab-h with the first Bruiser-h (Marcella r429 vs ours r628,
    // Ryth r607 vs r738, Vendetta r536 vs r618) and Marcella/Ryth carry Monster (40% / 24%, Health); ours never. Same health points.
    if (P_DMON >= 2) s.plan = {{"treasure", 'h', 1}, {"jungle", 's', 1}, {"durab", 'h', 1}, {"monster", 'h', 1}, {"bruiser", 's', 1}, {"bruiser", 'h', 99}};
    else s.plan = {{"treasure", 'h', 1}, {"jungle", 's', 1}, {"durab", 'h', 1}, {"bruiser", 'h', 1}, {"bruiser", 's', 1}, {"bruiser", 'h', 99}};
#endif
    return true;
}

}  // namespace ryth
