#pragma once
// vendetta.h - Vendetta (draft slot 5, in Varg's place: P_DRAFT_SWAP3). Hooks: shop_plan (champions.h shop part 2).
// fight.h's enemy model also knows her dash (legacy name list "vend", replaced by the engine query, P_KINDFIX).

namespace vendetta {

CHAMP_HOOK bool is(const std::string& n) { return starts_with(n, "vendetta"); }

// t10shop-v1: top-10 Vendetta build: Treasure first, Jungle-s, Bruiser-h, Durab-h, then Bruiser-s.
CHAMP_HOOK bool shop_plan(State& s) {
    if (!is(s.name)) return false;
    s.plan = {{"treasure", 'h', 1}, {"jungle", 's', 1}, {"bruiser", 'h', 1}, {"durab", 'h', 1}, {"bruiser", 's', 99}};
#if P_DMON
    // dmon (10-24): top-10 emblem completions (t10 vs t10 summaries) put Durab-h with the first Bruiser-h (Marcella r429 vs ours r628,
    // Ryth r607 vs r738, Vendetta r536 vs r618) and Marcella/Ryth carry Monster (40% / 24%, Health); ours never. Same health points.
    if (P_DMON >= 2) s.plan = {{"treasure", 'h', 1}, {"jungle", 's', 1}, {"durab", 'h', 1}, {"bruiser", 'h', 1}, {"bruiser", 's', 99}};
    else s.plan = {{"treasure", 'h', 1}, {"jungle", 's', 1}, {"durab", 'h', 1}, {"bruiser", 'h', 1}, {"bruiser", 's', 99}};
#endif
    return true;
}

}  // namespace vendetta
