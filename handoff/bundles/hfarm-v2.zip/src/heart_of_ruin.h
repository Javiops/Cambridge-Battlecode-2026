#pragma once
// heart_of_ruin.h - Heart of Ruin (draft slot 1 on near/mid maps; Ren takes it on far maps, P_FAR_SWAP).
// Hooks: shop_plan (champions.h shop part 2), keeps_dash_for_attacks (step_towards), dash_strike (cast_offense).
// Shop part 1 (legacy) also has a horfocus layer for her, and champ::hp_share her health share (0.25).

namespace heart_of_ruin {

CHAMP_HOOK bool is(const std::string& n) { return starts_with(n, "heart"); }

// t10shop-v1: top-10 HoR build (45 top-10 games on 1.0.3, 10-22): Treasure first, Jungle-f, Bruiser-h, Durab-h,
// then Bruiser-f.
CHAMP_HOOK bool shop_plan(State& s) {
    if (!is(s.name)) return false;
    s.plan = {{"treasure", 'h', 1}, {"jungle", 'f', 1}, {"bruiser", 'h', 1}, {"durab", 'h', 1}, {"bruiser", 'h', 2}, {"bruiser", 'f', 99}};
    // hfarm-v2: the top-10 farmer HoR's emblem order (power-1023/seq_out.txt, 152 t10 HoR): Jungle-f/Treasure-f first,
    // health from #3-#5, Power-f at #11. Their HoR has 1000/1500/2000 max hp at r150/500/700 (ours 1400/2100/3000) and
    // hits camps for 50 per attack round r150-800 (ours 34). Only with P_HFARM (she stays out of fights).
    if (P_HFARM && P_HFARM_BUILD)
        s.plan = {{"jungle", 'f', 1}, {"treasure", 'f', 1}, {"treasure", 'h', 1}, {"durab", 'h', 1}, {"bruiser", 'h', 1},
                  {"power", 'f', 1}, {"bruiser", 'h', 2}, {"bruiser", 'f', 99}};
    return true;
}

// horfocus-v1: HoR keeps the dash for attacks (never dashes to walk).
CHAMP_HOOK bool keeps_dash_for_attacks(const State& s) { return P_HORFOCUS && is(s.name); }

// hfarm-v1: the top 10 play Heart of Ruin as a farmer, we as a hunter (top10-micro-1023/plan-1023/README.md, r100-700:
// camp hits 20.5% of her rounds vs our 9.9%, a rival within 6 in 22% vs 34%, walks ending on a champion 23% vs 44%).
// From P_HFARM_R on, with no rival within 2, not hit in the last 2 rounds and no hurt ally (< 50%) within 5 of her
// with a rival within 3 of it, she does not walk into fights (chase, bcf engage, ally duty): she farms.
CHAMP_HOOK bool farms_first(State& s, bc::champion& me, const std::vector<Foe>& foes, int nearest_foe, int round) {
    if (!P_HFARM || !is(s.name) || round < P_HFARM_R || nearest_foe <= 2 || round - s.hit_round <= 2) return false;
    if (foes.empty()) return true;
    bool guard = false;
    const vec2 pos = me.position();
    attempt([&] {
        for (auto& a : bc::vision::champions(*s.my)) {
            if (a == me || !a.is_alive() || dist(a.position(), pos) > 5 || a.health() >= 0.5f * a.max_health()) continue;
            for (auto& f : foes)
                if (dist(f.p, a.position()) <= 3) { guard = true; break; }
            if (guard) break;
        }
        return true;
    });
    if (!guard) {
        static int last = -9, n = 0;
        ++n;
        if (last < round - 1 && fuel_ok(30000) && (n <= 20 || n % 50 == 0)) std::printf("[hfarm] r%d d=%d n=%d\n", round, nearest_foe, n);
        last = round;
    }
    return !guard;
}

// horfocus-v1: the dash is her damage spell. Cast it onto the target, choosing the landing that hits the most
// units of the same encounter. Returns true when it was cast (cast_offense is done for this turn).
template <class U, class A>  // U: one copy per target kind (camp, champion), as when it was inside cast_offense
CHAMP_HOOK bool dash_strike(State& s, bc::champion& me, A& abs, const U& tgt, vec2 tpos, bool champ) {
    (void)tgt;
    if (P_HORFOCUS && s.dash_slot >= 0 && is(s.name) && abs[s.dash_slot].is_ready()) {
        // Previously tried r=3 from our tile (actual dash range is 2) and
        // scanned positions in arbitrary order, causing bad-destination SDK
        // errors and poor multi-target landings. Get the SDK range mask once;
        // filter terrain/occupancy, require the intended target in the radius-1
        // landing hitbox and score other visible units in the SAME encounter.
        auto& ab = abs[s.dash_slot];
        const vec2 origin = me.position();
        bc::bitboard in_range, walls;
        const bool have_range = attempt([&] {
            in_range = ab.valid_tiles();
            walls = bc::map::walls();
            return true;
        });
        if (have_range && fuel_ok(19000)) {
            struct Landing { vec2 p; double score; };
            std::vector<Landing> choices;
            std::vector<vec2> others;
            // Stay away from unrelated camps: damaging them would wake them.
            if (champ) {
                for (auto& enemy : bc::vision::champions(*s.en)) {
                    if (!fuel_ok(9500)) break;
                    attempt([&] {
                        if (enemy.is_alive() && enemy.is_visible() && enemy.position() != tpos)
                            others.push_back(enemy.position());
                        return true;
                    });
                }
            } else if (s.target >= 0 && s.target < static_cast<int>(s.groups.size())) {
                const auto& group = s.groups[s.target];
                for (auto& other : bc::vision::camps()) {
                    if (!fuel_ok(9500)) break;
                    attempt([&] {
                        if (other.health() > 0 && group.mask.is_set(other.spawn_position()) && other.position() != tpos)
                            others.push_back(other.position());
                        return true;
                    });
                }
            }
            const int dash_range = 2;  // the patched Heart of Ruin kit
            for (int dx = -dash_range; dx <= dash_range; ++dx)
                for (int dy = -dash_range; dy <= dash_range; ++dy) {
                    vec2 p = origin + vec2(dx,dy);
                    if (!bc::map::is_in_bounds(p) || s.blocked.is_set(p) || !in_range.is_set(p)) continue;
                    if (!patch_v1::dash_landing_geometry(X(origin),Y(origin),X(p),Y(p),X(tpos),Y(tpos))) continue;
                    // A two-step dash must have at least one legal intermediate
                    // step not crossing a wall. Holes may be crossed by dash.
                    if (dist(origin,p) == 2) {
                        bool path = false;
                        for (int x=-1; x<=1 && !path; ++x)
                            for (int y=-1; y<=1 && !path; ++y) {
                                vec2 mid=origin+vec2(x,y);
                                if ((x || y) && dist(mid,p)==1 &&
                                    bc::map::is_in_bounds(mid) && !walls.is_set(mid)) path = true;
                            }
                        if (!path) continue;
                    }
                    int hits = 1;
                    for (auto other : others) if (dist(other,p) <= 1) ++hits;
                    // In PvP don't dash into extreme fire merely to hit one.
                    const double exposure = champ ? danger_at(s.thr,p) : 0.0;
                    const double score = patch_v1::dash_score(hits,exposure,me.health(),dist(origin,p),champ);
                    choices.push_back({p,score});
                }
            std::sort(choices.begin(),choices.end(),[](const Landing& a,const Landing& b){
                return a.score>b.score;
            });
            for (const auto& c : choices) {
                if (!fuel_ok(11000)) break;
                if (attempt([&] { return ab.use(c.p); })) {
                    ++g_dash_corrected;
                    if (g_dash_corrected <= 8 || g_dash_corrected % 100 == 0)
                        std::printf("[patch-dash] who=%s r=%u casts=%d landing=(%d,%d) score=%.1f\n",
                                    s.name.c_str(), static_cast<unsigned>(bc::round_number()),g_dash_corrected,
                                    X(c.p),Y(c.p),c.score);
                    return true;
                }
            }
        }
    }
    return false;
}

}  // namespace heart_of_ruin
