#pragma once
// Heart of Ruin's own behaviour (Javier 10-23 20:36: per-champion rules live in <champion>.h; without this champion the generic rule applies).
namespace heart_of_ruin {
// laterecall-v2: from r400, below this % hp with a rival within 8, leave (flee, recall when safe). Hard panel vs v6d, laterecall-v1b
// (all champions at 50%): Heart of Ruin r400+ kills-deaths +0.17/game, every other champion 0 or negative (Vesper -0.08, Ryth -0.07).
constexpr int late_recall_pct = 50;
}
