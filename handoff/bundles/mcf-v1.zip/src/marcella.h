#pragma once
// marcella.h - Marcella (draft slot 3, in Ren's place: P_DRAFT_SWAP).
// Hooks: shop_plan (champions.h shop part 2). Her damage work (build, spell use) goes here.

namespace marcella {

CHAMP_HOOK bool is(const std::string& n) { return starts_with(n, "marcella"); }

// t10shop-v1: top-10 Marcella build (45 top-10 games on 1.0.3, 10-22): Treasure first, Jungle-s, 2 Bruiser-h,
// Durab-h, 2 Bruiser-f, then Bruiser-h.
CHAMP_HOOK bool shop_plan(State& s) {
    if (!is(s.name)) return false;
    s.plan = {{"treasure", 'h', 1}, {"jungle", 's', 1}, {"bruiser", 'h', 2}, {"durab", 'h', 1}, {"bruiser", 'f', 2}, {"bruiser", 'h', 99}};
#if P_MCF
    // mcf-v1: her spell does 2 x Focus. Top-10 Marcella shards (t10 vs t10, 162 sides) at r200/400/600: Focus 1.9/4.4/7.7,
    // ours 0.0/0.4/2.6; on near maps her spell hits champions for 437 against our 186. The first Bruiser-f moves to the
    // third slot (after Treasure-h and Jungle-s); the second follows the first Bruiser-h.
    s.plan = {{"treasure", 'h', 1}, {"jungle", 's', 1}, {"bruiser", 'f', 1}, {"bruiser", 'h', 1}, {"bruiser", 'f', 2}, {"bruiser", 'h', 2}, {"durab", 'h', 1}, {"bruiser", 'h', 99}};
#endif
    return true;
}

}  // namespace marcella
