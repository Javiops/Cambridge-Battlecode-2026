#pragma once
// marcella.h - Marcella (draft slot 3, in Ren's place: P_DRAFT_SWAP).
// Hooks: shop_plan (champions.h shop part 2). Her damage work (build, spell use) goes here.

namespace marcella {

CHAMP_HOOK bool is(const std::string& n) { return starts_with(n, "marcella"); }

// t10shop-v1: top-10 Marcella build (45 top-10 games on 1.0.3, 10-22): Treasure first, Jungle-s, 2 Bruiser-h,
// Durab-h, 2 Bruiser-f, then Bruiser-h.
CHAMP_HOOK bool shop_plan(State& s) {
    if (!is(s.name)) return false;
    s.plan = {{"treasure", 'h', 1}, {"jungle", 's', 1}, {"bruiser", 'h', 2}, {"durab", 'h', 1}, {"bruiser", 'f', 2}, {"bruiser", 'h', 99}};
    return true;
}

// mcgo-v1 (thread "Tienda y habilidades", 10-24): near maps, r150-800, our Marcella vs the top-10 Marcella (t10 vs t10):
// same number of fights and the same starts (she strikes first 68% / 58%, at a camp 53% / 52%), but our fights last
// 5.1 rounds against 2.9 and we take more than we deal (0.89 against 1.51). After a spell on a champion the top-10
// Marcella makes 0.33 basic attacks on champions in the next 7 rounds and takes 163 damage; ours makes 1.68 and takes 305.
// Rule: on a near map, with her damage spell on cooldown and a healthy foe (>= P_MCGO_FHP %) within 3 that we do not
// outnumber, hit what is in reach and step home. A foe below that hp is left to the finish / chase rules above.
CHAMP_HOOK bool cast_go(State& s, bc::champion& me, const std::vector<Foe>& foes, int round) {
    if (!is(s.name) || g_tpc_path < 0 || g_tpc_path >= P_MCGO_PATH || round < 100) return false;
    static int last_ready = -100;
    bool cd = false;
    attempt([&] {
        auto abs = me.abilities();
        for (int k = 0; k < 2; ++k)
            if (s.slots[k] == Slot::Targeted) {
                if (abs[k].is_ready()) last_ready = round;
                else cd = true;
            }
        return true;
    });
    if (!cd || round - last_ready > 7) return false;
    vec2 pos = me.position();
    const Foe* nf = nullptr;
    int fc = 0;
    for (auto& f : foes) {
        if (f.d <= 5) ++fc;
        if (!nf || f.d < nf->d) nf = &f;
    }
    if (!nf || nf->d > 3) return false;
    float mh = 1;
    attempt([&] { mh = std::max(1.0f, nf->c.max_health()); return true; });
    if (nf->hp < P_MCGO_FHP / 100.0f * mh) return false;
    int mc = 0;
    for (auto& a : bc::vision::champions(*s.my))
        attempt([&] {
            if (!(a == me) && a.is_alive() && dist(a.position(), pos) <= 4) ++mc;
            return true;
        });
    if (mc > fc) return false;
    static int last_print = -10;
    if (round - last_print > 8) std::printf("[mcgo] r%d d=%d fhp=%d mates=%d foes=%d\n", round, nf->d, static_cast<int>(100 * nf->hp / mh), mc, fc);
    last_print = round;
    g_mode = "mcgo";
    bool hit = fight::hit_now(s, me, foes);
    bool moved = me.can_move() && step_towards(s, me, s.my_spawn, false);
    return hit || moved;
}

}  // namespace marcella
