#pragma once
// Prism's own behaviour (Javier 10-23 20:36: per-champion rules live in <champion>.h; without this champion the generic rule applies).
// v20-draft: none yet, Prism plays the generic rules.
namespace prism {
}
