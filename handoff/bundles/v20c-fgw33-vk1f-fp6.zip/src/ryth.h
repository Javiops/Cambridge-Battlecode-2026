#pragma once
// ryth.h - Ryth (draft slot 4). Hooks: shop_plan (champions.h shop part 2); champ::hp_share has her health share.

namespace ryth {

CHAMP_HOOK bool is(const std::string& n) { return starts_with(n, "ryth"); }

// farplan-v1 (far-maps thread 10-24): on far maps the online far rivals' build (rivals: Jungle-s 2.2, Treasure-s 2.2, Treasure-h 1.5, Durab-h 1.5).
CHAMP_HOOK bool far_plan(State& s) {
    if (!is(s.name) || !(P_FARPLAN & 4)) return false;
    s.plan = {{"jungle", 's', 1}, {"treasure", 's', 1}, {"treasure", 'h', 1}, {"durab", 'h', 1}, {"bruiser", 's', 99}};
    return true;
}

// t10shop-v1: top-10 Ryth build: Treasure first, Jungle-s, Bruiser-h, Durab-h, Bruiser-s, then Bruiser-h.
CHAMP_HOOK bool shop_plan(State& s) {
    if (!is(s.name)) return false;
    s.plan = {{"treasure", 'h', 1}, {"jungle", 's', 1}, {"bruiser", 'h', 1}, {"durab", 'h', 1}, {"bruiser", 's', 1}, {"bruiser", 'h', 99}};
    return true;
}

}  // namespace ryth
