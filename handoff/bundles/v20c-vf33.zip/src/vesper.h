#pragma once
// vesper.h - Vesper (draft slot 2, in Stellar's place: P_DRAFT_SWAP2).
// Today she has no hook of her own: her emblem plan is shop part 1's generic one (champions.h legacy_plan:
// durab-s, jungle-s, bruiser-h, then bruiser-s after P_BRUISER_FILL), no health rule (hp_pick), and she switches
// the team to the caster mode (champ::caster_mode, P_VESP_CASTER). Her damage work (build, spell use) goes here.

namespace vesper {

CHAMP_HOOK bool is(const std::string& n) { return starts_with(n, "vesper"); }

// vcapfar (far-maps thread 10-23): on far maps (spawn path >= P_VCAPFAR_PATH) Vesper takes the captures first
// (vespcap-v2's rule, far only). Far top-10 Vesper earns 741 gold by r500, ours 337 (22 shards vs 10); with the rule
// ours earns 984 on the solo far bench. On top of fgw33: 84 far games +1 (9/8), deaths -0.27, gold@800 +140.
CHAMP_HOOK bool far_captain(int spawn_path) { return P_VCAPFAR && spawn_path >= P_VCAPFAR_PATH; }

}  // namespace vesper
