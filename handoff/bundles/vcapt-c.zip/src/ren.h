#pragma once
// ren.h - Ren (takes Heart of Ruin's slot on far maps, P_FAR_SWAP; Marcella took his old slot).
// No hook of his own: shop part 1 (champions.h legacy_plan) gives him the casters' plan (power-f, durab-h, then
// bruiser-f after P_BRUISER_FILL), champ::hp_share a 0.50 bruiser health share, champ::cap_rank rank 2.

namespace ren {

CHAMP_HOOK bool is(const std::string& n) { return starts_with(n, "ren"); }

// vcapt-v1: on far maps r150-500 the top 10's Vesper takes 1.3 shared captures (165 gold) a game, ours 0.3 (24 gold); her
// solo captures 377 vs 212 gold (34 t10 sides vs 32 v139, goldsrc/vsolo.py). From P_VCAPT_R this tank leaves a reward to a
// Vesper that claims it within 2 tiles or stands next to it.
CHAMP_HOOK bool yields_reward(const State& s, const std::string& ally, int round) {
    return P_VCAPT && is(s.name) && round >= P_VCAPT_R && vesper::is(ally);
}

}  // namespace ren
