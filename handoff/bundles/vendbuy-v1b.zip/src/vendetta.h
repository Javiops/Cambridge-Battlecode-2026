#pragma once
// Vendetta's own behaviour (Javier 10-23 20:36: per-champion rules live in <champion>.h; other champions keep the generic rule).
namespace vendetta {
// vendbuy-v1 (analysis/fights-1023/buy/buy.txt): shards by r400, top-10 Vendetta (117 champion-games, t10 vs t10) vs ours (v139, 78):
// strength 5.7 vs 3.9, health 6.4 vs 7.7 (Treasure-H 2.9 vs 4.6, Durability-H 1.0 vs 1.0, Power-S 1.1 vs 0, Bruiser-S 1.1 vs 0.5);
// by r600 S 10.2 vs 9.2. Online mid r400-800 clashes: our Vendetta 89 dmg per hit vs 193. The top 10 put a Power-S emblem in before the
// health tier. vendbuy-v1b keeps every health step of t10shop-v1 (API 10-24 00:28: farplan-v1's straight copy of the rival build cut
// health and doubled Vendetta deaths) and adds one Power-S emblem before the Bruiser-S fill.
template <class Plan> void shop_plan(Plan& plan) {
    plan = {{"treasure", 'h', 1}, {"jungle", 's', 1}, {"bruiser", 'h', 1}, {"durab", 'h', 1}, {"power", 's', 1}, {"bruiser", 's', 99}};
}
}
