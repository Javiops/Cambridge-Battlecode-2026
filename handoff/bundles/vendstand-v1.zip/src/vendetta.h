#pragma once
// Vendetta's own behaviour (Javier 10-23 20:36: per-champion rules live in <champion>.h; other champions keep the generic rule).
namespace vendetta {
// vendstand-v1: online mid r400-800 clashes, our Vendetta deals 24 dmg per round in reach and hits 27% of them, the top 10's 79 and 41%.
// Local trace (V20, 160 games): in range (1) it attacks 83% of its turns; one tile out with the attack ready it does not attack 39% of
// the time, and 51% of those turns end in the generic "avoid" back-off (nearest foe <= P_AVOID_DIST 2 while the fight is not
// favourable), mostly at 40-100% hp. A melee that backs off at 2 never closes an even fight. With at least stand_hp % hp and not
// outnumbered by 2+ within 4, Vendetta skips the distance trigger (the low-hp avoid below P_GA_AVOID_HP still applies).
constexpr int stand_hp = 55;
}
