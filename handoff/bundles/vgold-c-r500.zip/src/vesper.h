#pragma once
// vesper.h - Vesper (draft slot 2, in Stellar's place: P_DRAFT_SWAP2).
// Today she has no hook of her own: her emblem plan is shop part 1's generic one (champions.h legacy_plan:
// durab-s, jungle-s, bruiser-h, then bruiser-s after P_BRUISER_FILL), no health rule (hp_pick), and she switches
// the team to the caster mode (champ::caster_mode, P_VESP_CASTER). Her damage work (build, spell use) goes here.

namespace vesper {

CHAMP_HOOK bool is(const std::string& n) { return starts_with(n, "vesper"); }

// vgold-v1: the top 10's Vesper is their gold carry. Far maps r150-500 (34 t10-vs-t10 sides vs 32 v139, goldsrc/):
// capture gold 542 vs 237 a game, 113 vs 76 gold a capture, rewards of 160+ gold 0.95 vs 0.19; her team's share 31% vs 18%.
// richcap-v2 cut every champion's gold weight to 0.45 from r150; Vesper keeps P_VGOLD_W until P_VGOLD_R1.
CHAMP_HOOK void gold_weight(const State& s, int round, double& gold_w) {
    if (P_VGOLD && is(s.name) && round < P_VGOLD_R1) gold_w = std::max(gold_w, P_VGOLD_W / 100.0);
}

}  // namespace vesper
