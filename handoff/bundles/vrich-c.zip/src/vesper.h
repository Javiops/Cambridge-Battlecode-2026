#pragma once
// vesper.h - Vesper (draft slot 2, in Stellar's place: P_DRAFT_SWAP2).
// Today she has no hook of her own: her emblem plan is shop part 1's generic one (champions.h legacy_plan:
// durab-s, jungle-s, bruiser-h, then bruiser-s after P_BRUISER_FILL), no health rule (hp_pick), and she switches
// the team to the caster mode (champ::caster_mode, P_VESP_CASTER). Her damage work (build, spell use) goes here.

namespace vesper {

CHAMP_HOOK bool is(const std::string& n) { return starts_with(n, "vesper"); }

// vrich-v1: far maps r150-500 (34 t10-vs-t10 sides vs 32 v139, goldsrc/bigcap.py): rewards of 160+ gold per side,
// top 10 2.76 (their Vesper 0.95: 0.53 alone, 0.42 with allies within 4), ours 1.91 (our Vesper 0.19, 0.03 with allies:
// Ryth, Marcella, Vendetta and Ren take them). From P_VRICH_R an ally leaves a P_VRICH_GOLD+ reward to a Vesper that
// claims it within 2 tiles or stands next to it. vespcap-v2 did this for every reward and lost online.
CHAMP_HOOK bool claims_rich(const std::string& ally, int gold, int round) {
    return P_VRICH && is(ally) && gold >= P_VRICH_GOLD && round >= P_VRICH_R;
}

}  // namespace vesper
