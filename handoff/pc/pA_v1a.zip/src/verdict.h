// verdict.h - decide a fight once, at first contact, and hold the decision (2026-10-16, thread
// "Decidir la pelea antes de empezar"). Included by main.cpp after fight.h.
//
// Why (63 online v52 games, 1,843 of our fight episodes, first contact = first round an enemy champion is
// within 6): our own hp at first contact does not predict a lost fight (AUC 0.51) but the power ratio of the
// two groups does (health x damage of us + allies within 6 against the enemies in view). Below 0.8 we lose
// 40% and win 4%; we stay in 85% of those fights; the few times we left at once we lost 24%; our rivals leave
// at once 42% of the time and lose 19%. Above 4 we win only 24% where the top two win 41%.
//
//   P_PV        0 off (v52 unchanged); 1 = leave verdict only; 2 = leave and fight verdicts
//   P_PV_LEAVE  ratio x100 below which the first-contact verdict is "leave" (held until contact ends)
//   P_PV_FIGHT  ratio x100 at or above which the verdict is "fight": v52's "unfavourable" back-offs stop
//   P_PV_R      first contact = nearest enemy champion within this many tiles
//   P_PV_GAP    rounds without an enemy within 8 that end the engagement
//   P_PV_ER     enemies within this many tiles enter the ratio (8 = all in view)
//   P_PV_KEEPCAP 1: a leave verdict waits while capturing, unless a foe is within 3
// Hysteresis: "leave" flips to "fight" only if the ratio climbs to P_PV_FIGHT x 1.5 (allies arrived);
// "fight" flips to "leave" if it drops under P_PV_LEAVE x 0.75 (enemies arrived). The hp cuts of step 2
// (P_FLEE_PCT, P_UNI_FLEE) and P_LOWHP still apply.


namespace pv {

// Each champion runs its own program, so these globals are per champion.
inline int g_verdict = 0;    // 0 none (v52 rules), 1 fight, 2 leave
inline int g_last = -100;    // last round with an enemy champion within 8
inline bool g_judged = false;

// Health x damage of me + allies within 6 (alive, not recalling) over the enemies in view within 8.
inline double power_ratio(State& s, bc::champion& me, const std::vector<Foe>& foes) {
    vec2 pos = me.position();
    double oh = me.health(), od = fight::unit_dps(me), th = 0, td = 0;
    attempt([&] {
        for (auto& a : bc::vision::champions(*s.my)) {
            try {
                if (a == me || !a.is_alive() || a.is_recalling()) continue;
                if (dist(a.position(), pos) > 6) continue;
                oh += a.health();
                od += fight::unit_dps(a);
            } catch (...) {
            }
        }
        return true;
    });
    for (auto& f : foes)
        if (f.d <= P_PV_ER && !s.en_spawn.is_set(f.p)) {
            th += f.hp;
            td += fight::unit_dps(f.c);
        }
    if (th <= 0) return 99.0;
    return (oh * od) / (th * td);
}

// Called once per turn at the start of step 3. Returns the verdict held for this engagement.
inline int verdict(State& s, bc::champion& me, const std::vector<Foe>& foes, int round, bool on_spawn) {
    int nearest = 99;
    for (auto& f : foes)
        if (!s.en_spawn.is_set(f.p)) nearest = std::min(nearest, f.d);
    if (nearest > 8) {
        if (round - g_last > P_PV_GAP) { g_verdict = 0; g_judged = false; }
        return g_verdict;
    }
    if (round - g_last > P_PV_GAP) { g_verdict = 0; g_judged = false; }
    g_last = round;
    if (on_spawn) return g_verdict;
    if (!g_judged) {
        if (nearest > P_PV_R) return 0;
        g_judged = true;
        double r = power_ratio(s, me, foes) * 100.0;
        g_verdict = r < P_PV_LEAVE ? 2 : false;
        return g_verdict;
    }
    if (g_verdict) {
        double r = power_ratio(s, me, foes) * 100.0;
        if (g_verdict == 2 && r >= P_PV_FIGHT * 1.5) g_verdict = P_PV >= 2 ? 1 : 0;
        else if (g_verdict == 1 && r < P_PV_LEAVE * 0.75) g_verdict = 2;
    }
    return g_verdict;
}

}  // namespace pv
