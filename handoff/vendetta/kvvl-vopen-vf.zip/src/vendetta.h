#pragma once
// vendetta.h - Vendetta (draft slot 5, in Varg's place: P_DRAFT_SWAP3). Hooks: shop_plan (champions.h shop part 2).
// fight.h's enemy model also knows her dash (legacy name list "vend", replaced by the engine query, P_KINDFIX).

namespace vendetta {

CHAMP_HOOK bool is(const std::string& n) { return starts_with(n, "vendetta"); }

// t10shop-v1: top-10 Vendetta build: Treasure first, Jungle-s, Bruiser-h, Durab-h, then Bruiser-s.
CHAMP_HOOK bool shop_plan(State& s) {
    if (!is(s.name)) return false;
    s.plan = {{"treasure", 'h', 1}, {"jungle", 's', 1}, {"bruiser", 'h', 1}, {"durab", 'h', 1}, {"bruiser", 's', 99}};
    return true;
}

// lshop-v1 weights (Power folded into Bruiser of the same stat): late fill mix from P_LSHOP_R. Vendetta: t10 Bruiser s 1840 / h 1144 + Power-s 514, ours all Bruiser-s.
CHAMP_HOOK bool late_mix(const State& s, std::vector<LateFill>& o) {
    if (!is(s.name)) return false;
    o = {{"bruiser", 'h', 1.15f}, {"bruiser", 's', 2.35f}};
    return true;
}

// vopen-v1 (pelea-v1, 10-24): online near maps, the top 10's Vendetta hits her first camp at r6 and has 534 monster
// damage at r20; ours r24 and 160 (no item is bought before r40 by anyone; same damage per hit, farmexec.py). Our
// choice prices value/rounds, so the big groups 15-17 tiles out beat the small ones next to spawn. Until P_VOP_UNTIL on
// near maps, gem groups farther than P_VOP_D tiles of walking are priced down: score x (P_VOP_D / travel)^P_VOP_EXP.
// Vendetta only: the other champions keep their opening (opening-near-v1 on all heavies cost r300 gold locally).
CHAMP_HOOK double open_k(const State& s, int round, int gems, double travel) {
    if (!P_VOP || round > P_VOP_UNTIL || travel <= P_VOP_D || !is(s.name)) return 1.0;
    const int sp = pf_spawn_path();
    if (sp < 0 || sp >= P_VOP_MAX) return 1.0;
    return std::pow(P_VOP_D / travel, P_VOP_EXP);
}

}  // namespace vendetta
