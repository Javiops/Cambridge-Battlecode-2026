// v9.h - t10plan-v9 "escuadras": one team policy per round from r30 (P_V9_FROM). The five champions split into two
// squads led by Vesper and Marcella (fallback: the highest-hp alive member); the other three join the nearest leader
// (2+3, or 2+2+1 on maps with P_V9_MANY+ groups: the champion farthest from both leaders farms free as in v4o2).
// Every champion computes the plan from the same inputs (own roster, visible positions, claims), no randomness.
// Included by main.cpp after the claim helpers and my_dps, before choose_target_impl.
namespace v9 {

struct Ally {
    bool alive = false, seen = false, recalling = false, home = false;
    vec2 p{0, 0};      // seen: its tile; unseen: its claimed group's centre, else our spawn centre
    double hpr = 1.0;  // health fraction (unseen: 1)
    double hp = 0;     // absolute health (seen)
    int claim = -1;    // claimed group (-1 none)
    double dps = 60;
    int gems = 0;      // v11: carried gems (carrier choice)
};

inline int g_role = 0;          // 0 off / free, 1 leader, 2 follower
inline int g_leader = -1;       // roster index of my squad's leader (me when leader)
inline int g_other_leader = -1; // the other squad's leader
inline int g_squad[8];          // roster indices of my squad (alive members, me included)
inline int g_nsq = 0;
inline int g_round = -1;
inline Ally g_al[8];
inline int g_nal = 0;
inline int g_mem_of[8];         // per roster index: leader it follows (hysteresis), -1 unknown
inline bool g_mem_init = false;
// counters / episode state
inline int g_plans = 0, g_waits = 0, g_wakes = 0, g_fights = 0, g_retreats = 0, g_picks = 0, g_rot = 0;
inline int g_wait_t = -1, g_wait_n = 0, g_wait_lead = -1;   // leader waits per target
inline int g_wake_t = -1, g_wake_n = 0, g_wake_done = -1;   // camp wake waits per target
inline int g_fstate = 0;                                    // 0 none, 1 fighting, 2 retreating (episode lines)
inline int g_last_cap = -1;                                 // group captured last (rotation bonus)
inline int g_ahead_t = -1, g_ahead_n = 0;
inline int g_big = -1;          // groups of value >= 40 (gems + gold/5.4) on the map (-1 unknown)
inline int g_slack = 0, g_pickdump = 0;
// t10plan-v11 "bloque": one block of all alive members (the carrier walks home alone and rejoins); the leader targets the
// live group nearest the block centroid; mandatory rally before the first hit; retreat towards the block, never alone.
inline vec2 g_cent = vec2(0, 0);       // centroid of the block (alive, not recalling, off the spawn)
inline int g_nblock = 0;        // members in the block
inline bool g_top_gems = true;  // I carry at least as many gems as every other alive member (the carrier)
inline int g_go_t = -1;  // v11f: target whose rally condition was met once
inline int g_rally_t = -1, g_rally_r0 = -1, g_rallies = 0, g_hits = 0, g_rejoins = 0, g_vretreats = 0;
inline int g_nopre = 0, g_nopre_r = -1;  // v11g: no-preempt episodes / last round it held
inline bool g_hit_logged = false, g_was_home = false, g_lead_changed = false;
inline int g_lead_prev = -1, g_prev_claim = -1;
inline int g_pick_r = -1, g_solo_r0 = -1, g_solos = 0;  // v11c: pick round of the rally target; first round hitting alone
inline bool v11_on(int round) { return P_V9 && P_V11 && round >= P_V9_FROM; }

inline bool on(int round) { return P_V9 && round >= P_V9_FROM; }
inline bool is_lead_name(const std::string& n) { return starts_with(n, "vesper") || starts_with(n, "marcella"); }

// The plan of this round. Cheap: one pass over the roster (position / health of visible allies) and the claims.
inline void plan(State& s, bc::champion& me, int round) {
    if (g_round == round) return;
    g_round = round;
    g_role = 0; g_leader = -1; g_other_leader = -1; g_nsq = 0;
    if (!on(round) || s.ally_idx < 0 || s.roster < 3) return;
    auto sm = read_sm();
    const auto& allies = my_roster(s);
    g_nal = std::min<int>(8, static_cast<int>(allies.size()));
    if (!g_mem_init) { for (int k = 0; k < 8; ++k) g_mem_of[k] = -1; g_mem_init = true; }
    static int lead_name[8] = {-2, -2, -2, -2, -2, -2, -2, -2};  // -2 unknown, 1 Vesper/Marcella, 0 other
    for (int k = 0; k < g_nal; ++k) {
        Ally& a = g_al[k];
        a = Ally();
        const int claim = k < claim_slots(s) ? claim_value(s, sm, k) : 0;
        a.claim = (claim > 0 && claim - 1 < static_cast<int>(s.groups.size())) ? claim - 1 : -1;
        a.p = a.claim >= 0 ? s.groups[a.claim].center : s.spawn_center;
        if (lead_name[k] == -2) {
            lead_name[k] = 0;
            try { lead_name[k] = is_lead_name(norm(bc::to_string(allies[k].champion_name()))) ? 1 : 0; } catch (...) { lead_name[k] = -2; }
        }
        if (k == s.ally_idx) {
            a.alive = true; a.seen = true; a.p = me.position();
            a.hpr = me.health() / std::max(1.0, static_cast<double>(me.max_health()));
            a.hp = me.health();
            a.home = s.my_spawn.is_set(a.p);
            a.dps = my_dps(s, me);
            try { a.gems = static_cast<int>(me.gem_count()); } catch (...) {}
            continue;
        }
        try {
            a.alive = allies[k].is_alive();
            if (!a.alive) continue;
            a.recalling = allies[k].is_recalling();
            const vec2 ap = allies[k].position();
            a.seen = true; a.p = ap;
            a.home = s.my_spawn.is_set(ap);
            a.hpr = allies[k].health() / std::max(1.0, static_cast<double>(allies[k].max_health()));
            a.hp = allies[k].health();
            double str = 60, foc = 0;
            try { str = allies[k].strength(); foc = allies[k].focus(); } catch (...) {}
            try { a.gems = static_cast<int>(allies[k].gem_count()); } catch (...) {}
            a.dps = std::max(10.0, str + foc * 1.5 / 8.0);
        } catch (...) {
        }
    }
    if (g_big < 0) { g_big = 0; for (auto& g : s.groups) if (g.gems + g.gold / 5.4 >= 40) ++g_big; }
    if (P_V11) {  // v11: one block. Leader = Vesper, else Marcella, else the highest-hp member, among those in the field.
        const int me_k = s.ally_idx;
        int L = -1; double bh = -1; int nb = 0; double cx = 0, cy = 0; int topg = 0;
        for (int pass = 0; pass < 2 && L < 0; ++pass)
            for (int k = 0; k < g_nal; ++k) {
                const Ally& a = g_al[k];
                if (!a.alive) continue;
                if (pass == 0 && (a.recalling || a.home || a.claim < 0)) continue;  // v11c: a leader on a tribute trip (no claim) hands over
                int pri = 0;
                if (lead_name[k] == 1) { std::string nm; try { nm = norm(bc::to_string(allies[k].champion_name())); } catch (...) {} pri = starts_with(nm, "vesper") ? 3 : 2; }
                const double sc = pri * 10 + a.hpr;
                if (sc > bh) { bh = sc; L = k; }
            }
        if (L < 0) return;
        for (int k = 0; k < g_nal; ++k) {
            const Ally& a = g_al[k];
            if (!a.alive) continue;
            g_squad[g_nsq++] = k;
            if (k != me_k && a.gems > topg) topg = a.gems;
            if (a.recalling || a.home) continue;
            ++nb; cx += X(a.p); cy += Y(a.p);
        }
        g_nblock = nb;
        g_cent = nb > 0 ? vec2(static_cast<float>(std::lround(cx / nb)), static_cast<float>(std::lround(cy / nb))) : me.position();
        g_top_gems = g_al[me_k].gems >= topg;
        g_role = me_k == L ? 1 : 2; g_leader = L; g_other_leader = -1;
        g_lead_changed = false;
        if (L != g_lead_prev) { if (g_lead_prev >= 0 && me_k == L) { g_lead_changed = true; g_prev_claim = g_al[g_lead_prev].claim; } g_lead_prev = L; }
        ++g_plans;
        if (g_plans == 1 || round % 100 == 0) std::printf("[v9-plan] r=%d who=%s v11 lead=%d nblock=%d nsq=%d cent=%d,%d role=%d\n", round, s.name.c_str(), L, nb, g_nsq, X(g_cent), Y(g_cent), g_role);
        return;
    }
    // v9c: on maps with fewer than P_V9_BIGMAPS groups of value 40+, only the Vesper pair (2+1+1+1); the rest farm solo as v4o2
    if (g_big < P_V9_BIGMAPS) {
        int Lv = -1;
        for (int k = 0; k < g_nal; ++k) if (lead_name[k] == 1 && g_al[k].alive && starts_with(norm(bc::to_string(allies[k].champion_name())), "vesper")) Lv = k;
        if (Lv < 0) { double bh = -1; for (int k = 0; k < g_nal; ++k) if (g_al[k].alive && g_al[k].hpr > bh) { bh = g_al[k].hpr; Lv = k; } }
        if (Lv < 0) return;
        int mk = -1, md = 1 << 30;
        if (g_mem_init && g_mem_of[Lv] >= 0 && g_al[g_mem_of[Lv]].alive && g_mem_of[Lv] != Lv) mk = g_mem_of[Lv];  // hysteresis: keep the partner while alive
        else for (int k = 0; k < g_nal; ++k) { if (!g_al[k].alive || k == Lv) continue; const int d = dist(g_al[k].p, g_al[Lv].p); if (d < md) { md = d; mk = k; } }
        for (int k = 0; k < 8; ++k) g_mem_of[k] = -1;
        if (mk < 0) return;
        g_mem_of[Lv] = mk;  // partner stored on the leader's slot (hysteresis)
        const int me_k = s.ally_idx;
        if (me_k == Lv) { g_role = 1; g_leader = Lv; }
        else if (me_k == mk) { g_role = 2; g_leader = Lv; }
        else return;
        g_squad[g_nsq++] = Lv; g_squad[g_nsq++] = mk;
        ++g_plans;
        if (g_plans == 1 || round % 100 == 0) std::printf("[v9-plan] r=%d who=%s pair=%d:%d big=%d role=%d\n", round, s.name.c_str(), Lv, mk, g_big, g_role);
        return;
    }
    // leaders: Vesper and Marcella when alive; a missing one is replaced by the highest-hp alive non-leader
    int L[2] = {-1, -1};
    int nl = 0;
    for (int k = 0; k < g_nal && nl < 2; ++k)
        if (lead_name[k] == 1 && g_al[k].alive) L[nl++] = k;
    while (nl < 2) {
        int best = -1; double bh = -1;
        for (int k = 0; k < g_nal; ++k) {
            if (!g_al[k].alive || k == L[0] || k == L[1]) continue;
            if (g_al[k].hpr > bh) { bh = g_al[k].hpr; best = k; }
        }
        if (best < 0) break;
        L[nl++] = best;
    }
    if (nl < 2) return;  // fewer than two alive: v4o2 play
    // members: nearest leader, with hysteresis (switch only when the other leader is 4+ tiles nearer)
    int cnt[2] = {1, 1};
    int who[2] = {-1, -1};
    int far_k = -1, far_d = -1;  // the member farthest from both leaders (2+2+1 maps)
    for (int k = 0; k < g_nal; ++k) {
        if (!g_al[k].alive || k == L[0] || k == L[1]) { if (k != L[0] && k != L[1]) g_mem_of[k] = -1; continue; }
        const int d0 = dist(g_al[k].p, g_al[L[0]].p), d1 = dist(g_al[k].p, g_al[L[1]].p);
        int w = d0 <= d1 ? 0 : 1;
        if (g_mem_of[k] == L[1 - w] && std::abs(d0 - d1) < 4) w = 1 - w;
        g_mem_of[k] = L[w];
        ++cnt[w];
        who[w] = k;
        const int dm = std::min(d0, d1);
        if (dm > far_d) { far_d = dm; far_k = k; }
    }
    const bool many = static_cast<int>(s.groups.size()) >= P_V9_MANY;
    int freek = -1;
    if (many && cnt[0] + cnt[1] >= 5) freek = far_k;  // 2+2+1: one free farmer
    // one leader with everybody: the farthest member goes to the other leader
    for (int w = 0; w < 2; ++w)
        if (cnt[w] >= 4 && cnt[1 - w] == 1) {
            int mk = -1, md = -1;
            for (int k = 0; k < g_nal; ++k)
                if (g_mem_of[k] == L[w] && k != freek) { const int d = dist(g_al[k].p, g_al[L[w]].p); if (d > md) { md = d; mk = k; } }
            if (mk >= 0) { g_mem_of[mk] = L[1 - w]; --cnt[w]; ++cnt[1 - w]; }
        }
    (void)who;
    if (freek >= 0) { if (freek == s.ally_idx) { ++g_plans; return; } g_mem_of[freek] = -1; }
    const int me_k = s.ally_idx;
    if (me_k == L[0] || me_k == L[1]) { g_role = 1; g_leader = me_k; g_other_leader = me_k == L[0] ? L[1] : L[0]; }
    else if (g_mem_of[me_k] >= 0) { g_role = 2; g_leader = g_mem_of[me_k]; g_other_leader = g_leader == L[0] ? L[1] : L[0]; }
    else return;
    for (int k = 0; k < g_nal; ++k)
        if (g_al[k].alive && (k == g_leader || g_mem_of[k] == g_leader) && k != freek) g_squad[g_nsq++] = k;
    ++g_plans;
    if (g_plans == 1 || round % 100 == 0) {  // one line per champion at the first plan and every 100 rounds
        char a[32], b[32]; int na = 0, nb = 0;
        for (int k = 0; k < g_nal; ++k) { if (g_mem_of[k] == L[0]) na += std::snprintf(a + na, sizeof a - na, "%d,", k); if (g_mem_of[k] == L[1]) nb += std::snprintf(b + nb, sizeof b - nb, "%d,", k); }
        a[na] = 0; b[nb] = 0;
        std::printf("[v9-plan] r=%d who=%s squads=%d:%s %d:%s free=%d role=%d\n", round, s.name.c_str(), L[0], a, L[1], b, freek, g_role);
    }
}

inline bool active() { return P_V9 && g_role > 0; }
inline bool leader() { return P_V9 && g_role == 1; }
inline bool follower() { return P_V9 && g_role == 2; }
inline const Ally& lead_ally() { return g_al[g_leader]; }
inline int squad_dps_sum() {
    double d = 0;
    for (int i = 0; i < g_nsq; ++i) d += g_al[g_squad[i]].dps;
    return static_cast<int>(d);
}
// v9c: combined dps of the alive squad members (not recalling, off the spawn) within r of a tile (me always counted)
inline int squad_dps_near(vec2 at, int r, int me_k) {
    double d = 0;
    for (int i = 0; i < g_nsq; ++i) {
        const int k = g_squad[i];
        const Ally& a = g_al[k];
        if (k == me_k) { d += a.dps; continue; }
        if (!a.alive || a.recalling || a.home || !a.seen) continue;
        if (dist(a.p, at) <= r) d += a.dps;
    }
    return static_cast<int>(d);
}
// v11d: combined health of the alive squad members (not recalling, off the spawn) within r of a tile, me counted as my_hp
inline double squad_hp_near(vec2 at, int r, int me_k, double my_hp) {
    double h = 0;
    for (int i = 0; i < g_nsq; ++i) {
        const int k = g_squad[i];
        const Ally& a = g_al[k];
        if (k == me_k) { h += my_hp; continue; }
        if (!a.alive || a.recalling || a.home || !a.seen) continue;
        if (dist(a.p, at) <= r) h += a.hp;
    }
    return h;
}
// v11e: dps / health of ALL alive block members by roster (not vision), not recalling, minus the carrier (most gems, not me)
inline int carrier_k(int me_k) {
    int c = -1, tg = 0;
    for (int i = 0; i < g_nsq; ++i) { const int k = g_squad[i]; if (k != me_k && g_al[k].alive && g_al[k].gems > tg) { tg = g_al[k].gems; c = k; } }
    return c;
}
inline double block_dps_all(int me_k) {
    double d = 0; const int c = carrier_k(me_k);
    for (int i = 0; i < g_nsq; ++i) { const int k = g_squad[i]; const Ally& a = g_al[k]; if (k == me_k) { d += a.dps; continue; } if (!a.alive || a.recalling || k == c) continue; d += a.dps; }
    return d;
}
inline double block_hp_all(int me_k, double my_hp) {
    double h = 0; const int c = carrier_k(me_k);
    for (int i = 0; i < g_nsq; ++i) { const int k = g_squad[i]; const Ally& a = g_al[k]; if (k == me_k) { h += my_hp; continue; } if (!a.alive || a.recalling || k == c) continue; h += a.hp; }
    return h;
}
inline int g_idle = 0, g_gated = 0, g_gfall = 0;   // v11d counters (v11e: gate fallbacks)
inline unsigned long long g_gate_logged = 0;
// squad members (alive, not recalling, off the spawn) within r of a tile, me included when I am
inline int near(vec2 at, int r, int me_k, bool count_me) {
    int n = 0;
    for (int i = 0; i < g_nsq; ++i) {
        const int k = g_squad[i];
        if (k == me_k && !count_me) continue;
        const Ally& a = g_al[k];
        if (!a.alive || a.recalling || (a.home && k != me_k)) continue;
        if (k != me_k && !a.seen) continue;
        if (dist(a.p, at) <= r) ++n;
    }
    return n;
}
// alive squad members that count for the camp wake (not recalling, not on the spawn, hp >= 40%)
inline int expected(int me_k) {
    int n = 0;
    for (int i = 0; i < g_nsq; ++i) {
        const int k = g_squad[i];
        const Ally& a = g_al[k];
        if (!a.alive || a.recalling || (a.home && k != me_k) || a.hpr < 0.4) continue;
        ++n;
    }
    return n;
}

}  // namespace v9
