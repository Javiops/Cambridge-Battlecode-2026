#!/usr/bin/env python3
"""Read-only unique-input audit; optionally export compact experiment evidence.

Default: print an audit snapshot, without changing experiment files. --export
DIR writes only new deliverables in a task-local directory. It never starts a
CLI/game/build, creates maps, edits source, or contacts a remote service.
Large pretty-printed result stages are decoded one row at a time using stdlib.
"""
from __future__ import annotations
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
import codecs
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import re
import stat
import sys
import zipfile

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
ARENA=ROOT/'arena'
LIMIT=25_000_000
SCRIPT_SHA256=None

def require(ok,message):
    if not ok:raise RuntimeError(message)
def now():return datetime.now(timezone.utc).isoformat()
def digest(data):return hashlib.sha256(data).hexdigest()
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def canonical(value):return json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
def timestamp(value):return datetime.fromisoformat(value.replace('Z','+00:00'))
def relative(path):return Path(path).relative_to(ROOT).as_posix()
def sanitize(value):
    if isinstance(value,dict):return {k:sanitize(v) for k,v in value.items()}
    if isinstance(value,list):return [sanitize(v) for v in value]
    if isinstance(value,str):
        for prefix,label in ((str(ROOT),'TASK'),(str(ROOT.parent),'WORK'),(str(Path.home()),'USER')):
            value=value.replace(prefix,label).replace(prefix.replace('\\','/'),label)
    return value
def output_guard(path):
    path=Path(path).absolute();require(path.is_relative_to(ROOT),'Export must stay in this task root')
    cursor=path
    while True:
        try:info=cursor.lstat()
        except FileNotFoundError:info=None
        if info is not None:
            require(not stat.S_ISLNK(info.st_mode) and not(getattr(info,'st_file_attributes',0)&0x400),'Refusing output redirect '+str(cursor))
        if cursor==ROOT:break
        cursor=cursor.parent
    require(path.resolve()==path,'Export path redirects');return path

class JSONStream:
    """Incremental root-object reader; keeps only one game object in memory."""
    def __init__(self,path):
        self.stream=Path(path).open('rb');self.buffer='';self.pos=0;self.eof=False
        self.decoder=json.JSONDecoder();self.utf8=codecs.getincrementaldecoder('utf8')();self.hash=hashlib.sha256()
    def close(self):self.stream.close()
    def more(self):
        if self.eof:return False
        if self.pos:self.buffer=self.buffer[self.pos:];self.pos=0
        block=self.stream.read(1024*1024)
        self.hash.update(block)
        if not block:self.eof=True
        self.buffer+=self.utf8.decode(block,final=self.eof)
        return bool(block)
    def peek(self):
        while True:
            while self.pos<len(self.buffer) and self.buffer[self.pos].isspace():self.pos+=1
            if self.pos<len(self.buffer):return self.buffer[self.pos]
            if not self.more():return ''
    def token(self,wanted):
        require(self.peek()==wanted,'Malformed JSON token, expected '+wanted);self.pos+=1
    def value(self):
        self.peek()
        while True:
            try:value,end=self.decoder.raw_decode(self.buffer,self.pos)
            except json.JSONDecodeError:
                require(self.more(),'Malformed/incomplete JSON value');continue
            # A scalar may end at a chunk boundary midway through its token.
            if end==len(self.buffer) and not self.eof:
                self.more();continue
            if end<len(self.buffer) and not (self.buffer[end].isspace() or self.buffer[end] in ',:]}'):
                require(self.more(),'Malformed JSON token continuation');continue
            self.pos=end;return value

def stage_rows(path,metadata):
    stream=JSONStream(path);seen=False
    try:
        stream.token('{')
        while stream.peek()!='}':
            key=stream.value();require(isinstance(key,str),'Invalid root key');stream.token(':')
            if key=='games':
                require(not seen,'Duplicate root games key');seen=True;stream.token('[')
                while stream.peek()!=']':
                    row=stream.value();require(isinstance(row,dict),'Invalid game row');yield row
                    if stream.peek()!=']':
                        stream.token(',');require(stream.peek()!=']','Trailing comma in games array')
                stream.token(']')
            else:
                require(key not in metadata,'Duplicate result metadata key');metadata[key]=stream.value()
            if stream.peek()!='}':
                stream.token(',');require(stream.peek()!='}','Trailing comma in root object')
        stream.token('}');require(stream.peek()=='','Trailing result data');require(seen,'Missing games array')
        metadata['_file_sha256']=stream.hash.hexdigest()
    finally:stream.close()

def physical_key(identity):
    # Must match test_matches.py: default ensure_ascii=True in the identity hash.
    return digest(json.dumps(identity,sort_keys=True,separators=(',',':')).encode())
def compact(row):
    fields=('key','created_utc','outcome','rounds','gems','deaths','kills','faults','engine_version','statistics_schema',
            'statistics_sha256','statistics_content_sha256','replay_sha256','stdout',
            'collectedGems','championDamageDone','championDamageTaken','monsterDamageDone','monsterDamageTaken')
    result={k:row[k] for k in fields if k in row}
    result['identity']=row['identity']
    result['execution_attempts']=len(row.get('execution_attempts',[]))
    result['pre_game_access_denied_retries']=sum(a.get('pre_game_access_denied_retry',False) for a in row.get('execution_attempts',[]))
    return result
def verify_row(row):
    require(row.get('valid') and row.get('schema_version')==2,'Unexpected cache schema')
    require(physical_key(row['identity'])==row['key'],'Physical key mismatch')
    require(row['engine_version']=='0.0.1' and row['statistics_schema']==2,'Unexpected engine/stats version')
    data=row['statistics'];require(digest(canonical(data))==row['statistics_content_sha256'],'Canonical statistics hash mismatch')
    for field,source in (('outcome','outcome'),('rounds','round'),('faults','botFaults'),('engine_version','engineVersion'),('statistics_schema','schemaVersion')):
        require(row[field]==data[source],'Derived field mismatch: '+field)
    require(row['gems']==[t['submittedGems'] for t in data['teams']],'Gem totals mismatch')
    require(isinstance(row['faults'],list) and len(row['faults'])==2 and all(type(n)is int and n>=0 for n in row['faults']),'Invalid faults')
    require(row['outcome'] in ('teamA','teamB','draw') and 1<=row['rounds']<=2000,'Invalid outcome/round')

def audit(allow_incomplete=False,verify_cache=True):
    started=now();paths=sorted((ROOT/'results').glob('*.json'));cache_inventory={p.stem for p in (ROOT/'game-cache').glob('*.json')}
    physical={};views={};stages={};plans={};sources={};map_paths={};runtime={};fresh_claims={};candidate_stages={}
    for path in paths:
        stage=path.stem;plan_path=ROOT/'stages'/f'{stage}-plan.json'
        require(plan_path.is_file(),'Missing plan for '+stage)
        envelope=read(plan_path);plan=envelope['plan'];require(plan['stage']==stage,'Stage plan name mismatch')
        plans[stage]={'created_utc':envelope['created_utc'],'sha256':sha(plan_path),'plan':plan}
        require(timestamp(envelope['created_utc'])<=timestamp(now()),'Future stage plan timestamp')
        expected=Counter((s['candidate'],s['opponent'],s['map_sha256'],s['side'],s['key']) for s in plan['slots'])
        require(all(n==1 for n in expected.values()),'Duplicate semantic slot in plan '+stage)
        for name,record in plan['sources'].items():
            if name in sources:require(sources[name]==record,'Candidate provenance changed between stages: '+name)
            sources[name]=record;candidate_stages.setdefault(name,set()).add(stage)
            require(timestamp(record['created_utc'])<=timestamp(envelope['created_utc']),'Candidate registered after its stage plan')
        for name,h in plan['maps'].items():
            p=ARENA/Path(name);require(p.is_file() and sha(p)==h,'Map changed: '+name)
            map_paths.setdefault(h,set()).add(p)
        rt=plan['runtime'];runtime.setdefault(digest(canonical(rt)),rt)
        metadata={};count=0;stage_keys=set();new_keys=set();cache_keys=set()
        for row in stage_rows(path,metadata):
            key=row['key'];slot=(row['candidate'],row['opponent'],row['map_sha256'],row['side'],key)
            require(expected[slot]>0,'Unplanned/duplicate game slot in '+stage);expected[slot]-=1;count+=1
            side=row['side'];a,b=(row['candidate'],row['opponent']) if side==0 else (row['opponent'],row['candidate'])
            require(row['identity']['runtime']==rt,'Game runtime differs from plan')
            require(row['identity']['map_sha256']==row['map_sha256'],'Map identity differs')
            require(row['identity']['wasm_a_sha256']==plan['sources'][a]['wasm_sha256'] and row['identity']['wasm_b_sha256']==plan['sources'][b]['wasm_sha256'],'Ordered source-pair differs from plan')
            if key not in physical:
                verify_row(row);value=compact(row)
                value['stages']=[];physical[key]=value
            else:
                old=physical[key];require(all(old[k]==v for k,v in compact(row).items()),'Physical input produced conflicting recorded outcome')
            if stage not in physical[key]['stages']:physical[key]['stages'].append(stage)
            stage_keys.add(key)
            if row['cached']:cache_keys.add(key)
            else:new_keys.add(key)
            view=slot[:4]
            if view in views:require(views[view]['key']==key,'Semantic slot changed physical identity across stages')
            val=views.setdefault(view,{'candidate':row['candidate'],'opponent':row['opponent'],'map_sha256':row['map_sha256'],'side':side,'key':key,'stages':[]})
            val['stages'].append(stage)
        require(all(n==0 for n in expected.values()),'Incomplete stage coverage: '+stage)
        require(metadata['stage']==stage and metadata['plan_sha256']==plans[stage]['sha256'],'Result plan pin changed')
        require(count==metadata['semantic_games']==plan['semantic_games'],'Wrong semantic game count')
        require(len(stage_keys)==metadata['unique_physical_games']==plan['unique_physical_games'],'Wrong physical game count')
        require(len(new_keys)==metadata['new_unique_games'] and len(cache_keys)==metadata['cached_unique_games'],'Wrong cache/new annotation counts')
        require(not new_keys.intersection(cache_keys),'Same stage classified one physical game both new and cached')
        for key in new_keys:fresh_claims.setdefault(key,[]).append(stage)
        completed=timestamp(metadata['completed_utc']);require(timestamp(envelope['created_utc'])<=completed,'Stage completed before plan')
        require(all(timestamp(physical[k]['created_utc'])<=completed for k in stage_keys),'Stage references a later physical game')
        stages[stage]={'plan_created_utc':envelope['created_utc'],'completed_utc':metadata['completed_utc'],
            'result_sha256':metadata['_file_sha256'],'plan_sha256':plans[stage]['sha256'],
            'semantic_games':count,'unique_physical_games':len(stage_keys),'new_unique_games':len(new_keys),'cached_unique_games':len(cache_keys),
            'maps':len(plan['maps']),'names':plan['names'],'opponents':plan['opponents'],'sets':plan['sets'],
            'summary':metadata.get('summary',{})}
        print(f'Audited {stage}: {count} slots, {len(stage_keys)} physical inputs ({len(new_keys)} new / {len(cache_keys)} reused)',file=sys.stderr,flush=True)
    if verify_cache:
        def check_cache(key):
            cp=ROOT/'game-cache'/(key+'.json');require(cp.is_file(),'Completed stage missing cache entry')
            content=cp.read_bytes();row=json.loads(content);verify_row(row)
            require(all(physical[key][k]==v for k,v in compact(row).items()),'Stage row differs from physical cache entry')
            return key,digest(content)
        with ThreadPoolExecutor(max_workers=8) as pool:
            futures=[pool.submit(check_cache,key) for key in physical]
            for index,future in enumerate(as_completed(futures),1):
                key,file_sha=future.result();physical[key]['cache_file_sha256']=file_sha
                if index%5000==0 or index==len(futures):print(f'Independently verified {index}/{len(futures)} cache files',file=sys.stderr,flush=True)
    pending=sorted(p.name.removesuffix('-plan.json') for p in (ROOT/'stages').glob('*-plan.json') if p.name.removesuffix('-plan.json') not in stages)
    if not allow_incomplete:require(not pending,'Planned stages still incomplete: '+', '.join(pending))
    for name,record in sources.items():
        src=ARENA/'bots'/name/'src'
        observed={p.name:sha(p) for p in src.iterdir() if p.is_file()};require(observed==record['source_sha256'],'Current candidate source differs: '+name)
        require(sha(ARENA/'bots'/name/'.cambc/build/bot-injected.wasm')==record['wasm_sha256'],'Current candidate WASM differs: '+name)
        for module,h in record.get('patch_modules_sha256',{}).items():require(sha(ROOT/module)==h,'Frozen patch module changed: '+module)
    # Registration without any result-stage participation is not played evidence.
    registered={p.stem:read(p) for p in (ROOT/'candidates').glob('*.json')}
    played={name for val in views.values() for name in (val['candidate'],val['opponent'])}
    registered_unplayed=sorted(set(registered)-played)
    faults={key:r['faults'] for key,r in physical.items() if any(r['faults'])}
    reinit={key:{t:s['reinitializations_observed'] for t,s in r['stdout'].items()} for key,r in physical.items() if any(s['reinitializations_observed'] for s in r['stdout'].values())}
    runtime_pins=[sanitize(r) for r in runtime.values()]
    summary={'audit_started_utc':started,'audit_completed_utc':now(),'snapshot_is_final':not pending,'pending_stages':pending,
        'independent_cache_reread':verify_cache,
        'completed_stages':len(stages),'semantic_stage_rows':sum(s['semantic_games'] for s in stages.values()),
        'unique_semantic_slots':len(views),'unique_completed_physical_inputs':len(physical),
        'repeated_physical_stage_memberships':sum(s['unique_physical_games'] for s in stages.values())-len(physical),
        'annotated_new_unique_sum':sum(s['new_unique_games'] for s in stages.values()),
        'annotated_cached_unique_sum':sum(s['cached_unique_games'] for s in stages.values()),
        'duplicate_new_claims':{k:v for k,v in fresh_claims.items() if len(v)>1},
        'unique_maps':len(map_paths),'played_bot_names':sorted(played),'registered_unplayed':registered_unplayed,
        'cache_files_at_snapshot_start':len(cache_inventory),'cache_inputs_not_referenced_by_completed_stages_at_snapshot_start':len(cache_inventory-set(physical)),
        'fault_games':len(faults),'faults':faults,'reinitialization_games':len(reinit),'reinitializations':reinit,
        'caught_error_log_samples':sum(sum(s.get('caught_errors',{}).values()) for r in physical.values() for s in r['stdout'].values()),
        'pre_game_access_denied_retry_attempts':sum(r['pre_game_access_denied_retries'] for r in physical.values()),
        'first_physical_game_created_utc':min((r['created_utc'] for r in physical.values()),default=None),
        'last_physical_game_created_utc':max((r['created_utc'] for r in physical.values()),default=None),
        'runtime_pins':runtime_pins,'stages':stages,
        'limits':['Unique physical inputs are exact ordered WASM/map/runtime/config/settings identities, not statistically independent games.',
                  'Cache reuse, duplicate smoke slots and panel reuse never add new evidence.',
                  'SDK errors and low-fuel status are sampled logs, not exact native fuel-exhaustion counts.',
                  'Compact exports omit full raw statistics and native replay bulk; raw SHA256 pins remain, and full local evidence is retained.',
                  'Completed-stage snapshot can exclude concurrently running/newly published stages; snapshot_is_final is false when a planned stage is pending.']}
    return summary,physical,views,plans,sources,map_paths,registered

def export(dest,payload):
    summary,physical,views,plans,sources,map_paths,registered=payload
    require(summary['snapshot_is_final'],'Do not export an incomplete experiment snapshot')
    require(SCRIPT_SHA256 is None or sha(Path(__file__))==SCRIPT_SHA256,'Audit script changed during execution')
    dest=output_guard(dest);require(dest!=ROOT,'Export directory cannot be task root')
    try:dest.lstat()
    except FileNotFoundError:pass
    else:raise RuntimeError('Export directory must be new and absent: '+str(dest))
    dest.mkdir(parents=True,exist_ok=False)
    required=['audit.json','outcomes.jsonl.gz','views.jsonl.gz','maps.zip','provenance.zip','export-manifest.json']
    require(not any((dest/name).exists() for name in required),'Export targets already exist; use a new directory')
    with output_guard(dest/'audit.json').open('xb') as stream:stream.write(json.dumps(sanitize(summary),indent=2,ensure_ascii=False).encode()+b'\n')
    with gzip.open(output_guard(dest/'outcomes.jsonl.gz'),'xb',compresslevel=9) as stream:
        for key in sorted(physical):stream.write(canonical(sanitize(physical[key]))+b'\n')
    with gzip.open(output_guard(dest/'views.jsonl.gz'),'xb',compresslevel=9) as stream:
        for key in sorted(views):stream.write(canonical(views[key])+b'\n')
    with zipfile.ZipFile(output_guard(dest/'maps.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        manifest={}
        for h,paths in sorted(map_paths.items()):
            path=sorted(paths,key=str)[0];name=path.relative_to(ARENA).as_posix()
            archive.write(path,name);manifest[h]={'archive_path':name,'aliases':[p.relative_to(ARENA).as_posix() for p in sorted(paths,key=str)]}
        archive.writestr('audit-map-manifest.json',json.dumps(manifest,indent=2))
    with zipfile.ZipFile(output_guard(dest/'provenance.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for stage,plan in plans.items():archive.writestr('stages/'+stage+'-plan.json',json.dumps(sanitize(plan),indent=2))
        for name,record in registered.items():
            archive.writestr('candidates/'+name+'.json',json.dumps(sanitize(record),indent=2))
            for file in sorted((ARENA/'bots'/name/'src').iterdir()):
                if file.is_file():archive.write(file,'sources/'+name+'/src/'+file.name)
        explicit=('plan.json','selection-plan.json','additional-development-plan.txt','refinement-plan.txt','corners-plan.txt','corners-coverage-correction.txt','reentry-development-plan.txt','reentry-activity-note.txt',
            'hold-coverage-proof.json','farm-helper-fixtures.json','farm-refined-fixtures.json','reentry-fixtures.json',
            'test_farm_helper.py','test_farm_refined.py','check_patch_farm.py',
            'patch_farm.py','patch_farm_refined.py','patch_corners.py','patch_reentry.py','patch_reentry_active.py',
            'generate-corners.mjs','generate-corners-v1.mjs','compare.py','lab.py','test_matches.py','audit_export.py')
        extras={ROOT/name for name in explicit if (ROOT/name).is_file()}
        extras.update(ROOT.glob('*freeze*.json'))
        for folder in ('baseline','corners-baseline'):
            if (ROOT/folder/'manifest.json').is_file():extras.add(ROOT/folder/'manifest.json')
        for folder in {p.parent for paths in map_paths.values() for p in paths}:
            if (folder/'manifest.json').is_file():extras.add(folder/'manifest.json')
        extras.update(p for p in (ROOT/'publish-tools').glob('*') if p.is_file())
        for path in sorted(extras,key=str):
            if path.suffix=='.json':archive.writestr(relative(path),json.dumps(sanitize(read(path)),indent=2))
            else:archive.write(path,relative(path))
    artifacts={name:{'bytes':(dest/name).stat().st_size,'sha256':sha(dest/name)} for name in required if (dest/name).exists()}
    require(all(v['bytes']<LIMIT for v in artifacts.values()),'An evidence artifact exceeds the GitHub 25MB limit')
    manifest={'created_utc':now(),'audit_script_sha256':sha(Path(__file__)),'artifacts':artifacts,
        'unique_completed_physical_inputs':summary['unique_completed_physical_inputs'],
        'path_policy':'Published plan copies replace task/work/user-home prefixes with TASK/WORK/USER; original local plan/result/cache SHA256 values pin original evidence.',
        'limits':summary['limits']}
    with output_guard(dest/'export-manifest.json').open('xb') as stream:stream.write(json.dumps(manifest,indent=2).encode()+b'\n')
    return manifest

def main():
    global SCRIPT_SHA256
    SCRIPT_SHA256=sha(Path(__file__))
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--allow-incomplete',action='store_true',help='Read-only snapshot while stages run; exports remain disabled');p.add_argument('--no-verify-cache',action='store_true',help='Skip independent cache-file reread (stage statistics still self-checked)');p.add_argument('--export',type=Path)
    a=p.parse_args();payload=audit(a.allow_incomplete,not a.no_verify_cache)
    if a.export:print(json.dumps(export(a.export,payload),indent=2))
    else:
        report=payload[0];print(json.dumps({k:v for k,v in report.items() if k!='stages'},indent=2))
    return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except (RuntimeError,OSError,ValueError,KeyError) as exc:
        print('AUDIT FAILED: '+str(exc),file=sys.stderr);raise SystemExit(1)
