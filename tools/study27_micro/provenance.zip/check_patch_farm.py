"""Transform contracts, not a substitute for engine A/B matches.

Run beside patch_farm.py. Check pinned inputs, unchanged capture/channel/combat
branches, independently composable reservation controls and fail-closed edits.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import patch_farm

ROOT = Path(__file__).resolve().parent


def section(text: str, start: str, end: str) -> str:
    return text.split(start, 1)[1].split(end, 1)[0]


def main() -> None:
    manifest = json.loads((ROOT / "baseline/manifest.json").read_text())
    source = {p.name: p.read_text() for p in (ROOT / "baseline/src").iterdir() if p.is_file()}
    for name, wanted in manifest["source_sha256"].items():
        actual = hashlib.sha256((ROOT / "baseline/src" / name).read_bytes()).hexdigest()
        assert actual == wanted, (name, actual, wanted)
    before = dict(source)
    main0 = source["main.cpp"]
    control_sections = [
        ("bool other_captures(", "void drop_target("),
        ("// Nothing of this group is visible alive.", "// ---------------------------------------------------------------------------\n// One turn"),
        ("bool g_ally_near_tgt = false;", "void support_spells("),
        ("    // 4. Recall to heal", "    // 5. Bank gems."),
        ("template <class U>\nbool cast_offense(", "template <class U>\nbool basic_attack("),
    ]
    outputs = []
    for name in patch_farm.GUARDS:
        variant = patch_farm.apply(source, name)
        assert source == before, f"input mutation for {name}"
        assert set(variant) == set(source)
        assert {n for n in source if source[n] != variant[n]} == {"main.cpp"}
        for start, end in control_sections:
            assert section(main0, start, end) == section(variant["main.cpp"], start, end), (name, start)
        assert variant["main.cpp"].count("if (farm_under_threat(s, me, *tgt, str, foes))") == 1
        assert "farm(s, me, round, camps);" not in variant["main.cpp"]
        assert "s.farm_guard_checks =" not in variant["main.cpp"]
        outputs.append(variant["main.cpp"])
        for reservation in patch_farm.RESERVES:
            composed = patch_farm.apply(variant, reservation)
            assert composed["main.cpp"] == variant["main.cpp"]
            assert composed["params.h"].endswith(f"#define P_SAVECC {reservation[-1]}\n")
    assert len(set(outputs)) == len(patch_farm.GUARDS)
    for name in patch_farm.RESERVES:
        variant = patch_farm.apply(source, name)
        assert {n for n in source if source[n] != variant[n]} == {"params.h"}
        assert variant["params.h"].startswith(source["params.h"])
    broken = dict(source)
    broken["main.cpp"] = main0.replace("    farm(s, me, round, camps);", "    // different source")
    try:
        patch_farm.apply(broken, patch_farm.GUARDS[0])
    except ValueError:
        pass
    else:
        raise AssertionError("An unrecognised baseline was silently patched")
    assert broken["main.cpp"].count("farm_guard") == 0
    print(f"PASS: {len(patch_farm.FEATURES)} variants, pinned input, unchanged capture/recall/combat, compositions and anchor failures")


if __name__ == "__main__":
    main()
