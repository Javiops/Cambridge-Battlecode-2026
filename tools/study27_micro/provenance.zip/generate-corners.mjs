// New Corners-signature procedural topologies. No source maps/results are read.
// The imported utility initializes the cached official editor WASM only.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { E, out, checked, decode, encode, verifyGame, hash, terrainNames }
  from '../battlecode-bot-v1/r2-ward/map-variants.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const HELPER = path.resolve(HERE, '../battlecode-bot-v1/r2-ward/map-variants.mjs');
const ENGINE = path.resolve(HERE, '../battlecode-bot-v1/r2-research/v0_0_1-ctH8uuEb.wasm');
const view = () => new DataView(E.memory.buffer);
const key = ([x, y]) => `${x},${y}`;
const unkey = value => value.split(',').map(Number);
const sortTiles = tiles => [...tiles].sort((a, b) => a[1] - b[1] || a[0] - b[0]);
const assert = (condition, message) => { if (!condition) throw new Error(message); };
const STYLE_NAMES = ['open', 'chokes', 'scatter', 'ribs', 'mixed'];
const MAX_ATTEMPTS = 120;
const MAX_TOTAL_ATTEMPTS = 2000;

function rng(seed) {
  let state = seed >>> 0;
  return {
    next() {
      // Mulberry32, including a well-defined zero seed.
      state = (state + 0x6d2b79f5) >>> 0;
      let value = Math.imul(state ^ (state >>> 15), state | 1);
      value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
      return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
    },
    int(lo, hi) { return lo + Math.floor(this.next() * (hi - lo + 1)); },
    pick(values) { return values[this.int(0, values.length - 1)]; },
  };
}

function derivedSeed(seed, index, attempt) {
  const bytes = Buffer.from(`${seed >>> 0}/corners-topology-v2/${index}/${attempt}`);
  return Buffer.from(hash(bytes), 'hex').readUInt32LE(0);
}

// Official enum semantics were checked directly with AddWall/decode:
// 0 flips x; 1 flips y; 2 rotates both coordinates through180 degrees.
function mirror(p, source) {
  const [x, y] = p;
  if (source.symmetry === 0) return [source.width - 1 - x, y];
  if (source.symmetry === 1) return [x, source.height - 1 - y];
  return [source.width - 1 - x, source.height - 1 - y];
}

function rectangle(bounds) {
  const tiles = [];
  for (let y = bounds[1]; y < bounds[3]; ++y)
    for (let x = bounds[0]; x < bounds[2]; ++x) tiles.push([x, y]);
  return tiles;
}

function inside(p, source) {
  return p[0] >= 0 && p[1] >= 0 && p[0] < source.width && p[1] < source.height;
}

function cheby(a, b) { return Math.max(Math.abs(a[0] - b[0]), Math.abs(a[1] - b[1])); }

function walkField(source, blocked, roots) {
  const distance = new Int32Array(source.width * source.height).fill(-1);
  const queue = new Int32Array(distance.length);
  let head = 0, tail = 0;
  for (const p of roots) {
    const id = p[1] * source.width + p[0];
    if (!blocked.has(key(p)) && distance[id] < 0) { distance[id] = 0; queue[tail++] = id; }
  }
  while (head < tail) {
    const id = queue[head++], x = id % source.width, y = Math.floor(id / source.width);
    for (let dy = -1; dy <= 1; ++dy) for (let dx = -1; dx <= 1; ++dx) {
      if (!dx && !dy) continue;
      const q = [x + dx, y + dy];
      if (!inside(q, source) || blocked.has(key(q))) continue;
      const next = q[1] * source.width + q[0];
      if (distance[next] >= 0) continue;
      distance[next] = distance[id] + 1; queue[tail++] = next;
    }
  }
  return { distance, reached: tail, at: p => distance[p[1] * source.width + p[0]] };
}

function fullCamps(source) {
  return source.camps.flatMap(camp => {
    const p = [camp.x, camp.y], q = mirror(p, source);
    assert(key(p) !== key(q), 'Camp on a self-mirrored tile');
    return [{ ...camp }, { type: camp.type, x: q[0], y: q[1] }];
  });
}

function design(seed, index, attempt) {
  const random = rng(derivedSeed(seed, index, attempt));
  const width = 71, height = 71;
  const symmetry = 2; // One central altar is self-mirrored under180 degrees.
  const champions = 3 + ((index + seed) % 3);
  const style = STYLE_NAMES[(index + (seed % STYLE_NAMES.length)) % STYLE_NAMES.length];
  const source = { width, height, symmetry, champions, style, camps: [],
    terrain: { Bush: [], Wall: [], Hole: [], Altar: [] } };
  // All spawn rectangles are half-open and have at least9 tiles, also enough
  // for the extra body produced by the Cassi/Issac draft pick.
  const inset = index % 2 === 1;
  source.spawn_class = inset ? 'inset_path_le45' : 'far_path_gt45';
  const x = inset ? random.int(12, 22) : random.int(1, 8);
  const upper = random.next() < 0.5;
  const y = inset ? (upper ? random.int(12, 22) : random.int(46, 56)) :
    (upper ? random.int(1, 8) : random.int(59, 66));
  source.spawn = [x, y, x + 3, y + 3];
  const aSpawn = rectangle(source.spawn), bSpawn = aSpawn.map(p => mirror(p, source));
  assert(!aSpawn.some(p => bSpawn.some(q => key(p) === key(q))), 'Spawn overlap');
  const protectedTiles = new Set();
  const protect = (p, radius) => {
    for (let dx = -radius; dx <= radius; ++dx) for (let dy = -radius; dy <= radius; ++dy) {
      const q = [p[0] + dx, p[1] + dy];
      if (inside(q, source)) protectedTiles.add(key(q));
    }
  };
  for (const p of [...aSpawn, ...bSpawn]) protect(p, 2);
  // Leave room for two randomized, distinct central groups per authored half.
  protect([35, 35], 6);
  const routeTiles = new Set();
  const route = (start, end) => {
    const p = [...start];
    const radius = random.int(0, 1);
    for (let guard = 0; guard < width + height + 1; ++guard) {
      for (const q of [p, mirror(p, source)]) {
        routeTiles.add(key(q)); protect(q, radius);
      }
      if (key(p) === key(end)) return;
      p[0] += Math.sign(end[0] - p[0]); p[1] += Math.sign(end[1] - p[1]);
    }
    throw new Error('Route construction exceeded bound');
  };
  const home = [x + 1, y + 1], away = mirror(home, source);
  const waypoint = [random.int(Math.floor(width / 3), Math.floor(2 * width / 3)),
    random.int(Math.floor(height / 3), Math.floor(2 * height / 3))];
  route(home, waypoint); route(waypoint, away);
  const terrain = Object.fromEntries(terrainNames.map(name => [name, new Set()]));
  function addObstacle(name, p) {
    const pair = [p, mirror(p, source)];
    if (key(pair[0]) === key(pair[1])) return;
    if (pair.some(q => !inside(q, source) || protectedTiles.has(key(q)))) return;
    if (pair.some(q => terrain.Wall.has(key(q)) || terrain.Hole.has(key(q)))) return;
    for (const q of pair) terrain[name].add(key(q));
  }
  const area = width * height;
  // Exactly22 mirrored wall pairs. Variable holes carry corridor and
  // obstacle-density diversity while preserving the classifier's44 walls.
  if (style === 'chokes' || style === 'ribs') {
    const vertical = index % 2 === 0;
    const count = style === 'chokes' ? random.int(1, 2) : random.int(2, 4);
    for (let n = 0; n < count; ++n) {
      const axis = random.int(15, 55), gap = random.int(10, 60);
      for (let t = 2; t < 69; ++t) {
        if (Math.abs(t - gap) <= 2 || (style === 'ribs' && t % 7 === 0)) continue;
        addObstacle('Hole', vertical ? [axis, t] : [t, axis]);
      }
    }
  }
  const holePatches = style === 'open' ? random.int(0, 3) :
    style === 'mixed' ? random.int(20, 40) : random.int(8, 24);
  for (let n = 0; n < holePatches; ++n) {
    const p = [random.int(1, 69), random.int(1, 69)];
    const w = random.int(1, 3), h = random.int(1, 3);
    for (let dx = 0; dx < w; ++dx) for (let dy = 0; dy < h; ++dy)
      addObstacle('Hole', [p[0] + dx, p[1] + dy]);
  }
  for (let trial = 0; terrain.Wall.size < 44 && trial < 2000; ++trial) {
    const p = [random.int(1, 69), random.int(1, 69)];
    if (style === 'scatter' || style === 'open') addObstacle('Wall', p);
    else {
      const w = random.int(1, 4), h = random.int(1, 2);
      for (let dx = 0; dx < w && terrain.Wall.size < 44; ++dx)
        for (let dy = 0; dy < h && terrain.Wall.size < 44; ++dy)
          addObstacle('Wall', [p[0] + dx, p[1] + dy]);
    }
  }
  assert(terrain.Wall.size === 44, 'Unable to place exactly22 mirrored wall pairs');
  const spawnSet = new Set([...aSpawn, ...bSpawn].map(key));
  const staticBlock = new Set([...terrain.Wall, ...terrain.Hole]);
  const canonicalSide = p => p[1] * width + p[0] < mirror(p, source)[1] * width + mirror(p, source)[0];
  const usable = p => inside(p, source) && !staticBlock.has(key(p)) && !spawnSet.has(key(p));
  terrain.Altar.add('35,35'); staticBlock.add('35,35');
  for (let n = 0; n < 2; ++n) {
    let added = false;
    for (let trial = 0; trial < 220; ++trial) {
      const p = [random.int(3, width - 4), random.int(3, height - 4)], q = mirror(p, source);
      if (!usable(p) || !usable(q) || protectedTiles.has(key(p)) || protectedTiles.has(key(q))) continue;
      if (cheby(p, q) < 4 || [...terrain.Altar].some(k => cheby(p, unkey(k)) < 4 || cheby(q, unkey(k)) < 4)) continue;
      if ([...aSpawn, ...bSpawn].some(t => cheby(t, p) < 3 || cheby(t, q) < 3)) continue;
      terrain.Altar.add(key(p)); terrain.Altar.add(key(q));
      staticBlock.add(key(p)); staticBlock.add(key(q)); added = true; break;
    }
    assert(added, 'Unable to place scattered altars');
  }
  const occupied = new Set();
  const shapes = [ [[0, 0]], [[0, 0], [1, 0]], [[0, 0], [1, 0], [2, 0]],
    [[0, 0], [1, 0], [0, 1]], [[0, 0], [1, 0], [2, 0], [3, 0]],
    [[0, 0], [1, 0], [0, 1], [1, 1]] ];
  const groupCount = random.int(8, 20);
  const types = [0, 0, 0, 0, 1, 1, 1, 2, 2, 3]; // wolf, elk, gem cluster, occasional gold
  for (let group = 0; group < groupCount; ++group) {
    let added = false;
    for (let trial = 0; trial < 350; ++trial) {
      const central = group < 2;
      const anchor = central ? [random.int(29, 41), random.int(29, 33)] :
        [random.int(2, width - 3), random.int(2, height - 3)];
      const turns = random.int(0, 3), shape = random.pick(central ? shapes.slice(0, 2) : shapes);
      const coords = shape.map(offset => {
        let [dx, dy] = offset;
        for (let t = 0; t < turns; ++t) [dx, dy] = [-dy, dx];
        return [anchor[0] + dx, anchor[1] + dy];
      });
      if (coords.some(p => !canonicalSide(p))) continue;
      if (central && coords.some(p => cheby(p, [35, 35]) > 6)) continue;
      const expanded = [...coords, ...coords.map(p => mirror(p, source))];
      if (new Set(expanded.map(key)).size !== expanded.length) continue;
      if (expanded.some(p => !usable(p) || terrain.Altar.has(key(p)) ||
          [...spawnSet].some(k => cheby(p, unkey(k)) < 3) ||
          [...terrain.Altar].some(k => cheby(p, unkey(k)) < 2) ||
          [...occupied].some(k => cheby(p, unkey(k)) < 3))) continue;
      // Keep opposite halves as two distinct cardinal groups.
      if (coords.some(p => coords.some(t => cheby(p, mirror(t, source)) < 3))) continue;
      const mainType = random.pick(central ? [0, 1, 2] : types);
      const groupTypes = coords.map(() => random.next() < 0.8 ? mainType : random.pick(types));
      if (central && groupTypes.every(type => type === 3)) groupTypes[0] = 2;
      if (groupTypes.every(type => type === 3) && random.next() < 0.8) groupTypes[0] = 2;
      for (let i = 0; i < coords.length; ++i) source.camps.push({ type: groupTypes[i], x: coords[i][0], y: coords[i][1] });
      for (const p of expanded) occupied.add(key(p));
      added = true; break;
    }
    assert(added, 'Unable to place separated camp groups');
  }
  const bushPatches = Math.floor(area * random.next() * 0.017);
  for (let n = 0; n < bushPatches; ++n) {
    const p = [random.int(1, width - 2), random.int(1, height - 2)];
    const radius = random.int(0, 2);
    for (let dx = -radius; dx <= radius; ++dx) for (let dy = -radius; dy <= radius; ++dy) {
      const tile = [p[0] + dx, p[1] + dy], pair = [tile, mirror(tile, source)];
      if (pair.some(q => !usable(q) || terrain.Altar.has(key(q)) || occupied.has(key(q)) ||
          [...spawnSet].some(k => cheby(q, unkey(k)) < 2))) continue;
      for (const q of pair) terrain.Bush.add(key(q));
    }
  }
  for (const name of terrainNames) source.terrain[name] = sortTiles([...terrain[name]].map(unkey));
  source.designed_groups_per_half = groupCount;
  source.central_groups_per_half = 2;
  return source;
}

function validateStatic(source) {
  assert(source.width === 71 && source.height === 71 && source.symmetry === 2,
    'Wrong Corners dimensions/symmetry');
  assert(source.terrain.Wall.length === 44 && source.terrain.Altar.length === 5,
    'Wrong Corners classifier fingerprint');
  assert(source.terrain.Altar.some(p => key(p) === '35,35'), 'Missing central self-mirrored altar');
  const a = rectangle(source.spawn), b = a.map(p => mirror(p, source));
  const terrain = Object.fromEntries(terrainNames.map(name => [name, new Set(source.terrain[name].map(key))]));
  for (const name of terrainNames) for (const p of source.terrain[name])
    assert(terrain[name].has(key(mirror(p, source))), `Asymmetric ${name}`);
  const block = new Set([...terrain.Wall, ...terrain.Hole, ...terrain.Altar]);
  const spawnTiles = new Set([...a, ...b].map(key));
  for (const p of [...a, ...b]) assert(!block.has(key(p)), 'Blocked spawn');
  const camps = fullCamps(source), campKeys = camps.map(c => key([c.x, c.y]));
  assert(new Set(campKeys).size === camps.length, 'Duplicate runtime camp tile');
  for (const k of campKeys) assert(!block.has(k) && !spawnTiles.has(k), 'Camp on obstacle/spawn');
  const neutral = walkField(source, block, a);
  const pathDistance = Math.min(...b.map(p => neutral.at(p)).filter(n => n >= 0));
  assert(Number.isFinite(pathDistance) && pathDistance >= 8, 'Spawn-to-spawn is disconnected/too close');
  // Same eight-neighbour static blockers and spawn-to-spawn minimum as the
  // original P_DRAFTUNI2 distance-field decision; this predicts its path gate,
  // not the actual roster, which also depends on the draft opponent and side.
  if (source.spawn_class === 'inset_path_le45') assert(pathDistance <= 45, 'Inset map misses caster draft path gate');
  else assert(pathDistance > 45, 'Far map misses farming draft path gate');
  const aField = walkField(source, new Set([...block, ...b.map(key)]), a);
  const bField = walkField(source, new Set([...block, ...a.map(key)]), b);
  const traversable = source.width * source.height - block.size;
  assert(neutral.reached / traversable >= 0.96, 'Too much disconnected walking space');
  for (const c of camps) {
    const p = [c.x, c.y], mirrored = mirror(p, source);
    assert(aField.at(p) >= 0 && bField.at(p) >= 0, 'Unreachable camp');
    assert(aField.at(p) === bField.at(mirrored), 'Asymmetric spawn-to-camp distance');
  }
  const altarApproach = [];
  for (const altar of source.terrain.Altar) {
    const ring = [];
    for (let dy = -1; dy <= 1; ++dy) for (let dx = -1; dx <= 1; ++dx) {
      const p = [altar[0] + dx, altar[1] + dy];
      if (inside(p, source) && !block.has(key(p))) ring.push(p);
    }
    const da = Math.min(...ring.map(p => aField.at(p)).filter(n => n >= 0));
    const db = Math.min(...ring.map(p => bField.at(p)).filter(n => n >= 0));
    assert(Number.isFinite(da) && Number.isFinite(db), 'Unreachable altar approach');
    altarApproach.push({ altar, spawn_distances: [da, db] });
  }
  return { spawn_to_spawn: pathDistance, connected_walking_fraction: neutral.reached / traversable,
    spawn_tiles_per_team: a.length, runtime_camps: camps.length,
    terrain_counts: Object.fromEntries(terrainNames.map(name => [name, source.terrain[name].length])),
    classifier_family: 'Corners', exact_fingerprint: { width: 71, height: 71, altars: 5, walls: 44 },
    draft_path_gate: pathDistance <= 45 ? 'caster_path' : 'farm_path',
    actual_roster_or_caster_state_verified: false,
    designed_central_groups_per_half: source.central_groups_per_half,
    all_camps_reachable_from_both_teams: true, all_altars_reachable_from_both_teams: true,
    mirrored_camp_distance_equal: true, altar_approaches: altarApproach };
}

function encodeOfficial(source) {
  checked('MapBuilder_Create', source.width, source.height, source.symmetry, out);
  const handle = view().getBigUint64(out, true);
  try {
    const initial = decode(handle);
    assert(initial.camps.length === 0, 'Blank official builder unexpectedly has camps');
    for (const name of terrainNames) for (const p of initial.terrain[name]) checked(`MapBuilder_Remove${name}`, handle, ...p);
    checked('MapBuilder_SetNumChampsPerTeam', handle, source.champions);
    source.spawn.forEach((value, i) => view().setInt32(out + i * 4, value, true));
    checked('MapBuilder_SetTeamASpawnArea', handle, out);
    // Stable neutral colours; no random cosmetics enter the procedural seed.
    for (const [name, value] of Object.entries(initial.colors)) {
      if (name === 'BushTintRange') checked('MapBuilder_SetBushTintRange', handle, 0, 0);
      else checked(`MapBuilder_Set${name}`, handle, value);
    }
    for (const name of ['Hole', 'Wall', 'Altar', 'Bush']) for (const p of source.terrain[name]) {
      const q = mirror(p, source);
      if (p[1] * source.width + p[0] > q[1] * source.width + q[0]) continue;
      checked(`MapBuilder_Add${name}`, handle, ...p);
    }
    for (const c of source.camps) checked('MapBuilder_AddCamp', handle, c.type, c.x, c.y, out);
    checked('MapBuilder_VerifyIntegrity', handle);
    const buffer = encode(handle), decoded = decode(handle);
    for (const name of terrainNames)
      assert(JSON.stringify(sortTiles(decoded.terrain[name])) === JSON.stringify(sortTiles(source.terrain[name])), `Terrain roundtrip mismatch: ${name}`);
    assert(JSON.stringify(decoded.spawn) === JSON.stringify(source.spawn), 'Half-open spawn bounds changed');
    const campSort = camps => camps.map(c => [c.type, c.x, c.y]).sort((a, b) => a[2] - b[2] || a[1] - b[1] || a[0] - b[0]);
    assert(JSON.stringify(campSort(decoded.camps)) === JSON.stringify(campSort(source.camps)), 'Stored camp representatives changed');
    assert(decoded.groups === source.designed_groups_per_half, 'Unexpected merged stored camp groups');
    assert(hash(buffer) === hash(encode(handle)), 'Encoding the same official builder is not deterministic');
    verifyGame(buffer);
    return { buffer, decoded };
  } finally { checked('MapBuilder_Destroy', handle); }
}

function verifyRuntime(buffer, source) {
  const p = E.Engine_Malloc(buffer.length);
  let game, snapshot, perspective;
  try {
    new Uint8Array(E.memory.buffer, p, buffer.length).set(buffer);
    checked('Game_FromMapFileBytes', p, buffer.length, out, 0);
    game = view().getBigUint64(out, true);
    // Initialize static runtime entities only. No champion is drafted and no
    // round, turn, bot or match is advanced during this integrity check.
    checked('Game_Runner_Init', game);
    // Game_GetCamp describes authored half-map records. The initial visualiser
    // snapshot contains the actual expanded symmetric runtime entities.
    const size = E.Game_Visualiser_SnapshotSize();
    assert(size === 184696, 'Official full snapshot ABI changed');
    snapshot = E.Engine_Malloc(size); perspective = E.Engine_Malloc(8);
    view().setUint32(perspective, 2, true);
    view().setUint32(perspective + 4, 0xffffffff, true);
    checked('Game_Visualiser_ReadState', game, perspective, snapshot);
    assert(view().getUint32(snapshot, true) === 1 && view().getUint32(snapshot + 4, true) === size, 'Invalid full snapshot header');
    const count = view().getUint32(snapshot + 124, true), camps = [], groupSizes = [], grouped = new Map();
    for (let i = 0; i < count; ++i) {
      const c = snapshot + 7436 + i * 232;
      camps.push([view().getUint32(c + 12, true), view().getInt32(c + 20, true), view().getInt32(c + 24, true)]);
      const group = view().getUint32(c + 224, true);
      groupSizes[group] = (groupSizes[group] ?? 0) + 1;
      if (!grouped.has(group)) grouped.set(group, []);
      grouped.get(group).push(camps[camps.length - 1]);
    }
    const sorted = values => values.sort((a, b) => a[2] - b[2] || a[1] - b[1] || a[0] - b[0]);
    assert(JSON.stringify(sorted(camps)) === JSON.stringify(sorted(fullCamps(source).map(c => [c.type, c.x, c.y]))), 'Runtime mirrored camps differ');
    const groups = view().getUint32(snapshot + 128, true);
    assert(groups === 2 * source.designed_groups_per_half, 'Unexpected merged runtime groups');
    for (let i = 0; i < groups; ++i) {
      assert(groupSizes[i] >= 1 && groupSizes[i] <= 4, 'Runtime camp group size outside1..4');
    }
    const gemCenters = [...grouped.values()].filter(cs => cs.some(c => c[0] !== 3)).map(cs => [
      Math.floor(cs.reduce((sum, c) => sum + c[1], 0) / cs.length),
      Math.floor(cs.reduce((sum, c) => sum + c[2], 0) / cs.length),
    ]);
    const centralGroups = gemCenters.filter(p => cheby(p, [35, 35]) <= 6).length;
    assert(centralGroups >= 4, 'Native runtime central gem hotspot has fewer than4 groups');
    const home = [source.spawn[0] + 1, source.spawn[1] + 1], away = mirror(home, source);
    const eligibleHold = source.terrain.Altar.filter(a => Math.abs(cheby(a, home) - cheby(a, away)) <= 4 &&
      gemCenters.filter(c => cheby(c, a) <= 6).length >= 2).sort((a, b) => cheby(a, home) - cheby(b, home));
    assert(eligibleHold.length > 0 && key(eligibleHold[0]) === '35,35', 'Study27 geometric hold would not choose central hotspot');
    return { runtime_camps: count, runtime_groups: groups, group_sizes: groupSizes,
      runtime_central_gem_groups: centralGroups, eligible_geometric_hold_altar: [35, 35],
      official_integrity: true, official_verify_game: true, official_runtime_expansion_equal: true };
  } finally {
    if (snapshot !== undefined) E.Engine_Free(snapshot);
    if (perspective !== undefined) E.Engine_Free(perspective);
    if (game !== undefined) checked('Game_Destroy', game);
    E.Engine_Free(p);
  }
}

function geometryIdentity(source) {
  // This hash excludes bushes/cosmetics and removes D4 orientation plus team
  // labels. A mere bush edit or rotation cannot become a new topology here.
  const points = name => source.terrain[name];
  const full = fullCamps(source), spawns = rectangle(source.spawn);
  const forms = [];
  for (let reflect = 0; reflect < 2; ++reflect) for (let rotate = 0; rotate < 4; ++rotate) {
    const transform = p => {
      let [x, y] = p, w = source.width, h = source.height;
      if (reflect) x = w - 1 - x;
      for (let n = 0; n < rotate; ++n) { [x, y] = [h - 1 - y, x]; [w, h] = [h, w]; }
      return [x, y];
    };
    const spawnPair = [spawns.map(transform), spawns.map(p => transform(mirror(p, source)))].map(sortTiles)
      .sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
    const terrain = Object.fromEntries(['Wall', 'Hole', 'Altar'].map(name => [name, sortTiles(points(name).map(transform))]));
    const camps = full.map(c => [c.type, ...transform([c.x, c.y])]).sort((a, b) => a[0] - b[0] || a[2] - b[2] || a[1] - b[1]);
    forms.push(JSON.stringify({ width: rotate % 2 ? source.height : source.width,
      height: rotate % 2 ? source.width : source.height, champions: source.champions, spawns: spawnPair, terrain, camps }));
  }
  return hash(Buffer.from(forms.sort()[0]));
}

function parseArgs(argv) {
  const result = {};
  assert(argv.length === 6, 'Usage: node generate-corners.mjs --seed UINT32 --count N --out NEW_DIRECTORY');
  for (let i = 0; i < argv.length; i += 2) {
    assert(['--seed', '--count', '--out'].includes(argv[i]), `Unknown argument: ${argv[i]}`);
    assert(!Object.hasOwn(result, argv[i]), `Duplicate argument: ${argv[i]}`);
    result[argv[i]] = argv[i + 1];
  }
  assert(/^\d+$/.test(result['--seed'] ?? ''), 'Seed must be an unsigned32-bit decimal integer');
  const seed = Number(result['--seed']), count = Number(result['--count']);
  assert(Number.isInteger(seed) && seed >= 0 && seed <= 0xffffffff, 'Seed outside UINT32');
  assert(Number.isInteger(count) && count >= 1 && count <= 4096, 'Count must be1..4096');
  assert(result['--out'], 'Missing output directory');
  return { seed, count, destination: path.resolve(result['--out']) };
}

function main() {
  const { seed, count, destination } = parseArgs(process.argv.slice(2));
  assert(!fs.existsSync(destination), `Refusing to overwrite an existing directory: ${destination}`);
  fs.mkdirSync(destination, { recursive: true });
  const hashes = new Set(), geometries = new Set(), maps = [], rejected = [];
  let totalAttempts = 0;
  for (let index = 0; index < count; ++index) {
    let accepted = false;
    for (let attempt = 0; attempt < MAX_ATTEMPTS; ++attempt) {
      assert(++totalAttempts <= MAX_TOTAL_ATTEMPTS, 'Exceeded2000 total deterministic design attempts');
      try {
        const source = design(seed, index, attempt), validation = validateStatic(source);
        const geometrySha = geometryIdentity(source);
        assert(!geometries.has(geometrySha), 'Duplicate D4 geometry without bushes');
        const { buffer, decoded } = encodeOfficial(source), runtime = verifyRuntime(buffer, source);
        const sha256 = hash(buffer);
        assert(!hashes.has(sha256), 'Duplicate encoded SHA256');
        const filename = `corners-${String(index).padStart(4, '0')}.map26a`;
        fs.writeFileSync(path.join(destination, filename), buffer, { flag: 'wx' });
        hashes.add(sha256); geometries.add(geometrySha);
        maps.push({ file: filename, sha256, topology_d4_sha256: geometrySha,
          seed: derivedSeed(seed, index, attempt), index, attempt,
          width: source.width, height: source.height, symmetry: source.symmetry,
          champions: source.champions, style: source.style, spawn_a_half_open: source.spawn,
          spawn_class: source.spawn_class,
          stored_camps: decoded.camps.length, stored_groups: decoded.groups,
          camp_type_counts: Object.fromEntries([0, 1, 2, 3].map(type => [type, fullCamps(source).filter(c => c.type === type).length])),
          validation: { ...validation, ...runtime } });
        console.log(`${index + 1}/${count}: ${filename} ${source.width}x${source.height} ${source.style} team${source.champions}`);
        accepted = true; break;
      } catch (error) {
        rejected.push({ index, attempt, seed: derivedSeed(seed, index, attempt), reason: error.message });
      }
    }
    assert(accepted, `Map${index} exhausted${MAX_ATTEMPTS} deterministic attempts`);
  }
  const manifest = { schema: 'corners-procedural-topologies-v2', created_at_utc: new Date().toISOString(),
    seed, count, source_maps_read: 0, candidate_results_read: false,
    generator_sha256: hash(fs.readFileSync(fileURLToPath(import.meta.url))),
    helper_sha256: hash(fs.readFileSync(HELPER)), engine_sha256: hash(fs.readFileSync(ENGINE)),
    generation: 'Blank official MapBuilder; new71x71 rotate180 topologies with44walls and5altars, mixed far/inset corner spawns, procedural holes/camps/bushes; no source-map edits.',
    coverage_correction: 'V1 was never evaluated in matches. Its paths all exceeded45 and missed the caster path gate. V2 alternates far and inset spawns before any Corners outcomes are inspected.',
    symmetry_enum: { 0: 'flip_x', 1: 'flip_y', 2: 'rotate180' },
    constraints: { dimensions: [71, 71], exact_walls: 44, exact_altars: 5, center_altar: [35, 35],
      central_groups_per_half: 2, picks_per_team: [3, 4, 5], camp_group_size: [1, 4],
      spawn_class_rule: 'Even indices require path>45; odd indices require path<=45; exact static draft BFS blockers.',
      max_attempts_per_index: MAX_ATTEMPTS, max_total_attempts: MAX_TOTAL_ATTEMPTS,
      walking: 'Eight-neighbour landing-only;walls+holes+altars blocked;enemy spawn blocked in each team field.',
      unique_topology_identity: 'D4 normalized, team labels exchangeable, excludes bushes and cosmetics.',
      note: 'Controlled Corners-fingerprint maps include a central gem hotspot and balanced farm/caster draft path gates. Actual roster and hold activation require bot-match observation. This is not representative of all maps or all71x71topologies. Test both sides.' },
    summary: { total_attempts: totalAttempts, rejected_attempts: rejected.length,
      dimension_range: [Math.min(...maps.flatMap(m => [m.width, m.height])), Math.max(...maps.flatMap(m => [m.width, m.height]))],
      spawn_classes: Object.fromEntries(['far_path_gt45', 'inset_path_le45'].map(c => [c, maps.filter(m => m.spawn_class === c).length])),
      unique_nonbush_d4_geometries: geometries.size }, maps, rejected_attempts: rejected };
  fs.writeFileSync(path.join(destination, 'manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`, { flag: 'wx' });
  console.log(`Created${count} unique official-valid new topologies; manifest:${path.join(destination, 'manifest.json')}`);
}

export { design, validateStatic, geometryIdentity, encodeOfficial, verifyRuntime };
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main();
