"""Immutable source-pinned study27 farming experiments. No online submissions."""
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import contextmanager
import argparse, hashlib, importlib.util, json, os, re, shutil, subprocess, threading, time

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
REPO = WORK / 'battlecode-team-github/review-43d0033/snapshot/Cambridge-Battlecode-2026-main'
BASE = ROOT / 'baseline/src'
BASE_COMMIT = 'c462346d4ace741bfd8f5251fb0e5e2eee69b800'
SPAR_COMMIT = '43d003323cd16059cda6a54de14ed86e2da3b788'
SPARS = ('spar11', 'spar12', 'spar16')
ARENA = ROOT / 'arena'
CLI = WORK / 'battlecode-bot-v1/runtime/cambc.exe'
OLD_ARENA = WORK / 'battlecode-bot-v1/arena'
ENV = {**os.environ, 'CAMBC_NO_UPDATE_CHECK': '1',
       'CAMBC_WASMTIME_CACHE': str(ROOT / 'wasmtime-cache')}

def now(): return datetime.now(timezone.utc).isoformat()
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text(encoding='utf8'))
def require(ok, message):
    if not ok: raise RuntimeError(message)
def guard(p):
    p = Path(p)
    require(p.resolve().is_relative_to(ROOT), 'Output escapes task root: '+str(p))
    return p
def write(p, obj):
    p = guard(p); p.parent.mkdir(parents=True, exist_ok=True)
    temp = guard(p.with_name(p.name+f'.{os.getpid()}.{threading.get_ident()}.tmp'))
    temp.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n', encoding='utf8')
    os.replace(temp, p)
def hashes(p):
    p = Path(p)
    require(p.is_dir(), 'Missing source directory: '+str(p))
    require(all(f.is_file() and f.resolve().is_relative_to(p.resolve()) for f in p.iterdir()),
            'Source directory must contain only ordinary files: '+str(p))
    return {f.name: sha(f) for f in sorted(p.iterdir())}
def valid_name(name):
    require(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,63}', name), 'Invalid candidate name: '+str(name))

@contextmanager
def exclusive(p, timeout=1200):
    p = guard(p); p.parent.mkdir(parents=True, exist_ok=True); start=time.monotonic()
    while True:
        try:
            fd=os.open(p, os.O_CREAT|os.O_EXCL|os.O_WRONLY); break
        except FileExistsError:
            require(time.monotonic()-start < timeout, 'Timed out on lock '+str(p)+'; check active process before removing.')
            time.sleep(.1)
    try:
        with os.fdopen(fd,'w',encoding='utf8') as stream: stream.write(json.dumps({'pid':os.getpid(),'created_utc':now()}))
        yield
    finally: p.unlink(missing_ok=True)

def feature_module():
    path=ROOT/'patch_farm.py'
    require(path.is_file(), 'Missing transform module '+str(path))
    spec=importlib.util.spec_from_file_location('study27_patch_farm', path)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module, path

def setup():
    require(hashes(BASE)==read(ROOT/'baseline/manifest.json')['source_sha256'], 'Pinned baseline source mismatch')
    require(read(ROOT/'baseline/manifest.json')['commit']==BASE_COMMIT, 'Pinned baseline commit mismatch')
    ARENA.mkdir(exist_ok=True)
    for d in ('sdk','cmake','maps'):
        if not (ARENA/d).exists(): shutil.copytree(OLD_ARENA/d,guard(ARENA/d))
    for d in ('maps_gen','maps_dev200','maps_hold60'):
        if not (ARENA/d).exists(): shutil.copytree(REPO/d,guard(ARENA/d))
    if not (ARENA/'cambc.toml').exists(): shutil.copyfile(OLD_ARENA/'cambc.toml',guard(ARENA/'cambc.toml'))
    if not (ROOT/'plan.json').exists():
        write(ROOT/'plan.json', {'created_utc':now(),'base_commit':BASE_COMMIT,
            'base_source_sha256':hashes(BASE),'spar_commit':SPAR_COMMIT,
            'development':['official9','maps_gen44','maps_dev200'],
            'legacy_validation':'maps_hold60 has prior team exposure; never an unseen holdout.',
            'selection':'Compare isolated farming policies and promising combinations against original and independently pinned spar11/12/16. Select on development only. Preserve unchanged baseline as candidate against the same sparring opponents/maps for paired outcome-delta analysis.',
            'confirmation':'Freeze source/WASM before generating a new fixed map cohort. Report all confirmation results, no tuning or early stopping.',
            'unit':'Exact map content, two candidate sides, grouped by opponent. Sparring aggregate is descriptive; shared maps/opponents are correlated.',
            'deduplication':'Identical ordered WASM pair, map, CLI, configuration, engine identity is one physical game. Reused results are never new independent evidence.',
            'limitations':'A positive self-play/old-spar result alone does not demonstrate broad ladder strength.'})
    require(read(ROOT/'plan.json')['base_source_sha256']==hashes(BASE), 'Existing plan baseline changed')
    register('original', [])
    for name in SPARS: register_spar(name)

def materialize(name, source, payload, metadata):
    valid_name(name)
    target=guard(ARENA/'bots'/name/'src'); record=ROOT/'candidates'/f'{name}.json'
    metadata={**metadata,'name':name,'source_sha256':{f:hashlib.sha256(v).hexdigest() for f,v in sorted(payload.items())}}
    if record.exists():
        old=read(record)
        require(all(old.get(k)==v for k,v in metadata.items()), 'Candidate provenance changed: '+name)
        require(old['source_sha256']==hashes(target), 'Registered candidate source changed: '+name)
        return
    require(not target.exists(), 'Unregistered candidate source already exists: '+name)
    target.mkdir(parents=True)
    for f, content in payload.items():
        require(Path(f).name==f, 'Invalid source filename')
        guard(target/f).write_bytes(content)
    write(record,{**metadata,'created_utc':now()})

def register(name, features):
    valid_name(name)
    require(name not in SPARS, 'Sparring names are reserved')
    require(name!='original' or not features, 'Original cannot carry features')
    require(len(features)==len(set(features)), 'Duplicate feature')
    require(hashes(BASE)==read(ROOT/'baseline/manifest.json')['source_sha256'], 'Baseline changed')
    original={f.name:f.read_bytes() for f in BASE.iterdir()}
    decoded={f:b.decode('utf8').replace('\r\n','\n').replace('\r','\n') for f,b in original.items()}
    files=dict(decoded); patches={}
    if features:
        module, path=feature_module(); registry=getattr(module,'FEATURES',{})
        for feature in features:
            require(not feature.startswith('_'), 'Invalid feature name')
            if not isinstance(registry,dict) and feature in registry and callable(getattr(module,'apply',None)):
                changed=module.apply(files,feature=feature)
            else:
                func=registry.get(feature,getattr(module,feature,None)) if isinstance(registry,dict) else getattr(module,feature,None)
                if isinstance(func,str):func=getattr(module,func)
                require(callable(func), 'Unknown feature: '+feature)
                changed=func(files)
            if changed is not None:
                require(isinstance(changed,dict),'Transform must mutate input or return a source dictionary')
                files=changed
        patches[path.name]=sha(path)
    require(files.keys()==original.keys(), 'Patch added or removed source files')
    payload={f:original[f] if text==decoded[f] else text.encode('utf8') for f,text in files.items()}
    materialize(name,BASE,payload,{'base_commit':BASE_COMMIT,'base_path':'bots/study27/src',
        'base_source_sha256':hashes(BASE),'features':list(features),'patch_modules_sha256':patches,'role':'candidate'})

def register_spar(name):
    require(name in SPARS,'Unknown sparring bot')
    source=REPO/'bots'/name/'src'; payload={f.name:f.read_bytes() for f in source.iterdir() if f.is_file()}
    materialize(name,source,payload,{'base_commit':SPAR_COMMIT,'base_path':f'bots/{name}/src',
        'base_source_sha256':hashes(source),'features':[],'patch_modules_sha256':{},'role':'sparring'})

def build(names, jobs=1):
    require(1<=jobs<=8,'Build concurrency must be 1..8')
    def one(name):
        valid_name(name); path=ROOT/'candidates'/f'{name}.json'
        with exclusive(ROOT/'locks'/f'build-{name}.lock'):
            record=read(path); source=ARENA/'bots'/name/'src'
            require(hashes(source)==record['source_sha256'], 'Source changed before build: '+name)
            log=guard(ROOT/'build-logs'/f'{name}.log'); log.parent.mkdir(exist_ok=True)
            with log.open('w',encoding='utf8') as out:
                result=subprocess.run([str(CLI),'build','bots/'+name],cwd=ARENA,env=ENV,stdout=out,stderr=subprocess.STDOUT,timeout=600)
            require(result.returncode==0,'Build failed '+name+': '+log.read_text(errors='replace')[-2200:])
            require(hashes(source)==record['source_sha256'], 'Source changed during build: '+name)
            wasm=guard(ARENA/'bots'/name/'.cambc/build/bot-injected.wasm'); digest=sha(wasm)
            require('wasm_sha256' not in record or record['wasm_sha256']==digest,'Immutable build changed: '+name)
            record.update(wasm_sha256=digest,cli_sha256=sha(CLI),project_config_sha256=sha(ARENA/'cambc.toml'),sdk_header_sha256=sha(ARENA/'sdk/cpp/cambc.h'))
            write(path,record); return name
    with ThreadPoolExecutor(max_workers=jobs) as pool:
        for future in as_completed([pool.submit(one,n) for n in names]): print('Built',future.result(),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('op',choices=['setup','register','build']);p.add_argument('names',nargs='*');p.add_argument('--features',default='');p.add_argument('--jobs',type=int,default=1)
    a=p.parse_args()
    if a.op=='setup':setup()
    elif a.op=='register':
        require(len(a.names)==1,'register needs one name');register(a.names[0],[f.strip() for f in a.features.split(',') if f.strip()])
    else:build(a.names,a.jobs)
