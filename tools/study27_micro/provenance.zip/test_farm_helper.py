"""Compile and execute the actual inserted C++ guard with narrow SDK stand-ins.

This proves branch/range/availability/action-order contracts, not tactical value;
the paired engine matches measure tactical value separately.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess
import patch_farm

HERE = Path(__file__).resolve().parent
COMPILER = Path("C:/Users/frans/AppData/Local/cambc/wasi-sdk-33/bin/clang++.exe")
NODE = Path("C:/Users/frans/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe")


def block(text: str, start: str) -> str:
    assert text.count(start) == 1
    begin = text.index(start)
    brace = text.index("{", begin)
    depth, end = 1, brace + 1
    while depth:
        depth += (text[end] == "{") - (text[end] == "}")
        end += 1
    return text[begin:end]


PREFIX = r'''
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <stdexcept>
#include <string>
#include <vector>
struct vec2 {
    int x=0,y=0;
    vec2()=default;
    vec2(int xx,int yy):x(xx),y(yy){}
    vec2 operator+(vec2 b) const {return {x+b.x,y+b.y};}
    bool operator==(vec2 b) const {return x==b.x && y==b.y;}
};
int dist(vec2 a,vec2 b) {return std::max(std::abs(a.x-b.x),std::abs(a.y-b.y));}
int self_health_reads=0;
namespace bc {
struct Ability {bool ready=false;bool is_ready() const {return ready;}};
struct champion {
    int id=0,ar=1;
    vec2 p{10,10};
    double hp=1000,mhp=1000,damage=100,spell=0;
    int spell_range=0,spell_cd=0;
    bool visible=true,alive=true,recall=false,teleport=false,submit=false;
    bool move=true,cast=true,bad=false,dash_ready=false;
    bool operator==(const champion& b) const {return id==b.id;}
    bool is_visible() const {return visible;}
    bool is_alive() const {return alive;}
    vec2 position() const {if(bad)throw std::runtime_error("hidden");return p;}
    double health() const {if(id==0)++self_health_reads;return hp;}
    double max_health() const {return mhp;}
    int attack_range() const {return ar;}
    bool is_recalling() const {return recall;}
    bool is_teleporting() const {return teleport;}
    bool is_submitting_gems() const {return submit;}
    bool can_move() const {return move;}
    bool can_cast() const {return cast;}
    std::array<Ability,2> abilities() const {return {Ability{dash_ready},Ability{false}};}
};
struct camp {vec2 p{11,10};vec2 position() const{return p;}};
namespace map {bool is_in_bounds(vec2 p) {return p.x>=0 && p.y>=0 && p.x<32 && p.y<32;}}
namespace vision {
std::vector<champion> allies;
const std::vector<champion>& champions(int) {return allies;}
}
}
template<class F> bool attempt(F f) {try{return f();}catch(...){return false;}}
int fuel_budget=40000,loop_checks=999;
bool fuel_ok(int n) {if(n==12000 && --loop_checks<0)return false;return fuel_budget>=n;}
struct Mask {
    std::vector<vec2> tiles;
    bool is_set(vec2 p) const {return std::find(tiles.begin(),tiles.end(),p)!=tiles.end();}
};
struct State {
    int farm_guard_checks=0,farm_guard_blocks=0,dash_slot=-1;
    Mask en_spawn,blocked;
    const int team=0;
    const int* my=&team;
};
constexpr int CAMP_RANGE=3;
'''

MIDDLE = r'''
// threat_of is an interface stand-in here. The guard and danger_at below are
// extracted from the real candidate/baseline source, not reimplemented tests.
Threat threat_of(bc::champion c,vec2 p,int ar) {
    Threat t;t.p=p;t.ar=ar;t.atk=c.damage;
    if(c.spell_cd==0 && c.spell>0) {t.xd=c.spell;t.xr=c.spell_range;}
    return t;
}
struct Foe {bc::champion c;vec2 p;float hp;int d;int gems;bool channeling;bool away=false;};
int camp_attacks=0,camp_casts=0,camp_moves=0,champ_hits=0,back_steps=0;
const char* g_farm="test";
namespace fight {
int reach(const Foe& f) {return f.c.attack_range()+1;}
void back_off(State&,bc::champion&,const std::vector<Foe>&,int) {++back_steps;++champ_hits;}
}
void shoot_back(State&,bc::champion&,const std::vector<Foe>&) {++champ_hits;}
void engage(State&,bc::champion&,const bc::camp&,vec2,bool,bool) {++camp_attacks;++camp_casts;++camp_moves;}
Foe foe(int id,int x,int y,double damage=100) {
    bc::champion c;c.id=id;c.p={x,y};c.damage=damage;
    return {c,c.p,1000.0f,dist(c.p,{10,10}),0,false};
}
void reset() {
    bc::vision::allies.clear();fuel_budget=40000;loop_checks=999;self_health_reads=0;
    camp_attacks=camp_casts=camp_moves=champ_hits=back_steps=0;g_farm="test";
}
'''

CASES = r'''
int main() {
    int checks=0;
    auto test=[&](bool result,const char* label) {if(!result)std::printf("FAIL %s\n",label);assert(result);++checks;};
    auto run=[&](std::vector<Foe> fs,double strength=0,bc::camp camp={},int dash=-1,bool ready=false) {
        State s;s.dash_slot=dash;bc::champion me;me.dash_ready=ready;
        return farm_under_threat(s,me,camp,strength,fs);
    };
    reset();test(!run({}),"no enemy");test(self_health_reads==0,"no extra self API without enemies");
    reset();test(!run({foe(1,25,25)}),"distant enemy does not pause farm");
    reset();auto two=std::vector<Foe>{foe(1,12,10),foe(2,12,11)};
    test(run(two),"outnumbered at live camp");test(self_health_reads==1,"one self-health read per check");
    reset();test(!run({foe(1,12,10)}),"equal healthy one-on-one low pressure");
    reset();test(run({foe(1,12,10,250)})==(@MODE@==3),"distinct 20 vs 35 percent thresholds");
    reset();test(run({foe(1,12,10,400)})==(@MODE@>=2),"ready volley threshold");
    reset();test(run({foe(1,12,10,150)},250)==(@MODE@>=2),"camp retaliation plus champion pressure");
    reset();bc::champion ally;ally.id=3;ally.p={11,9};ally.hp=ally.mhp=3000;bc::vision::allies={ally};
    test(!run(two),"near healthy support counters local outnumber");
    test(!run({foe(1,12,10,400)}),"strong support permits favourable farm");
    reset();ally.p={18,10};bc::vision::allies={ally};test(run(two),"distant ally HP is not support");
    reset();ally.p={11,9};ally.recall=true;bc::vision::allies={ally};test(run(two),"recalling ally unavailable");
    reset();ally.recall=false;ally.teleport=true;bc::vision::allies={ally};test(run(two),"teleporting ally unavailable");
    reset();ally.teleport=false;ally.submit=true;bc::vision::allies={ally};test(run(two),"tributary ally unavailable");
    reset();ally.submit=false;ally.hp=300;ally.mhp=1000;bc::vision::allies={ally};test(run(two),"wounded ally unavailable");
    reset();ally.hp=ally.mhp=3000;ally.p={17,10};ally.spell=200;ally.spell_range=5;ally.spell_cd=0;bc::vision::allies={ally};
    test(!run(two),"ready long spell can help");
    ally.spell_cd=1;bc::vision::allies={ally};test(run(two),"cooldown long spell cannot help");
    reset();auto recalling=two;for(auto& f:recalling)f.c.recall=true;test(!run(recalling),"channeling enemies not ready threats");
    reset();auto hidden=two;for(auto& f:hidden)f.c.visible=false;test(!run(hidden),"hidden handles excluded");
    reset();auto bad=two;for(auto& f:bad)f.c.bad=true;test(!run(bad),"unreadable enemy does not throw");
    reset();auto approach=std::vector<Foe>{foe(1,13,9),foe(2,13,11)};bc::camp cp;cp.p={13,10};
    test(run(approach,0,cp),"one-step advance exposure included");
    reset();cp.p={14,10};auto dashfoes=std::vector<Foe>{foe(1,15,9),foe(2,15,11)};
    test(!run(dashfoes,0,cp,0,false),"unready dash does not widen envelope");
    test(run(dashfoes,0,cp,0,true),"ready dash and follow-up step included");
    reset();State blocked;bc::champion me;cp.p={13,10};
    for(int dx=-1;dx<=1;++dx)for(int dy=-1;dy<=1;++dy)if(dx||dy)blocked.blocked.tiles.push_back({10+dx,10+dy});
    test(!farm_under_threat(blocked,me,cp,0,approach),"blocked forward landings excluded");
    reset();State spawn;for(auto& f:two)spawn.en_spawn.tiles.push_back(f.p);
    test(!farm_under_threat(spawn,me,bc::camp{},0,two),"enemy spawn excluded");
    reset();fuel_budget=21000;test(!run(two),"entry fuel reserve");test(self_health_reads==0,"fuel exit before SDK reads");
    reset();loop_checks=0;cp.p={13,10};test(!run(approach,0,cp),"envelope fuel exit preserves fail-open contract");
    reset();State state;dispatch(state,me,bc::camp{},two);
    test(camp_attacks==0 && camp_casts==0 && camp_moves==0,"guard before camp action costs");
    test(champ_hits==1 && back_steps==@BACKOFF@,"correct response only");
    test(state.farm_guard_blocks==1 && state.farm_guard_checks==1,"mechanism counters");
    reset();State quiet;dispatch(quiet,me,bc::camp{},{});
    test(camp_attacks==1 && camp_casts==1 && camp_moves==1,"unchanged engage when safe");
    test(champ_hits==0 && back_steps==0,"safe path adds no champion action");
    std::printf("actual farm helper: %d checks passed\n",checks);
}
'''


def main() -> None:
    source = {p.name:p.read_text() for p in (HERE / "baseline/src").iterdir() if p.is_file()}
    baseline = source["main.cpp"]
    threat_struct = block(baseline, "struct Threat {") + ";\n"
    danger = block(baseline, "inline double danger_at(")
    records = []
    for feature in patch_farm.GUARDS:
        variant = patch_farm.apply(source, feature)["main.cpp"]
        helper = block(variant, "bool farm_under_threat(")
        call = block(variant, "        if (farm_under_threat(")
        mode, response = feature.removeprefix("farm_").rsplit("_", 1)
        dispatch = ("void dispatch(State& s,bc::champion& me,const bc::camp& target,const std::vector<Foe>& foes) {\n"
                    "const bc::camp* tgt=&target;double str=0;int round=7;\n" + call +
                    "\nengage(s,me,*tgt,tgt->position(),false,true);\n}\n")
        code = (PREFIX + threat_struct + MIDDLE + danger + "\n" + helper + "\n" + dispatch +
                CASES.replace("@MODE@",str(patch_farm.MODES.index(mode)+1))
                .replace("@BACKOFF@",str(int(response == "backoff"))))
        cpp,wasm = HERE / f"fixture-{feature}.cpp",HERE / f"fixture-{feature}.wasm"
        cpp.write_text(code,newline="\n")
        proc = subprocess.run([str(COMPILER),"-std=c++20","-fwasm-exceptions","-O2",str(cpp),"-lunwind","-o",str(wasm)],capture_output=True,text=True)
        if proc.returncode:
            raise RuntimeError(proc.stderr)
        runner = HERE / f"fixture-{feature}.mjs"
        runner.write_text(f'''import fs from 'node:fs';
import {{WASI}} from 'node:wasi';
const wasi=new WASI({{version:'preview1',args:[],env:{{}},preopens:{{}}}});
const {{instance}}=await WebAssembly.instantiate(fs.readFileSync(new URL('./{wasm.name}',import.meta.url)),{{wasi_snapshot_preview1:wasi.wasiImport}});
wasi.start(instance);
''',newline="\n")
        proc=subprocess.run([str(NODE),str(runner)],capture_output=True,text=True)
        if proc.returncode:
            raise RuntimeError(proc.stdout+proc.stderr)
        records.append({"feature":feature,"stdout":proc.stdout.strip(),
                        "cpp_sha256":hashlib.sha256(cpp.read_bytes()).hexdigest()})
    out={"passed":True,"method":"Actual inserted C++ guard and dispatch, with actual baseline danger_at, WASI-compiled and executed using narrow SDK stand-ins. Full engine matches measure tactical value separately.",
         "patch_sha256":hashlib.sha256((HERE/"patch_farm.py").read_bytes()).hexdigest(),"cases":records}
    (HERE/"farm-helper-fixtures.json").write_text(json.dumps(out,indent=2)+"\n")
    print(json.dumps(out,indent=2))


if __name__ == "__main__":
    main()
