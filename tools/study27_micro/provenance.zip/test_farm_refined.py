"""Contracts and actual-inserted-C++ fixtures for refined development policies."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess
import patch_farm_refined as patch
import test_farm_helper as first

HERE=Path(__file__).resolve().parent
BASE=HERE/"baseline/src"


def section(text,start,end):
    return text.split(start,1)[1].split(end,1)[0]


def run_cpp(name,code):
    cpp,wasm=HERE/f"refined-fixture-{name}.cpp",HERE/f"refined-fixture-{name}.wasm"
    cpp.write_text(code,newline="\n")
    proc=subprocess.run([str(first.COMPILER),"-std=c++20","-fwasm-exceptions","-O2",str(cpp),"-lunwind","-o",str(wasm)],capture_output=True,text=True)
    if proc.returncode:raise RuntimeError(proc.stderr)
    runner=HERE/f"refined-fixture-{name}.mjs"
    runner.write_text(f'''import fs from 'node:fs';
import {{WASI}} from 'node:wasi';
const wasi=new WASI({{version:'preview1',args:[],env:{{}},preopens:{{}}}});
const {{instance}}=await WebAssembly.instantiate(fs.readFileSync(new URL('./{wasm.name}',import.meta.url)),{{wasi_snapshot_preview1:wasi.wasiImport}});
wasi.start(instance);
''',newline="\n")
    proc=subprocess.run([str(first.NODE),str(runner)],capture_output=True,text=True)
    if proc.returncode:raise RuntimeError(proc.stdout+proc.stderr)
    return {"fixture":name,"stdout":proc.stdout.strip(),"cpp_sha256":hashlib.sha256(cpp.read_bytes()).hexdigest()}


def main():
    base={p.name:p.read_text()for p in BASE.iterdir()if p.is_file()}
    before=dict(base)
    variants={name:patch.apply(base,name)for name in patch.FEATURES}
    assert base==before
    pin=json.loads((HERE/"baseline/manifest.json").read_text())["source_sha256"]
    assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in BASE.iterdir()if p.is_file()}==pin
    for name,v in variants.items():
        assert {k for k in base if base[k]!=v[k]}=={"main.cpp"}
        for start,end in (("bool other_captures(","void drop_target("),
                ("// Nothing of this group is visible alive.","// ---------------------------------------------------------------------------\n// One turn"),
                ("bool g_ally_near_tgt = false;","void support_spells("),
                ("    // 4. Recall to heal","    // 5. Bank gems."),
                ("template <class U>\nbool basic_attack(","bool g_ally_near_tgt = false;")):
            assert section(base["main.cpp"],start,end)==section(v["main.cpp"],start,end),(name,start)
        try:patch.apply(v,name)
        except ValueError:pass
        else:raise AssertionError("Repeated transform accepted: "+name)
    threat=first.block(base["main.cpp"],"struct Threat {")+";\n"
    danger=first.block(base["main.cpp"],"inline double danger_at(")
    records=[]
    for name in ("start_only_backoff","start_only_retarget"):
        text=variants[name]["main.cpp"]
        helper=first.block(text,"bool farm_under_threat(")
        call=first.block(text,"        if (!engaged && farm_under_threat(")
        extra=r'''
struct Group {int bad_until=0;};
int drops=0;
void drop_target(State&) {++drops;}
void dispatch(State& s,bc::champion& me,const bc::camp& camp,const std::vector<Foe>& foes,Group& g,bool engaged) {
    const bc::camp* tgt=&camp;double str=0;int round=7;
'''+call+r'''
    engage(s,me,*tgt,tgt->position(),false,true);
}
int main() {
    int checks=0;auto test=[&](bool p){assert(p);++checks;};
    reset();State s;bc::champion me;bc::camp c;Group g;
    const auto foes=std::vector<Foe>{foe(1,12,10),foe(2,12,11)};
    dispatch(s,me,c,foes,g,false);
    test(camp_attacks==0 && camp_casts==0 && camp_moves==0);
    test(back_steps==1 && champ_hits==1);
    test(s.farm_guard_checks==1 && s.farm_guard_blocks==1);
    test(drops==@RETARGET@ && g.bad_until==(@RETARGET@?15:0));
    reset();State injured;Group injured_group;drops=0;
    dispatch(injured,me,c,foes,injured_group,true);
    test(injured.farm_guard_checks==0 && injured.farm_guard_blocks==0);
    test(camp_attacks==1 && camp_casts==1 && camp_moves==1);
    test(back_steps==0 && champ_hits==0 && drops==0 && injured_group.bad_until==0);
    reset();State quiet;Group quiet_group;dispatch(quiet,me,c,{},quiet_group,false);
    test(camp_attacks==1 && camp_casts==1 && camp_moves==1);
    test(back_steps==0 && champ_hits==0 && quiet_group.bad_until==0);
    std::printf("actual start-only dispatch: %d checks passed\n",checks);
}
'''
        records.append(run_cpp(name,first.PREFIX+threat+first.MIDDLE+danger+helper+extra.replace("@RETARGET@",str(int(name=="start_only_retarget")))))

    source=variants["no_contact_dash"]["main.cpp"]
    helper=first.block(source,"bool farm_contact(")
    prefix=first.PREFIX.replace("int farm_guard_checks=0,farm_guard_blocks=0,dash_slot=-1;",
                              "int farm_guard_checks=0,farm_guard_blocks=0,dash_slot=-1;bool farm_preserve_cc=false;")
    middle=first.MIDDLE.replace("int camp_attacks=0,camp_casts=0,camp_moves=0,champ_hits=0,back_steps=0;",
                               "int camp_attacks=0,camp_casts=0,camp_moves=0,champ_hits=0,back_steps=0;bool last_dash=true;")
    middle=middle.replace("void engage(State&,bc::champion&,const bc::camp&,vec2,bool,bool) {++camp_attacks;++camp_casts;++camp_moves;}",
                          "void engage(State&,bc::champion&,const bc::camp&,vec2,bool,bool dash) {last_dash=dash;++camp_attacks;++camp_casts;++camp_moves;}")
    dispatches=[]
    for name in ("no_contact_dash","reserve_cc_contact5","reserve_cc_contact3"):
        text=variants[name]["main.cpp"]
        start=text.index("        // Preserve a dash near a healthy enemy;" if name=="no_contact_dash" else "        // Keep CC for current nearby enemy contact,")
        end=text.index("        return;",start)
        dispatches.append("void dispatch_"+name+"(State& s,bc::champion& me,const bc::camp& target,const std::vector<Foe>& foes) {\n"
                          "const bc::camp* tgt=&target;\n"+text[start:end]+"}\n")
    cc_line=next(line for line in variants["reserve_cc_contact5"]["main.cpp"].splitlines()if "if (!champ && s.farm_preserve_cc &&"in line)
    cases=r'''
struct FakeAbility {bool cc=false,fail=false;bool is_cc() const {if(fail)throw std::runtime_error("hidden");return cc;}};
bool gate(bool champ,bool preserve,bool cc,bool fail=false) {
    State s;s.farm_preserve_cc=preserve;FakeAbility ab{cc,fail};
    for(int k=0;k<1;++k) {
@GATE@
        return true;
    }
    return false;
}
int main() {
    int checks=0;auto test=[&](bool p){assert(p);++checks;};
    reset();State s;bc::champion me;bc::camp camp;
    test(!farm_contact(s,me,camp.p,{},6,5,true));
    auto enemy=foe(1,25,25);test(!farm_contact(s,me,camp.p,{enemy},6,5,true));
    enemy=foe(1,16,10);camp.p={25,10};test(farm_contact(s,me,camp.p,{enemy},6,5,true));
    enemy=foe(1,17,10);test(!farm_contact(s,me,camp.p,{enemy},6,5,true));
    camp.p={15,10};enemy=foe(1,20,10);test(farm_contact(s,me,camp.p,{enemy},6,5,true));
    enemy=foe(1,21,10);test(!farm_contact(s,me,camp.p,{enemy},6,5,true));
    camp.p={11,10};enemy=foe(1,13,10);enemy.c.recall=true;test(!farm_contact(s,me,camp.p,{enemy},6,5,true));
    enemy.c.recall=false;enemy.c.teleport=true;test(!farm_contact(s,me,camp.p,{enemy},6,5,true));
    enemy.c.teleport=false;enemy.c.submit=true;test(!farm_contact(s,me,camp.p,{enemy},6,5,true));
    enemy.c.submit=false;enemy.c.hp=349;test(!farm_contact(s,me,camp.p,{enemy},6,5,true));
    test(farm_contact(s,me,camp.p,{enemy},5,5));
    enemy.c.hp=350;test(farm_contact(s,me,camp.p,{enemy},6,5,true));
    enemy.c.visible=false;test(!farm_contact(s,me,camp.p,{enemy},6,5,true));
    enemy.c.visible=true;enemy.c.alive=false;test(!farm_contact(s,me,camp.p,{enemy},6,5,true));
    enemy.c.alive=true;enemy.c.bad=true;test(!farm_contact(s,me,camp.p,{enemy},6,5,true));
    enemy.c.bad=false;s.en_spawn.tiles.push_back(enemy.c.p);test(!farm_contact(s,me,camp.p,{enemy},6,5,true));
    reset();State dash;dash.dash_slot=0;enemy=foe(1,13,10);dispatch_no_contact_dash(dash,me,camp,{enemy});
    test(!last_dash && camp_attacks==1 && camp_casts==1 && camp_moves==1);
    reset();dispatch_no_contact_dash(dash,me,camp,{});test(last_dash && camp_attacks==1 && camp_casts==1);
    enemy.c.hp=100;dispatch_no_contact_dash(dash,me,camp,{enemy});test(last_dash);
    reset();State cc5;enemy=foe(1,16,10);dispatch_reserve_cc_contact5(cc5,me,camp,{enemy});
    test(cc5.farm_preserve_cc && last_dash && camp_attacks==1 && camp_casts==1 && camp_moves==1);
    State cc3;dispatch_reserve_cc_contact3(cc3,me,camp,{enemy});test(!cc3.farm_preserve_cc);
    test(!gate(false,true,true));test(gate(false,true,false));test(gate(false,false,true));
    test(gate(true,true,true));test(gate(true,true,false));test(gate(false,true,true,true));
    std::printf("actual contact helper/dispatch/CC gate: %d checks passed\n",checks);
}
'''
    records.append(run_cpp("contact",prefix+threat+middle+helper+"\n"+"\n".join(dispatches)+cases.replace("@GATE@",cc_line)))
    output={"passed":True,"source_contracts":len(patch.FEATURES),"base_unchanged":True,
            "method":"Actual inserted helpers and dispatch/gate blocks, WASI compiled and executed with narrow SDK stand-ins. No engine matches in this test.",
            "patch_sha256":hashlib.sha256((HERE/"patch_farm_refined.py").read_bytes()).hexdigest(),"fixtures":records}
    (HERE/"farm-refined-fixtures.json").write_text(json.dumps(output,indent=2)+"\n")
    print(json.dumps(output,indent=2))


if __name__=="__main__":main()
